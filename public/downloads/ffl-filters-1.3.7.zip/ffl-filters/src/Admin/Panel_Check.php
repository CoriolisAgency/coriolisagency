<?php
/**
 * Checks whether the filter panel shows on the Shop page (Welcome step 1).
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Admin;

defined( 'ABSPATH' ) || exit;

use FFL_Filters\Panel\Placement;

/**
 * Admin-side check only. The storefront never writes anything for this.
 */
class Panel_Check {

	/**
	 * Option set once the panel has been found.
	 *
	 * @var string
	 */
	const OPTION = 'fflf_panel_seen';

	/**
	 * Short cache of a failed check so the Welcome tab does not refetch on every load.
	 *
	 * @var string
	 */
	const TRANSIENT = 'fflf_panel_check';

	/**
	 * 1.3.7: short cache of the hidden-placement check (which saved placements the Shop page does not show).
	 *
	 * @var string
	 */
	const HIDDEN_TRANSIENT = 'fflf_placement_check';

	/**
	 * Shop page URL.
	 *
	 * @return string
	 */
	public function shop_url() {
		$url = function_exists( 'wc_get_page_permalink' ) ? (string) wc_get_page_permalink( 'shop' ) : '';
		if ( '' === $url ) {
			$url = home_url( '/' );
		}
		return $url;
	}

	/**
	 * Drop a cached "not found" so the next check fetches the Shop page again.
	 *
	 * @return void
	 */
	public function forget_failure() {
		delete_transient( self::TRANSIENT );
	}

	/**
	 * Drop the cached hidden-placement result so the next check reads the Shop page again.
	 *
	 * @return void
	 */
	public function forget_placement() {
		delete_transient( self::HIDDEN_TRANSIENT );
	}

	/**
	 * Saved placements outside the shop template: widget (a widget area that counts), content (the Shop page's content).
	 *
	 * @return array<int, string>
	 */
	public function saved_placements() {
		$saved = array();
		if ( Placement::in_widgets() ) {
			$saved[] = 'widget';
		}
		$shop_id = function_exists( 'wc_get_page_id' ) ? (int) wc_get_page_id( 'shop' ) : 0;
		$shop    = $shop_id > 0 ? get_post( $shop_id ) : null;
		if ( $shop instanceof \WP_Post && Placement::in_content( (string) $shop->post_content ) ) {
			$saved[] = 'content';
		}
		return $saved;
	}

	/**
	 * 1.3.7: which saved placements the Shop page does not show, best effort.
	 *
	 * Reads the Shop page as a visitor would. When a placed panel did not render there, the automatic panel that stood in
	 * for it carries data-fflf-standin (widget, content). No panel at all while a placement is saved counts as hidden too
	 * (automatic placement off). Nothing is written on the storefront for this.
	 *
	 * @param bool $allow_fetch Whether a loopback fetch may run now.
	 * @return string Space-separated widget / content, or empty when the placed panel shows, nothing is saved, or unknown.
	 */
	public function hidden_placement( $allow_fetch = true ) {
		/**
		 * Short-circuits the hidden-placement check. Return a string (widget, content, both space-separated, or empty).
		 *
		 * @since 1.3.7
		 * @param string|null $pre Null to run the normal check.
		 */
		$pre = apply_filters( 'fflf_pre_hidden_placement', null );
		if ( null !== $pre ) {
			return (string) $pre;
		}

		$saved = $this->saved_placements();
		if ( ! $saved ) {
			return '';
		}
		$key    = implode( ' ', $saved );
		$cached = get_transient( self::HIDDEN_TRANSIENT );
		if ( is_array( $cached ) && isset( $cached['key'], $cached['hidden'] ) && $key === $cached['key'] ) {
			return (string) $cached['hidden'];
		}
		if ( ! $allow_fetch ) {
			return '';
		}

		$response = wp_remote_get(
			$this->shop_url(),
			array(
				'timeout'     => 8,
				'redirection' => 3,
				'headers'     => array( 'Cache-Control' => 'no-cache' ),
			)
		);
		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return '';
		}
		$body = (string) wp_remote_retrieve_body( $response );

		$hidden = '';
		if ( preg_match( '/data-fflf-standin="([a-z ]+)"/', $body, $m ) ) {
			$hidden = trim( $m[1] );
		} elseif ( ! preg_match( '/<[a-z][^>]*\sdata-fflf-panel[\s>]/i', $body ) ) {
			// No panel element (the panel's assets may still be on the page, so not a plain string search).
			$hidden = $key;
		} else {
			update_option( self::OPTION, time(), false );
		}
		set_transient(
			self::HIDDEN_TRANSIENT,
			array(
				'key'    => $key,
				'hidden' => $hidden,
			),
			10 * MINUTE_IN_SECONDS
		);
		return $hidden;
	}

	/**
	 * Whether the panel has been found on the Shop page.
	 *
	 * @param bool $allow_fetch Whether a loopback fetch may run now.
	 * @return bool
	 */
	public function detected( $allow_fetch = true ) {
		/**
		 * Short-circuits the Welcome step 1 check. Return true or false to skip the Shop page fetch.
		 *
		 * @since 1.1.0
		 * @param bool|null $pre Null to run the normal check.
		 */
		$pre = apply_filters( 'fflf_pre_panel_detected', null );
		if ( null !== $pre ) {
			return (bool) $pre;
		}

		if ( get_option( self::OPTION ) ) {
			return true;
		}
		if ( ! $allow_fetch || false !== get_transient( self::TRANSIENT ) ) {
			return false;
		}

		$found    = false;
		$response = wp_remote_get(
			$this->shop_url(),
			array(
				'timeout'     => 8,
				'redirection' => 3,
				'headers'     => array( 'Cache-Control' => 'no-cache' ),
			)
		);
		if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
			$found = false !== strpos( (string) wp_remote_retrieve_body( $response ), 'data-fflf-panel' );
		}

		if ( $found ) {
			update_option( self::OPTION, time(), false );
			return true;
		}
		set_transient( self::TRANSIENT, 0, 10 * MINUTE_IN_SECONDS );
		return false;
	}
}
