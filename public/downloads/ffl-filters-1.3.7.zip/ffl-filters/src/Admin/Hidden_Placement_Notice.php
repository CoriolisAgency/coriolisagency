<?php
/**
 * Warns when the panel sits somewhere the shop pages don't show.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Admin;

defined( 'ABSPATH' ) || exit;

use FFL_Filters\Panel\Controller;
use FFL_Filters\Panel\Placement;

/**
 * 1.3.7: best-effort, generic. Panel_Check reads the Shop page as a visitor; when a placed panel did not render there
 * (a widget area the archive layout hides, or Shop page content the theme never prints), this says so on the Widgets
 * screen and on the Welcome tab. No theme is named or special-cased.
 */
class Hidden_Placement_Notice {

	/**
	 * Shop page check.
	 *
	 * @var Panel_Check
	 */
	private $check;

	/**
	 * Constructor.
	 *
	 * @param Panel_Check|null $check Shop page check.
	 */
	public function __construct( $check = null ) {
		$this->check = $check ? $check : new Panel_Check();
	}

	/**
	 * Hook the Widgets screen notice.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_notices', array( $this, 'render_on_widgets' ) );
	}

	/**
	 * On the Widgets screen only, for people who can manage FFL Filters.
	 *
	 * @return void
	 */
	public function render_on_widgets() {
		if ( ! Onboarding::user_can() ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || 'widgets' !== $screen->id ) {
			return;
		}
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- html() escapes its output.
		echo $this->html( $this->check->hidden_placement( true ), false );
	}

	/**
	 * Whether the automatic panel stands in when a placed panel does not render.
	 *
	 * @return bool
	 */
	public static function fallback_on() {
		return 'above_products' === Controller::current_placement() || Controller::auto_insert_enabled();
	}

	/**
	 * Names of the widget areas that hold the panel, joined for a sentence.
	 *
	 * @return string
	 */
	public function area_names() {
		global $wp_registered_sidebars;
		$names = array();
		foreach ( Placement::widget_areas() as $id ) {
			$names[] = is_array( $wp_registered_sidebars ) && isset( $wp_registered_sidebars[ $id ]['name'] ) ? (string) $wp_registered_sidebars[ $id ]['name'] : $id;
		}
		if ( ! $names ) {
			return __( 'a widget area', 'ffl-filters' );
		}
		return implode( ', ', $names );
	}

	/**
	 * Notice HTML for a hidden-placement result.
	 *
	 * @param string $hidden Space-separated widget / content (Panel_Check::hidden_placement()), or empty.
	 * @param bool   $inline Inline on a settings tab (true) or a screen notice (false).
	 * @return string
	 */
	public function html( $hidden, $inline ) {
		$parts = array_filter( explode( ' ', (string) $hidden ) );
		if ( ! $parts ) {
			return '';
		}

		$lines = array();
		if ( in_array( 'widget', $parts, true ) ) {
			$lines[] = sprintf(
				/* translators: %s: widget area names, for example Primary Sidebar */
				__( "The FFL Filters panel is in %s, but your shop pages don't show that widget area, so shoppers can't see the panel there.", 'ffl-filters' ),
				$this->area_names()
			);
		}
		if ( in_array( 'content', $parts, true ) ) {
			$lines[] = __( "The [ffl_filters] shortcode is in your Shop page's content, but your theme doesn't show that content on your shop pages.", 'ffl-filters' );
		}
		$lines[] = self::fallback_on()
			? __( 'FFL Filters shows the panel above your products instead.', 'ffl-filters' )
			: __( "Shoppers won't see any filters until you turn on Place the panel automatically.", 'ffl-filters' );
		if ( in_array( 'widget', $parts, true ) ) {
			$lines[] = __( "To show it in a sidebar, turn the sidebar on for shop pages in your theme's layout settings, or move the panel to a widget area your shop pages show.", 'ffl-filters' );
		}

		return '<div class="notice notice-warning' . ( $inline ? ' inline' : '' ) . ' fflf-hidden-placement" data-fflf-hidden-placement="' . esc_attr( implode( ' ', $parts ) ) . '"><p>' . esc_html( implode( ' ', $lines ) ) . '</p></div>';
	}
}
