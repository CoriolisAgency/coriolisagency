<?php
/**
 * Keeps exactly one panel on a product archive when a placed panel may or may not render.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Panel;

defined( 'ABSPATH' ) || exit;

/**
 * 1.3.7: a panel placed in a widget area or in the Shop page's content only counts when it actually renders.
 *
 * The widget and Shop page scans in Placement only say a panel is saved somewhere. Whether the theme prints that widget
 * area, or the Shop page's content, on this request is only known once it happens, and most classic themes print their
 * sidebar after the product loop (Storefront, Kadence and Astra all put the sidebar after the main column in the HTML).
 *
 * So when such a placement is saved, the automatic copy still prints at its usual spot, marked as provisional, inside a
 * page buffer opened on template_redirect. If a placed copy then renders in a widget area that counts (or in the page
 * content), the provisional copy is cut from the page before it is sent, and the store owner's placement is the only
 * panel. If no placed copy renders (a sidebar the archive layout hides, page content the theme never prints), the
 * provisional copy stays, marked data-fflf-standin, and is the only panel.
 *
 * Late-rendering sidebars are handled by that buffer: the decision is taken when the page is complete, not at
 * woocommerce_before_shop_loop. When the buffer is not there (another plugin closed it early, or output already went
 * out), the copy that printed first is kept and the later placed copy prints nothing, so a page never shows two panels.
 */
class Render_Guard {

	/**
	 * Start marker of a provisional automatic copy.
	 *
	 * @var string
	 */
	const START = '<!--fflf-provisional-->';

	/**
	 * End marker of a provisional automatic copy.
	 *
	 * @var string
	 */
	const END = '<!--/fflf-provisional-->';

	/**
	 * Start marker of the phone opener printed while a provisional copy is pending.
	 *
	 * @var string
	 */
	const OPENER_START = '<!--fflf-provisional-opener-->';

	/**
	 * End marker of that opener.
	 *
	 * @var string
	 */
	const OPENER_END = '<!--/fflf-provisional-opener-->';

	/**
	 * Whether the page buffer is open.
	 *
	 * @var bool
	 */
	private static $active = false;

	/**
	 * Output-buffer level of the page buffer.
	 *
	 * @var int
	 */
	private static $level = 0;

	/**
	 * Output held back by an early flush of the page buffer.
	 *
	 * @var string
	 */
	private static $held = '';

	/**
	 * Whether a provisional automatic copy has printed.
	 *
	 * @var bool
	 */
	private static $provisional = false;

	/**
	 * Whether that copy was the Above products panel (it set the body class).
	 *
	 * @var bool
	 */
	private static $provisional_above = false;

	/**
	 * Which saved placements the provisional copy stands in for (widget, content).
	 *
	 * @var string
	 */
	private static $sources = '';

	/**
	 * Panel counter before the provisional copy rendered, so a placed copy can take the same IDs.
	 *
	 * @var int
	 */
	private static $counter_before = 0;

	/**
	 * Whether a placed copy rendered after the provisional one (the provisional copy is cut).
	 *
	 * @var bool
	 */
	private static $placed_after = false;

	/**
	 * Whether the Above products body class went out before it was known which panel prints.
	 *
	 * @var bool
	 */
	private static $body_pending = false;

	/**
	 * Whether a placed copy (one that counts) rendered on this request.
	 *
	 * @var bool
	 */
	private static $placed_seen = false;

	/**
	 * Widget areas being printed right now (innermost last).
	 *
	 * @var array<int, string>
	 */
	private static $sidebars = array();

	/**
	 * Forget this request's state (tests, or a new sub-request). Does not close a buffer.
	 *
	 * @return void
	 */
	public static function reset() {
		self::$active            = false;
		self::$level             = 0;
		self::$held              = '';
		self::$provisional       = false;
		self::$provisional_above = false;
		self::$sources           = '';
		self::$counter_before    = 0;
		self::$placed_after      = false;
		self::$body_pending      = false;
		self::$placed_seen       = false;
		self::$sidebars          = array();
	}

	/**
	 * The Above products body class was added while a saved placement may still render (the body tag comes first).
	 * It stays only if the provisional Above products panel stays.
	 *
	 * @return void
	 */
	public static function body_class_pending() {
		self::$body_pending = true;
	}

	/**
	 * Open the page buffer (once per request).
	 *
	 * @return bool Whether the buffer is open.
	 */
	public static function start() {
		if ( self::is_active() ) {
			return true;
		}
		if ( ! ob_start( array( __CLASS__, 'handle' ) ) ) {
			return false;
		}
		self::$active = true;
		self::$level  = ob_get_level();
		self::$held   = '';
		return true;
	}

	/**
	 * Whether the page buffer is still open, so a provisional copy can still be cut.
	 *
	 * @return bool
	 */
	public static function is_active() {
		return self::$active && self::$level > 0 && ob_get_level() >= self::$level;
	}

	/**
	 * A widget area starts printing (dynamic_sidebar_before).
	 *
	 * @param int|string $index Widget area id.
	 * @return void
	 */
	public static function enter_sidebar( $index ) {
		self::$sidebars[] = (string) $index;
	}

	/**
	 * A widget area finished printing (dynamic_sidebar_after).
	 *
	 * @return void
	 */
	public static function leave_sidebar() {
		array_pop( self::$sidebars );
	}

	/**
	 * Widget area being printed right now, or an empty string.
	 *
	 * @return string
	 */
	public static function current_sidebar() {
		$count = count( self::$sidebars );
		return $count ? self::$sidebars[ $count - 1 ] : '';
	}

	/**
	 * Mark an automatic copy as provisional.
	 *
	 * @param string $html           Panel HTML.
	 * @param bool   $above          Whether it is the Above products panel.
	 * @param string $sources        Saved placements it stands in for (space-separated: widget, content).
	 * @param int    $counter_before Renderer counter before it rendered.
	 * @return string
	 */
	public static function wrap( $html, $above, $sources, $counter_before ) {
		$html = (string) $html;
		if ( '' === $html ) {
			return '';
		}
		self::$provisional       = true;
		self::$provisional_above = (bool) $above;
		self::$sources           = (string) $sources;
		self::$counter_before    = (int) $counter_before;
		return self::START . $html . self::END;
	}

	/**
	 * Mark the phone opener printed while the page buffer is open. It opens a placed panel's drawer, so it is kept only if
	 * a placed copy renders (otherwise it would open nothing, for example with automatic placement off).
	 *
	 * @param string $html Opener HTML.
	 * @return string
	 */
	public static function wrap_opener( $html ) {
		$html = (string) $html;
		if ( '' === $html || ! ( self::is_active() || self::$provisional ) ) {
			return $html;
		}
		return self::OPENER_START . $html . self::OPENER_END;
	}

	/**
	 * A placed copy that counts rendered (its phone opener is kept).
	 *
	 * @return void
	 */
	public static function placed_seen() {
		self::$placed_seen = true;
	}

	/**
	 * Whether a provisional copy has printed this request.
	 *
	 * @return bool
	 */
	public static function provisional_pending() {
		return self::$provisional;
	}

	/**
	 * Whether the provisional copy will be cut (a placed copy rendered after it).
	 *
	 * @return bool
	 */
	public static function placed_after() {
		return self::$placed_after;
	}

	/**
	 * A placed copy rendered after the provisional copy: cut the provisional copy when the page is sent.
	 *
	 * @return int Renderer counter the placed copy should start from (same IDs as the copy it replaces).
	 */
	public static function placed_rendered() {
		self::$placed_after = true;
		return self::$counter_before;
	}

	/**
	 * Output handler for the page buffer.
	 *
	 * An early flush is held back (the decision needs the whole page). A clean drops the current contents. The final call
	 * resolves and sends what is held.
	 *
	 * @param string $buffer Buffer contents.
	 * @param int    $phase  PHP_OUTPUT_HANDLER_* flags.
	 * @return string
	 */
	public static function handle( $buffer, $phase ) {
		// A clean drops only the current contents; anything held from an earlier flush was already output.
		if ( ! ( $phase & PHP_OUTPUT_HANDLER_CLEAN ) ) {
			self::$held .= (string) $buffer;
		}
		if ( $phase & PHP_OUTPUT_HANDLER_FINAL ) {
			self::$active = false;
			$out          = self::resolve( self::$held );
			self::$held   = '';
			return $out;
		}
		return '';
	}

	/**
	 * Apply the decision to a complete page (or to a page captured for fragments).
	 *
	 * @param string $html Page HTML.
	 * @return string
	 */
	public static function resolve( $html ) {
		$html = (string) $html;
		if ( false === strpos( $html, '<!--fflf-provisional' ) && ! self::$body_pending ) {
			return $html;
		}
		$cut  = self::$placed_after;
		$keep = $cut || self::$placed_seen;

		$html = self::each_segment(
			$html,
			self::START,
			self::END,
			function ( $inner ) use ( $cut ) {
				return $cut ? '' : Render_Guard::mark_standin( $inner );
			}
		);
		$html = self::each_segment(
			$html,
			self::OPENER_START,
			self::OPENER_END,
			function ( $inner ) use ( $keep ) {
				return $keep ? $inner : '';
			}
		);

		// The body class belongs to the Above products panel: drop it when that panel is cut, or when it went out early
		// and a placed panel printed instead (for example Shop page content printed before the products).
		$kept_above = self::$provisional && self::$provisional_above && ! $cut;
		if ( ( $cut && self::$provisional_above ) || ( self::$body_pending && ! $kept_above ) ) {
			$html = self::drop_body_class( $html, 'fflf-above-products' );
		}
		return $html;
	}

	/**
	 * Add data-fflf-standin to a provisional panel that stays (the saved placement did not render).
	 *
	 * @param string $html Panel HTML.
	 * @return string
	 */
	public static function mark_standin( $html ) {
		$sources = '' !== self::$sources ? self::$sources : 'placement';
		return (string) preg_replace( '/ data-fflf-panel(?=[\s>])/', ' data-fflf-panel data-fflf-standin="' . esc_attr( $sources ) . '"', (string) $html, 1 );
	}

	/**
	 * Replace every marked segment through a callback (string search, no regex over the page).
	 *
	 * @param string   $html     Page HTML.
	 * @param string   $start    Start marker.
	 * @param string   $end      End marker.
	 * @param callable $callback Receives the inner HTML, returns the replacement.
	 * @return string
	 */
	private static function each_segment( $html, $start, $end, $callback ) {
		$out    = '';
		$offset = 0;
		while ( false !== ( $from = strpos( $html, $start, $offset ) ) ) { // phpcs:ignore Generic.CodeAnalysis.AssignmentInCondition.FoundInWhileCondition
			$to = strpos( $html, $end, $from + strlen( $start ) );
			if ( false === $to ) {
				break;
			}
			$out   .= substr( $html, $offset, $from - $offset );
			$out   .= (string) call_user_func( $callback, substr( $html, $from + strlen( $start ), $to - $from - strlen( $start ) ) );
			$offset = $to + strlen( $end );
		}
		return $out . substr( $html, $offset );
	}

	/**
	 * Remove one class from the <body> tag.
	 *
	 * @param string $html  Page HTML.
	 * @param string $name  Class name.
	 * @return string
	 */
	private static function drop_body_class( $html, $name ) {
		return (string) preg_replace_callback(
			'/<body\b[^>]*>/i',
			function ( $m ) use ( $name ) {
				return (string) preg_replace_callback(
					'/\bclass=(["\'])(.*?)\1/i',
					function ( $c ) use ( $name ) {
						$list = preg_split( '/\s+/', trim( $c[2] ) );
						$list = array_values( array_diff( is_array( $list ) ? $list : array(), array( $name ) ) );
						return 'class=' . $c[1] . implode( ' ', $list ) . $c[1];
					},
					$m[0],
					1
				);
			},
			$html,
			1
		);
	}
}
