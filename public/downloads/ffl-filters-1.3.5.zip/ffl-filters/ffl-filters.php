<?php
/**
 * Plugin Name:       FFL Filters
 * Description:       Faceted product filters for WooCommerce store catalogs.
 * Version:           1.3.5
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * Requires Plugins:  woocommerce
 * WC requires at least: 9.2
 * WC tested up to:   11.2
 * Author:            Coriolis Agency
 * Author URI:        https://coriolisagency.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ffl-filters
 * Domain Path:       /languages
 *
 * @package FFL_Filters
 */

defined( 'ABSPATH' ) || exit;

define( 'FFLF_VERSION', '1.3.5' );
define( 'FFLF_FILE', __FILE__ );
define( 'FFLF_BASENAME', plugin_basename( __FILE__ ) );
define( 'FFLF_DIR', plugin_dir_path( __FILE__ ) );
define( 'FFLF_URL', plugin_dir_url( __FILE__ ) );

if ( is_readable( FFLF_DIR . 'vendor/autoload.php' ) ) {
	require_once FFLF_DIR . 'vendor/autoload.php';
} else {
	require_once FFLF_DIR . 'src/Autoloader.php';
	\FFL_Filters\Autoloader::register();
}

register_activation_hook( __FILE__, array( \FFL_Filters\Admin\Onboarding::class, 'on_activation' ) );

/**
 * Whether a request has any effective FFL Filters params.
 *
 * Empty values are stripped first, so this is the single has-filters
 * function used for query application, 301 normalization, and DONOTCACHE.
 *
 * @param array|null $source Optional request array. Defaults to unslashed $_GET.
 * @return bool
 */
function fflf_request_has_filters( $source = null ) {
	if ( ! is_array( $source ) ) {
		$source = wp_unslash( $_GET ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}

	return ( new \FFL_Filters\Query\Request_Parser() )->parse( $source )->has_filters();
}

/**
 * Return the filter panel HTML.
 *
 * @param array $args Optional args (source, result_count).
 * @return string
 */
function fflf_get_filters( $args = array() ) {
	$controller = \FFL_Filters\Panel\Controller::instance();
	if ( ! $controller ) {
		return '';
	}

	return $controller->render( is_array( $args ) ? $args : array() );
}

/**
 * Print the filter panel.
 *
 * @param array $args Optional args (source, result_count).
 * @return void
 */
function fflf_the_filters( $args = array() ) {
	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Renderer escapes its output.
	echo fflf_get_filters( $args );
}

/**
 * Whether Coriolis Product Filters is active (black-box coexistence).
 *
 * Used so FFL Filters can stay passive: no [coriolis_filters] alias, and the
 * [ffl_filters] shortcode and panel block render only an admin-visible placeholder.
 *
 * @return bool
 */
function fflf_compare_plugin_is_active() {
	if ( defined( 'CPF_VERSION' ) ) {
		return true;
	}
	if ( ! function_exists( 'get_option' ) ) {
		return false;
	}

	$plugins = (array) get_option( 'active_plugins', array() );
	foreach ( $plugins as $plugin ) {
		if ( 0 === strpos( (string) $plugin, 'coriolis-product-filters' ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Whether FFL Filters should stay passive on this request.
 *
 * CPF still owns the storefront unless this admin has preview enabled.
 *
 * @return bool
 */
function fflf_is_passive() {
	if ( ! fflf_compare_plugin_is_active() ) {
		return false;
	}
	if ( class_exists( '\FFL_Filters\Import\Preview' ) ) {
		$preview = new \FFL_Filters\Import\Preview();
		if ( $preview->is_active() ) {
			return false;
		}
	}
	return true;
}

/**
 * Declare compatibility with WooCommerce features.
 *
 * @return void
 */
function fflf_declare_feature_compatibility() {
	if ( ! class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		return;
	}

	\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', FFLF_FILE, true );
	\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', FFLF_FILE, true );
}
add_action( 'before_woocommerce_init', 'fflf_declare_feature_compatibility' );

/**
 * Boot the plugin, or show a notice when WooCommerce is missing.
 *
 * @return void
 */
function fflf_bootstrap() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		( new \FFL_Filters\Admin\Missing_WooCommerce_Notice() )->register();
		return;
	}

	( new \FFL_Filters\Plugin() )->init();
}
add_action( 'plugins_loaded', 'fflf_bootstrap' );
