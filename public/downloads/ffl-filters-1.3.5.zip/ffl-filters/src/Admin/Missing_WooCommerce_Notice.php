<?php
/**
 * Admin notice when WooCommerce is not active.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Admin;

/**
 * Shows one dismissible notice when the WooCommerce dependency is missing.
 */
class Missing_WooCommerce_Notice {

	/**
	 * Hook the notice.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_notices', array( $this, 'render' ) );
	}

	/**
	 * Print the notice.
	 *
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		echo '<div class="notice notice-error is-dismissible"><p>';
		echo esc_html__( 'FFL Filters needs WooCommerce to be installed and active.', 'ffl-filters' );
		echo '</p></div>';
	}
}
