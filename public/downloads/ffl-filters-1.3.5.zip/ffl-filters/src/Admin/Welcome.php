<?php
/**
 * Welcome tab: three-step setup, old filter plugin notice, help card and the slim contact form.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Admin;

use FFL_Filters\Panel\Placement;
use FFL_Filters\Settings\Repository;

defined( 'ABSPATH' ) || exit;

/**
 * Renders the Welcome tab and handles its forms.
 */
class Welcome {

	/**
	 * Sidebar name for the notice after Undo (the placement record is gone by then).
	 *
	 * @var string
	 */
	const UNDONE_TRANSIENT = 'fflf_sidebar_undone_name';

	/**
	 * Settings repository.
	 *
	 * @var Repository
	 */
	private $repository;

	/**
	 * Sidebar placer.
	 *
	 * @var Sidebar_Placer
	 */
	private $placer;

	/**
	 * Panel check.
	 *
	 * @var Panel_Check
	 */
	private $check;

	/**
	 * Constructor.
	 *
	 * @param Repository|null     $repository Settings.
	 * @param Sidebar_Placer|null $placer     Placer.
	 * @param Panel_Check|null    $check      Step 1 check.
	 */
	public function __construct( $repository = null, $placer = null, $check = null ) {
		$this->repository = $repository ? $repository : new Repository();
		$this->placer     = $placer ? $placer : new Sidebar_Placer();
		$this->check      = $check ? $check : new Panel_Check();
	}

	/**
	 * Hook admin-post handlers.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_post_fflf_welcome_filters', array( $this, 'handle_filters' ) );
		add_action( 'admin_post_fflf_add_sidebar', array( $this, 'handle_add_sidebar' ) );
		add_action( 'admin_post_fflf_undo_sidebar', array( $this, 'handle_undo_sidebar' ) );
	}

	/**
	 * Whether the current user may change settings.
	 *
	 * @return bool
	 */
	private function user_can() {
		return Onboarding::user_can();
	}

	/**
	 * Capability + nonce gate for every Welcome form.
	 *
	 * @param string $action Nonce action.
	 * @return void
	 */
	private function assert_post( $action ) {
		if ( ! $this->user_can() ) {
			wp_die( esc_html__( 'You do not have permission to manage FFL Filters.', 'ffl-filters' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( $action, 'fflf_nonce' );
	}

	/**
	 * Back to the Welcome tab.
	 *
	 * @param string $notice Notice code.
	 * @param string $anchor Optional fragment.
	 * @return void
	 */
	private function back( $notice, $anchor = '' ) {
		$url = add_query_arg( 'fflf_notice', $notice, Onboarding::welcome_url() );
		if ( '' !== $anchor ) {
			$url .= '#' . $anchor;
		}
		wp_safe_redirect( $url );
		exit;
	}

	/**
	 * Merged caliber backing taxonomies (hidden from the filter lists while the merge is on).
	 *
	 * @return array<int, string>
	 */
	public static function merged_backing_ids() {
		$config = new \FFL_Filters\Presets\Config();
		if ( ! $config->caliber_enabled() ) {
			return array();
		}
		return array_values( array_map( 'strval', $config->caliber_taxonomies() ) );
	}

	/**
	 * Settings rows shown as switches on step 2, in saved order.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public function step_two_rows() {
		$all    = $this->repository->all();
		$rows   = isset( $all['facets'] ) && is_array( $all['facets'] ) ? $all['facets'] : array();
		$hidden = self::merged_backing_ids();
		$out    = array();
		foreach ( $rows as $id => $row ) {
			if ( ! is_array( $row ) || in_array( (string) $id, $hidden, true ) ) {
				continue;
			}
			$out[ (string) $id ] = $row;
		}
		uasort(
			$out,
			static function ( $a, $b ) {
				$ao = isset( $a['order'] ) ? (int) $a['order'] : 0;
				$bo = isset( $b['order'] ) ? (int) $b['order'] : 0;
				return $ao <=> $bo;
			}
		);
		return $out;
	}

	/**
	 * Friendly label for a row.
	 *
	 * @param string               $id  Facet id.
	 * @param array<string, mixed> $row Row.
	 * @return string
	 */
	public static function row_label( $id, $row ) {
		$label = isset( $row['label'] ) ? (string) $row['label'] : '';
		if ( '' !== $label ) {
			return $label;
		}
		$config = new \FFL_Filters\Presets\Config();
		$fixed  = array(
			\FFL_Filters\Presets\Defaults::CALIBER_ID => $config->caliber_label(),
			'instore'                                 => $config->instore_label(),
			'instock'                                 => __( 'In stock', 'ffl-filters' ),
			'price'                                   => __( 'Price', 'ffl-filters' ),
		);
		if ( isset( $fixed[ $id ] ) ) {
			return (string) $fixed[ $id ];
		}
		if ( $config->is_firearm_type_taxonomy( $id ) ) {
			return $config->firearm_type_label();
		}
		if ( 0 === strpos( $id, 'pa_' ) && function_exists( 'wc_attribute_label' ) ) {
			return (string) wc_attribute_label( $id );
		}
		$tax = function_exists( 'get_taxonomy' ) ? get_taxonomy( $id ) : null;
		if ( $tax && isset( $tax->labels->singular_name ) ) {
			return (string) $tax->labels->singular_name;
		}
		return ucwords( str_replace( array( 'pa_', '_', '-' ), array( '', ' ', ' ' ), $id ) );
	}

	/**
	 * Step 2 names, with the source added when two filters share a name
	 * (for example WooCommerce Brands and a Brand attribute).
	 *
	 * @param array<string, array<string, mixed>> $rows Rows by id.
	 * @return array<string, string>
	 */
	public static function distinct_labels( $rows ) {
		$labels = array();
		$seen   = array();
		foreach ( $rows as $id => $row ) {
			$label                  = self::row_label( (string) $id, is_array( $row ) ? $row : array() );
			$labels[ (string) $id ] = $label;
			$key                    = strtolower( trim( $label ) );
			$seen[ $key ]           = isset( $seen[ $key ] ) ? $seen[ $key ] + 1 : 1;
		}
		foreach ( $labels as $id => $label ) {
			if ( $seen[ strtolower( trim( $label ) ) ] < 2 ) {
				continue;
			}
			if ( 'product_cat' === $id ) {
				/* translators: %s: filter name */
				$labels[ $id ] = sprintf( __( '%s (from product categories)', 'ffl-filters' ), $label );
				continue;
			}
			if ( 'product_tag' === $id ) {
				/* translators: %s: filter name */
				$labels[ $id ] = sprintf( __( '%s (from product tags)', 'ffl-filters' ), $label );
				continue;
			}
			$source = self::source_label( $id );
			if ( '' !== $source ) {
				/* translators: 1: filter name, 2: where its values come from */
				$labels[ $id ] = sprintf( __( '%1$s (%2$s)', 'ffl-filters' ), $label, $source );
			}
		}
		return $labels;
	}

	/**
	 * Where a filter's values come from, used only to tell same-named filters apart.
	 *
	 * @param string $id Filter id.
	 * @return string
	 */
	public static function source_label( $id ) {
		$sources = array(
			'product_brand' => __( 'WooCommerce Brands', 'ffl-filters' ),
		);
		if ( isset( $sources[ $id ] ) ) {
			return $sources[ $id ];
		}
		if ( 0 === strpos( $id, 'pa_' ) ) {
			return __( 'from a product attribute', 'ffl-filters' );
		}
		return '';
	}

	/**
	 * Hint under a step 2 switch (COPY.md, step 2 table).
	 *
	 * @param string $id Facet id.
	 * @return string
	 */
	public function hint( $id ) {
		$hints = array(
			\FFL_Filters\Presets\Defaults::CALIBER_ID => __( '9mm, 9x19 and 9mm Luger shown as one choice', 'ffl-filters' ),
			'product_brand'                           => __( 'Long list, with a search box', 'ffl-filters' ),
			'price'                                   => __( 'Min and max boxes', 'ffl-filters' ),
			'instock'                                 => __( 'One checkbox', 'ffl-filters' ),
			'instore'                                 => __( 'One checkbox', 'ffl-filters' ),
			'product_cat'                             => __( 'Handguns, rifles, ammo and more', 'ffl-filters' ),
		);
		if ( isset( $hints[ $id ] ) ) {
			return $hints[ $id ];
		}
		$numeric = ( new \FFL_Filters\Presets\Config() )->numeric();
		if ( $numeric->is_range_taxonomy( $id ) ) {
			return __( 'Shown as a range', 'ffl-filters' );
		}
		return '';
	}

	/**
	 * Step completion.
	 *
	 * @param bool $allow_fetch Whether step 1 may fetch the Shop page.
	 * @return array{1: bool, 2: bool, 3: bool}
	 */
	public function steps( $allow_fetch = true ) {
		$all = $this->repository->all();
		return array(
			1 => $this->check->detected( $allow_fetch ),
			2 => ! empty( $all['wizard']['completed'] ),
			3 => $this->sidebar_done(),
		);
	}

	/**
	 * Whether the panel has been placed by hand (widget area or shop template).
	 *
	 * @return bool
	 */
	public function sidebar_done() {
		if ( Placement::in_widgets() ) {
			return true;
		}
		if ( Sidebar_Placer::is_block_theme() && function_exists( 'get_block_template' ) && function_exists( 'get_stylesheet' ) ) {
			foreach ( array( 'archive-product', 'product-catalog' ) as $slug ) {
				$template = get_block_template( get_stylesheet() . '//' . $slug, 'wp_template' );
				if ( $template && Placement::in_content( (string) $template->content ) ) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Whether automatic placement is on (Display tab).
	 *
	 * @return bool
	 */
	public function auto_insert_on() {
		$all = $this->repository->all();
		return ! isset( $all['display']['auto_insert'] ) || ! empty( $all['display']['auto_insert'] );
	}

	/**
	 * One line naming where the panel is placed.
	 *
	 * @return string
	 */
	public function placement_text() {
		// The scans cannot tell the block, a widget and the shortcode apart, so one line covers all three.
		if ( $this->sidebar_done() ) {
			return __( 'Placement: you placed it with the FFL Filters block, a widget or the [ffl_filters] shortcode', 'ffl-filters' );
		}
		if ( $this->auto_insert_on() ) {
			return __( 'Placement: automatic, in your shop sidebar or above your products', 'ffl-filters' );
		}
		return __( "Placement: off, and the panel isn't placed anywhere", 'ffl-filters' );
	}

	/**
	 * Warn when automatic placement is off and no manual placement was found.
	 *
	 * @return void
	 */
	public function render_placement_warning() {
		if ( $this->auto_insert_on() || $this->sidebar_done() || $this->check->detected( false ) ) {
			return;
		}
		$display = admin_url( 'admin.php?page=' . Page::SLUG . '&tab=display' );
		echo '<div class="notice notice-warning inline fflf-placement-warning"><p>';
		echo esc_html__( "Shoppers won't see any filters right now. Turn on Place the panel automatically, or add the FFL Filters block or the [ffl_filters] shortcode to your shop sidebar.", 'ffl-filters' ) . ' ';
		echo '<a href="' . esc_url( $display ) . '">' . esc_html__( 'Place the panel automatically', 'ffl-filters' ) . '</a>';
		echo '</p></div>';
	}

	/**
	 * Render the whole tab.
	 *
	 * @param string $notice Current notice code.
	 * @return void
	 */
	public function render( $notice = '' ) {
		$this->render_sidebar_notice( $notice );
		$this->render_conflicts();
		// Re-check the Shop page on every visit until the panel is found, so a manual placement ticks step 1 too.
		$this->check->forget_failure();
		$this->render_placement_warning();

		$steps   = $this->steps();
		$done    = count( array_filter( $steps ) );
		$current = 3;
		foreach ( $steps as $n => $ok ) {
			if ( ! $ok ) {
				$current = (int) $n;
				break;
			}
		}

		echo '<div class="fflf-welcome">';
		echo '<div class="fflf-welcome__main fflf-card">';
		echo '<h1 class="fflf-welcome__title">' . esc_html__( 'Welcome to FFL Filters', 'ffl-filters' ) . '</h1>';
		echo '<p class="fflf-welcome__lede">' . esc_html__( "Work through the three steps below and your shoppers can narrow your catalog by caliber, brand, price and what's in stock, right from your shop page. You can come back to this tab any time, and it opens again after each update so you can see what changed.", 'ffl-filters' ) . '</p>';

		$pct = (int) round( ( $done / 3 ) * 100 );
		echo '<div class="fflf-progress">';
		/* translators: %d: current step number */
		echo '<span class="fflf-progress__label">' . esc_html( sprintf( __( 'Step %d of 3', 'ffl-filters' ), $current ) ) . '</span>';
		echo '<span class="fflf-progress__bar" role="progressbar" aria-valuemin="0" aria-valuemax="3" aria-valuenow="' . esc_attr( (string) $done ) . '"><i style="width:' . esc_attr( (string) $pct ) . '%"></i></span>';
		/* translators: %d: number of finished steps */
		echo '<span class="fflf-progress__count">' . esc_html( sprintf( __( '%d of 3 done', 'ffl-filters' ), $done ) ) . '</span>';
		echo '</div>';

		$names = array(
			1 => __( 'Showing on your shop', 'ffl-filters' ),
			2 => __( 'Pick your filters', 'ffl-filters' ),
			3 => __( 'Put it in your sidebar', 'ffl-filters' ),
		);
		echo '<ol class="fflf-stepbar">';
		foreach ( $names as $n => $name ) {
			$state = $steps[ $n ] ? 'done' : ( $n === $current ? 'now' : 'next' );
			echo '<li class="fflf-stepbar__item is-' . esc_attr( $state ) . '"' . ( 'now' === $state ? ' aria-current="step"' : '' ) . '>';
			echo '<span class="fflf-dot" aria-hidden="true">' . ( $steps[ $n ] ? '&#10003;' : esc_html( (string) $n ) ) . '</span>' . esc_html( $name ) . '</li>';
		}
		echo '</ol>';

		$this->render_step_one( $steps[1], $current );
		$this->render_step_two( $steps[2], $current );
		$this->render_step_three( $steps[3], $current );
		echo '</div>';

		echo '<aside class="fflf-welcome__aside">';
		$this->render_help_card();
		$this->render_contact_card();
		echo '</aside>';
		echo '</div>';
	}

	/**
	 * Step state badge.
	 *
	 * @param bool $done    Done.
	 * @param int  $n       Step number.
	 * @param int  $current Current step.
	 * @return string
	 */
	private function state( $done, $n, $current ) {
		if ( $done ) {
			return 'done';
		}
		return $n === $current ? 'now' : 'next';
	}

	/**
	 * Open a step card.
	 *
	 * @param int    $n       Step number.
	 * @param string $state   done|now|next.
	 * @param string $heading Heading.
	 * @param string $extra   Extra badge text (optional).
	 * @param string $state_text State badge text instead of the default (optional).
	 * @return void
	 */
	private function open_step( $n, $state, $heading, $extra = '', $state_text = '' ) {
		$badges = array(
			'done' => __( 'Done', 'ffl-filters' ),
			'now'  => __( 'You are here', 'ffl-filters' ),
			'next' => __( 'Next', 'ffl-filters' ),
		);
		echo '<section class="fflf-step is-' . esc_attr( $state ) . '" id="fflf-step-' . esc_attr( (string) $n ) . '">';
		echo '<div class="fflf-step__top"><span class="fflf-dot" aria-hidden="true">' . ( 'done' === $state ? '&#10003;' : esc_html( (string) $n ) ) . '</span>';
		echo '<h2>' . esc_html( $heading ) . '</h2>';
		if ( '' !== $extra ) {
			echo '<span class="fflf-badge">' . esc_html( $extra ) . '</span>';
		}
		echo '<span class="fflf-step__state">' . esc_html( '' !== $state_text ? $state_text : $badges[ $state ] ) . '</span></div>';
		echo '<div class="fflf-step__body">';
	}

	/**
	 * Step 1.
	 *
	 * @param bool $done    Done.
	 * @param int  $current Current.
	 * @return void
	 */
	private function render_step_one( $done, $current ) {
		if ( $done ) {
			$this->open_step( 1, 'done', __( '1. FFL Filters is showing on your shop', 'ffl-filters' ) );
			echo '<p>' . esc_html__( "FFL Filters checks your Shop page on its own and ticks this step when it finds the filter panel there, so there's nothing for you to do here. View your shop in a new tab if you'd like to see how it looks with your theme.", 'ffl-filters' ) . '</p>';
		} else {
			$this->open_step( 1, $this->state( $done, 1, $current ), __( "1. FFL Filters isn't showing on your shop yet", 'ffl-filters' ), '', __( 'Not found yet', 'ffl-filters' ) );
			echo '<p>' . esc_html__( "We checked your Shop page and didn't find the filter panel there, which happens with some themes. Use step 3 below to put it in your sidebar, or click Add to my shop sidebar, and this step ticks itself once the panel shows up.", 'ffl-filters' ) . '</p>';
		}
		echo '<p class="fflf-placement">' . esc_html( $this->placement_text() ) . '</p>';
		echo '<p><a href="' . esc_url( $this->check->shop_url() ) . '" target="_blank" rel="noopener">' . esc_html__( 'View your shop', 'ffl-filters' ) . ' <span class="screen-reader-text">' . esc_html__( '(opens in a new tab)', 'ffl-filters' ) . '</span></a></p>';
		echo '</div></section>';
	}

	/**
	 * Step 2.
	 *
	 * @param bool $done    Done.
	 * @param int  $current Current.
	 * @return void
	 */
	private function render_step_two( $done, $current ) {
		$this->open_step( 2, $this->state( $done, 2, $current ), __( '2. Pick your filters', 'ffl-filters' ) );
		echo '<p>' . esc_html__( 'These are the product attributes we found in your catalog. Turn on the ones your shoppers actually shop by, and leave the rest off so the panel stays short.', 'ffl-filters' ) . '</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="fflf_welcome_filters" />';
		wp_nonce_field( 'fflf_welcome_filters', 'fflf_nonce' );
		echo '<ul class="fflf-switches">';
		$rows   = $this->step_two_rows();
		$labels = self::distinct_labels( $rows );
		foreach ( $rows as $id => $row ) {
			$label   = $labels[ $id ];
			$hint    = $this->hint( $id );
			$input   = 'fflf-welcome-' . sanitize_html_class( $id );
			$enabled = ! empty( $row['enabled'] );
			echo '<li class="fflf-switch">';
			echo '<input type="hidden" name="fflf[facets][' . esc_attr( $id ) . '][enabled]" value="0" />';
			echo '<label for="' . esc_attr( $input ) . '"><span class="fflf-switch__name">' . esc_html( $label ) . '</span>';
			if ( '' !== $hint ) {
				echo '<span class="fflf-switch__hint">' . esc_html( $hint ) . '</span>';
			}
			echo '</label>';
			echo '<input type="checkbox" role="switch" class="fflf-switch__input" id="' . esc_attr( $input ) . '" name="fflf[facets][' . esc_attr( $id ) . '][enabled]" value="1"' . checked( $enabled, true, false ) . ' />';
			echo '</li>';
		}
		echo '</ul>';
		echo '<p class="fflf-step__actions">';
		submit_button( __( 'Save and go to step 3', 'ffl-filters' ), 'primary', 'submit', false );
		echo ' <span class="description">' . esc_html__( 'You can rename, reorder or hide any filter later on the Filters tab.', 'ffl-filters' ) . '</span></p>';
		echo '</form>';
		echo '</div></section>';
	}

	/**
	 * Step 3, with classic and block-theme variants.
	 *
	 * @param bool $done    Done.
	 * @param int  $current Current.
	 * @return void
	 */
	private function render_step_three( $done, $current ) {
		$block_theme = Sidebar_Placer::is_block_theme();
		$state       = $this->state( $done, 3, $current );

		echo '<div class="fflf-variant" data-fflf-variant="classic"' . ( $block_theme ? ' hidden' : '' ) . '>';
		$this->open_step( 3, $state, __( '3. Put it in your sidebar', 'ffl-filters' ) );
		echo '<p class="fflf-variant__line">' . esc_html__( 'Classic theme with widgets.', 'ffl-filters' ) . ' <a href="#fflf-step-3" data-fflf-show-variant="block">' . esc_html__( 'Using a block theme? See the block theme steps.', 'ffl-filters' ) . '</a></p>';
		$this->render_one_click();
		echo '<p>' . esc_html__( 'If your theme has a Shop sidebar, this is where the filters belong.', 'ffl-filters' ) . '</p>';
		echo '<ol class="fflf-steps-list">';
		echo '<li>' . esc_html__( 'In WordPress, go to Appearance > Widgets.', 'ffl-filters' ) . '</li>';
		echo '<li>' . esc_html__( 'Open the Shop sidebar area and click the + button.', 'ffl-filters' ) . '</li>';
		echo '<li>' . esc_html__( 'Search for FFL Filters, add the block, and click Update.', 'ffl-filters' ) . '</li>';
		echo '</ol>';
		$this->render_shortcode_line( __( "If you'd rather use a shortcode, add a Shortcode block in the same spot and paste this in:", 'ffl-filters' ), 'classic' );
		echo '</div></section></div>';

		echo '<div class="fflf-variant" data-fflf-variant="block"' . ( $block_theme ? '' : ' hidden' ) . '>';
		$this->open_step( 3, $state, __( '3. Put it beside your products', 'ffl-filters' ), $block_theme ? __( 'Block theme', 'ffl-filters' ) : '' );
		echo '<p class="fflf-variant__line">' . esc_html__( 'We found a block theme on this site, so these steps use the Site Editor.', 'ffl-filters' ) . ' <a href="#fflf-step-3" data-fflf-show-variant="classic">' . esc_html__( 'Using widgets instead? See the classic steps.', 'ffl-filters' ) . '</a></p>';
		echo '<p>' . esc_html__( "Block themes don't have a Widgets screen, so the filters go into your shop template instead.", 'ffl-filters' ) . '</p>';
		echo '<ol class="fflf-steps-list">';
		echo '<li>' . esc_html__( 'In WordPress, go to Appearance > Editor and click Templates.', 'ffl-filters' ) . '</li>';
		echo '<li>' . esc_html__( 'Open the Product Catalog template, which is the one your Shop page uses.', 'ffl-filters' ) . '</li>';
		echo '<li>' . esc_html__( "Click the + button in the column beside your products. If there's no side column yet, add a Columns block first and move the products into one column.", 'ffl-filters' ) . '</li>';
		echo '<li>' . esc_html__( 'Search for FFL Filters, add the block, and click Save.', 'ffl-filters' ) . '</li>';
		echo '</ol>';
		$this->render_shortcode_line( __( "If you'd rather use a shortcode, add a Shortcode block in the same column and paste this in:", 'ffl-filters' ), 'block' );
		echo '</div></section></div>';
	}

	/**
	 * Shortcode line with a Copy button.
	 *
	 * @param string $line Lead-in sentence.
	 * @param string $key  Unique suffix.
	 * @return void
	 */
	private function render_shortcode_line( $line, $key ) {
		$id = 'fflf-shortcode-' . $key;
		echo '<p>' . esc_html( $line ) . '</p>';
		echo '<p class="fflf-copy"><code id="' . esc_attr( $id ) . '">[ffl_filters]</code> ';
		echo '<button type="button" class="button" data-fflf-copy="' . esc_attr( $id ) . '">' . esc_html__( 'Copy shortcode', 'ffl-filters' ) . '</button>';
		echo ' <span class="fflf-copy__status" aria-live="polite"></span></p>';
	}

	/**
	 * One-click Add to my shop sidebar, or its undo.
	 *
	 * @return void
	 */
	private function render_one_click() {
		if ( ! $this->placer->supported() ) {
			return;
		}
		$added = $this->placer->added();
		if ( $added ) {
			echo '<form class="fflf-one-click" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			echo '<input type="hidden" name="action" value="fflf_undo_sidebar" />';
			wp_nonce_field( 'fflf_undo_sidebar', 'fflf_nonce' );
			echo '<p>' . esc_html(
				sprintf(
					/* translators: %s: widget area name, for example Sidebar 1 */
					__( 'FFL Filters is in your %s widget area.', 'ffl-filters' ),
					$this->placer->sidebar_name( $added['sidebar'] )
				)
			) . ' ';
			submit_button( __( 'Undo', 'ffl-filters' ), 'secondary', 'submit', false );
			echo '</p></form>';
			return;
		}
		if ( $this->placer->already_placed() ) {
			return;
		}
		echo '<form class="fflf-one-click" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="fflf_add_sidebar" />';
		wp_nonce_field( 'fflf_add_sidebar', 'fflf_nonce' );
		submit_button( __( 'Add to my shop sidebar', 'ffl-filters' ), 'primary', 'submit', false );
		echo '</form>';
	}

	/**
	 * Notices for the one-click button.
	 *
	 * @param string $notice Notice code.
	 * @return void
	 */
	private function render_sidebar_notice( $notice ) {
		if ( 'sidebar_added' === $notice ) {
			$added = $this->placer->added();
			$name  = $added ? $this->placer->sidebar_name( $added['sidebar'] ) : '';
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html(
				sprintf(
					/* translators: %s: the sidebar name the theme uses */
					__( 'FFL Filters is now in your %s. Open your shop page to see it.', 'ffl-filters' ),
					$name
				)
			) . ' <a href="' . esc_url( $this->check->shop_url() ) . '" target="_blank" rel="noopener">' . esc_html__( 'View your shop', 'ffl-filters' ) . ' <span class="screen-reader-text">' . esc_html__( '(opens in a new tab)', 'ffl-filters' ) . '</span></a></p></div>';
		} elseif ( 'sidebar_exists' === $notice ) {
			echo '<div class="notice notice-info is-dismissible"><p>' . esc_html__( 'FFL Filters is already in one of your widget areas, so nothing was added.', 'ffl-filters' ) . '</p></div>';
		} elseif ( 'sidebar_unsupported' === $notice ) {
			echo '<div class="notice notice-warning is-dismissible"><p>' . esc_html__( "We couldn't find a shop sidebar in your theme, so nothing was added. Follow the steps below to place the FFL Filters block yourself, or paste the [ffl_filters] shortcode into a Shortcode block.", 'ffl-filters' ) . '</p></div>';
		} elseif ( 'sidebar_undone' === $notice ) {
			$name = (string) get_transient( self::UNDONE_TRANSIENT );
			delete_transient( self::UNDONE_TRANSIENT );
			if ( '' === $name ) {
				$name = __( 'sidebar', 'ffl-filters' );
			}
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html(
				sprintf(
					/* translators: %s: the sidebar name */
					__( 'Done. FFL Filters is out of your %s again.', 'ffl-filters' ),
					$name
				)
			) . '</p></div>';
		}
	}

	/**
	 * Old filter plugin notice.
	 *
	 * @return void
	 */
	public function render_conflicts() {
		$found = ( new Conflicts() )->found();
		foreach ( $found as $item ) {
			echo '<div class="notice notice-warning fflf-conflict">';
			echo '<h3>' . esc_html(
				sprintf(
					/* translators: %s: name of the other filter plugin */
					__( 'Another filter plugin is active: %s', 'ffl-filters' ),
					$item['name']
				)
			) . '</h3>';
			echo '<p>' . esc_html(
				sprintf(
					/* translators: %s: short name of the other filter plugin */
					__( 'With two filter plugins running, shoppers can end up with two sets of filters on the same shop page, so deactivate %s once FFL Filters is set up the way you want it.', 'ffl-filters' ),
					$item['short']
				)
			) . '</p>';
			echo '<p class="fflf-conflict__act">';
			if ( 'plugin' === $item['type'] ) {
				echo '<a class="button" href="' . esc_url( admin_url( 'plugins.php?plugin_status=active' ) ) . '">' . esc_html(
					sprintf(
						/* translators: %s: short name of the other filter plugin */
						__( 'Deactivate %s in Plugins', 'ffl-filters' ),
						$item['short']
					)
				) . '</a> ';
			} else {
				echo '<a class="button" href="' . esc_url( admin_url( 'widgets.php' ) ) . '">' . esc_html__( 'Open Appearance > Widgets', 'ffl-filters' ) . '</a> ';
			}
			echo '<span class="description">' . esc_html__( "FFL Filters also checks for YITH filter plugins and for WooCommerce's own filter widgets and blocks, and lists any it finds here.", 'ffl-filters' ) . '</span></p>';
			echo '</div>';
		}
	}

	/**
	 * Help card.
	 *
	 * @return void
	 */
	private function render_help_card() {
		$base = admin_url( 'admin.php?page=' . Page::SLUG );
		echo '<section class="fflf-card fflf-help-card">';
		echo '<h2>' . esc_html__( 'Help when you need it', 'ffl-filters' ) . '</h2>';
		echo '<ul>';
		echo '<li><a href="' . esc_url( $base . '&tab=health' ) . '">' . esc_html__( 'Open the Health tab', 'ffl-filters' ) . '</a><span>' . esc_html__( "Check the filter index and cache, and look up why a product isn't showing.", 'ffl-filters' ) . '</span></li>';
		echo '<li><a href="' . esc_url( $base . '&tab=help' ) . '">' . esc_html__( 'Open the Help tab', 'ffl-filters' ) . '</a><span>' . esc_html__( 'Answers for cache plugins, block themes and very long attribute lists.', 'ffl-filters' ) . '</span></li>';
		echo '</ul>';
		echo '<p class="fflf-help-card__advanced"><a href="' . esc_url( $base . '&tab=import' ) . '">' . esc_html__( 'Advanced: back up or restore your FFL Filters settings on the Import tab.', 'ffl-filters' ) . '</a></p>';
		echo '</section>';
	}

	/**
	 * Slim optional contact card.
	 *
	 * @return void
	 */
	private function render_contact_card() {
		echo '<section class="fflf-card fflf-contact-card">';
		echo '<h2>' . esc_html__( 'Want a hand setting it up? Coriolis can help.', 'ffl-filters' ) . ' <span class="fflf-badge">' . esc_html__( 'Optional', 'ffl-filters' ) . '</span></h2>';
		echo '<p>' . esc_html__( "Skip this if you're all set. FFL Filters works the same either way.", 'ffl-filters' ) . '</p>';
		$this->render_slim_form( 'welcome' );
		echo '</section>';
	}

	/**
	 * The only contact form: name, email, optional message and an unticked consent box.
	 * Nothing else is posted (no store details, no site info).
	 *
	 * @param string $tab Tab to return to.
	 * @return void
	 */
	public function render_slim_form( $tab ) {
		$service = new \FFL_Filters\Lead\Service();
		$prefill = $service->prefill();
		$id      = 'fflf-' . sanitize_key( $tab ) . '-lead';
		echo '<form class="fflf-lead-form fflf-lead-form--slim" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" target="_blank" data-fflf-slim-lead>';
		echo '<input type="hidden" name="action" value="fflf_lead_handoff" />';
		echo '<input type="hidden" name="fflf_tab" value="' . esc_attr( $tab ) . '" />';
		echo '<input type="hidden" name="fflf_form" value="slim" />';
		wp_nonce_field( 'fflf_lead_handoff', 'fflf_nonce' );
		echo '<p><label for="' . esc_attr( $id . '-name' ) . '">' . esc_html__( 'Name', 'ffl-filters' ) . '</label>';
		echo '<input type="text" class="widefat" id="' . esc_attr( $id . '-name' ) . '" name="name" required maxlength="200" value="' . esc_attr( $prefill['name'] ) . '" /></p>';
		echo '<p><label for="' . esc_attr( $id . '-email' ) . '">' . esc_html__( 'Email', 'ffl-filters' ) . '</label>';
		echo '<input type="email" class="widefat" id="' . esc_attr( $id . '-email' ) . '" name="email" required maxlength="200" value="' . esc_attr( $prefill['email'] ) . '" /></p>';
		echo '<p><label for="' . esc_attr( $id . '-message' ) . '">' . esc_html__( 'Message (optional)', 'ffl-filters' ) . '</label>';
		echo '<textarea class="widefat" id="' . esc_attr( $id . '-message' ) . '" name="message" rows="4" maxlength="1000"></textarea></p>';
		echo '<p><label class="fflf-consent"><input type="checkbox" name="consent" value="1" required data-fflf-consent /> ';
		echo esc_html( $service->consent_text( 'slim' ) ) . '</label></p>';
		echo '<p><button type="submit" class="button" data-fflf-consent-submit disabled>' . esc_html__( 'Send to Coriolis', 'ffl-filters' ) . '</button></p>';
		echo '</form>';
	}

	/**
	 * Save step 2 switches.
	 *
	 * @return void
	 */
	public function handle_filters() {
		$this->assert_post( 'fflf_welcome_filters' );
		$input   = isset( $_POST['fflf']['facets'] ) ? wp_unslash( $_POST['fflf']['facets'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$current = $this->repository->all();
		if ( is_array( $input ) ) {
			foreach ( $input as $id => $row ) {
				$id = (string) $id;
				if ( ! isset( $current['facets'][ $id ] ) || ! is_array( $row ) ) {
					continue;
				}
				$current['facets'][ $id ]['enabled'] = ! empty( $row['enabled'] );
			}
		}
		$current['wizard']['completed'] = true;
		$this->repository->save( $current );
		$this->back( 'saved', 'fflf-step-3' );
	}

	/**
	 * One-click: add the block to the shop sidebar.
	 *
	 * @return void
	 */
	public function handle_add_sidebar() {
		$this->assert_post( 'fflf_add_sidebar' );
		$result = $this->placer->add();
		$this->check->forget_failure();
		$this->back( 'sidebar_' . $result, 'fflf-step-3' );
	}

	/**
	 * One-click undo: remove only the widget the button added.
	 *
	 * @return void
	 */
	public function handle_undo_sidebar() {
		$this->assert_post( 'fflf_undo_sidebar' );
		$added = $this->placer->added();
		if ( $added ) {
			set_transient( self::UNDONE_TRANSIENT, $this->placer->sidebar_name( $added['sidebar'] ), 5 * MINUTE_IN_SECONDS );
		}
		$this->placer->undo();
		$this->back( 'sidebar_undone', 'fflf-step-3' );
	}
}
