<?php
/**
 * Welcome-tab landing after activation and after each update, plus the Plugins-screen Settings link.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Sends the admin to the Welcome tab once after activation or an update.
 */
class Onboarding {

	/**
	 * One-time activation transient.
	 *
	 * @var string
	 */
	const ACTIVATION_TRANSIENT = 'fflf_activation_redirect';

	/**
	 * Last plugin version the admin has seen on the Welcome tab.
	 *
	 * @var string
	 */
	const VERSION_OPTION = 'fflf_last_seen_version';

	/**
	 * Redirect callback (tests swap this out).
	 *
	 * @var callable|null
	 */
	private $redirector;

	/**
	 * Constructor.
	 *
	 * @param callable|null $redirector Receives the URL; defaults to wp_safe_redirect + exit.
	 */
	public function __construct( $redirector = null ) {
		$this->redirector = $redirector;
	}

	/**
	 * Hooks.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_init', array( $this, 'maybe_redirect' ), 1 );
		if ( defined( 'FFLF_BASENAME' ) ) {
			add_filter( 'plugin_action_links_' . FFLF_BASENAME, array( $this, 'action_links' ) );
		}
	}

	/**
	 * Activation hook callback: set the one-time transient.
	 *
	 * @param bool $network_wide Network activation.
	 * @return void
	 */
	public static function on_activation( $network_wide = false ) {
		if ( $network_wide ) {
			return;
		}
		set_transient( self::ACTIVATION_TRANSIENT, 1, 60 );
	}

	/**
	 * Welcome tab URL.
	 *
	 * @return string
	 */
	public static function welcome_url() {
		return admin_url( 'admin.php?page=' . Page::SLUG . '&tab=welcome' );
	}

	/**
	 * Whether the current user may open FFL Filters settings.
	 *
	 * @return bool
	 */
	public static function user_can() {
		return current_user_can( 'manage_woocommerce' ) || current_user_can( 'manage_options' );
	}

	/**
	 * Add Settings before Deactivate on the Plugins screen.
	 *
	 * @param array<string, string>|mixed $links Action links.
	 * @return array<string, string>|mixed
	 */
	public function action_links( $links ) {
		if ( ! is_array( $links ) || ! self::user_can() ) {
			return $links;
		}
		$settings = '<a href="' . esc_url( self::welcome_url() ) . '">' . esc_html__( 'Settings', 'ffl-filters' ) . '</a>';
		return array_merge( array( 'settings' => $settings ), $links );
	}

	/**
	 * Why a redirect should be skipped on this request, or '' when it may run.
	 *
	 * @return string
	 */
	public function skip_reason() {
		if ( wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || wp_doing_cron() || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
			return 'background';
		}
		if ( is_network_admin() ) {
			return 'network';
		}
		if ( isset( $_GET['activate-multi'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return 'bulk';
		}
		if ( ! self::user_can() ) {
			return 'cap';
		}
		global $pagenow;
		if ( in_array( (string) $pagenow, array( 'update.php', 'update-core.php', 'admin-post.php', 'async-upload.php' ), true ) ) {
			return 'updating';
		}
		if ( isset( $_GET['page'] ) && Page::SLUG === sanitize_key( wp_unslash( $_GET['page'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'welcome'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			if ( 'welcome' === $tab ) {
				return 'here';
			}
		}
		return '';
	}

	/**
	 * The reason a redirect is due ('activation' or 'update'), or ''.
	 *
	 * @return string
	 */
	public function due() {
		if ( get_transient( self::ACTIVATION_TRANSIENT ) ) {
			return 'activation';
		}
		$current = defined( 'FFLF_VERSION' ) ? FFLF_VERSION : '';
		if ( '' !== $current && (string) get_option( self::VERSION_OPTION, '' ) !== $current ) {
			return 'update';
		}
		return '';
	}

	/**
	 * Record that this version's Welcome tab has been seen.
	 *
	 * @return void
	 */
	public static function mark_seen() {
		delete_transient( self::ACTIVATION_TRANSIENT );
		if ( defined( 'FFLF_VERSION' ) && (string) get_option( self::VERSION_OPTION, '' ) !== FFLF_VERSION ) {
			update_option( self::VERSION_OPTION, FFLF_VERSION, false );
		}
	}

	/**
	 * Callback for admin_init.
	 *
	 * @return void
	 */
	public function maybe_redirect() {
		$this->run();
	}

	/**
	 * Redirect once to the Welcome tab after activation or an update.
	 *
	 * @return string The URL redirected to, or '' when nothing happened.
	 */
	public function run() {
		$due = $this->due();
		if ( '' === $due ) {
			return '';
		}
		$skip = $this->skip_reason();
		if ( 'bulk' === $skip ) {
			// Bulk activation never redirects; drop the one-time flag so the next page load does not either.
			delete_transient( self::ACTIVATION_TRANSIENT );
			return '';
		}
		if ( 'here' === $skip ) {
			self::mark_seen();
			return '';
		}
		if ( '' !== $skip ) {
			return '';
		}

		self::mark_seen();
		$url = self::welcome_url();
		if ( $this->redirector ) {
			call_user_func( $this->redirector, $url );
			return $url;
		}
		wp_safe_redirect( $url );
		exit;
	}
}
