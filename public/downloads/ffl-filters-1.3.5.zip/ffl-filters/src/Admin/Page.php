<?php
/**
 * WooCommerce submenu settings screen for FFL Filters.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Admin;

use FFL_Filters\Cache\Generation;
use FFL_Filters\Settings\Repository;
use FFL_Filters\Settings\Seed;

defined( 'ABSPATH' ) || exit;

/**
 * Renders the dealer settings UI and handles saves, import, reset, and cache flush.
 */
class Page {

	/**
	 * Menu / page slug.
	 *
	 * @var string
	 */
	const SLUG = 'ffl-filters';

	/**
	 * Allowed tabs.
	 *
	 * @var array<int, string>
	 */
	const TABS = array( 'welcome', 'filters', 'presets', 'display', 'seo', 'health', 'performance', 'import', 'help' );

	/**
	 * Settings repository.
	 *
	 * @var Repository
	 */
	private $repository;

	/**
	 * Welcome tab.
	 *
	 * @var Welcome
	 */
	private $welcome;

	/**
	 * Constructor.
	 *
	 * @param Repository|null $repository Settings.
	 */
	public function __construct( $repository = null ) {
		$this->repository = $repository ? $repository : new Repository();
		$this->welcome    = new Welcome( $this->repository );
	}

	/**
	 * Hook menu, assets, and admin-post handlers.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_menu', array( $this, 'register_menu' ), 60 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
		add_action( 'admin_post_fflf_save_settings', array( $this, 'handle_save' ) );
		add_action( 'admin_post_fflf_import_settings', array( $this, 'handle_import' ) );
		add_action( 'admin_post_fflf_export_settings', array( $this, 'handle_export' ) );
		add_action( 'admin_post_fflf_reset_settings', array( $this, 'handle_reset' ) );
		add_action( 'admin_post_fflf_flush_cache', array( $this, 'handle_flush' ) );
		add_action( 'admin_post_fflf_complete_wizard', array( $this, 'handle_wizard' ) );
		add_action( 'admin_post_fflf_import_cpf', array( $this, 'handle_import_cpf' ) );
		add_action( 'admin_post_fflf_switch_now', array( $this, 'handle_switch_now' ) );
		add_action( 'admin_post_fflf_rollback_cpf', array( $this, 'handle_rollback' ) );
		add_action( 'admin_post_fflf_preview_cpf', array( $this, 'handle_preview' ) );
		add_action( 'admin_post_fflf_cleanup_cpf', array( $this, 'handle_cleanup' ) );
		add_action( 'admin_post_fflf_clear_slow_log', array( $this, 'handle_clear_slow_log' ) );
		add_action( 'admin_post_fflf_lead_handoff', array( $this, 'handle_lead_handoff' ) );
		add_action( 'admin_post_fflf_skip_lead', array( $this, 'handle_skip_lead' ) );
		add_action( 'admin_post_fflf_forget_lead', array( $this, 'handle_forget_lead' ) );
		$this->welcome->register();
	}

	/**
	 * Add the WooCommerce submenu.
	 *
	 * @return void
	 */
	public function register_menu() {
		add_submenu_page(
			'woocommerce',
			__( 'FFL Filters', 'ffl-filters' ),
			__( 'FFL Filters', 'ffl-filters' ),
			'manage_woocommerce',
			self::SLUG,
			array( $this, 'render' )
		);
	}

	/**
	 * Enqueue branded admin assets on this screen only.
	 *
	 * @param string $hook Current hook suffix.
	 * @return void
	 */
	public function enqueue( $hook ) {
		if ( false === strpos( (string) $hook, 'ffl-filters' ) ) {
			return;
		}

		$dir = defined( 'FFLF_DIR' ) ? FFLF_DIR : '';
		$url = defined( 'FFLF_URL' ) ? FFLF_URL : '';
		$css = $dir . 'assets/css/admin.css';
		$js  = $dir . 'assets/js/admin-settings.js';
		$ver = defined( 'FFLF_VERSION' ) ? FFLF_VERSION : '0.0.1';

		if ( is_readable( $css ) ) {
			wp_enqueue_style(
				'fflf-admin',
				$url . 'assets/css/admin.css',
				array(),
				filemtime( $css ) ? (string) filemtime( $css ) : $ver
			);
		}

		if ( is_readable( $js ) ) {
			wp_enqueue_script(
				'fflf-admin',
				$url . 'assets/js/admin-settings.js',
				array(),
				filemtime( $js ) ? (string) filemtime( $js ) : $ver,
				true
			);
			wp_localize_script(
				'fflf-admin',
				'fflfAdmin',
				array(
					'restUrl'   => esc_url_raw( rest_url( Terms_Controller::NAMESPACE . '/terms' ) ),
					'restNonce' => wp_create_nonce( 'wp_rest' ),
					'threshold' => $this->large_threshold(),
					'i18n'      => array(
						'largeConfirm'    => __( 'This attribute has many terms and can make the panel heavy. Enable it anyway?', 'ffl-filters' ),
						/* translators: 1: width in pixels, 2: layout name (Bar or Stacked) */
						'checkLayout'     => __( 'Filter area on your shop page is %1$spx wide, so Auto uses the %2$s.', 'ffl-filters' ),
						/* translators: 1: light or dark, 2: panel name (Light or Dark) */
						'checkStyle'      => __( 'Background behind the filters is %1$s, so Auto uses the %2$s panel.', 'ffl-filters' ),
						'checkFailed'     => __( 'We couldn\'t find the filters on your shop page. Make sure they\'re placed there (pick Above products, or add FFL Filters to your shop sidebar), save your changes, and try again.', 'ffl-filters' ),
						'bar'             => __( 'Bar', 'ffl-filters' ),
						'stacked'         => __( 'Stacked', 'ffl-filters' ),
						'lightWord'       => __( 'light', 'ffl-filters' ),
						'darkWord'        => __( 'dark', 'ffl-filters' ),
						'light'           => __( 'Light', 'ffl-filters' ),
						'dark'            => __( 'Dark', 'ffl-filters' ),
						'resetConfirm'    => __( 'Reset all FFL Filters settings to defaults? This cannot be undone.', 'ffl-filters' ),
						'switchConfirm'   => __( 'Switch now? Your previous filter plugin will be deactivated in this request. FFL Filters will start serving the catalog. You can switch back for 30 days if the old plugin folder is still installed.', 'ffl-filters' ),
						'rollbackConfirm' => __( 'Switch back to your previous filter plugin? FFL Filters will be deactivated and the previous plugin will be reactivated. Its settings are unchanged.', 'ffl-filters' ),
						'cleanupConfirm'  => __( 'Delete leftover settings from your previous filter plugin? Only do this after that plugin has been deleted.', 'ffl-filters' ),
						'copied'          => __( 'Copied', 'ffl-filters' ),
						/* translators: %s: term name */
						'remove'          => __( 'Remove %s', 'ffl-filters' ),
						/* translators: 1: filter name, 2: new position, 3: number of filters */
						'moved'           => __( '%1$s moved to position %2$d of %3$d', 'ffl-filters' ),
					),
				)
			);
		}

		if ( function_exists( 'delete_transient' ) ) {
			delete_transient( Seed::NOTICE_TRANSIENT );
		}
	}

	/**
	 * Render the settings screen.
	 *
	 * @return void
	 */
	public function render() {
		if ( ! $this->user_can() ) {
			wp_die( esc_html__( 'You do not have permission to manage FFL Filters.', 'ffl-filters' ) );
		}

		$settings = $this->repository->all();
		$tab      = $this->current_tab();
		$notice   = isset( $_GET['fflf_notice'] ) ? sanitize_key( wp_unslash( $_GET['fflf_notice'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		echo '<div class="wrap fflf-settings">';
		$this->render_header();
		if ( '' !== $notice ) {
			$this->render_notice( $notice );
		}

		$this->render_tabs( $tab );

		if ( 'welcome' === $tab ) {
			Onboarding::mark_seen();
			$this->welcome->render( $notice );
		} elseif ( 'import' === $tab ) {
			$this->render_import_tab( $settings );
		} elseif ( 'health' === $tab ) {
			$this->render_health_tab();
		} elseif ( 'help' === $tab ) {
			$this->render_help_tab();
		} else {
			echo '<form class="fflf-settings__form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			echo '<input type="hidden" name="action" value="fflf_save_settings" />';
			echo '<input type="hidden" name="fflf_tab" value="' . esc_attr( $tab ) . '" />';
			wp_nonce_field( 'fflf_save_settings', 'fflf_nonce' );
			if ( 'display' === $tab ) {
				$this->render_display_tab( $settings );
			} elseif ( 'seo' === $tab ) {
				$this->render_seo_tab( $settings );
			} elseif ( 'presets' === $tab ) {
				$this->render_presets_tab( $settings );
			} else {
				$this->render_filters_tab( $settings );
			}
			submit_button( __( 'Save changes', 'ffl-filters' ) );
			echo '</form>';
		}

		echo '</div>';
	}

	/**
	 * Save Filters / Display / SEO.
	 *
	 * @return void
	 */
	public function handle_save() {
		$this->assert_post( 'fflf_save_settings' );
		$input = isset( $_POST['fflf'] ) ? wp_unslash( $_POST['fflf'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		if ( ! is_array( $input ) ) {
			$input = array();
		}

		$current = $this->repository->all();
		$merged  = $current;
		foreach ( array( 'facets', 'pinned', 'display', 'sort', 'seo', 'sets', 'wizard', 'seed', 'presets' ) as $key ) {
			if ( isset( $input[ $key ] ) ) {
				$merged[ $key ] = $input[ $key ];
			}
		}

		// A tab-scoped save should not wipe keys that were not posted.
		if ( ! isset( $input['facets'] ) ) {
			$merged['facets'] = $current['facets'];
			$merged['pinned'] = $current['pinned'];
			$merged['sets']   = $current['sets'];
		}
		if ( ! isset( $input['display'] ) && ! isset( $input['sort'] ) ) {
			$merged['display'] = $current['display'];
			$merged['sort']    = $current['sort'];
		}
		if ( ! isset( $input['seo'] ) ) {
			$merged['seo'] = $current['seo'];
		}
		if ( ! isset( $input['presets'] ) ) {
			$merged['presets'] = $current['presets'];
		} else {
			$merged = $this->sync_preset_rows( $merged );
		}

		$this->repository->save( $merged );
		$this->redirect( 'saved' );
	}

	/**
	 * Presets that say a filter is on must not leave its row switched off on the Filters tab.
	 *
	 * @param array<string, mixed> $settings Settings about to be saved.
	 * @return array<string, mixed>
	 */
	public function sync_preset_rows( $settings ) {
		$presets = \FFL_Filters\Presets\Config::sanitize( isset( $settings['presets'] ) ? $settings['presets'] : array() );
		if ( ! isset( $settings['facets'] ) || ! is_array( $settings['facets'] ) ) {
			return $settings;
		}
		$type = isset( $presets['firearm_type'] ) && is_array( $presets['firearm_type'] ) ? $presets['firearm_type'] : array();
		$tax  = isset( $type['taxonomy'] ) ? (string) $type['taxonomy'] : '';
		if ( '' !== $tax && isset( $settings['facets'][ $tax ] ) && is_array( $settings['facets'][ $tax ] ) ) {
			$settings['facets'][ $tax ]['enabled'] = ! empty( $type['enabled'] );
		}
		$ranges = isset( $presets['ranges'] ) && is_array( $presets['ranges'] ) ? $presets['ranges'] : array();
		foreach ( $ranges as $taxonomy => $row ) {
			if ( is_array( $row ) && ! empty( $row['enabled'] ) && isset( $settings['facets'][ $taxonomy ] ) && is_array( $settings['facets'][ $taxonomy ] ) ) {
				$settings['facets'][ $taxonomy ]['enabled'] = true;
			}
		}
		return $settings;
	}

	/**
	 * Import a JSON settings document.
	 *
	 * @return void
	 */
	public function handle_import() {
		$this->assert_post( 'fflf_import_settings' );
		$json = $this->uploaded_backup();
		if ( '' === $json ) {
			$json = isset( $_POST['fflf_import_json'] ) ? wp_unslash( $_POST['fflf_import_json'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		}
		$ok = $this->repository->import( is_string( $json ) ? $json : '' );
		$this->redirect( null === $ok ? 'import_error' : 'imported' );
	}

	/**
	 * Contents of an uploaded backup file (1 MB cap), or ''.
	 *
	 * @return string
	 */
	private function uploaded_backup() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- Nonce checked in handle_import(); the temp path is checked with is_uploaded_file().
		if ( empty( $_FILES['fflf_import_file']['tmp_name'] ) || ! empty( $_FILES['fflf_import_file']['error'] ) ) {
			return '';
		}
		$tmp  = (string) $_FILES['fflf_import_file']['tmp_name'];
		$size = isset( $_FILES['fflf_import_file']['size'] ) ? (int) $_FILES['fflf_import_file']['size'] : 0;
		// phpcs:enable
		if ( $size <= 0 || $size > MB_IN_BYTES || ! is_uploaded_file( $tmp ) ) {
			return '';
		}
		$body = file_get_contents( $tmp ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local uploaded temp file.
		return is_string( $body ) ? $body : '';
	}

	/**
	 * Download the current settings as a backup file.
	 *
	 * @return void
	 */
	public function handle_export() {
		$this->assert_post( 'fflf_export_settings' );
		$json = $this->repository->export();
		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="ffl-filters-settings-' . gmdate( 'Y-m-d' ) . '.json"' );
		echo $json; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON file download, not HTML.
		exit;
	}

	/**
	 * Reset settings to defaults.
	 *
	 * @return void
	 */
	public function handle_reset() {
		$this->assert_post( 'fflf_reset_settings' );
		$this->repository->reset();
		$this->redirect( 'reset' );
	}

	/**
	 * Nonce-protected cache generation bump.
	 *
	 * @return void
	 */
	public function handle_flush() {
		$this->assert_post( 'fflf_flush_cache' );
		( new Generation() )->bump();
		$this->redirect( 'flushed' );
	}

	/**
	 * Empty the Health-tab slow-query log.
	 *
	 * @return void
	 */
	public function handle_clear_slow_log() {
		$this->assert_post( 'fflf_clear_slow_log' );
		( new \FFL_Filters\Health\Slow_Log() )->clear();
		$this->redirect( 'slow_cleared' );
	}

	/**
	 * Complete or skip the first-run wizard.
	 *
	 * @return void
	 */
	public function handle_wizard() {
		$this->assert_post( 'fflf_complete_wizard' );
		$input   = isset( $_POST['fflf'] ) ? wp_unslash( $_POST['fflf'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$current = $this->repository->all();
		if ( is_array( $input ) ) {
			if ( isset( $input['facets'] ) ) {
				$current['facets'] = $input['facets'];
			}
			if ( isset( $input['display'] ) ) {
				$current['display'] = $input['display'];
			}
			if ( isset( $input['seo'] ) ) {
				$current['seo'] = $input['seo'];
			}
		}
		$current['wizard']['completed'] = true;
		$this->repository->save( $current );
		$this->redirect( 'wizard', array( 'tab' => 'welcome' ) );
	}

	/**
	 * Render header.
	 *
	 * @return void
	 */
	private function render_header() {
		$base    = defined( 'FFLF_URL' ) ? FFLF_URL : '';
		$icon    = $base . 'assets/images/ffl-filters-icon.svg';
		$version = defined( 'FFLF_VERSION' ) ? FFLF_VERSION : '';
		echo '<header class="fflf-settings__header">';
		echo '<img class="fflf-settings__icon" src="' . esc_url( $icon ) . '" width="64" height="64" alt="" />';
		echo '<span class="fflf-settings__wordmark"><b>FFL</b> Filters</span>';
		if ( '' !== $version ) {
			/* translators: %s: plugin version */
			echo '<span class="fflf-settings__version">' . esc_html( sprintf( __( 'Version %s', 'ffl-filters' ), $version ) ) . '</span>';
		}
		echo '<span class="fflf-settings__links"><a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG . '&tab=help' ) ) . '">' . esc_html__( 'Help', 'ffl-filters' ) . '</a></span>';
		echo '</header>';
	}

	/**
	 * Render tabs.
	 *
	 * @param string $tab Current tab.
	 * @return void
	 */
	private function render_tabs( $tab ) {
		$labels = array(
			'welcome' => __( 'Welcome', 'ffl-filters' ),
			'filters' => __( 'Filters', 'ffl-filters' ),
			'presets' => __( 'Presets', 'ffl-filters' ),
			'display' => __( 'Appearance', 'ffl-filters' ),
			'seo'     => __( 'SEO', 'ffl-filters' ),
			'health'  => __( 'Health', 'ffl-filters' ),
			'import'  => __( 'Import', 'ffl-filters' ),
			'help'    => __( 'Help', 'ffl-filters' ),
		);
		echo '<nav class="nav-tab-wrapper fflf-settings__tabs">';
		foreach ( $labels as $id => $label ) {
			$url   = admin_url( 'admin.php?page=' . self::SLUG . '&tab=' . $id );
			$class = 'nav-tab' . ( $tab === $id ? ' nav-tab-active' : '' );
			echo '<a class="' . esc_attr( $class ) . '" href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>';
		}
		echo '</nav>';
	}

	/**
	 * Render filters tab.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return void
	 */
	private function render_filters_tab( $settings ) {
		$facets = isset( $settings['facets'] ) && is_array( $settings['facets'] ) ? $settings['facets'] : array();
		uasort(
			$facets,
			static function ( $a, $b ) {
				$ao = isset( $a['order'] ) ? (int) $a['order'] : 0;
				$bo = isset( $b['order'] ) ? (int) $b['order'] : 0;
				if ( $ao === $bo ) {
					return 0;
				}
				return ( $ao < $bo ) ? -1 : 1;
			}
		);

		echo '<h2>' . esc_html__( 'Filters', 'ffl-filters' ) . '</h2>';
		echo '<p class="description">' . esc_html__( 'Rename, reorder, and choose a display type for each filter. Newly arrived product attributes are hidden until you enable them.', 'ffl-filters' ) . '</p>';
		$merged = Welcome::merged_backing_ids();
		echo '<div class="fflf-facet-list" data-fflf-facet-list>';
		foreach ( $facets as $id => $facet ) {
			$facet = is_array( $facet ) ? $facet : array();
			if ( in_array( (string) $id, $merged, true ) ) {
				$this->render_merged_row( (string) $id, $facet );
				continue;
			}
			$this->render_facet_row( (string) $id, $facet );
		}
		echo '</div>';
		echo '<p class="screen-reader-text" aria-live="polite" data-fflf-move-status></p>';

		$this->render_pinned( $settings );
		$this->render_sets( $settings );
	}

	/**
	 * Render facet row.
	 *
	 * @param string               $id    Facet id.
	 * @param array<string, mixed> $facet Row.
	 * @return void
	 */
	private function render_facet_row( $id, $facet ) {
		$enabled = ! empty( $facet['enabled'] );
		$label   = isset( $facet['label'] ) ? (string) $facet['label'] : '';
		$type    = isset( $facet['type'] ) ? (string) $facet['type'] : 'checkbox';
		$order   = isset( $facet['order'] ) ? (int) $facet['order'] : 0;
		$mode    = isset( $facet['mode'] ) ? (string) $facet['mode'] : 'all';
		$nested  = ! empty( $facet['nested'] );
		$hidden  = isset( $facet['hidden_terms'] ) && is_array( $facet['hidden_terms'] ) ? $facet['hidden_terms'] : array();
		$slugs   = isset( $facet['slugs'] ) && is_array( $facet['slugs'] ) ? $facet['slugs'] : array();
		$prefix  = 'fflf[facets][' . $id . ']';
		$locked  = in_array( $id, array( 'price', 'instock' ), true );
		$virtual = in_array( $id, array( 'instore', \FFL_Filters\Presets\Defaults::CALIBER_ID ), true );
		$count   = ( $locked || $virtual ) ? 0 : $this->term_count( $id );
		$name    = Welcome::row_label( $id, $facet );

		echo '<section class="fflf-facet" data-fflf-facet="' . esc_attr( $id ) . '" data-fflf-name="' . esc_attr( $name ) . '" data-term-count="' . esc_attr( (string) $count ) . '">';
		echo '<div class="fflf-facet__row">';
		echo '<span class="fflf-facet__handle" draggable="true" aria-hidden="true" title="' . esc_attr__( 'Drag to reorder', 'ffl-filters' ) . '">&#8942;&#8942;</span>';
		$name_id = 'fflf-facet-name-' . sanitize_html_class( $id );
		echo '<button type="button" class="button fflf-facet__move" data-fflf-move="up" aria-describedby="' . esc_attr( $name_id ) . '" title="' . esc_attr__( 'Move up', 'ffl-filters' ) . '"><span aria-hidden="true">&#9650;</span> <span class="fflf-facet__move-text">' . esc_html__( 'Move up', 'ffl-filters' ) . '</span></button>';
		echo '<button type="button" class="button fflf-facet__move" data-fflf-move="down" aria-describedby="' . esc_attr( $name_id ) . '" title="' . esc_attr__( 'Move down', 'ffl-filters' ) . '"><span aria-hidden="true">&#9660;</span> <span class="fflf-facet__move-text">' . esc_html__( 'Move down', 'ffl-filters' ) . '</span></button>';
		echo '<input type="hidden" name="' . esc_attr( $prefix . '[id]' ) . '" value="' . esc_attr( $id ) . '" />';
		echo '<input type="hidden" class="fflf-facet__order" name="' . esc_attr( $prefix . '[order]' ) . '" value="' . esc_attr( (string) $order ) . '" />';
		echo '<input type="hidden" name="' . esc_attr( $prefix . '[enabled]' ) . '" value="0" />';
		echo '<label class="fflf-facet__enable"><input type="checkbox" class="fflf-facet__enabled" name="' . esc_attr( $prefix . '[enabled]' ) . '" value="1"' . checked( $enabled, true, false ) . ' /> ';
		echo '<span class="fflf-facet__name" id="' . esc_attr( $name_id ) . '">' . esc_html( $name ) . '</span></label>';
		/* translators: %s: the attribute name */
		echo '<label class="fflf-facet__label"><span class="screen-reader-text">' . esc_html( sprintf( __( 'Label for %s', 'ffl-filters' ), $name ) ) . '</span>';
		echo '<input type="text" name="' . esc_attr( $prefix . '[label]' ) . '" value="' . esc_attr( $label ) . '" placeholder="' . esc_attr( $name ) . '" /></label>';
		if ( $virtual ) {
			echo '<input type="hidden" name="' . esc_attr( $prefix . '[type]' ) . '" value="checkbox" />';
		} else {
			echo '<label class="fflf-facet__type"><span class="screen-reader-text">' . esc_html__( 'Type', 'ffl-filters' ) . '</span>';
			echo '<select name="' . esc_attr( $prefix . '[type]' ) . '"' . disabled( $locked, true, false ) . '>';
			foreach ( $this->type_labels( $locked ? $type : '' ) as $value => $text ) {
				echo '<option value="' . esc_attr( $value ) . '"' . selected( $type, $value, false ) . '>' . esc_html( $text ) . '</option>';
			}
			echo '</select></label>';
		}
		echo '</div>';

		if ( $locked || $virtual ) {
			echo '</section>';
			return;
		}

		echo '<div class="fflf-facet__details">';
		$this->render_slug_picker( $prefix . '[hidden_terms]', $id, $hidden, __( 'Hidden terms', 'ffl-filters' ) );
		if ( 'product_cat' === $id ) {
			echo '<label>' . esc_html__( 'Category mode', 'ffl-filters' ) . ' ';
			echo '<select name="' . esc_attr( $prefix . '[mode]' ) . '">';
			$modes = array(
				'all'   => __( 'Show all', 'ffl-filters' ),
				'allow' => __( 'Only these categories', 'ffl-filters' ),
				'hide'  => __( 'Hide these categories', 'ffl-filters' ),
			);
			foreach ( $modes as $value => $text ) {
				echo '<option value="' . esc_attr( $value ) . '"' . selected( $mode, $value, false ) . '>' . esc_html( $text ) . '</option>';
			}
			echo '</select></label>';
			$this->render_slug_picker( $prefix . '[slugs]', 'product_cat', $slugs, __( 'Category list', 'ffl-filters' ) );
			echo '<label><input type="hidden" name="' . esc_attr( $prefix . '[nested]' ) . '" value="0" />';
			echo '<input type="checkbox" name="' . esc_attr( $prefix . '[nested]' ) . '" value="1"' . checked( $nested, true, false ) . ' /> ';
			echo esc_html__( 'Show as a nested tree', 'ffl-filters' ) . '</label>';
		}
		echo '</div></section>';
	}

	/**
	 * A caliber attribute that is merged into Caliber: kept as hidden inputs so saves never drop it.
	 *
	 * @param string               $id    Facet id.
	 * @param array<string, mixed> $facet Row.
	 * @return void
	 */
	private function render_merged_row( $id, $facet ) {
		$prefix = 'fflf[facets][' . $id . ']';
		foreach ( array( 'id', 'label', 'type', 'order', 'mode' ) as $key ) {
			$value = 'id' === $key ? $id : ( isset( $facet[ $key ] ) && ! is_array( $facet[ $key ] ) ? (string) $facet[ $key ] : '' );
			echo '<input type="hidden" name="' . esc_attr( $prefix . '[' . $key . ']' ) . '" value="' . esc_attr( $value ) . '" />';
		}
		echo '<input type="hidden" name="' . esc_attr( $prefix . '[enabled]' ) . '" value="' . ( empty( $facet['enabled'] ) ? '0' : '1' ) . '" />';
		$hidden = isset( $facet['hidden_terms'] ) && is_array( $facet['hidden_terms'] ) ? $facet['hidden_terms'] : array();
		foreach ( $hidden as $slug ) {
			echo '<input type="hidden" name="' . esc_attr( $prefix . '[hidden_terms][]' ) . '" value="' . esc_attr( (string) $slug ) . '" />';
		}
	}

	/**
	 * Render pinned.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return void
	 */
	private function render_pinned( $settings ) {
		$pin   = isset( $settings['pinned'] ) && is_array( $settings['pinned'] ) ? $settings['pinned'] : array();
		$tags  = isset( $pin['tags'] ) && is_array( $pin['tags'] ) ? $pin['tags'] : array();
		$cats  = isset( $pin['categories'] ) && is_array( $pin['categories'] ) ? $pin['categories'] : array();
		$slugs = array();
		foreach ( $tags as $row ) {
			if ( is_array( $row ) && ! empty( $row['slug'] ) ) {
				$slugs[] = (string) $row['slug'];
			}
		}

		echo '<h2>' . esc_html__( 'Pinned tags', 'ffl-filters' ) . '</h2>';
		echo '<p class="description">' . esc_html__( 'When this is on, the Tag filter shows only these tags, in this order, with optional custom labels.', 'ffl-filters' ) . '</p>';
		echo '<input type="hidden" name="fflf[pinned][enabled]" value="0" />';
		echo '<label><input type="checkbox" name="fflf[pinned][enabled]" value="1"' . checked( ! empty( $pin['enabled'] ), true, false ) . ' /> ' . esc_html__( 'Enable pinned tags', 'ffl-filters' ) . '</label>';
		echo '<p><label>' . esc_html__( 'Match', 'ffl-filters' ) . ' ';
		echo '<select name="fflf[pinned][match]">';
		echo '<option value="or"' . selected( isset( $pin['match'] ) ? $pin['match'] : 'or', 'or', false ) . '>' . esc_html__( 'Any tag (OR)', 'ffl-filters' ) . '</option>';
		echo '<option value="and"' . selected( isset( $pin['match'] ) ? $pin['match'] : 'or', 'and', false ) . '>' . esc_html__( 'All tags (AND)', 'ffl-filters' ) . '</option>';
		echo '</select></label></p>';
		$this->render_slug_picker( 'fflf[pinned][tags]', 'product_tag', $slugs, __( 'Pinned tags', 'ffl-filters' ), true, $tags );
		$this->render_slug_picker( 'fflf[pinned][categories]', 'product_cat', $cats, __( 'Show on these categories', 'ffl-filters' ) );
		echo '<input type="hidden" name="fflf[pinned][shop]" value="0" />';
		echo '<label><input type="checkbox" name="fflf[pinned][shop]" value="1"' . checked( ! isset( $pin['shop'] ) || $pin['shop'], true, false ) . ' /> ' . esc_html__( 'Show on the shop archive', 'ffl-filters' ) . '</label>';
	}

	/**
	 * Render sets.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return void
	 */
	private function render_sets( $settings ) {
		$sets = isset( $settings['sets'] ) && is_array( $settings['sets'] ) ? $settings['sets'] : array();
		echo '<h2>' . esc_html__( 'Filters per category', 'ffl-filters' ) . '</h2>';
		echo '<p class="description">' . esc_html__( 'Pick a different set of filters for a category page, such as barrel length on rifles but not on ammo.', 'ffl-filters' ) . '</p>';
		if ( ! $sets ) {
			$sets = array(
				array(
					'categories' => array(),
					'facets'     => array(),
				),
			);
		}
		foreach ( $sets as $i => $set ) {
			$set  = is_array( $set ) ? $set : array();
			$cats = isset( $set['categories'] ) && is_array( $set['categories'] ) ? $set['categories'] : array();
			$ids  = isset( $set['facets'] ) && is_array( $set['facets'] ) ? $set['facets'] : array();
			echo '<div class="fflf-set">';
			$this->render_slug_picker( 'fflf[sets][' . (int) $i . '][categories]', 'product_cat', $cats, __( 'Categories', 'ffl-filters' ) );
			echo '<fieldset class="fflf-set__filters"><legend>' . esc_html__( 'Filters to show', 'ffl-filters' ) . '</legend>';
			echo '<p class="description">' . esc_html__( 'Turn on the filters your shoppers actually shop by, and leave the rest off so the panel stays short.', 'ffl-filters' ) . '</p>';
			$all_rows = isset( $settings['facets'] ) && is_array( $settings['facets'] ) ? $settings['facets'] : array();
			$merged   = Welcome::merged_backing_ids();
			foreach ( $all_rows as $row_id => $row ) {
				$row_id = (string) $row_id;
				if ( in_array( $row_id, $merged, true ) ) {
					continue;
				}
				echo '<label class="fflf-set__filter"><input type="checkbox" name="fflf[sets][' . esc_attr( (string) (int) $i ) . '][facets][]" value="' . esc_attr( $row_id ) . '"' . checked( in_array( $row_id, $ids, true ), true, false ) . ' /> ' . esc_html( Welcome::row_label( $row_id, is_array( $row ) ? $row : array() ) ) . '</label>';
			}
			echo '</fieldset>';
			echo '</div>';
		}
	}

	/**
	 * Render firearm presets tab.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return void
	 */
	private function render_presets_tab( $settings ) {
		$presets = isset( $settings['presets'] ) && is_array( $settings['presets'] ) ? $settings['presets'] : \FFL_Filters\Presets\Config::sanitize( array() );
		$caliber = isset( $presets['caliber'] ) && is_array( $presets['caliber'] ) ? $presets['caliber'] : array();
		$ranges  = isset( $presets['ranges'] ) && is_array( $presets['ranges'] ) ? $presets['ranges'] : array();
		$type    = isset( $presets['firearm_type'] ) && is_array( $presets['firearm_type'] ) ? $presets['firearm_type'] : array();
		$instore = isset( $presets['instore'] ) && is_array( $presets['instore'] ) ? $presets['instore'] : array();

		echo '<h2>' . esc_html__( 'Firearm presets', 'ffl-filters' ) . '</h2>';
		echo '<p class="description">' . esc_html__( 'These presets match the attribute names most gun store catalogs use. Check each one against your own products before you turn it on.', 'ffl-filters' ) . '</p>';

		echo '<h3>' . esc_html__( 'Caliber merge', 'ffl-filters' ) . '</h3>';
		echo '<p class="description">' . esc_html__( 'Shows your caliber attributes as one Caliber filter, so one caliber spelled a few different ways counts as a single choice.', 'ffl-filters' ) . '</p>';
		echo '<input type="hidden" name="fflf[presets][caliber][enabled]" value="0" />';
		echo '<p><label><input type="checkbox" name="fflf[presets][caliber][enabled]" value="1"' . checked( ! isset( $caliber['enabled'] ) || $caliber['enabled'], true, false ) . ' /> ';
		echo esc_html__( 'Merge caliber attributes into one Caliber filter (for example caliber-gauge and bullet-caliber)', 'ffl-filters' ) . '</label></p>';
		echo '<p><label>' . esc_html__( 'Label', 'ffl-filters' ) . ' <input type="text" name="fflf[presets][caliber][label]" value="' . esc_attr( isset( $caliber['label'] ) ? (string) $caliber['label'] : 'Caliber' ) . '" /></label></p>';
		$taxes = isset( $caliber['taxonomies'] ) && is_array( $caliber['taxonomies'] ) ? implode( ', ', $caliber['taxonomies'] ) : implode( ', ', \FFL_Filters\Presets\Defaults::caliber_taxonomies() );
		echo '<p><label>' . esc_html__( 'Backing taxonomies (comma-separated)', 'ffl-filters' ) . ' <input type="text" class="regular-text" name="fflf[presets][caliber][taxonomies]" value="' . esc_attr( $taxes ) . '" /></label></p>';
		$lines  = array();
		$merges = isset( $caliber['merges'] ) && is_array( $caliber['merges'] ) ? $caliber['merges'] : array();
		foreach ( $merges as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$label   = isset( $row['label'] ) ? (string) $row['label'] : '';
			$members = isset( $row['members'] ) && is_array( $row['members'] ) ? implode( ', ', $row['members'] ) : '';
			$lines[] = $label . ' = ' . $members;
		}
		echo '<p><label for="fflf-caliber-merges">' . esc_html__( 'Synonym groups (one per line: canonical = variant, variant)', 'ffl-filters' ) . '</label></p>';
		echo '<textarea class="large-text code" rows="10" id="fflf-caliber-merges" name="fflf[presets][caliber][merges]">' . esc_textarea(
			implode(
				'
',
				$lines
			)
		) . '</textarea>';

		echo '<h3>' . esc_html__( 'Numeric ranges', 'ffl-filters' ) . '</h3>';
		echo '<p class="description">' . esc_html__( 'Shows barrel length, capacity, bullet weight and magnification as ranges, read from the values you already have on your products.', 'ffl-filters' ) . '</p>';
		foreach ( $ranges as $taxonomy => $row ) {
			$row  = is_array( $row ) ? $row : array();
			$unit = isset( $row['unit'] ) ? (string) $row['unit'] : '';
			$vals = array();
			if ( isset( $row['values'] ) && is_array( $row['values'] ) ) {
				foreach ( $row['values'] as $slug => $value ) {
					$vals[] = $slug . '=' . $value;
				}
			}
			$row_label = Welcome::row_label( (string) $taxonomy, (array) $this->repository->facet( (string) $taxonomy ) );
			echo '<fieldset class="fflf-wizard__step"><legend>' . esc_html( $row_label ) . '</legend>';
			echo '<input type="hidden" name="fflf[presets][ranges][' . esc_attr( (string) $taxonomy ) . '][enabled]" value="0" />';
			echo '<p><label><input type="checkbox" name="fflf[presets][ranges][' . esc_attr( (string) $taxonomy ) . '][enabled]" value="1"' . checked( ! isset( $row['enabled'] ) || $row['enabled'], true, false ) . ' /> ' . esc_html__( 'Show as a numeric range', 'ffl-filters' ) . '</label></p>';
			echo '<p><label>' . esc_html__( 'Unit', 'ffl-filters' ) . ' <input type="text" name="fflf[presets][ranges][' . esc_attr( (string) $taxonomy ) . '][unit]" value="' . esc_attr( $unit ) . '" /></label></p>';
			echo '<p><label>' . esc_html__( 'Overrides (slug=number, one per line)', 'ffl-filters' ) . '</label></p>';
			echo '<textarea class="large-text code" rows="4" name="fflf[presets][ranges][' . esc_attr( (string) $taxonomy ) . '][values]">' . esc_textarea(
				implode(
					'
',
					$vals
				)
			) . '</textarea>';
			echo '</fieldset>';
		}

		echo '<h3>' . esc_html__( 'Firearm type', 'ffl-filters' ) . '</h3>';
		echo '<p class="description">' . esc_html__( "Shows the type values already in your catalog under the label Firearm type. FFL Filters doesn't classify anything.", 'ffl-filters' ) . '</p>';
		$type_tax = isset( $type['taxonomy'] ) ? (string) $type['taxonomy'] : 'pa_atf-type';
		$type_row = $this->repository->facet( $type_tax );
		$type_on  = ( ! isset( $type['enabled'] ) || $type['enabled'] ) && ( ! $type_row || ! empty( $type_row['enabled'] ) );
		echo '<input type="hidden" name="fflf[presets][firearm_type][enabled]" value="0" />';
		echo '<p><label><input type="checkbox" name="fflf[presets][firearm_type][enabled]" value="1"' . checked( $type_on, true, false ) . ' /> ' . esc_html__( 'Show the Firearm type facet when the attribute exists', 'ffl-filters' ) . '</label></p>';
		echo '<p><label>' . esc_html__( 'Label', 'ffl-filters' ) . ' <input type="text" name="fflf[presets][firearm_type][label]" value="' . esc_attr( isset( $type['label'] ) ? (string) $type['label'] : 'Firearm type' ) . '" /></label></p>';
		echo '<p><label>' . esc_html__( 'Taxonomy', 'ffl-filters' ) . ' <input type="text" name="fflf[presets][firearm_type][taxonomy]" value="' . esc_attr( isset( $type['taxonomy'] ) ? (string) $type['taxonomy'] : 'pa_atf-type' ) . '" /></label></p>';

		echo '<h3>' . esc_html__( 'In store', 'ffl-filters' ) . '</h3>';
		echo '<p class="description">' . esc_html__( "Adds an In store switch for products you've given the in-store tag, so shoppers can see what's on your shelf.", 'ffl-filters' ) . '</p>';
		echo '<input type="hidden" name="fflf[presets][instore][enabled]" value="0" />';
		echo '<p><label><input type="checkbox" name="fflf[presets][instore][enabled]" value="1"' . checked( ! isset( $instore['enabled'] ) || $instore['enabled'], true, false ) . ' /> ' . esc_html__( 'Enable the In store toggle when the tag exists', 'ffl-filters' ) . '</label></p>';
		echo '<p><label>' . esc_html__( 'Label', 'ffl-filters' ) . ' <input type="text" name="fflf[presets][instore][label]" value="' . esc_attr( isset( $instore['label'] ) ? (string) $instore['label'] : 'In store' ) . '" /></label></p>';
		echo '<p><label>' . esc_html__( 'Tag slug', 'ffl-filters' ) . ' <input type="text" name="fflf[presets][instore][slug]" value="' . esc_attr( isset( $instore['slug'] ) ? (string) $instore['slug'] : 'in-store' ) . '" /></label></p>';
		echo '<p><label>' . esc_html__( 'Taxonomy', 'ffl-filters' ) . ' <input type="text" name="fflf[presets][instore][taxonomy]" value="' . esc_attr( isset( $instore['taxonomy'] ) ? (string) $instore['taxonomy'] : 'product_tag' ) . '" /></label></p>';
	}

	/**
	 * Render display tab.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return void
	 */
	private function render_display_tab( $settings ) {
		$mobile = isset( $settings['display']['mobile'] ) ? (string) $settings['display']['mobile'] : 'drawer';
		$honor  = ! isset( $settings['sort']['honor_page_order'] ) || $settings['sort']['honor_page_order'];
		echo '<h2>' . esc_html__( 'Appearance', 'ffl-filters' ) . '</h2>';
		$this->render_appearance_rows( $settings );
		echo '<p><label>' . esc_html__( 'Mobile presentation', 'ffl-filters' ) . ' ';
		echo '<select name="fflf[display][mobile]">';
		$modes = array(
			'drawer'      => __( 'Drawer', 'ffl-filters' ),
			'collapsible' => __( 'Collapsible', 'ffl-filters' ),
			'sidebar'     => __( 'Sidebar', 'ffl-filters' ),
		);
		foreach ( $modes as $value => $text ) {
			echo '<option value="' . esc_attr( $value ) . '"' . selected( $mobile, $value, false ) . '>' . esc_html( $text ) . '</option>';
		}
		echo '</select></label></p>';
		$auto = ! isset( $settings['display']['auto_insert'] ) || $settings['display']['auto_insert'];
		echo '<p><input type="hidden" name="fflf[display][auto_insert]" value="0" />';
		echo '<label><input type="checkbox" name="fflf[display][auto_insert]" value="1"' . checked( $auto, true, false ) . ' /> ' . esc_html__( 'Place the panel automatically', 'ffl-filters' ) . '</label><br />';
		echo '<span class="description">' . esc_html__( "FFL Filters adds the panel to your shop and category pages on its own. Turn this off if you'd rather place it yourself with the FFL Filters block or the [ffl_filters] shortcode.", 'ffl-filters' ) . '</span></p>';
		$heading = isset( $settings['display']['heading'] ) ? (string) $settings['display']['heading'] : '';
		echo '<p><label for="fflf-display-heading">' . esc_html__( 'Panel heading', 'ffl-filters' ) . '</label><br />';
		echo '<input type="text" class="regular-text" id="fflf-display-heading" name="fflf[display][heading]" maxlength="100" value="' . esc_attr( $heading ) . '" placeholder="' . esc_attr__( 'Filter products', 'ffl-filters' ) . '" aria-describedby="fflf-display-heading-help" /><br />';
		echo '<span class="description" id="fflf-display-heading-help">' . esc_html__( 'Shown at the top of the filter panel. Leave blank to use Filter products.', 'ffl-filters' ) . '</span></p>';
		echo '<input type="hidden" name="fflf[sort][honor_page_order]" value="0" />';
		echo '<label><input type="checkbox" name="fflf[sort][honor_page_order]" value="1"' . checked( $honor, true, false ) . ' /> ';
		echo esc_html__( 'Honor the page order (do not override the catalog sort)', 'ffl-filters' ) . '</label>';
	}

	/**
	 * Appearance rows (1.3.0): Placement, Layout, Panel style and Accent color. Copy from Brandy's mockups.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return void
	 */
	private function render_appearance_rows( $settings ) {
		$d         = isset( $settings['display'] ) && is_array( $settings['display'] ) ? $settings['display'] : array();
		$placement = isset( $d['placement'] ) ? (string) $d['placement'] : 'sidebar';
		$layout    = isset( $d['layout'] ) ? (string) $d['layout'] : 'auto';
		$style     = isset( $d['panel_style'] ) ? (string) $d['panel_style'] : 'auto';
		$source    = isset( $d['accent_source'] ) ? (string) $d['accent_source'] : 'theme';
		$custom    = isset( $d['accent_color'] ) ? (string) $d['accent_color'] : '';
		$shop      = function_exists( 'wc_get_page_permalink' ) ? (string) wc_get_page_permalink( 'shop' ) : home_url( '/' );

		echo '<table class="form-table fflf-appearance" role="presentation"><tbody>';

		// Placement.
		echo '<tr><th scope="row">' . esc_html__( 'Placement', 'ffl-filters' ) . '</th><td><fieldset><legend class="screen-reader-text">' . esc_html__( 'Placement', 'ffl-filters' ) . '</legend>';
		$rows = array(
			'sidebar'        => array( __( 'Sidebar', 'ffl-filters' ), __( 'The filters go in your shop sidebar or widget area.', 'ffl-filters' ) ),
			'above_products' => array( __( 'Above products', 'ffl-filters' ), __( 'The filters go above the product grid on the shop and category pages, full width.', 'ffl-filters' ) ),
		);
		foreach ( $rows as $value => $text ) {
			echo '<label><input type="radio" name="fflf[display][placement]" value="' . esc_attr( $value ) . '"' . checked( $placement, $value, false ) . ' /> ' . esc_html( $text[0] ) . '</label>';
			echo '<span class="fflf-appearance__hint description">' . esc_html( $text[1] ) . '</span>';
		}
		echo '</fieldset></td></tr>';

		// Layout.
		echo '<tr><th scope="row">' . esc_html__( 'Layout', 'ffl-filters' ) . '</th><td><fieldset><legend class="screen-reader-text">' . esc_html__( 'Layout', 'ffl-filters' ) . '</legend>';
		$rows = array(
			'auto'    => __( 'Auto: pick the layout from the space the filters have', 'ffl-filters' ),
			'bar'     => __( 'Bar: a row of dropdown buttons', 'ffl-filters' ),
			'stacked' => __( 'Stacked: one group per row, opens in place', 'ffl-filters' ),
		);
		foreach ( $rows as $value => $text ) {
			echo '<label><input type="radio" name="fflf[display][layout]" value="' . esc_attr( $value ) . '"' . checked( $layout, $value, false ) . ' /> ' . esc_html( $text ) . '</label><br />';
		}
		echo '<p class="description">' . esc_html__( 'Auto uses the Bar when the filters have 720px or more to work with, and Stacked when they have less, like in a sidebar. Phones always get the Filter products button and the drawer.', 'ffl-filters' ) . '</p>';
		echo '<p><button type="button" class="button" data-fflf-check-shop="' . esc_url( $shop ) . '">' . esc_html__( 'Check my shop page', 'ffl-filters' ) . '</button></p>';
		echo '<p class="fflf-appearance__result" data-fflf-check-layout aria-live="polite"></p>';
		echo '</fieldset></td></tr>';

		// Panel style.
		echo '<tr><th scope="row">' . esc_html__( 'Panel style', 'ffl-filters' ) . '</th><td><fieldset><legend class="screen-reader-text">' . esc_html__( 'Panel style', 'ffl-filters' ) . '</legend>';
		$rows = array(
			'auto'  => __( 'Auto: match the background behind the filters', 'ffl-filters' ),
			'light' => __( 'Light', 'ffl-filters' ),
			'dark'  => __( 'Dark', 'ffl-filters' ),
		);
		foreach ( $rows as $value => $text ) {
			echo '<label><input type="radio" name="fflf[display][panel_style]" value="' . esc_attr( $value ) . '"' . checked( $style, $value, false ) . ' /> ' . esc_html( $text ) . '</label><br />';
		}
		echo '<p class="description">' . esc_html__( 'Auto checks the background behind the filters on your shop page and uses the dark panel on a dark theme. If your filters look wrong, pick Light or Dark here.', 'ffl-filters' ) . '</p>';
		echo '<p class="fflf-appearance__result" data-fflf-check-style aria-live="polite"></p>';
		echo '</fieldset></td></tr>';

		// Accent color (Paul, 10:13 AM ET: "Accent color: Theme color / Custom" with a preview).
		$tokens = \FFL_Filters\Panel\Accent::tokens();
		echo '<tr><th scope="row">' . esc_html__( 'Accent color', 'ffl-filters' ) . '</th><td><fieldset><legend class="screen-reader-text">' . esc_html__( 'Accent color', 'ffl-filters' ) . '</legend>';
		echo '<label><input type="radio" name="fflf[display][accent_source]" value="theme"' . checked( $source, 'theme', false ) . ' /> ' . esc_html__( 'Theme color', 'ffl-filters' ) . '</label><br />';
		echo '<label><input type="radio" name="fflf[display][accent_source]" value="custom"' . checked( $source, 'custom', false ) . ' /> ' . esc_html__( 'Custom', 'ffl-filters' ) . '</label> ';
		echo '<input type="color" name="fflf[display][accent_color]" value="' . esc_attr( '' !== $custom ? strtolower( $custom ) : '#0f1b2d' ) . '" aria-label="' . esc_attr__( 'Custom', 'ffl-filters' ) . '" />';
		// Copy placeholder: Brandy has not written the help line for this row yet.
		echo '<p class="description">' . esc_html__( 'Theme color uses your theme\'s button color, or its main or link color if there\'s no button color. Custom uses the color you pick. Either way, the filters darken or lighten it as needed so text on it stays readable on the light and dark panels, and use a neutral color if none can be read or made readable. Your theme\'s own colors don\'t change. The preview shows the saved colors.', 'ffl-filters' ) . '</p>';
		echo '<p class="fflf-accent-preview">';
		foreach ( array(
			'light' => __( 'Light', 'ffl-filters' ),
			'dark'  => __( 'Dark', 'ffl-filters' ),
		) as $set => $name ) {
			$bg   = 'light' === $set ? '#FFFFFF' : '#14191D';
			$fill = (string) $tokens[ $set ];
			$text = (string) $tokens[ $set . '_text' ];
			echo '<span class="fflf-accent-preview__set" style="background:' . esc_attr( $bg ) . ';color:' . esc_attr( 'light' === $set ? '#1F2933' : '#F3F5F7' ) . '">';
			echo esc_html( $name ) . ' <span class="fflf-accent-preview__chip" style="background:' . esc_attr( $fill ) . ';color:' . esc_attr( $text ) . '">' . esc_html( $fill ) . '</span></span> ';
		}
		echo '</p>';
		echo '</fieldset></td></tr>';

		echo '</tbody></table>';
	}

	/**
	 * Render seo tab.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return void
	 */
	private function render_seo_tab( $settings ) {
		$seo = isset( $settings['seo'] ) && is_array( $settings['seo'] ) ? $settings['seo'] : array();
		echo '<h2>' . esc_html__( 'SEO', 'ffl-filters' ) . '</h2>';
		echo '<p class="description">' . esc_html__( 'These settings are on by default: filtered views are noindex, follow, with no canonical link, and a robots.txt Disallow block covers filter URLs.', 'ffl-filters' ) . '</p>';
		$flags = array(
			'robots_disallow'   => __( 'Append the Product filter URLs block to robots.txt', 'ffl-filters' ),
			'canonical_noindex' => __( 'noindex, follow filtered views (no rel=canonical)', 'ffl-filters' ),
			'nofollow_facets'   => __( 'Add rel=nofollow to Clear and pagination on filtered views', 'ffl-filters' ),
		);
		foreach ( $flags as $key => $label ) {
			$on = ! isset( $seo[ $key ] ) || $seo[ $key ];
			echo '<p><input type="hidden" name="fflf[seo][' . esc_attr( $key ) . ']" value="0" />';
			echo '<label><input type="checkbox" name="fflf[seo][' . esc_attr( $key ) . ']" value="1"' . checked( $on, true, false ) . ' /> ' . esc_html( $label ) . '</label></p>';
		}
	}


	/**
	 * Render the Health tab.
	 *
	 * @return void
	 */
	private function render_health_tab() {
		$report    = ( new \FFL_Filters\Health\Report() )->snapshot();
		$log       = new \FFL_Filters\Health\Slow_Log();
		$index     = isset( $report['index'] ) && is_array( $report['index'] ) ? $report['index'] : array();
		$status    = isset( $index['status'] ) ? (string) $index['status'] : 'missing';
		$attr      = isset( $index['attributes'] ) && is_array( $index['attributes'] ) ? $index['attributes'] : array();
		$meta      = isset( $index['meta'] ) && is_array( $index['meta'] ) ? $index['meta'] : array();
		$health    = admin_url( 'admin.php?page=' . self::SLUG . '&tab=health' );
		$woo_tools = admin_url( 'admin.php?page=wc-status&tab=tools' );

		echo '<h2>' . esc_html__( 'Health', 'ffl-filters' ) . '</h2>';
		echo '<p class="description">' . esc_html__( 'FFL Filters uses the WooCommerce product lookup tables rather than a custom index. This screen reports those tables, the cache generation, a slow-query log that only writes when a filtered request is slow, and a lookup for products that are missing from a filtered view.', 'ffl-filters' ) . '</p>';

		echo '<section class="fflf-health-card">';
		echo '<h3>' . esc_html__( 'Index status', 'ffl-filters' ) . '</h3>';
		if ( 'ok' === $status ) {
			echo '<p>' . esc_html__( 'WooCommerce lookup tables look complete.', 'ffl-filters' ) . '</p>';
		} elseif ( 'incomplete' === $status ) {
			echo '<p>' . esc_html__( 'WooCommerce lookup tables exist but look incomplete. Regenerating the product attributes lookup table usually fixes missing products in attribute filters.', 'ffl-filters' ) . '</p>';
		} else {
			echo '<p>' . esc_html__( 'A WooCommerce lookup table is missing. Install and run WooCommerce, then regenerate the lookup tables.', 'ffl-filters' ) . '</p>';
		}
		echo '<p><a href="' . esc_url( $woo_tools ) . '">' . esc_html__( 'Open WooCommerce → Status → Tools', 'ffl-filters' ) . '</a></p>';
		echo '<table class="widefat striped fflf-health-table"><tbody>';
		echo '<tr><th>' . esc_html__( 'Attributes lookup', 'ffl-filters' ) . '</th><td>' . esc_html( $this->health_table_summary( $attr ) ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'Product meta lookup', 'ffl-filters' ) . '</th><td>' . esc_html( $this->health_table_summary( $meta ) ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'Attributes lookup enabled', 'ffl-filters' ) . '</th><td>' . esc_html( ! empty( $index['enabled'] ) ? __( 'Yes', 'ffl-filters' ) : __( 'No', 'ffl-filters' ) ) . '</td></tr>';
		echo '</tbody></table>';
		echo '</section>';

		echo '<section class="fflf-health-card">';
		echo '<h3>' . esc_html__( 'Cache generation', 'ffl-filters' ) . '</h3>';
		echo '<p>' . esc_html__( 'Current cache generation:', 'ffl-filters' ) . ' <code>' . esc_html( (string) $report['generation'] ) . '</code></p>';
		if ( ! empty( $report['bumped_at_text'] ) ) {
			echo '<p>' . esc_html__( 'Last rebuilt:', 'ffl-filters' ) . ' ' . esc_html( (string) $report['bumped_at_text'] ) . '</p>';
		} else {
			echo '<p>' . esc_html__( 'The cache generation has not been bumped yet.', 'ffl-filters' ) . '</p>';
		}
		echo '<p>' . esc_html__( 'Object cache:', 'ffl-filters' ) . ' ' . esc_html( ! empty( $report['object_cache'] ) ? __( 'Present', 'ffl-filters' ) : __( 'Not detected', 'ffl-filters' ) ) . '</p>';
		echo '<p>' . esc_html__( 'WP Engine:', 'ffl-filters' ) . ' ' . esc_html( ! empty( $report['wp_engine'] ) ? __( 'Detected', 'ffl-filters' ) . '. ' . __( 'Page-cache exclusions for filtered URLs still apply.', 'ffl-filters' ) : __( 'Not detected', 'ffl-filters' ) ) . '</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="fflf_flush_cache" />';
		echo '<input type="hidden" name="fflf_tab" value="health" />';
		wp_nonce_field( 'fflf_flush_cache', 'fflf_nonce' );
		submit_button( __( 'Flush filter cache', 'ffl-filters' ), 'secondary', 'submit', false );
		echo '</form>';
		echo '</section>';

		echo '<section class="fflf-health-card">';
		echo '<h3>' . esc_html__( 'Slow queries', 'ffl-filters' ) . '</h3>';
		echo '<p class="description">' . sprintf(
			/* translators: %d: threshold in milliseconds */
			esc_html__( 'Filtered catalog requests slower than %d ms are stored here (up to 25 rows). This log does not write on every front-end request.', 'ffl-filters' ),
			(int) $log->threshold()
		) . '</p>';
		$entries = $log->all();
		if ( $entries ) {
			echo '<table class="widefat striped fflf-health-table"><thead><tr>';
			echo '<th>' . esc_html__( 'When', 'ffl-filters' ) . '</th>';
			echo '<th>' . esc_html__( 'Duration', 'ffl-filters' ) . '</th>';
			echo '<th>' . esc_html__( 'Path', 'ffl-filters' ) . '</th>';
			echo '<th>' . esc_html__( 'Cache', 'ffl-filters' ) . '</th>';
			echo '<th>' . esc_html__( 'Query', 'ffl-filters' ) . '</th>';
			echo '</tr></thead><tbody>';
			foreach ( $entries as $entry ) {
				$when      = isset( $entry['at'] ) ? (int) $entry['at'] : 0;
				$when_text = $when && function_exists( 'wp_date' ) ? (string) wp_date( 'Y-m-d H:i:s T', $when ) : (string) $when;
				$ms        = isset( $entry['duration_ms'] ) ? (int) $entry['duration_ms'] : 0;
				$path      = isset( $entry['path'] ) ? (string) $entry['path'] : '';
				$cache     = isset( $entry['cache'] ) ? (string) $entry['cache'] : '';
				$query     = isset( $entry['query'] ) && is_array( $entry['query'] ) ? wp_json_encode( $entry['query'] ) : '';
				echo '<tr>';
				echo '<td>' . esc_html( $when_text ) . '</td>';
				echo '<td>' . esc_html(
					sprintf(
					/* translators: %d: milliseconds */
						__( '%d ms', 'ffl-filters' ),
						$ms
					)
				) . '</td>';
				echo '<td><code>' . esc_html( $path ) . '</code></td>';
				echo '<td>' . esc_html( $cache ) . '</td>';
				echo '<td><code>' . esc_html( is_string( $query ) ? $query : '' ) . '</code></td>';
				echo '</tr>';
			}
			echo '</tbody></table>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			echo '<input type="hidden" name="action" value="fflf_clear_slow_log" />';
			echo '<input type="hidden" name="fflf_tab" value="health" />';
			wp_nonce_field( 'fflf_clear_slow_log', 'fflf_nonce' );
			submit_button( __( 'Clear slow-query log', 'ffl-filters' ), 'secondary', 'submit', false );
			echo '</form>';
		} else {
			echo '<p>' . esc_html__( 'No slow filtered queries have been recorded yet.', 'ffl-filters' ) . '</p>';
		}
		echo '</section>';

		echo '<section class="fflf-health-card">';
		echo '<h3>' . esc_html__( "Why isn't this product showing?", 'ffl-filters' ) . '</h3>';
		echo '<p class="description">' . esc_html__( 'Look up a product by ID, SKU, or name to see why it might be missing from a filtered catalog view.', 'ffl-filters' ) . '</p>';
		$needle = isset( $_GET['fflf_why'] ) ? sanitize_text_field( wp_unslash( $_GET['fflf_why'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		echo '<form method="get" action="' . esc_url( admin_url( 'admin.php' ) ) . '">';
		echo '<input type="hidden" name="page" value="' . esc_attr( self::SLUG ) . '" />';
		echo '<input type="hidden" name="tab" value="health" />';
		echo '<label class="screen-reader-text" for="fflf-why">' . esc_html__( 'Product ID, SKU, or name', 'ffl-filters' ) . '</label>';
		echo '<input type="text" id="fflf-why" class="regular-text" name="fflf_why" value="' . esc_attr( $needle ) . '" />';
		submit_button( __( 'Look up', 'ffl-filters' ), 'secondary', 'submit', false );
		echo '</form>';
		if ( '' !== $needle ) {
			$result = ( new \FFL_Filters\Health\Why( $this->repository ) )->inspect( $needle, array() );
			$this->render_why_result( $result );
		}
		echo '</section>';

		$this->render_health_faq( $health, $woo_tools );
	}

	/**
	 * Summarize a lookup table row.
	 *
	 * @param array<string, mixed> $row Table snapshot.
	 * @return string
	 */
	private function health_table_summary( $row ) {
		if ( empty( $row['exists'] ) ) {
			return __( 'Table not found', 'ffl-filters' );
		}
		$products  = isset( $row['products'] ) ? (int) $row['products'] : 0;
		$rows      = isset( $row['rows'] ) ? (int) $row['rows'] : 0;
		$published = isset( $row['published'] ) ? (int) $row['published'] : 0;
		return sprintf(
			/* translators: 1: distinct products, 2: row count, 3: published products */
			__( '%1$d products in table (%2$d rows). %3$d published products in the catalog.', 'ffl-filters' ),
			$products,
			$rows,
			$published
		);
	}

	/**
	 * Render why-isn't-X results.
	 *
	 * @param array<string, mixed> $result Lookup result.
	 * @return void
	 */
	private function render_why_result( $result ) {
		if ( ! empty( $result['error'] ) ) {
			if ( 'empty' === $result['error'] ) {
				echo '<p>' . esc_html__( 'Enter a product ID, SKU, or name.', 'ffl-filters' ) . '</p>';
				return;
			}
			echo '<p>' . esc_html__( 'No product matched that lookup.', 'ffl-filters' ) . '</p>';
			return;
		}

		$product = isset( $result['product'] ) && is_array( $result['product'] ) ? $result['product'] : array();
		$title   = isset( $product['title'] ) ? (string) $product['title'] : '';
		$id      = isset( $product['id'] ) ? (int) $product['id'] : 0;
		$sku     = isset( $product['sku'] ) ? (string) $product['sku'] : '';
		echo '<p><strong>' . esc_html( $title ) . '</strong>';
		if ( $id ) {
			echo ' <code>#' . esc_html( (string) $id ) . '</code>';
		}
		if ( $sku ) {
			echo ' <code>' . esc_html( $sku ) . '</code>';
		}
		echo '</p>';

		if ( ! empty( $result['ok'] ) ) {
			echo '<p>' . esc_html__( 'Nothing in FFL Filters settings or the current catalog state obviously excludes this product.', 'ffl-filters' ) . '</p>';
		}

		$checks = isset( $result['checks'] ) && is_array( $result['checks'] ) ? $result['checks'] : array();
		echo '<ul class="fflf-health-checks">';
		foreach ( $checks as $check ) {
			$ok      = ! empty( $check['ok'] );
			$message = isset( $check['message'] ) ? (string) $check['message'] : '';
			$class   = $ok ? 'fflf-health-checks__ok' : 'fflf-health-checks__fail';
			$mark    = $ok ? __( 'Pass', 'ffl-filters' ) : __( 'Fail', 'ffl-filters' );
			echo '<li class="' . esc_attr( $class ) . '"><strong>' . esc_html( $mark ) . ':</strong> ' . esc_html( $message ) . '</li>';
		}
		echo '</ul>';
	}

	/**
	 * Failure-mode FAQ with a link back to this tab.
	 *
	 * @param string $health    Health tab URL.
	 * @param string $woo_tools Woo tools URL.
	 * @return void
	 */
	private function render_health_faq( $health, $woo_tools ) {
		echo '<section class="fflf-health-card">';
		echo '<h3>' . esc_html__( 'Support FAQ', 'ffl-filters' ) . '</h3>';
		echo '<dl class="fflf-health-faq">';
		echo '<dt>' . esc_html__( 'A cache plugin is serving stale filtered pages', 'ffl-filters' ) . '</dt>';
		echo '<dd>' . esc_html__( 'Filtered views send DONOTCACHEPAGE and should be excluded from full-page caches. Confirm your cache plugin is honoring that flag, then flush the filter cache on this tab.', 'ffl-filters' ) . ' <a href="' . esc_url( $health ) . '">' . esc_html__( 'Open the Health tab', 'ffl-filters' ) . '</a></dd>';
		echo '<dt>' . esc_html__( 'WooCommerce filter blocks are also on the page', 'ffl-filters' ) . '</dt>';
		echo '<dd>' . esc_html__( 'Built-in WooCommerce filter blocks can apply a second, conflicting query. Remove them from the product collection template if shoppers see empty or doubled results.', 'ffl-filters' ) . '</dd>';
		echo '<dt>' . esc_html__( 'A block theme is not showing the panel', 'ffl-filters' ) . '</dt>';
		echo '<dd>' . esc_html__( 'On block themes the panel injects above the product collection. You can also place the FFL Filters block or the [ffl_filters] shortcode in the template.', 'ffl-filters' ) . '</dd>';
		echo '<dt>' . esc_html__( 'The attributes lookup table is missing or incomplete', 'ffl-filters' ) . '</dt>';
		echo '<dd>' . esc_html__( 'Attribute filters read WooCommerce lookup tables, not a custom FFL Filters index. Use the Index status card on this tab, then regenerate the lookup tables in WooCommerce.', 'ffl-filters' ) . ' <a href="' . esc_url( $woo_tools ) . '">' . esc_html__( 'Open WooCommerce → Status → Tools', 'ffl-filters' ) . '</a></dd>';
		echo '<dt>' . esc_html__( 'A huge attribute is slowing the shop', 'ffl-filters' ) . '</dt>';
		echo '<dd>' . esc_html__( 'Leave very long filters switched off until you confirm them on the Filters tab. Enabling every term of a huge attribute can make the panel and queries slower than they need to be.', 'ffl-filters' ) . '</dd>';
		echo '</dl>';
		echo '</section>';
	}

	/**
	 * Render import tab.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return void
	 */
	private function render_import_tab( $settings ) {
		$service  = new \FFL_Filters\Import\Service( $this->repository );
		$switcher = new \FFL_Filters\Import\Switcher();
		$preview  = new \FFL_Filters\Import\Preview();
		$detector = new \FFL_Filters\Import\Detector();
		$migrate  = $detector->is_active() || $detector->is_installed() || $switcher->rollback_available() || array() !== $switcher->record();
		$report   = $migrate ? $service->dry_run() : array();

		if ( $migrate ) {
			echo '<h2>' . esc_html__( 'Previous filter plugin', 'ffl-filters' ) . '</h2>';
		}

		if ( ! $migrate ) {
			$report = array(); // Nothing to migrate: only Back up and restore below.
		} elseif ( $detector->is_active() ) {
			echo '<p>' . esc_html__( "We found filter settings from an earlier setup on this site. Review them here before you bring them in. The last step also turns the earlier filter plugin off, so shoppers don't see two panels.", 'ffl-filters' ) . '</p>';
			if ( $detector->has_dual_folder() ) {
				echo '<p>' . esc_html__( 'More than one copy of your previous filter plugin is installed. The importer will switch every active copy off together.', 'ffl-filters' ) . '</p>';
			}
			echo '<p><strong>' . esc_html__( 'Detected version:', 'ffl-filters' ) . '</strong> ' . esc_html( $report['from_version'] ? $report['from_version'] : __( 'unknown', 'ffl-filters' ) ) . '</p>';
			$this->render_import_diff( $report );
			$this->render_import_hooks( $report );
			if ( ! empty( $report['github_token_defined'] ) ) {
				echo '<p>' . esc_html__( 'A GitHub token constant for your previous filter plugin is defined in wp-config.php. FFL Filters does not use it, so you can remove that line after you switch.', 'ffl-filters' ) . '</p>';
			}

			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			echo '<input type="hidden" name="action" value="fflf_import_cpf" />';
			echo '<input type="hidden" name="fflf_tab" value="import" />';
			wp_nonce_field( 'fflf_import_cpf', 'fflf_nonce' );
			submit_button( __( 'Import settings', 'ffl-filters' ), 'secondary', 'submit', false );
			echo '</form>';

			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			echo '<input type="hidden" name="action" value="fflf_preview_cpf" />';
			echo '<input type="hidden" name="fflf_tab" value="import" />';
			echo '<input type="hidden" name="fflf_preview_state" value="' . ( $preview->is_active() ? '0' : '1' ) . '" />';
			wp_nonce_field( 'fflf_preview_cpf', 'fflf_nonce' );
			submit_button(
				$preview->is_active() ? __( 'Turn preview off', 'ffl-filters' ) : __( 'Import & preview', 'ffl-filters' ),
				'secondary',
				'submit',
				false
			);
			echo '</form>';

			echo '<form id="fflf-switch-now" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" data-fflf-switch>';
			echo '<input type="hidden" name="action" value="fflf_switch_now" />';
			echo '<input type="hidden" name="fflf_tab" value="import" />';
			wp_nonce_field( 'fflf_switch_now', 'fflf_nonce' );
			submit_button( __( 'Switch now', 'ffl-filters' ), 'primary', 'submit', false );
			echo '</form>';
			echo '<p class="description">' . esc_html__( 'Switch now deactivates your previous filter plugin in this request (well under two minutes). It does not delete that plugin or its settings, so you can switch back.', 'ffl-filters' ) . '</p>';
		} elseif ( $switcher->rollback_available() ) {
			echo '<p>' . esc_html__( 'Your previous filter plugin is not active, and its folder is still installed. You can switch back for 30 days after the last switch.', 'ffl-filters' ) . '</p>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" data-fflf-rollback>';
			echo '<input type="hidden" name="action" value="fflf_rollback_cpf" />';
			echo '<input type="hidden" name="fflf_tab" value="import" />';
			wp_nonce_field( 'fflf_rollback_cpf', 'fflf_nonce' );
			submit_button( __( 'Switch back to the previous filter plugin', 'ffl-filters' ), 'secondary', 'submit', false );
			echo '</form>';
		} elseif ( $detector->is_installed() ) {
			echo '<p>' . esc_html__( 'Your previous filter plugin is installed but not active. Activate it if you still want to import its settings, or delete the plugin when you no longer need a rollback path.', 'ffl-filters' ) . '</p>';
		} else {
			echo '<p>' . esc_html__( 'Your previous filter plugin has been deleted.', 'ffl-filters' ) . '</p>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" data-fflf-cleanup>';
			echo '<input type="hidden" name="action" value="fflf_cleanup_cpf" />';
			echo '<input type="hidden" name="fflf_tab" value="import" />';
			wp_nonce_field( 'fflf_cleanup_cpf', 'fflf_nonce' );
			submit_button( __( 'Clean up leftover settings', 'ffl-filters' ), 'delete', 'submit', false );
			echo '</form>';
			echo '<p class="description">' . esc_html__( 'This only runs after the previous filter plugin has been deleted. It removes its leftover settings. The switch itself never deletes that data.', 'ffl-filters' ) . '</p>';
		}

		unset( $settings );
		echo '<h2>' . esc_html__( 'Back up and restore', 'ffl-filters' ) . '</h2>';
		echo '<p>' . esc_html__( 'Download your FFL Filters settings as a backup file, or restore them from a backup you saved earlier.', 'ffl-filters' ) . '</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="fflf_export_settings" />';
		wp_nonce_field( 'fflf_export_settings', 'fflf_nonce' );
		submit_button( __( 'Download a backup', 'ffl-filters' ), 'secondary', 'submit', false );
		echo '</form>';
		echo '<form method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="fflf_import_settings" />';
		echo '<input type="hidden" name="fflf_tab" value="import" />';
		wp_nonce_field( 'fflf_import_settings', 'fflf_nonce' );
		echo '<p><label for="fflf-import-file">' . esc_html__( 'Import settings from a backup file', 'ffl-filters' ) . '</label><br />';
		echo '<input type="file" id="fflf-import-file" name="fflf_import_file" accept=".json,application/json" /></p>';
		echo '<p><label for="fflf-import-json">' . esc_html__( 'Or paste the settings text from a backup', 'ffl-filters' ) . '</label><br />';
		echo '<textarea id="fflf-import-json" name="fflf_import_json" rows="6" class="large-text code" aria-describedby="fflf-import-json-help"></textarea><br />';
		echo '<span class="description" id="fflf-import-json-help">' . esc_html__( "Use this if you can't upload the file. Open the backup file in a text editor and paste everything in it here.", 'ffl-filters' ) . '</span></p>';
		submit_button( __( 'Import settings', 'ffl-filters' ), 'secondary' );
		echo '</form>';
		echo '<h3>' . esc_html__( 'Reset', 'ffl-filters' ) . '</h3>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" data-fflf-reset>';
		echo '<input type="hidden" name="action" value="fflf_reset_settings" />';
		echo '<input type="hidden" name="fflf_tab" value="import" />';
		wp_nonce_field( 'fflf_reset_settings', 'fflf_nonce' );
		submit_button( __( 'Reset settings to defaults', 'ffl-filters' ), 'delete' );
		echo '</form>';
	}

	/**
	 * Render a dry-run diff table.
	 *
	 * @param array<string, mixed> $report Dry-run report.
	 * @return void
	 */
	private function render_import_diff( $report ) {
		$diff = isset( $report['diff'] ) && is_array( $report['diff'] ) ? $report['diff'] : array();
		if ( ! empty( $report['unchanged'] ) ) {
			echo '<p>' . esc_html__( 'FFL Filters already matches the settings from your previous filter plugin.', 'ffl-filters' ) . '</p>';
			return;
		}
		echo '<h3>' . esc_html__( 'Dry-run diff', 'ffl-filters' ) . '</h3>';
		echo '<table class="widefat striped fflf-import-diff"><thead><tr>';
		echo '<th>' . esc_html__( 'Change', 'ffl-filters' ) . '</th>';
		echo '<th>' . esc_html__( 'Setting', 'ffl-filters' ) . '</th>';
		echo '<th>' . esc_html__( 'From', 'ffl-filters' ) . '</th>';
		echo '<th>' . esc_html__( 'To', 'ffl-filters' ) . '</th>';
		echo '</tr></thead><tbody>';
		foreach ( array(
			'added'   => __( 'Added', 'ffl-filters' ),
			'removed' => __( 'Removed', 'ffl-filters' ),
			'changed' => __( 'Changed', 'ffl-filters' ),
		) as $kind => $label ) {
			$rows = isset( $diff[ $kind ] ) && is_array( $diff[ $kind ] ) ? $diff[ $kind ] : array();
			foreach ( $rows as $path => $value ) {
				echo '<tr>';
				echo '<td>' . esc_html( $label ) . '</td>';
				echo '<td><code>' . esc_html( (string) $path ) . '</code></td>';
				if ( 'changed' === $kind && is_array( $value ) ) {
					echo '<td><code>' . esc_html( wp_json_encode( isset( $value['from'] ) ? $value['from'] : null ) ) . '</code></td>';
					echo '<td><code>' . esc_html( wp_json_encode( isset( $value['to'] ) ? $value['to'] : null ) ) . '</code></td>';
				} elseif ( 'removed' === $kind ) {
					echo '<td><code>' . esc_html( wp_json_encode( $value ) ) . '</code></td><td></td>';
				} else {
					echo '<td></td><td><code>' . esc_html( wp_json_encode( $value ) ) . '</code></td>';
				}
				echo '</tr>';
			}
		}
		echo '</tbody></table>';
		if ( ! empty( $report['dropped_keys'] ) ) {
			echo '<p>' . esc_html__( 'These settings from your previous filter plugin are not imported:', 'ffl-filters' ) . ' <code>' . esc_html( implode( ', ', (array) $report['dropped_keys'] ) ) . '</code></p>';
		}
	}

	/**
	 * List cpf_* hooks that currently have callbacks.
	 *
	 * @param array<string, mixed> $report Dry-run report.
	 * @return void
	 */
	private function render_import_hooks( $report ) {
		$hooks = isset( $report['hooks'] ) && is_array( $report['hooks'] ) ? $report['hooks'] : array();
		if ( ! $hooks ) {
			return;
		}
		echo '<h3>' . esc_html__( 'Theme or mu-plugin hooks', 'ffl-filters' ) . '</h3>';
		echo '<p>' . esc_html__( 'These hooks from your previous filter plugin currently have callbacks. They are detected, not executed. After you switch, FFL Filters aliases the most-used ones to fflf_* equivalents.', 'ffl-filters' ) . '</p>';
		echo '<ul>';
		$map = \FFL_Filters\Import\Shim::MAP;
		foreach ( $hooks as $hook ) {
			$hook = (string) $hook;
			$repl = isset( $map[ $hook ] ) ? $map[ $hook ] : '';
			echo '<li><code>' . esc_html( $hook ) . '</code>';
			if ( '' !== $repl ) {
				echo ' → <code>' . esc_html( $repl ) . '</code>';
			}
			echo '</li>';
		}
		echo '</ul>';
	}

	/**
	 * Import mapped CPF settings into fflf_settings.
	 *
	 * @return void
	 */
	public function handle_import_cpf() {
		$this->assert_post( 'fflf_import_cpf' );
		( new \FFL_Filters\Import\Service( $this->repository ) )->commit();
		$this->redirect( 'cpf_imported' );
	}

	/**
	 * Deactivate CPF in the same request. FFL Filters stays on.
	 *
	 * @return void
	 */
	public function handle_switch_now() {
		$this->assert_post( 'fflf_switch_now' );
		if ( ! current_user_can( 'activate_plugins' ) ) {
			$this->redirect( 'cpf_switch_denied' );
		}
		( new \FFL_Filters\Import\Switcher() )->switch_now();
		$this->redirect( 'cpf_switched' );
	}

	/**
	 * Reactivate CPF and deactivate FFL Filters.
	 *
	 * @return void
	 */
	public function handle_rollback() {
		$this->assert_post( 'fflf_rollback_cpf' );
		if ( ! current_user_can( 'activate_plugins' ) ) {
			$this->redirect( 'cpf_switch_denied' );
		}
		( new \FFL_Filters\Import\Switcher() )->rollback();
		wp_safe_redirect( admin_url( 'plugins.php' ) );
		exit;
	}

	/**
	 * Toggle admin-only storefront preview.
	 *
	 * @return void
	 */
	public function handle_preview() {
		$this->assert_post( 'fflf_preview_cpf' );
		$preview = new \FFL_Filters\Import\Preview();
		$on      = isset( $_POST['fflf_preview_state'] ) ? (string) wp_unslash( $_POST['fflf_preview_state'] ) : '1'; // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		if ( '0' === $on ) {
			$preview->disable();
			$this->redirect( 'cpf_preview_off' );
		}
		( new \FFL_Filters\Import\Service( $this->repository ) )->commit();
		$preview->enable();
		$this->redirect( 'cpf_preview' );
	}

	/**
	 * Delete leftover CPF options after the plugin folder is gone.
	 *
	 * @return void
	 */
	public function handle_cleanup() {
		$this->assert_post( 'fflf_cleanup_cpf' );
		$result = ( new \FFL_Filters\Import\Switcher() )->cleanup_cpf_data();
		$this->redirect( ! empty( $result['ok'] ) ? 'cpf_cleaned' : 'cpf_cleanup_blocked' );
	}


	/**
	 * Help & support lead card (always available).
	 *
	 * @return void
	 */
	private function render_lead_card() {
		$service = new \FFL_Filters\Lead\Service();
		$status  = $service->status();
		echo '<section class="fflf-health-card fflf-lead-card">';
		echo '<h3>' . esc_html__( 'Help & support', 'ffl-filters' ) . '</h3>';
		if ( $status ) {
			$when = function_exists( 'wp_date' ) ? (string) wp_date( 'Y-m-d', (int) $status['sent_at'] ) : (string) (int) $status['sent_at'];
			echo '<p>' . sprintf(
				/* translators: %s: date the dealer sent the form */
				esc_html__( 'You contacted Coriolis on %s. To have your details deleted, use the deletion form on the Coriolis connect page.', 'ffl-filters' ),
				esc_html( $when )
			) . ' <a href="' . esc_url( \FFL_Filters\Lead\Service::DELETION_URL ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Request deletion', 'ffl-filters' ) . '</a></p>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			echo '<input type="hidden" name="action" value="fflf_forget_lead" />';
			echo '<input type="hidden" name="fflf_tab" value="help" />';
			wp_nonce_field( 'fflf_forget_lead', 'fflf_nonce' );
			submit_button( __( 'Forget local record', 'ffl-filters' ), 'secondary', 'submit', false );
			echo '</form>';
		} else {
			echo '<p>' . esc_html__( 'Optionally have Coriolis contact you about FFL Filters. Nothing is sent until you tick the consent box and click Send to Coriolis. The plugin works the same if you skip this.', 'ffl-filters' ) . '</p>';
			$this->welcome->render_slim_form( 'help' );
		}
		echo '</section>';
	}


	/**
	 * Validate, record local consent, and auto-POST allowed fields to Coriolis.
	 *
	 * @return void
	 */
	public function handle_lead_handoff() {
		$this->assert_post( 'fflf_lead_handoff' );
		$service = new \FFL_Filters\Lead\Service();
		$result  = $service->sanitize( wp_unslash( $_POST ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		if ( empty( $result['ok'] ) ) {
			$this->redirect( 'lead_error' );
		}

		$service->record( isset( $result['data']['consent_v'] ) ? (string) $result['data']['consent_v'] : \FFL_Filters\Lead\Service::CONSENT_VERSION );
		$fields = $service->handoff_fields( $result['data'] );
		$tab    = isset( $_POST['fflf_tab'] ) ? sanitize_key( wp_unslash( $_POST['fflf_tab'] ) ) : 'help'; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$back   = admin_url( 'admin.php?page=' . self::SLUG . '&tab=' . ( 'connect' === $tab ? 'help' : $tab ) . '&fflf_notice=lead_sent' );

		if ( ! headers_sent() ) {
			nocache_headers();
			header( 'Content-Type: text/html; charset=UTF-8' );
		}
		echo '<!DOCTYPE html><html><head><meta charset="UTF-8" /><title>' . esc_html__( 'Contact Coriolis', 'ffl-filters' ) . '</title></head><body>';
		echo '<p>' . esc_html__( 'Sending your request to Coriolis. If nothing happens, use the button below.', 'ffl-filters' ) . '</p>';
		echo '<form id="fflf-lead-handoff" method="post" action="' . esc_url( \FFL_Filters\Lead\Service::ENDPOINT ) . '">';
		foreach ( $fields as $name => $value ) {
			echo '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" />';
		}
		echo '<button type="submit">' . esc_html__( 'Send to Coriolis', 'ffl-filters' ) . '</button>';
		echo '</form>';
		echo '<p><a href="' . esc_url( $back ) . '">' . esc_html__( 'Back to FFL Filters', 'ffl-filters' ) . '</a></p>';
		echo '<script>document.getElementById("fflf-lead-handoff").submit();</script>';
		echo '</body></html>';
		exit;
	}

	/**
	 * Skip the one-time lead offer.
	 *
	 * @return void
	 */
	public function handle_skip_lead() {
		$this->assert_post( 'fflf_skip_lead' );
		( new \FFL_Filters\Lead\Service() )->mark_prompted();
		$this->redirect( 'lead_skipped' );
	}

	/**
	 * Clear the local fflf_lead record.
	 *
	 * @return void
	 */
	public function handle_forget_lead() {
		$this->assert_post( 'fflf_forget_lead' );
		( new \FFL_Filters\Lead\Service() )->forget();
		$this->redirect( 'lead_forgotten' );
	}

	/**
	 * Render help tab.
	 *
	 * @return void
	 */
	private function render_help_tab() {
		echo '<h2>' . esc_html__( 'Help', 'ffl-filters' ) . '</h2>';
		echo '<ol class="fflf-help">';
		echo '<li>' . esc_html__( 'Start on the Welcome tab. It walks you through three steps and ticks each one off as you go.', 'ffl-filters' ) . '</li>';
		echo '<li>' . esc_html__( 'Turn on the filters your shoppers should see. Review any attributes that arrived hidden.', 'ffl-filters' ) . '</li>';
		echo '<li>' . esc_html__( 'Hide leftover terms, set the category tree, and pin merchandising tags if you need them.', 'ffl-filters' ) . '</li>';
		echo '<li>' . esc_html__( 'Pick a mobile mode and confirm the SEO flags match how you want filtered pages indexed.', 'ffl-filters' ) . '</li>';
		echo '<li>' . esc_html__( 'Review firearm presets: caliber synonyms, numeric ranges, the Firearm type label, and the In store tag.', 'ffl-filters' ) . '</li>';
		echo '<li>' . esc_html__( 'Export a JSON backup from the Import tab before you experiment.', 'ffl-filters' ) . '</li>';
		echo '</ol>';
		echo '<h3>' . esc_html__( 'When something looks wrong', 'ffl-filters' ) . '</h3>';
		echo '<p>' . esc_html__( 'The Health tab shows WooCommerce lookup-table status, cache generation, a slow-query log, and a Why isn\'t this product showing lookup. Start there for cache plugins, WooCommerce filter blocks, block themes, a missing attributes lookup table, or a huge attribute.', 'ffl-filters' ) . ' ';
		echo '<a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG . '&tab=health' ) ) . '">' . esc_html__( 'Open the Health tab', 'ffl-filters' ) . '</a></p>';
		$this->render_lead_card();
	}



	/**
	 * Render slug picker.
	 *
	 * @param string                                                  $name  Input name.
	 * @param string                                                  $tax   Taxonomy for search.
	 * @param array<int, string>                                      $slugs Selected slugs.
	 * @param string                                                  $label Visible label.
	 * @param bool                                                    $labels Whether rows store custom labels (pinned tags).
	 * @param array<int, array{slug?: string, label?: string}|string> $rows  Optional label map.
	 * @return void
	 */
	private function render_slug_picker( $name, $tax, $slugs, $label, $labels = false, $rows = array() ) {
		$map = array();
		foreach ( $rows as $row ) {
			if ( is_array( $row ) && ! empty( $row['slug'] ) ) {
				$map[ (string) $row['slug'] ] = isset( $row['label'] ) ? (string) $row['label'] : (string) $row['slug'];
			}
		}
		$search_id = 'fflf-picker-' . substr( md5( $name ), 0, 10 );
		echo '<div class="fflf-picker" data-fflf-picker data-taxonomy="' . esc_attr( $tax ) . '" data-name="' . esc_attr( $name ) . '" data-labels="' . ( $labels ? '1' : '0' ) . '">';
		echo '<label class="fflf-picker__label" for="' . esc_attr( $search_id ) . '">' . esc_html( $label ) . '</label>';
		echo '<div class="fflf-picker__chips">';
		foreach ( $slugs as $index => $slug ) {
			$slug  = (string) $slug;
			$index = (int) $index;
			$term  = $this->term_name( $tax, $slug );
			/* translators: %s: term name */
			$remove = sprintf( __( 'Remove %s', 'ffl-filters' ), $term );
			if ( $labels ) {
				$custom = isset( $map[ $slug ] ) ? $map[ $slug ] : $term;
				echo '<span class="fflf-picker__chip"><input type="hidden" name="' . esc_attr( $name ) . '[' . esc_attr( (string) $index ) . '][slug]" value="' . esc_attr( $slug ) . '" />';
				echo '<span class="fflf-picker__name">' . esc_html( $term ) . '</span> ';
				/* translators: %s: term name */
				echo '<input type="text" aria-label="' . esc_attr( sprintf( __( 'Label for %s', 'ffl-filters' ), $term ) ) . '" name="' . esc_attr( $name ) . '[' . esc_attr( (string) $index ) . '][label]" value="' . esc_attr( $custom ) . '" />';
			} else {
				echo '<span class="fflf-picker__chip"><input type="hidden" name="' . esc_attr( $name ) . '[]" value="' . esc_attr( $slug ) . '" />';
				echo '<span class="fflf-picker__name">' . esc_html( $term ) . '</span>';
			}
			echo ' <button type="button" class="fflf-picker__remove" data-fflf-remove aria-label="' . esc_attr( $remove ) . '">&times;</button></span>';
		}
		echo '</div>';
		echo '<input type="search" id="' . esc_attr( $search_id ) . '" class="fflf-picker__search" placeholder="' . esc_attr__( 'Search terms…', 'ffl-filters' ) . '" autocomplete="off" />';
		echo '<div class="fflf-picker__results" hidden></div>';
		echo '</div>';
	}

	/**
	 * Term name for a slug, falling back to the slug.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @param string $slug     Slug.
	 * @return string
	 */
	private function term_name( $taxonomy, $slug ) {
		if ( function_exists( 'get_term_by' ) && taxonomy_exists( $taxonomy ) ) {
			$term = get_term_by( 'slug', $slug, $taxonomy );
			if ( $term instanceof \WP_Term ) {
				return (string) $term->name;
			}
		}
		return $slug;
	}

	/**
	 * Render notice.
	 *
	 * @param string $code Notice code.
	 * @return void
	 */
	private function render_notice( $code ) {
		$map = array(
			'saved'               => __( 'Settings saved.', 'ffl-filters' ),
			'imported'            => __( 'Your settings were imported from the backup file.', 'ffl-filters' ),
			'import_error'        => __( "We couldn't import that file. Make sure it's a backup saved from FFL Filters, then try again.", 'ffl-filters' ),
			'reset'               => __( 'Settings were reset to defaults.', 'ffl-filters' ),
			'flushed'             => __( 'Filter cache generation bumped.', 'ffl-filters' ),
			'slow_cleared'        => __( 'Slow-query log cleared.', 'ffl-filters' ),
			'lead_sent'           => __( 'Your request was recorded here. Finish sending it on the Coriolis page if that tab is still open.', 'ffl-filters' ),
			'lead_skipped'        => __( 'Skipped. You can contact Coriolis later from the Help tab.', 'ffl-filters' ),
			'lead_forgotten'      => __( 'The local Coriolis contact record was removed from this site.', 'ffl-filters' ),
			'lead_error'          => __( 'Please complete the required fields and tick the consent box before sending.', 'ffl-filters' ),
			'wizard'              => __( 'Setup complete. You can change these options any time.', 'ffl-filters' ),
			'cpf_imported'        => __( 'Settings from your previous filter plugin were imported. Preview the storefront, then switch when you are ready.', 'ffl-filters' ),
			'cpf_switched'        => __( 'Your previous filter plugin was deactivated. FFL Filters is now serving the catalog. You can switch back for 30 days if the old plugin folder is still installed.', 'ffl-filters' ),
			'cpf_preview'         => __( 'Preview is on. You will see FFL Filters on the storefront; everyone else still sees your previous filter plugin.', 'ffl-filters' ),
			'cpf_preview_off'     => __( 'Storefront preview is off.', 'ffl-filters' ),
			'cpf_rolled'          => __( 'Your previous filter plugin was reactivated and FFL Filters was deactivated.', 'ffl-filters' ),
			'cpf_cleaned'         => __( 'Leftover settings from your previous filter plugin were removed.', 'ffl-filters' ),
			'cpf_cleanup_blocked' => __( 'Your previous filter plugin is still installed. Delete that plugin first, then clean up leftover data.', 'ffl-filters' ),
			'cpf_switch_denied'   => __( 'You need permission to activate plugins to switch or roll back.', 'ffl-filters' ),
		);
		if ( ! isset( $map[ $code ] ) ) {
			return;
		}
		$class = in_array( $code, array( 'import_error', 'cpf_cleanup_blocked', 'cpf_switch_denied', 'lead_error' ), true ) ? 'notice-error' : 'notice-success';
		echo '<div class="notice ' . esc_attr( $class ) . ' is-dismissible"><p>' . esc_html( $map[ $code ] ) . '</p></div>';
	}

	/**
	 * Assert post.
	 *
	 * @param string $action Nonce action / admin-post action.
	 * @return void
	 */
	private function assert_post( $action ) {
		if ( ! $this->user_can() ) {
			wp_die( esc_html__( 'You do not have permission to manage FFL Filters.', 'ffl-filters' ) );
		}
		check_admin_referer( $action, 'fflf_nonce' );
	}

	/**
	 * Redirect.
	 *
	 * @param string               $notice Notice code.
	 * @param array<string, mixed> $args   Optional tab or view overrides.
	 * @return void
	 */
	private function redirect( $notice, $args = array() ) {
		$tab = isset( $_POST['fflf_tab'] ) ? sanitize_key( wp_unslash( $_POST['fflf_tab'] ) ) : 'filters'; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( isset( $args['tab'] ) ) {
			$tab = sanitize_key( (string) $args['tab'] );
		}
		if ( 'performance' === $tab ) {
			$tab = 'health';
		}
		if ( ! in_array( $tab, self::TABS, true ) ) {
			$tab = 'filters';
		}
		$url = admin_url( 'admin.php?page=' . self::SLUG . '&tab=' . $tab );
		if ( $notice ) {
			$url = add_query_arg( 'fflf_notice', $notice, $url );
		}
		if ( ! empty( $args['view'] ) ) {
			$url = add_query_arg( 'fflf_view', sanitize_key( (string) $args['view'] ), $url );
		}
		wp_safe_redirect( $url );
		exit;
	}

	/**
	 * Current tab.
	 *
	 * @return string
	 */
	public function current_tab() {
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'welcome'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( 'performance' === $tab ) {
			return 'health';
		}
		return in_array( $tab, self::TABS, true ) ? $tab : 'welcome';
	}


	/**
	 * User can.
	 *
	 * @return bool
	 */
	private function user_can() {
		return current_user_can( 'manage_woocommerce' ) || current_user_can( 'manage_options' );
	}

	/**
	 * Type labels.
	 *
	 * @param string $forced If locked, only this type.
	 * @return array<string, string>
	 */
	private function type_labels( $forced ) {
		$all = array(
			'checkbox' => __( 'Checkboxes', 'ffl-filters' ),
			'range'    => __( 'Range', 'ffl-filters' ),
			'toggle'   => __( 'Toggle', 'ffl-filters' ),
			'price'    => __( 'Price', 'ffl-filters' ),
			'instock'  => __( 'In stock', 'ffl-filters' ),
		);
		if ( '' !== $forced && isset( $all[ $forced ] ) ) {
			return array( $forced => $all[ $forced ] );
		}
		unset( $all['price'], $all['instock'] );
		return $all;
	}

	/**
	 * Term count.
	 *
	 * @param string $taxonomy Taxonomy or facet id.
	 * @return int
	 */
	private function term_count( $taxonomy ) {
		if ( in_array( $taxonomy, array( 'price', 'instock' ), true ) || ! function_exists( 'wp_count_terms' ) ) {
			return 0;
		}
		$count = wp_count_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
			)
		);
		return is_wp_error( $count ) ? 0 : (int) $count;
	}

	/**
	 * Large threshold.
	 *
	 * @return int
	 */
	private function large_threshold() {
		$n = 50;
		if ( function_exists( 'apply_filters' ) ) {
			/**
			 * Filters the term-count threshold that asks for confirmation before enabling a facet.
			 *
			 * @since 0.0.1
			 * @param int $n Term count.
			 */
			$n = (int) apply_filters( 'fflf_large_facet_threshold', $n );
		}
		return $n > 0 ? $n : 50;
	}
}
