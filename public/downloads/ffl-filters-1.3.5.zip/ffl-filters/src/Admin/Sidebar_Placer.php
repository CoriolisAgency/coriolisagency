<?php
/**
 * One-click placement of the FFL Filters block in the shop sidebar.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Admin;

use FFL_Filters\Panel\Placement;

defined( 'ABSPATH' ) || exit;

/**
 * Adds one block widget to the theme's shop sidebar, and removes only that widget on undo.
 */
class Sidebar_Placer {

	/**
	 * Option that records the widget this button added.
	 *
	 * @var string
	 */
	const OPTION = 'fflf_sidebar_placement';

	/**
	 * Block markup stored in the widget.
	 *
	 * @var string
	 */
	const BLOCK_MARKUP = '<!-- wp:ffl-filters/panel /-->';

	/**
	 * The shop sidebar id, or '' when the theme has none we can use (block theme, no widget areas).
	 *
	 * @return string
	 */
	public function shop_sidebar() {
		if ( self::is_block_theme() ) {
			return '';
		}

		global $wp_registered_sidebars;
		$sidebars = is_array( $wp_registered_sidebars ) ? $wp_registered_sidebars : array();
		$picked   = '';

		foreach ( $sidebars as $id => $sidebar ) {
			$haystack = strtolower( (string) $id . ' ' . ( isset( $sidebar['name'] ) ? (string) $sidebar['name'] : '' ) );
			if ( preg_match( '/shop|woocommerce|product/', $haystack ) ) {
				$picked = (string) $id;
				break;
			}
		}

		if ( '' === $picked ) {
			foreach ( array( 'sidebar-primary', 'sidebar-1', 'sidebar', 'primary-sidebar' ) as $id ) {
				if ( isset( $sidebars[ $id ] ) ) {
					$picked = $id;
					break;
				}
			}
		}

		/**
		 * Filters the widget area the Add to my shop sidebar button uses. Return '' to show the written steps instead.
		 *
		 * @since 1.1.0
		 * @param string $picked   Sidebar id, or ''.
		 * @param array  $sidebars Registered sidebars.
		 */
		$picked = (string) apply_filters( 'fflf_shop_sidebar_id', $picked, $sidebars );

		return ( '' !== $picked && isset( $sidebars[ $picked ] ) ) ? $picked : '';
	}

	/**
	 * Whether the active theme is a block theme (no Widgets screen).
	 *
	 * @return bool
	 */
	public static function is_block_theme() {
		$block = function_exists( 'wp_is_block_theme' ) && wp_is_block_theme();
		/**
		 * Filters whether FFL Filters treats the active theme as a block theme on the Welcome tab.
		 *
		 * @since 1.1.0
		 * @param bool $block Whether the theme is a block theme.
		 */
		return (bool) apply_filters( 'fflf_is_block_theme', $block );
	}

	/**
	 * Human name of a registered sidebar.
	 *
	 * @param string $id Sidebar id.
	 * @return string
	 */
	public function sidebar_name( $id ) {
		global $wp_registered_sidebars;
		if ( is_array( $wp_registered_sidebars ) && isset( $wp_registered_sidebars[ $id ]['name'] ) ) {
			return (string) $wp_registered_sidebars[ $id ]['name'];
		}
		return (string) $id;
	}

	/**
	 * Whether one-click placement can run on this site.
	 *
	 * @return bool
	 */
	public function supported() {
		return '' !== $this->shop_sidebar();
	}

	/**
	 * Whether the panel is already in any active widget area.
	 *
	 * @return bool
	 */
	public function already_placed() {
		return Placement::in_widgets();
	}

	/**
	 * The widget this button added, if it is still in place.
	 *
	 * @return array{widget_id: string, sidebar: string, at: int}|null
	 */
	public function added() {
		$stored = get_option( self::OPTION, null );
		if ( ! is_array( $stored ) || empty( $stored['widget_id'] ) || empty( $stored['sidebar'] ) ) {
			return null;
		}
		$sidebars = get_option( 'sidebars_widgets', array() );
		$sidebar  = (string) $stored['sidebar'];
		if ( ! is_array( $sidebars ) || ! isset( $sidebars[ $sidebar ] ) || ! is_array( $sidebars[ $sidebar ] ) || ! in_array( (string) $stored['widget_id'], $sidebars[ $sidebar ], true ) ) {
			return null;
		}
		return array(
			'widget_id' => (string) $stored['widget_id'],
			'sidebar'   => $sidebar,
			'at'        => isset( $stored['at'] ) ? (int) $stored['at'] : 0,
		);
	}

	/**
	 * Add the block widget to the top of the shop sidebar.
	 *
	 * @return string One of: added, exists, unsupported.
	 */
	public function add() {
		$sidebar = $this->shop_sidebar();
		if ( '' === $sidebar ) {
			return 'unsupported';
		}
		Placement::reset();
		if ( $this->already_placed() ) {
			return 'exists';
		}

		$instances = get_option( 'widget_block', array() );
		if ( ! is_array( $instances ) ) {
			$instances = array();
		}
		$numbers = array_filter( array_keys( $instances ), 'is_int' );
		$number  = $numbers ? max( $numbers ) + 1 : 2;
		if ( $number < 2 ) {
			$number = 2;
		}
		$instances[ $number ] = array( 'content' => self::BLOCK_MARKUP );
		if ( ! isset( $instances['_multiwidget'] ) ) {
			$instances['_multiwidget'] = 1;
		}
		update_option( 'widget_block', $instances );

		$widget_id = 'block-' . $number;
		$sidebars  = get_option( 'sidebars_widgets', array() );
		if ( ! is_array( $sidebars ) ) {
			$sidebars = array();
		}
		$current = isset( $sidebars[ $sidebar ] ) && is_array( $sidebars[ $sidebar ] ) ? $sidebars[ $sidebar ] : array();
		array_unshift( $current, $widget_id );
		$sidebars[ $sidebar ] = array_values( $current );
		update_option( 'sidebars_widgets', $sidebars );

		update_option(
			self::OPTION,
			array(
				'widget_id' => $widget_id,
				'sidebar'   => $sidebar,
				'at'        => time(),
			),
			false
		);

		Placement::reset();
		return 'added';
	}

	/**
	 * Remove only the widget this button added.
	 *
	 * @return bool Whether a widget was removed.
	 */
	public function undo() {
		$stored = get_option( self::OPTION, null );
		delete_option( self::OPTION );
		if ( ! is_array( $stored ) || empty( $stored['widget_id'] ) ) {
			return false;
		}
		$widget_id = (string) $stored['widget_id'];
		if ( ! preg_match( '/^block-(\d+)$/', $widget_id, $m ) ) {
			return false;
		}

		$removed  = false;
		$sidebars = get_option( 'sidebars_widgets', array() );
		if ( is_array( $sidebars ) ) {
			foreach ( $sidebars as $id => $widgets ) {
				if ( ! is_array( $widgets ) ) {
					continue;
				}
				$kept = array_values( array_diff( $widgets, array( $widget_id ) ) );
				if ( count( $kept ) !== count( $widgets ) ) {
					$sidebars[ $id ] = $kept;
					$removed         = true;
				}
			}
			if ( $removed ) {
				update_option( 'sidebars_widgets', $sidebars );
			}
		}

		$instances = get_option( 'widget_block', array() );
		$number    = (int) $m[1];
		if ( is_array( $instances ) && isset( $instances[ $number ]['content'] ) && self::BLOCK_MARKUP === trim( (string) $instances[ $number ]['content'] ) ) {
			unset( $instances[ $number ] );
			update_option( 'widget_block', $instances );
		}

		Placement::reset();
		return $removed;
	}
}
