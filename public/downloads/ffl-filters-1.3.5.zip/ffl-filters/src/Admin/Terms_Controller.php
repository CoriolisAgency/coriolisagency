<?php
/**
 * REST term search for the settings term picker.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Admin-only term search. Storefront never talks to this endpoint.
 */
class Terms_Controller {

	/**
	 * Route namespace.
	 *
	 * @var string
	 */
	const NAMESPACE = 'ffl-filters/v1';

	/**
	 * Register the route.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'rest_api_init', array( $this, 'register_route' ) );
	}

	/**
	 * Register GET /ffl-filters/v1/terms.
	 *
	 * @return void
	 */
	public function register_route() {
		register_rest_route(
			self::NAMESPACE,
			'/terms',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'search' ),
				'permission_callback' => array( $this, 'permissions' ),
				'args'                => array(
					'taxonomy' => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_key',
					),
					'search'   => array(
						'required'          => false,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);
	}

	/**
	 * Shop managers and admins only.
	 *
	 * @return bool
	 */
	public function permissions() {
		return current_user_can( 'manage_woocommerce' ) || current_user_can( 'manage_options' );
	}

	/**
	 * Search terms for the hidden-term / pinned-tag / category pickers.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function search( $request ) {
		$taxonomy = (string) $request->get_param( 'taxonomy' );
		$search   = (string) $request->get_param( 'search' );

		if ( '' === $taxonomy || ! taxonomy_exists( $taxonomy ) ) {
			return new \WP_Error( 'fflf_bad_taxonomy', __( 'Unknown taxonomy.', 'ffl-filters' ), array( 'status' => 400 ) );
		}

		$args = array(
			'taxonomy'   => $taxonomy,
			'hide_empty' => false,
			'number'     => 20,
			'orderby'    => 'name',
			'order'      => 'ASC',
		);
		if ( '' !== $search ) {
			$args['search'] = $search;
		}

		$found = get_terms( $args );
		if ( is_wp_error( $found ) ) {
			return $found;
		}

		$out = array();
		foreach ( $found as $term ) {
			$out[] = array(
				'slug'  => (string) $term->slug,
				'label' => (string) $term->name,
				'count' => (int) $term->count,
			);
		}

		return rest_ensure_response( $out );
	}
}
