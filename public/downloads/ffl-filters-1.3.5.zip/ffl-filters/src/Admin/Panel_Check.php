<?php
/**
 * Checks whether the filter panel shows on the Shop page (Welcome step 1).
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Admin-side check only. The storefront never writes anything for this.
 */
class Panel_Check {

	/**
	 * Option set once the panel has been found.
	 *
	 * @var string
	 */
	const OPTION = 'fflf_panel_seen';

	/**
	 * Short cache of a failed check so the Welcome tab does not refetch on every load.
	 *
	 * @var string
	 */
	const TRANSIENT = 'fflf_panel_check';

	/**
	 * Shop page URL.
	 *
	 * @return string
	 */
	public function shop_url() {
		$url = function_exists( 'wc_get_page_permalink' ) ? (string) wc_get_page_permalink( 'shop' ) : '';
		if ( '' === $url ) {
			$url = home_url( '/' );
		}
		return $url;
	}

	/**
	 * Drop a cached "not found" so the next check fetches the Shop page again.
	 *
	 * @return void
	 */
	public function forget_failure() {
		delete_transient( self::TRANSIENT );
	}

	/**
	 * Whether the panel has been found on the Shop page.
	 *
	 * @param bool $allow_fetch Whether a loopback fetch may run now.
	 * @return bool
	 */
	public function detected( $allow_fetch = true ) {
		/**
		 * Short-circuits the Welcome step 1 check. Return true or false to skip the Shop page fetch.
		 *
		 * @since 1.1.0
		 * @param bool|null $pre Null to run the normal check.
		 */
		$pre = apply_filters( 'fflf_pre_panel_detected', null );
		if ( null !== $pre ) {
			return (bool) $pre;
		}

		if ( get_option( self::OPTION ) ) {
			return true;
		}
		if ( ! $allow_fetch || false !== get_transient( self::TRANSIENT ) ) {
			return false;
		}

		$found    = false;
		$response = wp_remote_get(
			$this->shop_url(),
			array(
				'timeout'     => 8,
				'redirection' => 3,
				'headers'     => array( 'Cache-Control' => 'no-cache' ),
			)
		);
		if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
			$found = false !== strpos( (string) wp_remote_retrieve_body( $response ), 'data-fflf-panel' );
		}

		if ( $found ) {
			update_option( self::OPTION, time(), false );
			return true;
		}
		set_transient( self::TRANSIENT, 0, 10 * MINUTE_IN_SECONDS );
		return false;
	}
}
