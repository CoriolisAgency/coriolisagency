<?php
/**
 * Detects other product-filter plugins, widgets and blocks.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Finds filter tools that can put a second set of filters on the shop page.
 */
class Conflicts {

	/**
	 * Legacy WooCommerce filter widget id bases.
	 *
	 * @var array<int, string>
	 */
	const WOO_WIDGETS = array( 'woocommerce_layered_nav', 'woocommerce_layered_nav_filters', 'woocommerce_price_filter', 'woocommerce_rating_filter' );

	/**
	 * WooCommerce filter block names (Product Filters and the older filter blocks).
	 *
	 * @var array<int, string>
	 */
	const WOO_BLOCKS = array( 'woocommerce/product-filters', 'woocommerce/product-filter', 'woocommerce/attribute-filter', 'woocommerce/price-filter', 'woocommerce/stock-filter', 'woocommerce/rating-filter', 'woocommerce/active-filters', 'woocommerce/filter-wrapper' );

	/**
	 * Known filter plugins: basename prefix => [short name, full name].
	 *
	 * @return array<string, array{short: string, name: string}>
	 */
	public function known_plugins() {
		$plugins = array(
			'woocommerce-products-filter/'      => array(
				'short' => 'HUSKY',
				'name'  => 'HUSKY (WooCommerce Product Filter by HUSKY)',
			),
			'yith-woocommerce-ajax-navigation/' => array(
				'short' => 'YITH WooCommerce Ajax Product Filter',
				'name'  => 'YITH WooCommerce Ajax Product Filter',
			),
			'yith-woocommerce-ajax-product-filter-premium/' => array(
				'short' => 'YITH WooCommerce Ajax Product Filter Premium',
				'name'  => 'YITH WooCommerce Ajax Product Filter Premium',
			),
		);

		/**
		 * Filters the list of other filter plugins FFL Filters looks for.
		 *
		 * @since 1.1.0
		 * @param array<string, array{short: string, name: string}> $plugins Basename prefix => names.
		 */
		$filtered = apply_filters( 'fflf_conflicting_filter_plugins', $plugins );
		return is_array( $filtered ) ? $filtered : $plugins;
	}

	/**
	 * Everything found, in display order.
	 *
	 * @return array<int, array{type: string, short: string, name: string, basename: string}>
	 */
	public function found() {
		$found  = array();
		$active = $this->active_plugins();
		foreach ( $this->known_plugins() as $prefix => $names ) {
			foreach ( $active as $basename ) {
				if ( 0 === strpos( $basename, (string) $prefix ) ) {
					$found[] = array(
						'type'     => 'plugin',
						'short'    => isset( $names['short'] ) ? (string) $names['short'] : (string) $prefix,
						'name'     => isset( $names['name'] ) ? (string) $names['name'] : (string) $prefix,
						'basename' => $basename,
					);
					break;
				}
			}
		}

		if ( $this->woo_filters_in_widgets() ) {
			$found[] = array(
				'type'     => 'widgets',
				'short'    => __( "WooCommerce's own filter widgets and blocks", 'ffl-filters' ),
				'name'     => __( "WooCommerce's own filter widgets and blocks", 'ffl-filters' ),
				'basename' => '',
			);
		}

		return $found;
	}

	/**
	 * Active plugin basenames (site and network).
	 *
	 * @return array<int, string>
	 */
	private function active_plugins() {
		$list = (array) get_option( 'active_plugins', array() );
		if ( function_exists( 'is_multisite' ) && is_multisite() ) {
			$network = (array) get_site_option( 'active_sitewide_plugins', array() );
			$list    = array_merge( $list, array_keys( $network ) );
		}
		return array_values( array_map( 'strval', $list ) );
	}

	/**
	 * Whether an active widget area holds a WooCommerce filter widget or block.
	 *
	 * @return bool
	 */
	public function woo_filters_in_widgets() {
		$sidebars = get_option( 'sidebars_widgets' );
		if ( ! is_array( $sidebars ) ) {
			return false;
		}
		foreach ( $sidebars as $sidebar => $widgets ) {
			if ( 'wp_inactive_widgets' === $sidebar || ! is_array( $widgets ) ) {
				continue;
			}
			foreach ( $widgets as $widget_id ) {
				if ( ! preg_match( '/^(.+)-(\d+)$/', (string) $widget_id, $m ) ) {
					continue;
				}
				if ( in_array( $m[1], self::WOO_WIDGETS, true ) ) {
					return true;
				}
				if ( 'block' !== $m[1] ) {
					continue;
				}
				$blocks = get_option( 'widget_block' );
				$number = (int) $m[2];
				if ( is_array( $blocks ) && isset( $blocks[ $number ]['content'] ) && $this->has_woo_filter_block( (string) $blocks[ $number ]['content'] ) ) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Whether block markup contains a WooCommerce filter block.
	 *
	 * @param string $content Block markup.
	 * @return bool
	 */
	public function has_woo_filter_block( $content ) {
		foreach ( self::WOO_BLOCKS as $name ) {
			if ( preg_match( '/<!--\s+wp:' . preg_quote( $name, '/' ) . '[\s\/]/', $content ) ) {
				return true;
			}
		}
		return false;
	}
}
