<?php
/**
 * Admin warning when a physical robots.txt would hide the filter Disallow block.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Admin;

use FFL_Filters\Seo\Controller as Seo_Controller;

defined( 'ABSPATH' ) || exit;

/**
 * Shows copy-paste Disallow lines when WordPress cannot append to robots.txt.
 *
 * WordPress only fires the robots_txt filter for a virtual robots.txt. A
 * file at the site root is served as-is, so the product-filter Disallow
 * block never reaches crawlers unless the dealer adds it by hand.
 */
class Physical_Robots_Notice {

	/**
	 * Option that records a dealer dismissal.
	 *
	 * @var string
	 */
	const OPTION = 'fflf_dismiss_physical_robots_notice';

	/**
	 * Query arg used by the dismiss link.
	 *
	 * @var string
	 */
	const DISMISS_ARG = 'fflf_dismiss_physical_robots';

	/**
	 * Hook the notice and the dismiss handler.
	 *
	 * @return void
	 */
	public function register() {
		if ( function_exists( 'fflf_is_passive' ) ? fflf_is_passive() : ( function_exists( 'fflf_compare_plugin_is_active' ) && fflf_compare_plugin_is_active() ) ) {
			return;
		}

		add_action( 'admin_init', array( $this, 'maybe_dismiss' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
		add_action( 'admin_notices', array( $this, 'render' ) );
	}

	/**
	 * Persist a dismissal.
	 *
	 * @return void
	 */
	public function maybe_dismiss() {
		if ( ! isset( $_GET[ self::DISMISS_ARG ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		if ( ! $this->user_can_see() ) {
			return;
		}
		check_admin_referer( self::DISMISS_ARG );
		update_option( self::OPTION, '1', false );

		$target = function_exists( 'wp_get_referer' ) ? wp_get_referer() : '';
		if ( ! is_string( $target ) || '' === $target ) {
			$target = admin_url( 'plugins.php' );
		}
		if ( function_exists( 'wp_safe_redirect' ) ) {
			wp_safe_redirect( $target );
			exit;
		}
	}

	/**
	 * Enqueue notice tokens and the official small icon only on plugin screens.
	 *
	 * @param string $hook Current admin hook.
	 * @return void
	 */
	public function enqueue( $hook = '' ) {
		if ( ! $this->should_display() ) {
			return;
		}
		if ( ! in_array( $hook, array( 'plugins.php', 'index.php' ), true ) ) {
			return;
		}
		if ( ! function_exists( 'wp_enqueue_style' ) ) {
			return;
		}

		$base = defined( 'FFLF_URL' ) ? FFLF_URL : '';
		$ver  = defined( 'FFLF_VERSION' ) ? FFLF_VERSION : '0.0.1';
		$path = ( defined( 'FFLF_DIR' ) ? FFLF_DIR : '' ) . 'assets/css/admin-notice.css';

		wp_enqueue_style(
			'fflf-filters-admin-notice',
			$base . 'assets/css/admin-notice.css',
			array(),
			is_readable( $path ) ? (string) filemtime( $path ) : $ver
		);
	}

	/**
	 * Print the warning with copy-paste robots lines.
	 *
	 * @return void
	 */
	public function render() {
		if ( ! $this->should_display() ) {
			return;
		}

		$icon    = ( defined( 'FFLF_URL' ) ? FFLF_URL : '' ) . 'assets/images/ffl-filters-icon-small.svg';
		$dismiss = wp_nonce_url( add_query_arg( self::DISMISS_ARG, '1' ), self::DISMISS_ARG );
		$lines   = $this->copy_paste_block();

		echo '<div class="notice notice-warning fflf-physical-robots-notice">';
		echo '<div class="fflf-physical-robots-notice__inner">';
		echo '<img class="fflf-physical-robots-notice__icon" src="' . esc_url( $icon ) . '" width="32" height="32" alt="" />';
		echo '<div class="fflf-physical-robots-notice__body">';
		echo '<p><strong>' . esc_html__( "FFL Filters can't add its lines to robots.txt because your site has its own robots.txt file.", 'ffl-filters' ) . '</strong></p>';
		echo '<p>' . esc_html__( 'Add these lines to that file so search engines skip filtered shop pages and the filter data files.', 'ffl-filters' ) . '</p>';
		echo '<pre class="fflf-physical-robots-notice__code">' . esc_html( $lines ) . '</pre>';
		echo '<p><a href="' . esc_url( $dismiss ) . '">' . esc_html__( 'Dismiss this notice', 'ffl-filters' ) . '</a></p>';
		echo '</div></div></div>';
	}

	/**
	 * Lines a dealer can paste into a physical robots.txt.
	 *
	 * @return string
	 */
	public function copy_paste_block() {
		$seo   = new Seo_Controller();
		$block = "# Product filter URLs\nUser-agent: *\n";
		foreach ( $seo->disallow_paths() as $path ) {
			$block .= 'Disallow: ' . $path . "\n";
		}
		$block .= "Disallow: /ffl-filters/\n";
		return $block;
	}

	/**
	 * Whether a physical robots.txt exists at the WordPress root.
	 *
	 * @return bool
	 */
	public function has_physical_robots() {
		if ( ! defined( 'ABSPATH' ) ) {
			return false;
		}
		$path = ABSPATH . 'robots.txt';
		return is_file( $path ) && is_readable( $path );
	}

	/**
	 * Whether the notice should show on this request.
	 *
	 * @return bool
	 */
	public function should_display() {
		if ( ! $this->user_can_see() ) {
			return false;
		}
		if ( get_option( self::OPTION ) ) {
			return false;
		}
		if ( ! $this->is_target_screen() ) {
			return false;
		}
		return $this->has_physical_robots();
	}

	/**
	 * Whether the current user can manage the notice.
	 *
	 * @return bool
	 */
	private function user_can_see() {
		return function_exists( 'current_user_can' ) && current_user_can( 'manage_options' );
	}

	/**
	 * Plugins screen or Dashboard only.
	 *
	 * @return bool
	 */
	private function is_target_screen() {
		if ( ! function_exists( 'get_current_screen' ) ) {
			return false;
		}
		$screen = get_current_screen();
		if ( ! $screen ) {
			return false;
		}
		return in_array( $screen->id, array( 'plugins', 'dashboard' ), true );
	}
}
