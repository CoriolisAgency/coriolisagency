<?php
/**
 * Plugin bootstrap.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters;

/**
 * Main plugin controller.
 */
class Plugin {

	/**
	 * Wire hooks once WooCommerce is present.
	 *
	 * @return void
	 */
	public function init() {
		$repository  = new Cache\Repository();
		$invalidator = new Cache\Invalidator( $repository->generation() );
		$invalidator->register();

		$resolver = new Query\Term_Resolver( $repository );
		$builder  = new Query\Clause_Builder( $resolver );
		$engine   = new Query\Query_Engine( null, $builder, $repository );
		$engine->register();

		$urls = new Url\Controller();
		$urls->register();

		$panel = new Panel\Controller( $repository, $builder );
		$panel->register();

		$shortcode = new Panel\Shortcode( $panel );
		$shortcode->register();

		$block = new Panel\Block( $panel );
		$block->register();

		$seo = new Seo\Controller();
		$seo->register();

		$robots_notice = new Admin\Physical_Robots_Notice();
		$robots_notice->register();

		$settings = new Settings\Repository();
		$seed     = new Settings\Seed( $settings );
		$seed->register();

		$page = new Admin\Page( $settings );
		$page->register();

		$onboarding = new Admin\Onboarding();
		$onboarding->register();

		$privacy = new Lead\Privacy();
		$privacy->register();

		$terms = new Admin\Terms_Controller();
		$terms->register();

		$preview = new Import\Preview();
		$preview->register();

		$notice = new Import\Notice();
		$notice->register();

		if ( ! function_exists( 'fflf_is_passive' ) || ! fflf_is_passive() ) {
			( new Import\Shim() )->register();
		}

		$this->register_cli( $repository );
	}

	/**
	 * Register `wp fflf cache` when WP-CLI is running.
	 *
	 * @param Cache\Repository $repository Shared repository.
	 * @return void
	 */
	private function register_cli( Cache\Repository $repository ) {
		if ( ! defined( 'WP_CLI' ) || ! WP_CLI || ! class_exists( '\WP_CLI' ) ) {
			return;
		}

		\WP_CLI::add_command(
			'fflf cache',
			new Cache\CLI_Command( $repository->generation(), $repository->store() )
		);
	}
}
