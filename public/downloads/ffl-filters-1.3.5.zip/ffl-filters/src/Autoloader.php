<?php
/**
 * PSR-4 autoloader used when Composer vendor is not present.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters;

/**
 * Loads plugin classes from src/.
 */
class Autoloader {

	/**
	 * Register the autoloader.
	 *
	 * @return void
	 */
	public static function register() {
		spl_autoload_register( array( self::class, 'load' ) );
	}

	/**
	 * Load a class file if it belongs to this namespace.
	 *
	 * @param string $class_name Fully qualified class name.
	 * @return void
	 */
	public static function load( $class_name ) {
		$prefix = __NAMESPACE__ . '\\';

		if ( strncmp( $prefix, $class_name, strlen( $prefix ) ) !== 0 ) {
			return;
		}

		$relative = str_replace( '\\', '/', substr( $class_name, strlen( $prefix ) ) );
		$file     = dirname( __DIR__ ) . '/src/' . $relative . '.php';

		if ( is_readable( $file ) ) {
			require $file;
		}
	}
}
