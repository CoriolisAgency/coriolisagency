<?php
/**
 * DONOTCACHE headers for filtered URLs.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Url;

defined( 'ABSPATH' ) || exit;

/**
 * Marks filtered views uncacheable for WP Engine and other page caches.
 */
class Cache_Headers {

	/**
	 * Cache-Control value measured as the desired contract for filtered views.
	 *
	 * @var string
	 */
	const CACHE_CONTROL = 'no-cache, must-revalidate, max-age=0, no-store, private';

	/**
	 * Define DONOTCACHEPAGE when a request has effective filters.
	 *
	 * @return void
	 */
	public function flag() {
		if ( defined( 'DONOTCACHEPAGE' ) ) {
			return;
		}
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedConstantFound -- WP Engine / page-cache contract.
		define( 'DONOTCACHEPAGE', true );
	}

	/**
	 * Send nocache headers, including no-store and private.
	 *
	 * @return void
	 */
	public function send() {
		$this->flag();
		if ( function_exists( 'nocache_headers' ) ) {
			nocache_headers();
		}
		if ( ! headers_sent() ) {
			header( 'Cache-Control: ' . self::CACHE_CONTROL );
			header( 'Pragma: no-cache' );
		}
	}

	/**
	 * Merge nocache values into the WP headers array.
	 *
	 * @param array $headers Headers.
	 * @return array
	 */
	public function filter_headers( $headers ) {
		if ( ! is_array( $headers ) ) {
			$headers = array();
		}
		$this->flag();
		$headers['Cache-Control'] = self::CACHE_CONTROL;
		$headers['Pragma']        = 'no-cache';
		$headers['Expires']       = 'Wed, 11 Jan 1984 05:00:00 GMT';
		return $headers;
	}
}
