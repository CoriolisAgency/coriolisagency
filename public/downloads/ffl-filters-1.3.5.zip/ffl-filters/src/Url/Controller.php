<?php
/**
 * Front-end URL contract: normalize, 301, and DONOTCACHE.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Url;

defined( 'ABSPATH' ) || exit;

/**
 * Hooks template_redirect, send_headers and wp_headers.
 *
 * Passive while Coriolis Product Filters is active so the two never
 * double-redirect or double-flag DONOTCACHE.
 */
class Controller {

	/**
	 * Normalizer.
	 *
	 * @var Normalizer
	 */
	private $normalizer;

	/**
	 * Cache header helper.
	 *
	 * @var Cache_Headers
	 */
	private $headers;

	/**
	 * Constructor.
	 *
	 * @param Normalizer|null    $normalizer Normalizer.
	 * @param Cache_Headers|null $headers    Header helper.
	 */
	public function __construct( $normalizer = null, $headers = null ) {
		$this->normalizer = $normalizer ? $normalizer : new Normalizer();
		$this->headers    = $headers ? $headers : new Cache_Headers();
	}

	/**
	 * Register front-end hooks.
	 *
	 * @return void
	 */
	public function register() {
		if ( $this->compare_plugin_is_active() ) {
			return;
		}

		add_action( 'init', array( $this, 'maybe_flag_nocache' ), 0 );
		add_action( 'send_headers', array( $this, 'maybe_send_headers' ), PHP_INT_MAX );
		add_filter( 'wp_headers', array( $this, 'filter_headers' ), 999 );
		add_action( 'template_redirect', array( $this, 'maybe_redirect' ), 0 );
	}

	/**
	 * Define DONOTCACHEPAGE early when the request has effective filters.
	 *
	 * @return void
	 */
	public function maybe_flag_nocache() {
		if ( ! $this->should_handle() ) {
			return;
		}
		if ( $this->request_has_filters() ) {
			$this->headers->flag();
		}
	}

	/**
	 * Send nocache headers on filtered views.
	 *
	 * @return void
	 */
	public function maybe_send_headers() {
		if ( ! $this->should_handle() ) {
			return;
		}
		if ( $this->request_has_filters() ) {
			$this->headers->send();
		}
	}

	/**
	 * Add nocache values to the WP header list on filtered views.
	 *
	 * @param array $headers Headers.
	 * @return array
	 */
	public function filter_headers( $headers ) {
		if ( ! $this->should_handle() || ! $this->request_has_filters() ) {
			return $headers;
		}
		return $this->headers->filter_headers( $headers );
	}

	/**
	 * 301 to the canonical filter query when the current one is dirty.
	 *
	 * @return void
	 */
	public function maybe_redirect() {
		if ( ! $this->should_handle() ) {
			return;
		}

		$source   = $this->request_source();
		$location = $this->normalizer->redirect_url( $source, $this->request_path() );
		if ( '' === $location ) {
			return;
		}

		/**
		 * Filters the canonical filter-URL redirect location.
		 *
		 * Return an empty string to cancel the redirect (tests do this).
		 *
		 * @since 0.0.1
		 * @param string $location Absolute URL.
		 * @param array  $source   Request parameters.
		 */
		$location = (string) apply_filters( 'fflf_redirect_location', $location, $source );
		if ( '' === $location ) {
			return;
		}

		if ( function_exists( 'wp_safe_redirect' ) ) {
			wp_safe_redirect( $location, 301 );
		} elseif ( ! headers_sent() ) {
			header( 'Location: ' . $location, true, 301 );
		}

		if ( $this->is_wp_unit_test() ) {
			return;
		}
		exit;
	}

	/**
	 * Current request parameters, unslashed.
	 *
	 * @return array
	 */
	public function request_source() {
		$source = wp_unslash( $_GET ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return is_array( $source ) ? $source : array();
	}

	/**
	 * Path of the current request, with no query string.
	 *
	 * @return string
	 */
	public function request_path() {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '/'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		if ( function_exists( 'wp_parse_url' ) ) {
			$path = wp_parse_url( $uri, PHP_URL_PATH );
			if ( is_string( $path ) && '' !== $path ) {
				return $path;
			}
		}
		$qpos = strpos( $uri, '?' );
		return false === $qpos ? ( '' === $uri ? '/' : $uri ) : substr( $uri, 0, $qpos );
	}

	/**
	 * Whether the current request has effective filters.
	 *
	 * @return bool
	 */
	private function request_has_filters() {
		if ( function_exists( 'fflf_request_has_filters' ) ) {
			return fflf_request_has_filters( $this->request_source() );
		}
		return $this->normalizer->has_filters( $this->request_source() );
	}

	/**
	 * Front-end GET/HEAD only.
	 *
	 * @return bool
	 */
	private function should_handle() {
		if ( $this->compare_plugin_is_active() ) {
			return false;
		}
		if ( function_exists( 'is_admin' ) && is_admin() && ! $this->is_wp_unit_test() ) {
			return false;
		}
		if ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) {
			return false;
		}
		if ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ) {
			return false;
		}
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return false;
		}
		if ( defined( 'WP_CLI' ) && WP_CLI && ! $this->is_wp_unit_test() ) {
			return false;
		}

		$method = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( (string) wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : 'GET'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		if ( ! in_array( $method, array( 'GET', 'HEAD' ), true ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Whether the current request is a WP unit-test run.
	 *
	 * @return bool
	 */
	private function is_wp_unit_test() {
		return ( defined( 'WP_TESTS_DOMAIN' ) && WP_TESTS_DOMAIN ) || defined( 'WP_RUNNING_TESTS' );
	}

	/**
	 * Passive while Coriolis Product Filters is active.
	 *
	 * @return bool
	 */
	private function compare_plugin_is_active() {
		if ( function_exists( 'fflf_is_passive' ) ) {
			return fflf_is_passive();
		}
		return function_exists( 'fflf_compare_plugin_is_active' ) && fflf_compare_plugin_is_active();
	}
}
