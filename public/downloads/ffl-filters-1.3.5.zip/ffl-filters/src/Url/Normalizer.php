<?php
/**
 * Canonicalize CPF-compatible filter query strings.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Url;

use FFL_Filters\Query\Parsed_Request;
use FFL_Filters\Query\Request_Parser;

defined( 'ABSPATH' ) || exit;

/**
 * Strips empty values, sorts and dedupes slugs, and builds a canonical query.
 */
class Normalizer {

	/**
	 * Parser.
	 *
	 * @var Request_Parser
	 */
	private $parser;

	/**
	 * Constructor.
	 *
	 * @param Request_Parser|null $parser Parser.
	 */
	public function __construct( $parser = null ) {
		$this->parser = $parser ? $parser : new Request_Parser();
	}

	/**
	 * Parse a request array with the shared parser.
	 *
	 * @param array $source Request parameters (typically $_GET).
	 * @return Parsed_Request
	 */
	public function parse( $source ) {
		return $this->parser->parse( is_array( $source ) ? $source : array() );
	}

	/**
	 * Whether the source carries any effective filter after empty values are stripped.
	 *
	 * @param array $source Request parameters.
	 * @return bool
	 */
	public function has_filters( $source ) {
		return $this->parse( $source )->has_filters();
	}

	/**
	 * Canonical query string for the managed filter params (no leading '?').
	 *
	 * @param array $source Request parameters.
	 * @return string
	 */
	public function canonical_filter_query( $source ) {
		return $this->build_filter_query( $this->parse( $source ) );
	}

	/**
	 * Full canonical query string, with non-filter args appended in their original order.
	 *
	 * @param array $source Request parameters.
	 * @return string
	 */
	public function canonical_query( $source ) {
		if ( ! is_array( $source ) ) {
			$source = array();
		}

		$parts        = array();
		$filter_query = $this->canonical_filter_query( $source );
		if ( '' !== $filter_query ) {
			$parts[] = $filter_query;
		}

		$other = $this->encode_unmanaged_params( $source );
		if ( '' !== $other ) {
			$parts[] = $other;
		}

		return implode( '&', $parts );
	}

	/**
	 * Whether the managed filter params differ from the canonical form.
	 *
	 * Other args (utm, orderby, s, paged, …) are not a reason to redirect
	 * when the filter params are already canonical.
	 *
	 * @param array $source Request parameters.
	 * @return bool
	 */
	public function needs_redirect( $source ) {
		if ( ! is_array( $source ) ) {
			$source = array();
		}

		if ( ! $this->has_managed_params( $source ) ) {
			return false;
		}

		return $this->raw_filter_query( $source ) !== $this->canonical_filter_query( $source );
	}

	/**
	 * Absolute redirect URL, or an empty string when no redirect is needed.
	 *
	 * @param array  $source Request parameters.
	 * @param string $path   Path of the current request (leading slash, no query).
	 * @return string
	 */
	public function redirect_url( $source, $path ) {
		if ( ! $this->needs_redirect( $source ) ) {
			return '';
		}

		$path  = $this->normalize_path( $path );
		$query = $this->canonical_query( $source );
		$base  = $this->absolute_url( $path );

		return '' === $query ? $base : $base . '?' . $query;
	}

	/**
	 * Request key for a taxonomy (inverse of Request_Parser).
	 *
	 * @param string $taxonomy Taxonomy.
	 * @return string
	 */
	public function param_for_taxonomy( $taxonomy ) {
		$special = array_flip( Request_Parser::SPECIAL_TAXONOMIES );
		if ( isset( $special[ $taxonomy ] ) ) {
			return $special[ $taxonomy ];
		}

		if ( 0 === strpos( $taxonomy, 'pa_' ) ) {
			return 'filter_' . substr( $taxonomy, 3 );
		}

		return 'filter_' . $taxonomy;
	}

	/**
	 * Whether the source includes any managed filter param, including empties.
	 *
	 * @param array $source Request parameters.
	 * @return bool
	 */
	public function has_managed_params( $source ) {
		if ( ! is_array( $source ) ) {
			return false;
		}

		foreach ( $source as $key => $value ) {
			unset( $value );
			if ( $this->is_managed_param( (string) $key ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether a request key is a managed filter param.
	 *
	 * @param string $key Request key.
	 * @return bool
	 */
	public function is_managed_param( $key ) {
		if ( 0 === strpos( $key, 'filter_' ) ) {
			return true;
		}
		if ( in_array( $key, array( 'min_price', 'max_price', 'instock', 'instore' ), true ) ) {
			return true;
		}
		return ( new \FFL_Filters\Presets\Numeric_Parser() )->is_range_param( $key );
	}

	/**
	 * Build the canonical managed query from a parsed request.
	 *
	 * @param Parsed_Request $parsed Parsed request.
	 * @return string
	 */
	private function build_filter_query( Parsed_Request $parsed ) {
		$parts = array();
		$pairs = array();

		foreach ( $parsed->groups() as $taxonomy => $slugs ) {
			$param = $this->param_for_taxonomy( $taxonomy );
			$slugs = array_values( array_unique( array_map( 'strval', $slugs ) ) );
			sort( $slugs );
			if ( empty( $slugs ) ) {
				continue;
			}
			$pairs[ $param ] = $slugs;
		}

		ksort( $pairs );
		foreach ( $pairs as $param => $slugs ) {
			foreach ( $slugs as $slug ) {
				$parts[] = $this->encode_key( $param ) . '[]=' . rawurlencode( (string) $slug );
			}
		}

		$min = $parsed->min_price();
		if ( null !== $min ) {
			$parts[] = 'min_price=' . rawurlencode( $this->format_price( $min ) );
		}

		$max = $parsed->max_price();
		if ( null !== $max ) {
			$parts[] = 'max_price=' . rawurlencode( $this->format_price( $max ) );
		}

		if ( $parsed->instock() ) {
			$parts[] = 'instock=1';
		}

		if ( $parsed->instore() ) {
			$parts[] = 'instore=1';
		}

		$numeric     = new \FFL_Filters\Presets\Numeric_Parser();
		$range_parts = array();
		foreach ( $parsed->ranges() as $taxonomy => $range ) {
			if ( ! is_array( $range ) ) {
				continue;
			}
			if ( isset( $range['min'] ) ) {
				$range_parts[] = $numeric->min_param( $taxonomy ) . '=' . rawurlencode( $this->format_price( $range['min'] ) );
			}
			if ( isset( $range['max'] ) ) {
				$range_parts[] = $numeric->max_param( $taxonomy ) . '=' . rawurlencode( $this->format_price( $range['max'] ) );
			}
		}
		sort( $range_parts );
		$parts = array_merge( $parts, $range_parts );

		return implode( '&', $parts );
	}

	/**
	 * Rebuild the managed query from the raw request (empties, order, form preserved).
	 *
	 * @param array $source Request parameters.
	 * @return string
	 */
	private function raw_filter_query( $source ) {
		$parts = array();

		foreach ( $source as $key => $value ) {
			$key = (string) $key;
			if ( ! $this->is_managed_param( $key ) ) {
				continue;
			}

			if ( 0 === strpos( $key, 'filter_' ) ) {
				$parts = array_merge( $parts, $this->encode_raw_filter( $key, $value ) );
				continue;
			}

			if ( 'instock' === $key || 'instore' === $key ) {
				if ( is_array( $value ) || is_object( $value ) ) {
					continue;
				}
				$parts[] = $key . '=' . rawurlencode( trim( (string) $value ) );
				continue;
			}

			if ( is_array( $value ) || is_object( $value ) ) {
				continue;
			}
			$parts[] = $this->encode_key( $key ) . '=' . rawurlencode( trim( (string) $value ) );
		}

		return implode( '&', $parts );
	}

	/**
	 * Encode a raw filter_* value as it appeared on the request.
	 *
	 * @param string $key   Request key.
	 * @param mixed  $value Raw value.
	 * @return array<int, string>
	 */
	private function encode_raw_filter( $key, $value ) {
		$parts = array();
		$enc   = $this->encode_key( $key );

		if ( is_array( $value ) ) {
			foreach ( $value as $item ) {
				if ( is_array( $item ) || is_object( $item ) || is_bool( $item ) ) {
					// Nested / invalid values are not representable as a native slug list.
					$parts[] = $enc . '[]=';
					continue;
				}
				$parts[] = $enc . '[]=' . rawurlencode( trim( (string) $item ) );
			}
			return $parts;
		}

		if ( is_bool( $value ) || is_object( $value ) ) {
			return $parts;
		}

		$parts[] = $enc . '=' . rawurlencode( trim( (string) $value ) );
		return $parts;
	}

	/**
	 * Encode non-filter query args in their original order.
	 *
	 * @param array $source Request parameters.
	 * @return string
	 */
	private function encode_unmanaged_params( $source ) {
		$parts = array();

		foreach ( $source as $key => $value ) {
			$key = (string) $key;
			if ( $this->is_managed_param( $key ) ) {
				continue;
			}
			$parts = array_merge( $parts, $this->encode_arg( $key, $value ) );
		}

		return implode( '&', $parts );
	}

	/**
	 * Encode one non-filter query argument.
	 *
	 * @param string $key   Request key.
	 * @param mixed  $value Value.
	 * @return array<int, string>
	 */
	private function encode_arg( $key, $value ) {
		$enc = $this->encode_key( $key );

		if ( is_array( $value ) ) {
			$parts = array();
			foreach ( $value as $item ) {
				if ( is_array( $item ) || is_object( $item ) ) {
					continue;
				}
				$parts[] = $enc . '[]=' . rawurlencode( (string) $item );
			}
			return $parts;
		}

		if ( is_bool( $value ) || is_object( $value ) ) {
			return array();
		}

		return array( $enc . '=' . rawurlencode( (string) $value ) );
	}

	/**
	 * URL-encode a query key, keeping literal brackets.
	 *
	 * @param string $key Request key.
	 * @return string
	 */
	private function encode_key( $key ) {
		return str_replace( array( '%5B', '%5D' ), array( '[', ']' ), rawurlencode( $key ) );
	}

	/**
	 * Stable price token (integer when whole, otherwise trimmed).
	 *
	 * @param float $price Price.
	 * @return string
	 */
	private function format_price( $price ) {
		if ( (float) (int) $price === (float) $price ) {
			return (string) (int) $price;
		}
		$formatted = rtrim( rtrim( sprintf( '%.6F', $price ), '0' ), '.' );
		return '' === $formatted ? '0' : $formatted;
	}

	/**
	 * Strip the query string and normalize a leading slash.
	 *
	 * @param string $path Path.
	 * @return string
	 */
	private function normalize_path( $path ) {
		$path = (string) $path;
		if ( '' === $path ) {
			return '/';
		}
		if ( function_exists( 'wp_parse_url' ) ) {
			$parsed = wp_parse_url( $path, PHP_URL_PATH );
			if ( is_string( $parsed ) && '' !== $parsed ) {
				$path = $parsed;
			}
		} else {
			$qpos = strpos( $path, '?' );
			if ( false !== $qpos ) {
				$path = substr( $path, 0, $qpos );
			}
		}
		if ( '' === $path ) {
			return '/';
		}
		return '/' . ltrim( (string) $path, '/' );
	}

	/**
	 * Turn a path into an absolute URL on this site.
	 *
	 * @param string $path Path starting with /.
	 * @return string
	 */
	private function absolute_url( $path ) {
		if ( function_exists( 'home_url' ) ) {
			return home_url( $path );
		}
		return $path;
	}
}
