<?php
/**
 * Optional dealer-to-Coriolis lead handoff.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Lead;

defined( 'ABSPATH' ) || exit;

/**
 * Builds the browser-handoff POST payload and stores local consent state only.
 */
class Service {

	/**
	 * Receiving-page URL.
	 *
	 * @var string
	 */
	const ENDPOINT = 'https://coriolisagency.com/ffl-filters/connect';

	/**
	 * Deletion URL the receiving page must honor.
	 *
	 * @var string
	 */
	const DELETION_URL = 'https://coriolisagency.com/ffl-filters/connect#delete';

	/**
	 * Version of the consent text shown in the plugin.
	 *
	 * @var string
	 */
	const CONSENT_VERSION = '1';

	/**
	 * Version of the slim Welcome-tab consent text (name, email, message only).
	 *
	 * @var string
	 */
	const SLIM_CONSENT_VERSION = '2';

	/**
	 * Local option: { sent_at, consent_v }.
	 *
	 * @var string
	 */
	const OPTION = 'fflf_lead';

	/**
	 * Timestamp of the one-time offer (wizard or import), if shown or skipped.
	 *
	 * @var string
	 */
	const PROMPT_OPTION = 'fflf_lead_prompted';

	/**
	 * Maximum message length.
	 *
	 * @var int
	 */
	const MESSAGE_MAX = 1000;

	/**
	 * Allowed topic keys.
	 *
	 * @return array<string, string>
	 */
	public function topics() {
		return array(
			'setup'   => __( 'Help with setup', 'ffl-filters' ),
			'speed'   => __( 'Help with speed', 'ffl-filters' ),
			'catalog' => __( 'Help with catalog or feed', 'ffl-filters' ),
			'website' => __( 'A website project', 'ffl-filters' ),
			'other'   => __( 'Other', 'ffl-filters' ),
		);
	}

	/**
	 * Current consent text. Replace this string when the wording is revised, and bump CONSENT_VERSION.
	 *
	 * @param string $form full (Help tab) or slim (Welcome tab).
	 * @return string
	 */
	public function consent_text( $form = 'full' ) {
		if ( 'slim' === $form ) {
			return __( 'I agree to send my name, email and message to Coriolis Agency at coriolisagency.com so they can contact me about FFL Filters. Nothing is sent until I click Send to Coriolis.', 'ffl-filters' );
		}
		return __( 'I agree to send the details shown above to Coriolis Agency at coriolisagency.com so they can contact me about FFL Filters. Nothing is sent until I click Send to Coriolis. FFL Filters works the same if I skip this.', 'ffl-filters' );
	}

	/**
	 * Prefill store and admin contact fields.
	 *
	 * @return array<string, string>
	 */
	public function prefill() {
		$user  = function_exists( 'wp_get_current_user' ) ? wp_get_current_user() : null;
		$name  = ( $user && ! empty( $user->display_name ) ) ? (string) $user->display_name : '';
		$email = function_exists( 'get_option' ) ? (string) get_option( 'admin_email' ) : '';
		if ( $user && ! empty( $user->user_email ) ) {
			$email = (string) $user->user_email;
		}

		return array(
			'name'       => $name,
			'email'      => $email,
			'store_name' => function_exists( 'get_bloginfo' ) ? (string) get_bloginfo( 'name' ) : '',
			'store_url'  => function_exists( 'home_url' ) ? (string) home_url( '/' ) : '',
		);
	}

	/**
	 * Sanitize a submitted form.
	 *
	 * @param array<string, mixed> $input Raw input.
	 * @return array{ok: bool, errors: array<int, string>, data: array<string, mixed>}
	 */
	public function sanitize( $input ) {
		$input  = is_array( $input ) ? $input : array();
		$errors = array();
		$data   = array();
		$slim   = isset( $input['fflf_form'] ) && 'slim' === (string) $input['fflf_form'];

		$data['name'] = $this->clip( $this->text( isset( $input['name'] ) ? $input['name'] : '' ), 200 );
		if ( '' === $data['name'] ) {
			$errors[] = 'name';
		}

		$email = $this->text( isset( $input['email'] ) ? $input['email'] : '' );
		$email = function_exists( 'sanitize_email' ) ? sanitize_email( $email ) : $email;
		if ( ! is_email( $email ) ) {
			$errors[]      = 'email';
			$data['email'] = $email;
		} else {
			$data['email'] = $email;
		}

		if ( $slim ) {
			return $this->sanitize_slim( $input, $data, $errors );
		}

		$prefill            = $this->prefill();
		$data['store_name'] = $this->clip( $this->text( isset( $input['store_name'] ) ? $input['store_name'] : $prefill['store_name'] ), 200 );
		$data['store_url']  = $this->url( isset( $input['store_url'] ) ? $input['store_url'] : $prefill['store_url'] );
		if ( '' === $data['store_name'] || '' === $data['store_url'] ) {
			$errors[] = 'store';
		}

		$topic = $this->text( isset( $input['topic'] ) ? $input['topic'] : '' );
		if ( ! isset( $this->topics()[ $topic ] ) ) {
			$errors[]      = 'topic';
			$data['topic'] = '';
		} else {
			$data['topic'] = $topic;
		}

		$message         = isset( $input['message'] ) ? (string) $input['message'] : '';
		$message         = function_exists( 'sanitize_textarea_field' ) ? sanitize_textarea_field( $message ) : $this->text( $message );
		$data['message'] = $this->clip( $message, self::MESSAGE_MAX );

		$data['phone'] = $this->clip( $this->text( isset( $input['phone'] ) ? $input['phone'] : '' ), 40 );

		$consent         = isset( $input['consent'] ) && ! in_array( (string) $input['consent'], array( '', '0', 'false', 'off' ), true );
		$data['consent'] = $consent ? '1' : '';
		if ( ! $consent ) {
			$errors[] = 'consent';
		}

		$data['consent_v'] = self::CONSENT_VERSION;

		$include             = isset( $input['include_env'] ) && ! in_array( (string) $input['include_env'], array( '', '0', 'false', 'off' ), true );
		$data['include_env'] = $include ? '1' : '';
		if ( $include ) {
			$env                          = $this->environment();
			$data['plugin_version']       = $env['plugin_version'];
			$data['wp_version']           = $env['wp_version'];
			$data['woo_version']          = $env['woo_version'];
			$data['product_count_bucket'] = $env['product_count_bucket'];
		}

		return array(
			'ok'     => array() === $errors,
			'errors' => $errors,
			'data'   => $data,
		);
	}

	/**
	 * Finish sanitizing the slim Welcome-tab form: name, email, optional message and consent only.
	 *
	 * @param array<string, mixed> $input  Raw input.
	 * @param array<string, mixed> $data   Name and email already sanitized.
	 * @param array<int, string>   $errors Errors so far.
	 * @return array{ok: bool, errors: array<int, string>, data: array<string, mixed>}
	 */
	private function sanitize_slim( $input, $data, $errors ) {
		$message         = isset( $input['message'] ) ? (string) $input['message'] : '';
		$message         = function_exists( 'sanitize_textarea_field' ) ? sanitize_textarea_field( $message ) : $this->text( $message );
		$data['message'] = $this->clip( $message, self::MESSAGE_MAX );

		$consent         = isset( $input['consent'] ) && ! in_array( (string) $input['consent'], array( '', '0', 'false', 'off' ), true );
		$data['consent'] = $consent ? '1' : '';
		if ( ! $consent ) {
			$errors[] = 'consent';
		}
		$data['consent_v'] = self::SLIM_CONSENT_VERSION;
		$data['form']      = 'slim';

		return array(
			'ok'     => array() === $errors,
			'errors' => $errors,
			'data'   => $data,
		);
	}

	/**
	 * Fields that may be POSTed to the receiving page.
	 *
	 * @param array<string, mixed> $data Sanitized data.
	 * @return array<string, string>
	 */
	public function handoff_fields( $data ) {
		if ( isset( $data['form'] ) && 'slim' === $data['form'] ) {
			return array(
				'name'      => isset( $data['name'] ) ? (string) $data['name'] : '',
				'email'     => isset( $data['email'] ) ? (string) $data['email'] : '',
				'message'   => isset( $data['message'] ) ? (string) $data['message'] : '',
				'consent'   => '1',
				'consent_v' => self::SLIM_CONSENT_VERSION,
			);
		}
		$fields = array(
			'name'       => isset( $data['name'] ) ? (string) $data['name'] : '',
			'email'      => isset( $data['email'] ) ? (string) $data['email'] : '',
			'store_name' => isset( $data['store_name'] ) ? (string) $data['store_name'] : '',
			'store_url'  => isset( $data['store_url'] ) ? (string) $data['store_url'] : '',
			'topic'      => isset( $data['topic'] ) ? (string) $data['topic'] : '',
			'message'    => isset( $data['message'] ) ? (string) $data['message'] : '',
			'phone'      => isset( $data['phone'] ) ? (string) $data['phone'] : '',
			'consent'    => '1',
			'consent_v'  => self::CONSENT_VERSION,
		);
		if ( ! empty( $data['include_env'] ) ) {
			$fields['include_env']          = '1';
			$fields['plugin_version']       = isset( $data['plugin_version'] ) ? (string) $data['plugin_version'] : '';
			$fields['wp_version']           = isset( $data['wp_version'] ) ? (string) $data['wp_version'] : '';
			$fields['woo_version']          = isset( $data['woo_version'] ) ? (string) $data['woo_version'] : '';
			$fields['product_count_bucket'] = isset( $data['product_count_bucket'] ) ? (string) $data['product_count_bucket'] : '';
		}
		return $fields;
	}

	/**
	 * Environment fields for the optional preview and payload.
	 *
	 * @return array<string, string>
	 */
	public function environment() {
		$wp = '';
		if ( isset( $GLOBALS['wp_version'] ) ) {
			$wp = (string) $GLOBALS['wp_version'];
		}
		$woo = '';
		if ( defined( 'WC_VERSION' ) ) {
			$woo = (string) WC_VERSION;
		} elseif ( function_exists( 'WC' ) ) {
			$woocommerce = WC();
			if ( is_object( $woocommerce ) ) {
				$woo = (string) $woocommerce->version;
			}
		}

		return array(
			'plugin_version'       => defined( 'FFLF_VERSION' ) ? FFLF_VERSION : '',
			'wp_version'           => $wp,
			'woo_version'          => $woo,
			'product_count_bucket' => $this->product_count_bucket(),
		);
	}

	/**
	 * Product-count bucket, never a raw count.
	 *
	 * @param int|null $count Optional count; defaults to published products.
	 * @return string
	 */
	public function product_count_bucket( $count = null ) {
		if ( null === $count ) {
			$count = 0;
			if ( function_exists( 'wp_count_posts' ) ) {
				$counts = wp_count_posts( 'product' );
				if ( is_object( $counts ) && isset( $counts->publish ) ) {
					$count = (int) $counts->publish;
				}
			}
		}
		$count = (int) $count;
		if ( $count < 1000 ) {
			return '0-1k';
		}
		if ( $count < 10000 ) {
			return '1k-10k';
		}
		if ( $count < 50000 ) {
			return '10k-50k';
		}
		if ( $count < 80000 ) {
			return '50k-80k';
		}
		return '80k+';
	}

	/**
	 * Record local consent state. Never stores the message or contact fields.
	 *
	 * @param string $consent_v Consent text version the dealer saw.
	 * @return void
	 */
	public function record( $consent_v = self::CONSENT_VERSION ) {
		if ( function_exists( 'update_option' ) ) {
			update_option(
				self::OPTION,
				array(
					'sent_at'   => time(),
					'consent_v' => (string) $consent_v,
				),
				false
			);
		}
		$this->mark_prompted();
	}

	/**
	 * Clear local lead state.
	 *
	 * @return void
	 */
	public function forget() {
		if ( function_exists( 'delete_option' ) ) {
			delete_option( self::OPTION );
		}
	}

	/**
	 * Stored lead state, or null.
	 *
	 * @return array{sent_at: int, consent_v: string}|null
	 */
	public function status() {
		if ( ! function_exists( 'get_option' ) ) {
			return null;
		}
		$stored = get_option( self::OPTION, null );
		if ( ! is_array( $stored ) || empty( $stored['sent_at'] ) ) {
			return null;
		}
		return array(
			'sent_at'   => (int) $stored['sent_at'],
			'consent_v' => isset( $stored['consent_v'] ) ? (string) $stored['consent_v'] : '',
		);
	}

	/**
	 * Whether the one-time offer should be shown after wizard or import.
	 *
	 * @return bool
	 */
	public function should_offer() {
		if ( $this->status() ) {
			return false;
		}
		if ( ! function_exists( 'get_option' ) ) {
			return true;
		}
		return ! get_option( self::PROMPT_OPTION, false );
	}

	/**
	 * Mark the one-time offer as shown or skipped.
	 *
	 * @return void
	 */
	public function mark_prompted() {
		if ( function_exists( 'update_option' ) ) {
			update_option( self::PROMPT_OPTION, time(), false );
		}
	}

	/**
	 * Sanitize a single-line value.
	 *
	 * @param mixed $value Raw.
	 * @return string
	 */
	private function text( $value ) {
		$value = is_scalar( $value ) ? (string) $value : '';
		return function_exists( 'sanitize_text_field' ) ? sanitize_text_field( $value ) : trim( $value );
	}

	/**
	 * Sanitize a URL.
	 *
	 * @param mixed $value Raw.
	 * @return string
	 */
	private function url( $value ) {
		$value = is_scalar( $value ) ? (string) $value : '';
		$clean = function_exists( 'esc_url_raw' ) ? esc_url_raw( $value ) : $value;
		return is_string( $clean ) ? $clean : '';
	}

	/**
	 * Truncate a string.
	 *
	 * @param string $value Value.
	 * @param int    $max   Max length.
	 * @return string
	 */
	private function clip( $value, $max ) {
		$value = (string) $value;
		if ( function_exists( 'mb_substr' ) ) {
			return (string) mb_substr( $value, 0, $max );
		}
		return substr( $value, 0, $max );
	}
}
