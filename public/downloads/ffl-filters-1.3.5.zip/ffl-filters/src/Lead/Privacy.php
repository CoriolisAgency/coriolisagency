<?php
/**
 * Privacy-policy guide paragraph for the optional lead handoff.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Lead;

defined( 'ABSPATH' ) || exit;

/**
 * Registers suggested wording in Settings → Privacy.
 */
class Privacy {

	/**
	 * Hook the policy content.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_init', array( $this, 'add_policy' ) );
	}

	/**
	 * Add a paragraph to the privacy policy guide.
	 *
	 * @return void
	 */
	public function add_policy() {
		if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
			return;
		}

		$content  = '<p>' . esc_html__( 'FFL Filters includes an optional form that lets you ask Coriolis Agency to contact you. The form is opt-in, is shown only on the plugin settings screen (the setup wizard and the Help tab), and does not run on the storefront. Nothing is sent until you tick the consent box and click Send to Coriolis.', 'ffl-filters' ) . '</p>';
		$content .= '<p>' . esc_html__( 'When you do, your browser POSTs the form to https://coriolisagency.com/ffl-filters/connect. The fields are your name, email, store name and URL, the topic you chose, an optional message of up to 1,000 characters, an optional phone number, consent, and the consent text version. A second, separate checkbox can also include the FFL Filters version, WordPress and WooCommerce versions, and a product-count bucket. The plugin never sends customer data, orders, other users, a plugin list, server paths, or keys. This site stores only the date you sent the form and the consent version, not a copy of the message.', 'ffl-filters' ) . '</p>';
		$content .= '<p>' . esc_html__( 'You can clear the local record with the Forget button on the Help tab. To ask Coriolis to delete the copy they received, use the deletion link on the Coriolis connect page.', 'ffl-filters' ) . '</p>';

		wp_add_privacy_policy_content(
			__( 'FFL Filters', 'ffl-filters' ),
			$content
		);
	}
}
