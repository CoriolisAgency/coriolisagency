<?php
/**
 * Object-cache / transient storage for generation-keyed values.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Cache;

defined( 'ABSPATH' ) || exit;

/**
 * Stores cache entries in the `fflf` group, with a prefixed transient fallback.
 *
 * Public requests may write only the bounded, prefixed transient set (or
 * object-cache keys). The number of stored keys is capped.
 */
class Store {

	/**
	 * Object-cache group.
	 *
	 * @var string
	 */
	const GROUP = 'fflf';

	/**
	 * Prefix for data transients (no object cache).
	 *
	 * @var string
	 */
	const TRANSIENT_PREFIX = 'fflf_c_';

	/**
	 * Transient that lists currently stored data keys (no object cache).
	 *
	 * @var string
	 */
	const INDEX_TRANSIENT = 'fflf_c_index';

	/**
	 * Object-cache key for the stored-key index.
	 *
	 * @var string
	 */
	const INDEX_CACHE_KEY = 'key_index';

	/**
	 * Default cap on stored keys.
	 *
	 * @var int
	 */
	const DEFAULT_MAX_KEYS = 200;

	/**
	 * Default TTL in seconds.
	 *
	 * @var int
	 */
	const DEFAULT_TTL = DAY_IN_SECONDS;

	/**
	 * Whether a persistent / external object cache is in use.
	 *
	 * @return bool
	 */
	public function has_object_cache() {
		return function_exists( 'wp_using_ext_object_cache' ) && wp_using_ext_object_cache();
	}

	/**
	 * Read a value or return null on a miss.
	 *
	 * @param string $key Logical cache key.
	 * @return mixed|null
	 */
	public function get( $key ) {
		if ( $this->has_object_cache() ) {
			$found = false;
			$value = wp_cache_get( $key, self::GROUP, false, $found );
			if ( $found ) {
				return $value;
			}
			// Some drop-ins do not populate $found; treat a non-false value as a hit.
			return ( false === $value ) ? null : $value;
		}

		$value = get_transient( $this->transient_name( $key ) );
		if ( false === $value ) {
			return null;
		}

		return $value;
	}

	/**
	 * Store a value and evict the oldest key if the cap is exceeded.
	 *
	 * @param string $key   Logical cache key.
	 * @param mixed  $value Value.
	 * @param int    $ttl   TTL in seconds; 0 uses the default.
	 * @return void
	 */
	public function set( $key, $value, $ttl = 0 ) {
		$ttl = $this->normalize_ttl( $ttl );

		if ( $this->has_object_cache() ) {
			wp_cache_set( $key, $value, self::GROUP, $ttl );
		} else {
			set_transient( $this->transient_name( $key ), $value, $ttl );
		}

		$this->track_and_cap( $key, $ttl );
	}

	/**
	 * Delete one logical key.
	 *
	 * @param string $key Logical cache key.
	 * @return void
	 */
	public function delete( $key ) {
		if ( $this->has_object_cache() ) {
			wp_cache_delete( $key, self::GROUP );
		} else {
			delete_transient( $this->transient_name( $key ) );
		}

		$index = $this->get_index();
		$index = array_values(
			array_filter(
				$index,
				function ( $stored ) use ( $key ) {
					return $stored !== $key;
				}
			)
		);
		$this->set_index( $index );
	}

	/**
	 * Drop stored values. Generation must be bumped by the caller.
	 *
	 * Uses flush_group when the object cache supports it; otherwise deletes
	 * keys known to the index. Prefixed transients are removed when no
	 * object cache is present.
	 *
	 * @return void
	 */
	public function flush() {
		$index = $this->get_index();

		if ( $this->has_object_cache() ) {
			if ( function_exists( 'wp_cache_supports' ) && wp_cache_supports( 'flush_group' ) && function_exists( 'wp_cache_flush_group' ) ) {
				wp_cache_flush_group( self::GROUP );
			} else {
				foreach ( $index as $key ) {
					wp_cache_delete( $key, self::GROUP );
				}
				wp_cache_delete( self::INDEX_CACHE_KEY, self::GROUP );
			}
			return;
		}

		foreach ( $index as $key ) {
			delete_transient( $this->transient_name( $key ) );
		}
		delete_transient( self::INDEX_TRANSIENT );
		$this->delete_prefixed_transients();
	}

	/**
	 * Number of tracked keys.
	 *
	 * @return int
	 */
	public function key_count() {
		return count( $this->get_index() );
	}

	/**
	 * Maximum number of stored keys.
	 *
	 * @return int
	 */
	public function max_keys() {
		$cap = self::DEFAULT_MAX_KEYS;
		if ( function_exists( 'apply_filters' ) ) {
			/**
			 * Filters the cap on generation-cache keys.
			 *
			 * @since 0.0.1
			 * @param int $cap Maximum stored keys.
			 */
			$cap = (int) apply_filters( 'fflf_cache_max_keys', $cap );
		}

		return max( 1, $cap );
	}

	/**
	 * Default entry TTL.
	 *
	 * @return int
	 */
	public function default_ttl() {
		$ttl = self::DEFAULT_TTL;
		if ( function_exists( 'apply_filters' ) ) {
			/**
			 * Filters the TTL of generation-cache entries.
			 *
			 * @since 0.0.1
			 * @param int $ttl TTL in seconds.
			 */
			$ttl = (int) apply_filters( 'fflf_cache_ttl', $ttl );
		}

		return max( 1, $ttl );
	}

	/**
	 * Prefixed transient name for a logical key.
	 *
	 * @param string $key Logical cache key.
	 * @return string
	 */
	public function transient_name( $key ) {
		return self::TRANSIENT_PREFIX . md5( (string) $key );
	}

	/**
	 * Apply the default TTL when the caller passed 0 or a negative value.
	 *
	 * @param int $ttl Requested TTL.
	 * @return int
	 */
	private function normalize_ttl( $ttl ) {
		$ttl = (int) $ttl;
		if ( $ttl <= 0 ) {
			return $this->default_ttl();
		}
		return $ttl;
	}

	/**
	 * Record a key and evict the oldest when over the cap.
	 *
	 * @param string $key Logical cache key.
	 * @param int    $ttl TTL used for the index when stored as a transient.
	 * @return void
	 */
	private function track_and_cap( $key, $ttl ) {
		$index   = $this->get_index();
		$index   = array_values(
			array_filter(
				$index,
				function ( $stored ) use ( $key ) {
					return $stored !== $key;
				}
			)
		);
		$index[] = $key;

		$max   = $this->max_keys();
		$count = count( $index );
		while ( $count > $max ) {
			$evict = array_shift( $index );
			--$count;
			if ( $this->has_object_cache() ) {
				wp_cache_delete( $evict, self::GROUP );
			} else {
				delete_transient( $this->transient_name( $evict ) );
			}
		}

		$this->set_index( $index, $ttl );
	}

	/**
	 * List of tracked logical keys, oldest first.
	 *
	 * @return array<int, string>
	 */
	private function get_index() {
		if ( $this->has_object_cache() ) {
			$index = wp_cache_get( self::INDEX_CACHE_KEY, self::GROUP );
		} else {
			$index = get_transient( self::INDEX_TRANSIENT );
		}

		if ( ! is_array( $index ) ) {
			return array();
		}

		$clean = array();
		foreach ( $index as $key ) {
			if ( is_string( $key ) && '' !== $key ) {
				$clean[] = $key;
			}
		}

		return $clean;
	}

	/**
	 * Persist the tracked-key list.
	 *
	 * @param array<int, string> $index Keys.
	 * @param int                $ttl   TTL.
	 * @return void
	 */
	private function set_index( $index, $ttl = 0 ) {
		$ttl = $this->normalize_ttl( $ttl );
		if ( $this->has_object_cache() ) {
			wp_cache_set( self::INDEX_CACHE_KEY, array_values( $index ), self::GROUP, $ttl );
			return;
		}

		set_transient( self::INDEX_TRANSIENT, array_values( $index ), $ttl );
	}

	/**
	 * Remove leftover prefixed data / lock transients from wp_options.
	 *
	 * Used only from flush (CLI / uninstall), never as a public-request scan.
	 *
	 * @return void
	 */
	private function delete_prefixed_transients() {
		global $wpdb;

		if ( ! $wpdb instanceof \wpdb ) {
			return;
		}

		$like         = $wpdb->esc_like( '_transient_fflf_' ) . '%';
		$timeout_like = $wpdb->esc_like( '_transient_timeout_fflf_' ) . '%';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
				$like,
				$timeout_like
			)
		);
	}
}
