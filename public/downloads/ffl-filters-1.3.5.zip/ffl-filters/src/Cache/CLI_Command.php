<?php
/**
 * WP-CLI: wp fflf cache status|flush.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Cache;

defined( 'ABSPATH' ) || exit;

/**
 * Reports generation-cache status and performs an object-cache-safe flush.
 */
class CLI_Command {

	/**
	 * Generation source.
	 *
	 * @var Generation
	 */
	private $generation;

	/**
	 * Backing store.
	 *
	 * @var Store
	 */
	private $store;

	/**
	 * Constructor.
	 *
	 * @param Generation|null $generation Generation source.
	 * @param Store|null      $store      Backing store.
	 */
	public function __construct( $generation = null, $store = null ) {
		$this->generation = $generation ? $generation : new Generation();
		$this->store      = $store ? $store : new Store();
	}

	/**
	 * Snapshot used by `wp fflf cache status` and by tests.
	 *
	 * @return array<string, mixed>
	 */
	public function status_data() {
		$bumped = $this->generation->last_bumped_at();

		return array(
			'generation'      => $this->generation->current(),
			'object_cache'    => $this->store->has_object_cache(),
			'cached_keys'     => $this->store->key_count(),
			'max_keys'        => $this->store->max_keys(),
			'lock_backend'    => $this->store->has_object_cache() ? 'wp_cache_add' : 'transient',
			'group'           => Store::GROUP,
			'last_bumped_at'  => $bumped,
			'last_bumped_iso' => $bumped > 0 ? gmdate( 'c', $bumped ) : '',
		);
	}

	/**
	 * Increment the generation and drop stored values.
	 *
	 * Works with a persistent object cache because the generation is part of
	 * every entry; flush_group is used when the drop-in supports it.
	 *
	 * @return int New generation.
	 */
	public function flush_cache() {
		$next = $this->generation->bump();
		$this->store->flush();
		// Re-seed the generation after a group flush so subsequent reads see it.
		wp_cache_set( Generation::CACHE_KEY, $next, Store::GROUP );
		return $next;
	}

	/**
	 * Show cache status.
	 *
	 * ## EXAMPLES
	 *
	 *     wp fflf cache status
	 *
	 * @when after_wp_load
	 *
	 * @param array $args       Positional arguments.
	 * @param array $assoc_args Associative arguments.
	 * @return void
	 */
	public function status( $args = array(), $assoc_args = array() ) {
		unset( $args, $assoc_args );

		if ( ! class_exists( '\WP_CLI' ) ) {
			return;
		}

		$info = $this->status_data();
		\WP_CLI::log( 'Generation: ' . $info['generation'] );
		\WP_CLI::log( 'Object cache: ' . ( $info['object_cache'] ? 'yes' : 'no' ) );
		\WP_CLI::log( 'Cached keys: ' . $info['cached_keys'] . ' / ' . $info['max_keys'] );
		\WP_CLI::log( 'Lock backend: ' . $info['lock_backend'] );
		\WP_CLI::log( 'Cache group: ' . $info['group'] );
		if ( $info['last_bumped_at'] > 0 ) {
			\WP_CLI::log( 'Last bump (UTC): ' . $info['last_bumped_iso'] );
		} else {
			\WP_CLI::log( 'Last bump (UTC): never' );
		}
	}

	/**
	 * Flush the generation cache.
	 *
	 * ## EXAMPLES
	 *
	 *     wp fflf cache flush
	 *
	 * @when after_wp_load
	 *
	 * @param array $args       Positional arguments.
	 * @param array $assoc_args Associative arguments.
	 * @return void
	 */
	public function flush( $args = array(), $assoc_args = array() ) {
		unset( $args, $assoc_args );

		$next = $this->flush_cache();

		if ( ! class_exists( '\WP_CLI' ) ) {
			return;
		}

		\WP_CLI::success( sprintf( 'Cache flushed. Generation is now %d.', $next ) );
	}
}
