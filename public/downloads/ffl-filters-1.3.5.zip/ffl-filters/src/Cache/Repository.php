<?php
/**
 * Generation-key repository with stale-on-miss.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Cache;

defined( 'ABSPATH' ) || exit;

/**
 * Serves a stale value while a single bounded rebuild runs.
 *
 * A lock timeout never returns an invented empty result: it serves stale
 * data when any is available, and otherwise runs the builder inline.
 */
class Repository {

	/**
	 * Slot used for slug-to-term lookups.
	 *
	 * @var string
	 */
	const SLOT_TERMS = 'terms';

	/**
	 * Slot used for facet counts on the storefront panel.
	 *
	 * @var string
	 */
	const SLOT_COUNTS = 'counts';

	/**
	 * Slot used for the rendered storefront panel.
	 *
	 * @var string
	 */
	const SLOT_PANEL = 'panel';

	/**
	 * Slot used for filtered found_posts / result counts.
	 *
	 * @var string
	 */
	const SLOT_FOUND = 'found';

	/**
	 * Generation source.
	 *
	 * @var Generation
	 */
	private $generation;

	/**
	 * Backing store.
	 *
	 * @var Store
	 */
	private $store;

	/**
	 * Rebuild lock.
	 *
	 * @var Lock
	 */
	private $lock;

	/**
	 * Constructor.
	 *
	 * @param Generation|null $generation Generation source.
	 * @param Store|null      $store      Backing store.
	 * @param Lock|null       $lock       Rebuild lock.
	 */
	public function __construct( $generation = null, $store = null, $lock = null ) {
		$this->generation = $generation ? $generation : new Generation();
		$this->store      = $store ? $store : new Store();
		$this->lock       = $lock ? $lock : new Lock();
	}

	/**
	 * Generation helper.
	 *
	 * @return Generation
	 */
	public function generation() {
		return $this->generation;
	}

	/**
	 * Store helper.
	 *
	 * @return Store
	 */
	public function store() {
		return $this->store;
	}

	/**
	 * Lock helper.
	 *
	 * @return Lock
	 */
	public function lock() {
		return $this->lock;
	}

	/**
	 * Remember a slug-to-term map for a fingerprint.
	 *
	 * @param string   $fingerprint Normalized filter-state hash.
	 * @param callable $builder     Rebuild callback.
	 * @return mixed
	 */
	public function remember_terms( $fingerprint, $builder ) {
		return $this->remember( self::SLOT_TERMS, $fingerprint, $builder );
	}

	/**
	 * Remember a facet-count payload for a fingerprint.
	 *
	 * @param string   $fingerprint Normalized filter-state plus scope/facet hash.
	 * @param callable $builder     Rebuild callback.
	 * @return mixed
	 */
	public function remember_counts( $fingerprint, $builder ) {
		return $this->remember( self::SLOT_COUNTS, $fingerprint, $builder );
	}

	/**
	 * Remember rendered panel HTML for a fingerprint.
	 *
	 * @param string   $fingerprint Normalized filter-state plus scope hash.
	 * @param callable $builder     Rebuild callback.
	 * @return mixed
	 */
	public function remember_panel( $fingerprint, $builder ) {
		return $this->remember( self::SLOT_PANEL, $fingerprint, $builder );
	}

	/**
	 * Remember a filtered found-posts count for a fingerprint.
	 *
	 * @param string   $fingerprint Normalized filter-state plus scope hash.
	 * @param callable $builder     Rebuild callback.
	 * @return mixed
	 */
	public function remember_found( $fingerprint, $builder ) {
		return $this->remember( self::SLOT_FOUND, $fingerprint, $builder );
	}

	/**
	 * Get or rebuild a value under a slot and fingerprint.
	 *
	 * @param string   $slot        Slot name (terms, counts, ...).
	 * @param string   $fingerprint Normalized key fragment.
	 * @param callable $builder     Rebuild callback.
	 * @return mixed
	 */
	public function remember( $slot, $fingerprint, $builder ) {
		$key       = $this->entry_key( $slot, $fingerprint );
		$gen       = $this->generation->current();
		$cached    = $this->store->get( $key );
		$is_hit    = $this->is_current( $cached, $gen );
		$has_stale = $this->has_payload( $cached );

		if ( $is_hit ) {
			return $cached['data'];
		}

		$got_lock = $this->lock->acquire( $key );
		if ( ! $got_lock ) {
			if ( $has_stale ) {
				return $cached['data'];
			}

			$published = $this->wait_for_publication( $key, $gen );
			if ( $this->has_payload( $published ) ) {
				return $published['data'];
			}

			// Lock timed out with no stale value: build inline, never return empty.
			return $this->build_and_maybe_store( $key, $builder, false );
		}

		try {
			return $this->build_and_maybe_store( $key, $builder, true );
		} finally {
			$this->lock->release( $key );
		}
	}

	/**
	 * Logical store key for a slot and fingerprint.
	 *
	 * @param string $slot        Slot name.
	 * @param string $fingerprint Fingerprint.
	 * @return string
	 */
	public function entry_key( $slot, $fingerprint ) {
		return (string) $slot . ':' . (string) $fingerprint;
	}

	/**
	 * Whether a stored entry is a complete payload (including a legitimate empty list).
	 *
	 * @param mixed $entry Stored entry.
	 * @return bool
	 */
	public function has_payload( $entry ) {
		return is_array( $entry ) && array_key_exists( 'data', $entry );
	}

	/**
	 * Whether a stored entry matches the current generation.
	 *
	 * @param mixed $entry Stored entry.
	 * @param int   $gen   Current generation.
	 * @return bool
	 */
	private function is_current( $entry, $gen ) {
		return $this->has_payload( $entry ) && isset( $entry['gen'] ) && (int) $entry['gen'] === (int) $gen;
	}

	/**
	 * Poll the store until a current entry appears or the wait elapses.
	 *
	 * @param string $key Logical cache key.
	 * @param int    $gen Current generation.
	 * @return mixed|null
	 */
	private function wait_for_publication( $key, $gen ) {
		$wait_ms = $this->lock->wait_ms();
		if ( $wait_ms <= 0 ) {
			return $this->store->get( $key );
		}

		$deadline = microtime( true ) + ( $wait_ms / 1000 );
		$latest   = null;
		while ( microtime( true ) < $deadline ) {
			usleep( 50000 );
			$latest = $this->store->get( $key );
			if ( $this->is_current( $latest, $gen ) ) {
				return $latest;
			}
		}

		return $latest;
	}

	/**
	 * Run the builder and optionally publish the result.
	 *
	 * @param string   $key     Logical cache key.
	 * @param callable $builder Rebuild callback.
	 * @param bool     $store   Whether to store the result.
	 * @return mixed
	 */
	private function build_and_maybe_store( $key, $builder, $store ) {
		$data = call_user_func( $builder );
		if ( $store ) {
			$this->store->set(
				$key,
				array(
					'gen'  => $this->generation->current(),
					'data' => $data,
				)
			);
		}
		return $data;
	}
}
