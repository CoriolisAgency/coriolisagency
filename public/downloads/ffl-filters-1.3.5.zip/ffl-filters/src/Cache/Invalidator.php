<?php
/**
 * Debounced generation bumps on catalog change.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Cache;

defined( 'ABSPATH' ) || exit;

/**
 * Coalesces product, term, attribute and import events into one bump.
 *
 * A Cockpit-style 10k sync burst schedules a single short event, whether
 * the writes arrive in one request (shutdown coalescing) or many
 * (scheduled single event).
 */
class Invalidator {

	/**
	 * Scheduled event hook.
	 *
	 * @var string
	 */
	const HOOK = 'fflf_cache_bump_generation';

	/**
	 * Default debounce window in seconds.
	 *
	 * @var int
	 */
	const DEFAULT_DEBOUNCE_SECONDS = 3;

	/**
	 * Generation source.
	 *
	 * @var Generation
	 */
	private $generation;

	/**
	 * Whether a bump has already been scheduled in this request.
	 *
	 * @var bool
	 */
	private $pending = false;

	/**
	 * Constructor.
	 *
	 * @param Generation|null $generation Generation source.
	 */
	public function __construct( $generation = null ) {
		$this->generation = $generation ? $generation : new Generation();
	}

	/**
	 * Hook catalog events.
	 *
	 * @return void
	 */
	public function register() {
		add_action( self::HOOK, array( $this, 'run_scheduled_bump' ) );

		add_action( 'woocommerce_new_product', array( $this, 'schedule' ) );
		add_action( 'woocommerce_update_product', array( $this, 'schedule' ) );
		add_action( 'woocommerce_delete_product', array( $this, 'schedule' ) );
		add_action( 'woocommerce_trash_product', array( $this, 'schedule' ) );
		add_action( 'woocommerce_untrash_product', array( $this, 'schedule' ) );
		add_action( 'woocommerce_new_product_variation', array( $this, 'schedule' ) );
		add_action( 'woocommerce_update_product_variation', array( $this, 'schedule' ) );
		add_action( 'woocommerce_delete_product_variation', array( $this, 'schedule' ) );
		add_action( 'woocommerce_after_product_object_save', array( $this, 'schedule' ) );

		add_action( 'woocommerce_product_set_stock', array( $this, 'schedule' ) );
		add_action( 'woocommerce_product_set_stock_status', array( $this, 'schedule' ) );
		add_action( 'woocommerce_variation_set_stock', array( $this, 'schedule' ) );
		add_action( 'woocommerce_variation_set_stock_status', array( $this, 'schedule' ) );

		add_action( 'created_term', array( $this, 'on_term' ), 10, 3 );
		add_action( 'edited_term', array( $this, 'on_term' ), 10, 3 );
		add_action( 'delete_term', array( $this, 'on_term' ), 10, 3 );

		add_action( 'woocommerce_attribute_added', array( $this, 'schedule' ) );
		add_action( 'woocommerce_attribute_updated', array( $this, 'schedule' ) );
		add_action( 'woocommerce_attribute_deleted', array( $this, 'schedule' ) );

		add_action( 'woocommerce_product_import_inserted_product_object', array( $this, 'schedule' ) );
		add_action( 'woocommerce_product_bulk_and_quick_edit', array( $this, 'schedule' ) );
		add_action( 'woocommerce_rest_insert_product_object', array( $this, 'schedule' ) );
		add_action( 'woocommerce_rest_insert_product_variation_object', array( $this, 'schedule' ) );
	}

	/**
	 * Remove hooks (tests).
	 *
	 * @return void
	 */
	public function unregister() {
		remove_action( self::HOOK, array( $this, 'run_scheduled_bump' ) );

		$hooks = array(
			'woocommerce_new_product',
			'woocommerce_update_product',
			'woocommerce_delete_product',
			'woocommerce_trash_product',
			'woocommerce_untrash_product',
			'woocommerce_new_product_variation',
			'woocommerce_update_product_variation',
			'woocommerce_delete_product_variation',
			'woocommerce_after_product_object_save',
			'woocommerce_product_set_stock',
			'woocommerce_product_set_stock_status',
			'woocommerce_variation_set_stock',
			'woocommerce_variation_set_stock_status',
			'woocommerce_attribute_added',
			'woocommerce_attribute_updated',
			'woocommerce_attribute_deleted',
			'woocommerce_product_import_inserted_product_object',
			'woocommerce_product_bulk_and_quick_edit',
			'woocommerce_rest_insert_product_object',
			'woocommerce_rest_insert_product_variation_object',
		);
		foreach ( $hooks as $hook ) {
			remove_action( $hook, array( $this, 'schedule' ) );
		}

		remove_action( 'created_term', array( $this, 'on_term' ), 10 );
		remove_action( 'edited_term', array( $this, 'on_term' ), 10 );
		remove_action( 'delete_term', array( $this, 'on_term' ), 10 );

		remove_action( 'shutdown', array( $this, 'on_shutdown' ) );
		$this->pending = false;
	}

	/**
	 * Schedule a debounced bump, coalescing repeats in this request.
	 *
	 * @return void
	 */
	public function schedule() {
		$this->pending = true;

		if ( ! has_action( 'shutdown', array( $this, 'on_shutdown' ) ) ) {
			add_action( 'shutdown', array( $this, 'on_shutdown' ), 20 );
		}

		$debounce = $this->debounce_seconds();
		if ( $debounce <= 0 ) {
			return;
		}

		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_single_event( time() + $debounce, self::HOOK );
		}
	}

	/**
	 * Term create/edit/delete: bump only for product taxonomies.
	 *
	 * @param mixed  $term_id  Term ID.
	 * @param mixed  $tt_id    Term taxonomy ID.
	 * @param string $taxonomy Taxonomy.
	 * @return void
	 */
	public function on_term( $term_id, $tt_id, $taxonomy = '' ) {
		unset( $term_id, $tt_id );
		if ( $this->is_catalog_taxonomy( (string) $taxonomy ) ) {
			$this->schedule();
		}
	}

	/**
	 * Shutdown hook: if debounce is disabled, bump once at the end of the request.
	 *
	 * Across requests the scheduled single event is what collapses a burst.
	 *
	 * @return void
	 */
	public function on_shutdown() {
		if ( ! $this->pending ) {
			return;
		}

		if ( $this->debounce_seconds() <= 0 ) {
			$this->pending = false;
			$this->generation->bump();
			return;
		}

		// Ensure a single event exists if shutdown ran before schedule() finished
		// writing cron (should not happen, but keeps a burst from being lost).
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_single_event( time() + $this->debounce_seconds(), self::HOOK );
		}
	}

	/**
	 * Cron / scheduled callback: one generation bump.
	 *
	 * @return void
	 */
	public function run_scheduled_bump() {
		$this->pending = false;
		$this->generation->bump();
	}

	/**
	 * Fire the scheduled bump now (tests and CLI helpers).
	 *
	 * @return int New generation, or the current one if nothing was pending.
	 */
	public function flush_pending() {
		$scheduled = wp_next_scheduled( self::HOOK );
		if ( $scheduled ) {
			wp_unschedule_event( $scheduled, self::HOOK );
		}

		if ( $this->pending || $scheduled ) {
			$this->pending = false;
			return $this->generation->bump();
		}

		return $this->generation->current();
	}

	/**
	 * Whether a bump is waiting in this request or in cron.
	 *
	 * @return bool
	 */
	public function is_pending() {
		return $this->pending || (bool) wp_next_scheduled( self::HOOK );
	}

	/**
	 * Debounce window in seconds.
	 *
	 * @return int
	 */
	public function debounce_seconds() {
		$seconds = self::DEFAULT_DEBOUNCE_SECONDS;
		if ( function_exists( 'apply_filters' ) ) {
			/**
			 * Filters the generation-bump debounce window in seconds.
			 *
			 * @since 0.0.1
			 * @param int $seconds Debounce window.
			 */
			$seconds = (int) apply_filters( 'fflf_cache_debounce_seconds', $seconds );
		}

		return max( 0, $seconds );
	}

	/**
	 * Product-catalog taxonomies only.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @return bool
	 */
	private function is_catalog_taxonomy( $taxonomy ) {
		if ( '' === $taxonomy ) {
			return false;
		}
		if ( 0 === strpos( $taxonomy, 'pa_' ) ) {
			return true;
		}
		if ( in_array( $taxonomy, array( 'product_cat', 'product_tag', 'product_brand', 'product_shipping_class' ), true ) ) {
			return true;
		}
		if ( function_exists( 'taxonomy_is_product_attribute' ) && taxonomy_is_product_attribute( $taxonomy ) ) {
			return true;
		}
		return false;
	}
}
