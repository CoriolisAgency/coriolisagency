<?php
/**
 * Normalized filter-state fingerprints for cache keys.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Cache;

use FFL_Filters\Query\Parsed_Request;

defined( 'ABSPATH' ) || exit;

/**
 * Builds a stable hash from the normalized filter state.
 *
 * Term lookups key on groups only. Facet-count fingerprints include the
 * full filter state plus a scope and facet id.
 */
class Fingerprint {

	/**
	 * Fingerprint for a slug-to-term lookup.
	 *
	 * @param Parsed_Request $request Parsed request.
	 * @return string
	 */
	public static function for_terms( Parsed_Request $request ) {
		return self::hash(
			array(
				'slot'   => 'terms',
				'groups' => self::normalized_groups( $request->groups() ),
			)
		);
	}

	/**
	 * Fingerprint for a facet-count entry.
	 *
	 * @param string         $scope    Archive / shop scope identifier.
	 * @param Parsed_Request $request  Parsed request.
	 * @param string         $facet_id Facet identifier (taxonomy or field).
	 * @return string
	 */
	public static function for_counts( $scope, Parsed_Request $request, $facet_id ) {
		return self::hash(
			array(
				'slot'  => 'counts',
				'scope' => (string) $scope,
				'facet' => (string) $facet_id,
				'state' => self::request_state( $request ),
			)
		);
	}

	/**
	 * Fingerprint for the rendered panel.
	 *
	 * @param string               $scope   Archive scope identifier.
	 * @param Parsed_Request       $request Parsed request.
	 * @param array<string, mixed> $extra   Expand list, mobile mode, options, locale.
	 * @return string
	 */
	public static function for_panel( $scope, Parsed_Request $request, $extra = array() ) {
		if ( ! is_array( $extra ) ) {
			$extra = array();
		}
		$expand = isset( $extra['expand'] ) && is_array( $extra['expand'] ) ? array_values( array_map( 'strval', $extra['expand'] ) ) : array();
		sort( $expand );
		return self::hash(
			array(
				'slot'    => 'panel',
				// Markup changes between releases, so a cached panel from an older version is never served after an update.
				'version' => defined( 'FFLF_VERSION' ) ? (string) FFLF_VERSION : '',
				'scope'   => (string) $scope,
				'state'   => self::request_state( $request ),
				'expand'  => $expand,
				'mobile'  => isset( $extra['mobile'] ) ? (string) $extra['mobile'] : '',
				'options' => isset( $extra['options'] ) && is_array( $extra['options'] ) ? $extra['options'] : array(),
				'locale'  => isset( $extra['locale'] ) ? (string) $extra['locale'] : '',
				'hidden'  => isset( $extra['hidden'] ) && is_array( $extra['hidden'] ) ? $extra['hidden'] : array(),
				'count'   => array_key_exists( 'result_count', $extra ) ? $extra['result_count'] : null,
			)
		);
	}

	/**
	 * Fingerprint for a filtered found-posts count.
	 *
	 * @param string         $scope   Archive scope identifier.
	 * @param Parsed_Request $request Parsed request.
	 * @return string
	 */
	public static function for_found( $scope, Parsed_Request $request ) {
		return self::hash(
			array(
				'slot'  => 'found',
				'scope' => (string) $scope,
				'state' => self::request_state( $request ),
			)
		);
	}

	/**
	 * Canonical filter state for a cache key.
	 *
	 * @param Parsed_Request $request Parsed request.
	 * @return array<string, mixed>
	 */
	private static function request_state( Parsed_Request $request ) {
		return array(
			'groups'  => self::normalized_groups( $request->groups() ),
			'min'     => $request->min_price(),
			'max'     => $request->max_price(),
			'instock' => $request->instock(),
			'instore' => $request->instore(),
			'ranges'  => self::normalized_ranges( $request->ranges() ),
		);
	}

	/**
	 * Sort taxonomies and slugs so the hash is order-insensitive.
	 *
	 * @param array<string, array<int, string>> $groups Taxonomy => slugs.
	 * @return array<string, array<int, string>>
	 */
	private static function normalized_groups( $groups ) {
		if ( ! is_array( $groups ) ) {
			return array();
		}

		ksort( $groups );
		$normalized = array();
		foreach ( $groups as $taxonomy => $slugs ) {
			$slugs = is_array( $slugs ) ? array_values( array_map( 'strval', $slugs ) ) : array();
			$slugs = array_values( array_unique( $slugs ) );
			sort( $slugs );
			$normalized[ (string) $taxonomy ] = $slugs;
		}

		return $normalized;
	}

	/**
	 * Sort range taxonomies for a stable hash.
	 *
	 * @param array<string, array{min: float|null, max: float|null}> $ranges Ranges.
	 * @return array<string, array{min: float|null, max: float|null}>
	 */
	private static function normalized_ranges( $ranges ) {
		if ( ! is_array( $ranges ) ) {
			return array();
		}
		ksort( $ranges );
		$out = array();
		foreach ( $ranges as $taxonomy => $range ) {
			if ( ! is_array( $range ) ) {
				continue;
			}
			$out[ (string) $taxonomy ] = array(
				'min' => isset( $range['min'] ) ? $range['min'] : null,
				'max' => isset( $range['max'] ) ? $range['max'] : null,
			);
		}
		return $out;
	}

	/**
	 * Hash a canonical payload.
	 *
	 * @param array<string, mixed> $payload Canonical payload.
	 * @return string
	 */
	private static function hash( $payload ) {
		$json = wp_json_encode( $payload );
		if ( ! is_string( $json ) ) {
			$json = '';
		}

		return md5( $json );
	}
}
