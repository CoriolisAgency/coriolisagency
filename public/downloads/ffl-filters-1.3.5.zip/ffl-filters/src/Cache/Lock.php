<?php
/**
 * Singleflight lock for a cache rebuild.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Cache;

defined( 'ABSPATH' ) || exit;

/**
 * One rebuild per key: wp_cache_add when an object cache is present,
 * otherwise a short-TTL transient.
 */
class Lock {

	/**
	 * Default lock TTL in seconds.
	 *
	 * @var int
	 */
	const DEFAULT_TTL = 5;

	/**
	 * Default wait for a lock holder, in milliseconds.
	 *
	 * @var int
	 */
	const DEFAULT_WAIT_MS = 500;

	/**
	 * Prefix for lock transients (no object cache).
	 *
	 * @var string
	 */
	const TRANSIENT_PREFIX = 'fflf_l_';

	/**
	 * Object-cache key prefix.
	 *
	 * @var string
	 */
	const CACHE_PREFIX = 'lock:';

	/**
	 * Try to acquire a rebuild lock.
	 *
	 * @param string $key Logical cache key.
	 * @return bool True if this caller owns the lock.
	 */
	public function acquire( $key ) {
		$ttl = $this->ttl();

		if ( $this->has_object_cache() ) {
			return (bool) wp_cache_add( self::CACHE_PREFIX . $key, 1, Store::GROUP, $ttl );
		}

		return $this->add_transient_lock( $key, $ttl );
	}

	/**
	 * Release a lock held by this caller.
	 *
	 * @param string $key Logical cache key.
	 * @return void
	 */
	public function release( $key ) {
		if ( $this->has_object_cache() ) {
			wp_cache_delete( self::CACHE_PREFIX . $key, Store::GROUP );
			return;
		}

		delete_transient( $this->transient_name( $key ) );
	}

	/**
	 * How long a waiter should poll for the holder to publish, in milliseconds.
	 *
	 * @return int
	 */
	public function wait_ms() {
		$wait = self::DEFAULT_WAIT_MS;
		if ( function_exists( 'apply_filters' ) ) {
			/**
			 * Filters how long a lock loser waits for a rebuild, in milliseconds.
			 *
			 * @since 0.0.1
			 * @param int $wait Wait in milliseconds.
			 */
			$wait = (int) apply_filters( 'fflf_cache_lock_wait_ms', $wait );
		}

		return max( 0, min( 999, $wait ) );
	}

	/**
	 * Lock TTL in seconds.
	 *
	 * @return int
	 */
	public function ttl() {
		$ttl = self::DEFAULT_TTL;
		if ( function_exists( 'apply_filters' ) ) {
			/**
			 * Filters the rebuild-lock TTL in seconds.
			 *
			 * @since 0.0.1
			 * @param int $ttl TTL in seconds.
			 */
			$ttl = (int) apply_filters( 'fflf_cache_lock_ttl', $ttl );
		}

		return max( 1, $ttl );
	}

	/**
	 * Transient name for a lock key.
	 *
	 * @param string $key Logical cache key.
	 * @return string
	 */
	public function transient_name( $key ) {
		return self::TRANSIENT_PREFIX . md5( (string) $key );
	}

	/**
	 * Whether a persistent / external object cache is in use.
	 *
	 * @return bool
	 */
	private function has_object_cache() {
		return function_exists( 'wp_using_ext_object_cache' ) && wp_using_ext_object_cache();
	}

	/**
	 * Atomic-ish short-TTL lock using a transient option row.
	 *
	 * @param string $key Logical cache key.
	 * @param int    $ttl TTL in seconds.
	 * @return bool
	 */
	private function add_transient_lock( $key, $ttl ) {
		$name           = $this->transient_name( $key );
		$option         = '_transient_' . $name;
		$timeout_option = '_transient_timeout_' . $name;
		$expiration     = time() + $ttl;

		$added = add_option( $option, '1', '', false );
		if ( $added ) {
			add_option( $timeout_option, $expiration, '', false );
			return true;
		}

		$timeout = (int) get_option( $timeout_option, 0 );
		if ( $timeout > 0 && $timeout < time() ) {
			delete_option( $option );
			delete_option( $timeout_option );
			$added = add_option( $option, '1', '', false );
			if ( $added ) {
				add_option( $timeout_option, $expiration, '', false );
				return true;
			}
		}

		return false;
	}
}
