<?php
/**
 * Per-site cache generation number.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Cache;

defined( 'ABSPATH' ) || exit;

/**
 * An integer included in cache entries so a flush is an O(1) increment.
 *
 * Bumped only by admin or catalog events, never on a public read.
 */
class Generation {

	/**
	 * Option that stores the current generation.
	 *
	 * @var string
	 */
	const OPTION = 'fflf_generation';

	/**
	 * Option that stores the unix time of the last bump.
	 *
	 * @var string
	 */
	const BUMPED_AT_OPTION = 'fflf_generation_bumped_at';

	/**
	 * Object-cache key inside the fflf group.
	 *
	 * @var string
	 */
	const CACHE_KEY = 'generation';

	/**
	 * Current generation, starting at 1.
	 *
	 * @return int
	 */
	public function current() {
		$cached = wp_cache_get( self::CACHE_KEY, Store::GROUP );
		if ( is_numeric( $cached ) && (int) $cached > 0 ) {
			return (int) $cached;
		}

		$value = (int) get_option( self::OPTION, 1 );
		if ( $value < 1 ) {
			$value = 1;
		}

		wp_cache_set( self::CACHE_KEY, $value, Store::GROUP );

		return $value;
	}

	/**
	 * Increment the generation. Catalog / admin use only.
	 *
	 * @return int New generation.
	 */
	public function bump() {
		$current = (int) get_option( self::OPTION, 1 );
		if ( $current < 1 ) {
			$current = 1;
		}

		$next = $current + 1;

		update_option( self::OPTION, $next, true );
		update_option( self::BUMPED_AT_OPTION, time(), false );
		wp_cache_set( self::CACHE_KEY, $next, Store::GROUP );

		return $next;
	}

	/**
	 * Unix timestamp of the last bump, or 0.
	 *
	 * @return int
	 */
	public function last_bumped_at() {
		return (int) get_option( self::BUMPED_AT_OPTION, 0 );
	}
}
