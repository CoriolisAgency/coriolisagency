<?php
/**
 * Adaptive accent colour: generic, no per-store values.
 *
 * Reads the first colour it finds (the FFL Filters setting, then the theme's button colour, then its main colour,
 * then its link colour), steps it in OKLCH lightness until it passes against each panel set, and caches the result.
 * Port of the reference resolver in Brandy's mockups (src/accent.py).
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Panel;

defined( 'ABSPATH' ) || exit;

/**
 * Accent resolver and the tiny <style id="fflf-tokens"> it prints.
 */
class Accent {

	/**
	 * Cache option.
	 *
	 * @var string
	 */
	const OPTION = 'fflf_accent_cache';

	/**
	 * Cache shape version; bump when the stepping changes.
	 *
	 * @var int
	 */
	const VERSION = 1;

	const LIGHT_TEXT = '#FFFFFF';
	const DARK_TEXT  = '#0F1B2D';

	/**
	 * Each panel set: its surfaces (the accent must clear 3:1 against all of them) and its neutral accent.
	 *
	 * @var array<string, array{surfaces: array<int, string>, neutral: string, neutral_text: string, dark: bool}>
	 */
	const SETS = array(
		'light' => array(
			'surfaces'     => array( '#FFFFFF', '#F5F6F8' ),
			'neutral'      => '#0F1B2D',
			'neutral_text' => '#FFFFFF',
			'dark'         => false,
		),
		'dark'  => array(
			'surfaces'     => array( '#14191D', '#1E252B' ),
			'neutral'      => '#E6EBF0',
			'neutral_text' => '#0F1B2D',
			'dark'         => true,
		),
	);

	/**
	 * Resolved tokens for this request.
	 *
	 * @var array<string, mixed>|null
	 */
	private static $memo = null;

	/**
	 * Drop the request memo (tests).
	 *
	 * @return void
	 */
	public static function reset() {
		self::$memo = null;
	}

	/**
	 * The input colour and where it came from, in Paul's order: setting, theme button, theme main, theme link.
	 *
	 * @return array{color: string, source: string}
	 */
	public static function input() {
		$display = array();
		if ( class_exists( '\FFL_Filters\Settings\Repository' ) ) {
			$all     = ( new \FFL_Filters\Settings\Repository() )->all();
			$display = isset( $all['display'] ) && is_array( $all['display'] ) ? $all['display'] : array();
		}
		if ( isset( $display['accent_source'] ) && 'custom' === $display['accent_source'] && ! empty( $display['accent_color'] ) ) {
			return array(
				'color'  => (string) $display['accent_color'],
				'source' => 'setting',
			);
		}

		$theme = Theme_Colors::read();
		foreach ( array( 'button', 'main', 'link' ) as $role ) {
			if ( ! empty( $theme[ $role ] ) ) {
				return array(
					'color'  => (string) $theme[ $role ],
					'source' => $role,
				);
			}
		}

		return array(
			'color'  => '',
			'source' => 'neutral',
		);
	}

	/**
	 * Tokens for both panel sets, cached in one option and recomputed only when the input colour changes.
	 *
	 * @return array{input: string, source: string, light: string, light_text: string, dark: string, dark_text: string}
	 */
	public static function tokens() {
		if ( null !== self::$memo ) {
			return self::$memo;
		}
		$input  = self::input();
		$cached = function_exists( 'get_option' ) ? get_option( self::OPTION, array() ) : array();
		if ( is_array( $cached ) && isset( $cached['v'], $cached['input'], $cached['source'] ) && self::VERSION === (int) $cached['v'] && $cached['input'] === $input['color'] && $cached['source'] === $input['source'] ) {
			self::$memo = $cached;
			return self::$memo;
		}

		$light = self::resolve( $input['color'], 'light' );
		$dark  = self::resolve( $input['color'], 'dark' );
		$out   = array(
			'v'          => self::VERSION,
			'input'      => $input['color'],
			'source'     => $input['source'],
			'light'      => $light[0],
			'light_text' => $light[1],
			'dark'       => $dark[0],
			'dark_text'  => $dark[1],
		);
		if ( function_exists( 'update_option' ) ) {
			update_option( self::OPTION, $out, true );
		}
		self::$memo = $out;
		return $out;
	}

	/**
	 * Inline CSS with the saved accent pairs.
	 *
	 * @return string
	 */
	public static function inline_css() {
		$t = self::tokens();
		return '.ffl-filters,.ffl-filters-opener-wrap{--fflf-accent-saved:' . $t['light'] . ';--fflf-accent-saved-text:' . $t['light_text']
			. ';--fflf-accent-saved-dark:' . $t['dark'] . ';--fflf-accent-saved-dark-text:' . $t['dark_text'] . '}';
	}

	/**
	 * Step a colour until it passes on a panel set.
	 *
	 * @param string $hex Input colour (#RRGGBB) or ''.
	 * @param string $set 'light' or 'dark'.
	 * @return array{0: string, 1: string, 2: int|null} Accent, text on it, steps taken (null = neutral fallback).
	 */
	public static function resolve( $hex, $set ) {
		$cfg = isset( self::SETS[ $set ] ) ? self::SETS[ $set ] : self::SETS['light'];
		$hex = self::normalize( $hex );
		if ( '' === $hex ) {
			return array( $cfg['neutral'], $cfg['neutral_text'], null );
		}
		$dark  = $cfg['dark'];
		$lch   = self::to_oklch( $hex );
		$first = $dark ? self::DARK_TEXT : self::LIGHT_TEXT;
		$texts = array( $first, self::DARK_TEXT === $first ? self::LIGHT_TEXT : self::DARK_TEXT );
		foreach ( $texts as $text ) {
			for ( $i = 0; $i <= 60; $i++ ) {
				$l = $dark ? $lch[0] + $i * 0.01 : $lch[0] - $i * 0.01;
				if ( $l < 0 || $l > 1 ) {
					break;
				}
				$candidate = 0 === $i ? $hex : self::oklch_hex( $l, $lch[1], $lch[2] );
				if ( self::contrast( $text, $candidate ) < 4.5 ) {
					continue;
				}
				$ok = true;
				foreach ( $cfg['surfaces'] as $surface ) {
					if ( self::contrast( $candidate, $surface ) < 3 ) {
						$ok = false;
						break;
					}
				}
				if ( $ok ) {
					return array( $candidate, $text, $i );
				}
			}
		}
		return array( $cfg['neutral'], $cfg['neutral_text'], null );
	}

	/**
	 * Uppercase #RRGGBB, or '' for anything else (including see-through colours).
	 *
	 * @param mixed $value Colour.
	 * @return string
	 */
	public static function normalize( $value ) {
		return \FFL_Filters\Settings\Repository::sanitize_hex( $value );
	}

	/**
	 * WCAG contrast ratio.
	 *
	 * @param string $a #RRGGBB.
	 * @param string $b #RRGGBB.
	 * @return float
	 */
	public static function contrast( $a, $b ) {
		$la = self::luminance( $a );
		$lb = self::luminance( $b );
		return ( max( $la, $lb ) + 0.05 ) / ( min( $la, $lb ) + 0.05 );
	}

	/**
	 * WCAG relative luminance.
	 *
	 * @param string $hex #RRGGBB.
	 * @return float
	 */
	public static function luminance( $hex ) {
		$rgb = self::rgb( $hex );
		$c   = array();
		foreach ( $rgb as $v ) {
			$c[] = $v <= 0.03928 ? $v / 12.92 : pow( ( $v + 0.055 ) / 1.055, 2.4 );
		}
		return 0.2126 * $c[0] + 0.7152 * $c[1] + 0.0722 * $c[2];
	}

	/**
	 * 0..1 sRGB channels.
	 *
	 * @param string $hex #RRGGBB.
	 * @return array{0: float, 1: float, 2: float}
	 */
	private static function rgb( $hex ) {
		$hex = ltrim( (string) $hex, '#' );
		return array( hexdec( substr( $hex, 0, 2 ) ) / 255, hexdec( substr( $hex, 2, 2 ) ) / 255, hexdec( substr( $hex, 4, 2 ) ) / 255 );
	}

	/**
	 * Linearise one channel.
	 *
	 * @param float $c Channel.
	 * @return float
	 */
	private static function lin( $c ) {
		return $c <= 0.04045 ? $c / 12.92 : pow( ( $c + 0.055 ) / 1.055, 2.4 );
	}

	/**
	 * Gamma-encode one channel.
	 *
	 * @param float $c Channel.
	 * @return float
	 */
	private static function gam( $c ) {
		return $c <= 0.0031308 ? 12.92 * $c : 1.055 * pow( $c, 1 / 2.4 ) - 0.055;
	}

	/**
	 * Hex to OKLCH.
	 *
	 * @param string $hex #RRGGBB.
	 * @return array{0: float, 1: float, 2: float} L, C, hue (radians).
	 */
	public static function to_oklch( $hex ) {
		list( $r, $g, $b ) = array_map( array( __CLASS__, 'lin' ), self::rgb( $hex ) );

		$l = 0.4122214708 * $r + 0.5363325363 * $g + 0.0514459929 * $b;
		$m = 0.2119034982 * $r + 0.6806995451 * $g + 0.1073969566 * $b;
		$s = 0.0883024619 * $r + 0.2817188376 * $g + 0.6299787005 * $b;
		$l = self::cbrt( $l );
		$m = self::cbrt( $m );
		$s = self::cbrt( $s );

		$ok_l = 0.2104542553 * $l + 0.7936177850 * $m - 0.0040720468 * $s;
		$ok_a = 1.9779984951 * $l - 2.4285922050 * $m + 0.4505937099 * $s;
		$ok_b = 0.0259040371 * $l + 0.7827717662 * $m - 0.8086757660 * $s;
		return array( $ok_l, sqrt( $ok_a * $ok_a + $ok_b * $ok_b ), atan2( $ok_b, $ok_a ) );
	}

	/**
	 * Cube root that keeps the sign.
	 *
	 * @param float $v Value.
	 * @return float
	 */
	private static function cbrt( $v ) {
		return $v < 0 ? -pow( -$v, 1 / 3 ) : pow( $v, 1 / 3 );
	}

	/**
	 * OKLCH to linear sRGB.
	 *
	 * @param float $l Lightness.
	 * @param float $c Chroma.
	 * @param float $h Hue (radians).
	 * @return array{0: float, 1: float, 2: float}
	 */
	private static function from_oklch( $l, $c, $h ) {
		$a  = $c * cos( $h );
		$b  = $c * sin( $h );
		$l_ = pow( $l + 0.3963377774 * $a + 0.2158037573 * $b, 3 );
		$m_ = pow( $l - 0.1055613458 * $a - 0.0638541728 * $b, 3 );
		$s_ = pow( $l - 0.0894841775 * $a - 1.2914855480 * $b, 3 );
		return array(
			4.0767416621 * $l_ - 3.3077115913 * $m_ + 0.2309699292 * $s_,
			-1.2684380046 * $l_ + 2.6097574011 * $m_ - 0.3413193965 * $s_,
			-0.0041960863 * $l_ - 0.7034186147 * $m_ + 1.7076147010 * $s_,
		);
	}

	/**
	 * Whether linear sRGB is inside the gamut.
	 *
	 * @param array<int, float> $rgb Linear sRGB.
	 * @return bool
	 */
	private static function in_gamut( $rgb ) {
		foreach ( $rgb as $v ) {
			if ( $v < -1e-6 || $v > 1 + 1e-6 ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * OKLCH to hex, mapped into sRGB by lowering chroma only (hue and lightness kept).
	 *
	 * @param float $l Lightness.
	 * @param float $c Chroma.
	 * @param float $h Hue.
	 * @return string
	 */
	public static function oklch_hex( $l, $c, $h ) {
		$rgb = self::from_oklch( $l, $c, $h );
		if ( ! self::in_gamut( $rgb ) ) {
			$lo = 0.0;
			$hi = $c;
			for ( $i = 0; $i < 24; $i++ ) {
				$mid = ( $lo + $hi ) / 2;
				if ( self::in_gamut( self::from_oklch( $l, $mid, $h ) ) ) {
					$lo = $mid;
				} else {
					$hi = $mid;
				}
			}
			$rgb = self::from_oklch( $l, $lo, $h );
		}
		$out = '#';
		foreach ( $rgb as $v ) {
			$v    = self::gam( max( 0.0, $v ) );
			$out .= sprintf( '%02X', (int) round( min( 1, max( 0, $v ) ) * 255 ) );
		}
		return $out;
	}
}
