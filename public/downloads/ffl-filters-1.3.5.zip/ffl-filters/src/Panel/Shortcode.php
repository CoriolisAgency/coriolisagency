<?php
/**
 * Storefront shortcodes for the filter panel.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Panel;

defined( 'ABSPATH' ) || exit;

/**
 * Registers [ffl_filters] and the [coriolis_filters] alias.
 *
 * The alias is registered only while Coriolis Product Filters is not active,
 * so the two plugins never double-render. After CPF is uninstalled, pages and
 * Kadence widgets that still contain the old shortcode keep working.
 */
class Shortcode {

	/**
	 * Panel controller.
	 *
	 * @var Controller|null
	 */
	private $controller;

	/**
	 * Constructor.
	 *
	 * @param Controller|null $controller Panel controller.
	 */
	public function __construct( $controller = null ) {
		$this->controller = $controller;
	}

	/**
	 * Hook the shortcodes.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! function_exists( 'add_shortcode' ) ) {
			return;
		}

		add_shortcode( Placement::SHORTCODE, array( $this, 'render' ) );

		if ( ! $this->compare_plugin_is_active() ) {
			add_shortcode( Placement::ALIAS, array( $this, 'render' ) );
		}
	}

	/**
	 * Render the panel, or an admin-visible placeholder while CPF is active.
	 *
	 * @param array<string, mixed>|string $atts    Attributes.
	 * @param string|null                 $content Enclosed content (unused).
	 * @param string                      $tag     Shortcode tag.
	 * @return string
	 */
	public function render( $atts = array(), $content = '', $tag = '' ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
		if ( $this->compare_plugin_is_active() ) {
			return $this->placeholder();
		}

		$controller = $this->controller ? $this->controller : Controller::instance();
		if ( ! $controller ) {
			return '';
		}

		$controller->mark_manual();

		return $controller->render( Attributes::resolve_title( Attributes::normalize( is_array( $atts ) ? $atts : array() ) ) );
	}

	/**
	 * Admin-visible note when the compare plugin owns the storefront.
	 *
	 * Shoppers see nothing.
	 *
	 * @return string
	 */
	public function placeholder() {
		if ( ! $this->placeholder_is_visible() ) {
			return '';
		}

		$message = __( 'FFL Filters is paused because your previous filter plugin is still active.', 'ffl-filters' );

		return '<div class="ffl-filters-placeholder" data-fflf-placeholder role="note">' . esc_html( $message ) . '</div>';
	}

	/**
	 * Whether the coexistence placeholder should be shown to this viewer.
	 *
	 * @return bool
	 */
	private function placeholder_is_visible() {
		if ( function_exists( 'is_admin' ) && is_admin() ) {
			return true;
		}
		if ( function_exists( 'is_customize_preview' ) && is_customize_preview() ) {
			return true;
		}
		if ( function_exists( 'current_user_can' ) && function_exists( 'is_user_logged_in' ) && is_user_logged_in() && current_user_can( 'manage_options' ) ) {
			return true;
		}
		return false;
	}

	/**
	 * Whether Coriolis Product Filters is active.
	 *
	 * @return bool
	 */
	private function compare_plugin_is_active() {
		if ( function_exists( 'fflf_is_passive' ) ) {
			return fflf_is_passive();
		}
		return function_exists( 'fflf_compare_plugin_is_active' ) && fflf_compare_plugin_is_active();
	}
}
