<?php
/**
 * Archive scope for counts and the panel form action.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Panel;

use FFL_Filters\Query\Parsed_Request;

defined( 'ABSPATH' ) || exit;

/**
 * Identifies the current shop or product-taxonomy archive.
 */
class Scope {

	/**
	 * Scope identifier used in count cache keys.
	 *
	 * @return string
	 */
	public function id() {
		$object = $this->queried_term();
		if ( $object ) {
			return $object->taxonomy . ':' . $object->slug;
		}

		return 'shop';
	}

	/**
	 * Clean archive URL (no query string) for the form action and Clear all.
	 *
	 * @return string
	 */
	public function url() {
		if ( function_exists( 'is_shop' ) && is_shop() && function_exists( 'wc_get_page_permalink' ) ) {
			$url = wc_get_page_permalink( 'shop' );
			if ( is_string( $url ) && '' !== $url ) {
				return $url;
			}
		}

		$object = $this->queried_term();
		if ( $object && function_exists( 'get_term_link' ) ) {
			$link = get_term_link( $object );
			if ( is_string( $link ) ) {
				return $link;
			}
		}

		if ( function_exists( 'get_post_type_archive_link' ) ) {
			$link = get_post_type_archive_link( 'product' );
			if ( is_string( $link ) ) {
				return $link;
			}
		}

		if ( function_exists( 'home_url' ) ) {
			return home_url( '/' );
		}

		return '/';
	}

	/**
	 * Apply the archive's taxonomy as a constraint when it is not already a filter.
	 *
	 * @param Parsed_Request $request Current request.
	 * @return Parsed_Request
	 */
	public function constrain( Parsed_Request $request ) {
		$object = $this->queried_term();
		if ( ! $object ) {
			return $request;
		}

		$groups = $request->groups();
		if ( isset( $groups[ $object->taxonomy ] ) ) {
			return $request;
		}

		$groups[ $object->taxonomy ] = array( $object->slug );

		return new Parsed_Request( $groups, $request->min_price(), $request->max_price(), $request->instock(), $request->dropped() );
	}

	/**
	 * Scope identifier honouring inherit / category / tag attributes.
	 *
	 * @param array<string, mixed> $options Shortcode / block attributes.
	 * @return string
	 */
	public function id_for( $options = array() ) {
		$term = $this->primary_term( $options );
		if ( $term ) {
			return $term->taxonomy . ':' . $term->slug;
		}
		if ( ! Attributes::inherit( $options ) ) {
			return 'shop';
		}
		return $this->id();
	}

	/**
	 * Form action honouring inherit / category / tag attributes.
	 *
	 * @param array<string, mixed> $options Shortcode / block attributes.
	 * @return string
	 */
	public function url_for( $options = array() ) {
		$term = $this->primary_term( $options );
		if ( $term && function_exists( 'get_term_link' ) ) {
			$link = get_term_link( $term );
			if ( is_string( $link ) ) {
				return $link;
			}
		}
		if ( ! Attributes::inherit( $options ) ) {
			if ( function_exists( 'wc_get_page_permalink' ) ) {
				$url = wc_get_page_permalink( 'shop' );
				if ( is_string( $url ) && '' !== $url ) {
					return $url;
				}
			}
			if ( function_exists( 'get_post_type_archive_link' ) ) {
				$link = get_post_type_archive_link( 'product' );
				if ( is_string( $link ) ) {
					return $link;
				}
			}
		}
		return $this->url();
	}

	/**
	 * Apply archive or attribute-driven taxonomy constraints.
	 *
	 * @param Parsed_Request       $request Current request.
	 * @param array<string, mixed> $options Shortcode / block attributes.
	 * @return Parsed_Request
	 */
	public function constrain_for( Parsed_Request $request, $options = array() ) {
		$terms = $this->terms_from_options( $options );
		if ( $terms ) {
			$groups = $request->groups();
			foreach ( $terms as $term ) {
				if ( isset( $groups[ $term->taxonomy ] ) ) {
					continue;
				}
				$groups[ $term->taxonomy ] = array( $term->slug );
			}
			return new Parsed_Request( $groups, $request->min_price(), $request->max_price(), $request->instock(), $request->dropped() );
		}
		if ( ! Attributes::inherit( $options ) ) {
			return $request;
		}
		return $this->constrain( $request );
	}

	/**
	 * Current product-taxonomy term, if any.
	 *
	 * @return \WP_Term|null
	 */
	private function queried_term() {
		if ( ! function_exists( 'get_queried_object' ) ) {
			return null;
		}

		$object = get_queried_object();
		if ( ! $object instanceof \WP_Term || empty( $object->taxonomy ) || empty( $object->slug ) ) {
			return null;
		}

		if ( 0 !== strpos( (string) $object->taxonomy, 'product_' ) && 0 !== strpos( (string) $object->taxonomy, 'pa_' ) ) {
			return null;
		}

		return $object;
	}

	/**
	 * Primary scope term (category slug, then tag slug, then collection query).
	 *
	 * @param array<string, mixed> $options Attributes.
	 * @return \WP_Term|null
	 */
	private function primary_term( $options ) {
		$terms = $this->terms_from_options( $options );
		return $terms ? $terms[0] : null;
	}

	/**
	 * Terms implied by category/tag slugs or a Product Collection query context.
	 *
	 * @param array<string, mixed> $options Attributes.
	 * @return array<int, \WP_Term>
	 */
	private function terms_from_options( $options ) {
		$found = array();

		$category = Attributes::category_slug( $options );
		if ( '' !== $category ) {
			$term = $this->term_by_slug( 'product_cat', $category );
			if ( $term ) {
				$found[] = $term;
			}
		}

		$tag = Attributes::tag_slug( $options );
		if ( '' !== $tag ) {
			$term = $this->term_by_slug( 'product_tag', $tag );
			if ( $term ) {
				$found[] = $term;
			}
		}

		if ( ! $found && Attributes::inherit( $options ) && isset( $options['query'] ) && is_array( $options['query'] ) ) {
			$found = array_merge( $found, $this->terms_from_query( $options['query'] ) );
		}

		return $found;
	}

	/**
	 * Resolve a product taxonomy term by slug.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @param string $slug     Slug.
	 * @return \WP_Term|null
	 */
	private function term_by_slug( $taxonomy, $slug ) {
		if ( ! function_exists( 'get_term_by' ) ) {
			return null;
		}
		$term = get_term_by( 'slug', $slug, $taxonomy );
		if ( $term instanceof \WP_Term && ! empty( $term->slug ) ) {
			return $term;
		}
		return null;
	}

	/**
	 * Product Collection (or query-loop) taxQuery / woocommerceAttributes context.
	 *
	 * @param array<string, mixed> $query Block query context.
	 * @return array<int, \WP_Term>
	 */
	private function terms_from_query( $query ) {
		$found = array();
		if ( isset( $query['inherit'] ) && Attributes::parse_flag( $query['inherit'], false ) ) {
			return $found;
		}

		$tax_query = array();
		if ( isset( $query['taxQuery'] ) && is_array( $query['taxQuery'] ) ) {
			$tax_query = $query['taxQuery'];
		} elseif ( isset( $query['tax_query'] ) && is_array( $query['tax_query'] ) ) {
			$tax_query = $query['tax_query'];
		}

		foreach ( $tax_query as $taxonomy => $ids ) {
			if ( ! is_string( $taxonomy ) || ! is_array( $ids ) ) {
				continue;
			}
			foreach ( $ids as $id ) {
				$term = $this->term_by_id( (int) $id, $taxonomy );
				if ( $term ) {
					$found[] = $term;
				}
			}
		}

		if ( isset( $query['woocommerceAttributes'] ) && is_array( $query['woocommerceAttributes'] ) ) {
			foreach ( $query['woocommerceAttributes'] as $row ) {
				if ( ! is_array( $row ) ) {
					continue;
				}
				$taxonomy = isset( $row['taxonomy'] ) ? (string) $row['taxonomy'] : '';
				$term_id  = isset( $row['termId'] ) ? (int) $row['termId'] : ( isset( $row['term_id'] ) ? (int) $row['term_id'] : 0 );
				$term     = $this->term_by_id( $term_id, $taxonomy );
				if ( $term ) {
					$found[] = $term;
				}
			}
		}

		return $found;
	}

	/**
	 * Resolve a product taxonomy term by ID.
	 *
	 * @param int    $term_id  Term ID.
	 * @param string $taxonomy Taxonomy.
	 * @return \WP_Term|null
	 */
	private function term_by_id( $term_id, $taxonomy ) {
		if ( $term_id <= 0 || ! function_exists( 'get_term' ) ) {
			return null;
		}
		$term = get_term( $term_id, $taxonomy );
		if ( $term instanceof \WP_Term && ! empty( $term->slug ) ) {
			return $term;
		}
		return null;
	}
}
