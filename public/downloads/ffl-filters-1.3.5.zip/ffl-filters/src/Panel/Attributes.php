<?php
/**
 * Shared shortcode and block attributes.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Panel;

defined( 'ABSPATH' ) || exit;

/**
 * Normalizes [ffl_filters] / block attributes into panel options.
 *
 * Attribute names match the CPF shortcode contract: chips, tag, category, taxonomies.
 */
class Attributes {

	/**
	 * Default attribute values.
	 *
	 * @return array<string, string>
	 */
	public static function defaults() {
		return array(
			'chips'      => 'yes',
			'tag'        => '',
			'category'   => '',
			'taxonomies' => '',
			'inherit'    => 'yes',
			'title'      => '',
			'heading'    => '',
			'layout'     => '',
		);
	}

	/**
	 * Fill missing keys from the defaults.
	 *
	 * @param array<string, mixed> $atts Raw attributes.
	 * @return array<string, mixed>
	 */
	public static function normalize( $atts ) {
		$atts     = is_array( $atts ) ? $atts : array();
		$defaults = self::defaults();
		$out      = array();

		foreach ( $defaults as $key => $default ) {
			$out[ $key ] = array_key_exists( $key, $atts ) ? $atts[ $key ] : $default;
		}

		if ( isset( $atts['query'] ) ) {
			$out['query'] = $atts['query'];
		}

		return $out;
	}

	/**
	 * Whether selected-filter chips should render.
	 *
	 * @param array<string, mixed> $atts Attributes.
	 * @return bool
	 */
	public static function show_chips( $atts ) {
		$flag = self::parse_flag( isset( $atts['chips'] ) ? $atts['chips'] : 'yes', true );
		return false !== $flag;
	}

	/**
	 * Whether the panel heading shows on wide screens.
	 *
	 * Empty means automatic: hidden inside a widget area, where the theme usually
	 * prints its own widget title, and shown everywhere else.
	 *
	 * @param array<string, mixed> $atts Attributes.
	 * @return bool
	 */
	public static function show_title( $atts ) {
		$flag = self::parse_flag( isset( $atts['title'] ) ? $atts['title'] : '', null );
		if ( null !== $flag ) {
			return $flag;
		}
		return ! self::in_widget_area();
	}

	/**
	 * Fix an automatic title setting to yes or no for this render (keeps cache keys honest).
	 *
	 * @param array<string, mixed> $atts Attributes.
	 * @return array<string, mixed>
	 */
	public static function resolve_title( $atts ) {
		$atts          = is_array( $atts ) ? $atts : array();
		$atts['title'] = self::show_title( $atts ) ? 'yes' : 'no';
		return $atts;
	}

	/**
	 * Panel heading text: the block or shortcode heading, then the Display tab
	 * heading. Empty means the default, Filter products.
	 *
	 * @param array<string, mixed> $atts Attributes.
	 * @return string
	 */
	public static function heading( $atts ) {
		$heading = isset( $atts['heading'] ) && is_scalar( $atts['heading'] ) ? (string) $atts['heading'] : '';
		if ( '' === trim( $heading ) && class_exists( '\FFL_Filters\Settings\Repository' ) ) {
			$all     = ( new \FFL_Filters\Settings\Repository() )->all();
			$heading = isset( $all['display']['heading'] ) ? (string) $all['display']['heading'] : '';
		}
		$heading = function_exists( 'sanitize_text_field' ) ? sanitize_text_field( $heading ) : trim( wp_strip_all_tags( $heading ) );
		return mb_substr( trim( $heading ), 0, 100 );
	}

	/**
	 * Whether a widget area is being printed right now.
	 *
	 * @return bool
	 */
	public static function in_widget_area() {
		if ( ! function_exists( 'did_action' ) ) {
			return false;
		}
		return did_action( 'dynamic_sidebar_before' ) > did_action( 'dynamic_sidebar_after' );
	}

	/**
	 * Resolved layout: a valid block/shortcode attribute, otherwise the setting (default auto).
	 *
	 * @param array<string, mixed> $atts Attributes.
	 * @return string auto, bar, or stacked.
	 */
	public static function layout( $atts ) {
		$atts = is_array( $atts ) ? $atts : array();
		$raw  = isset( $atts['layout'] ) && is_scalar( $atts['layout'] ) ? strtolower( trim( (string) $atts['layout'] ) ) : '';
		if ( in_array( $raw, array( 'auto', 'bar', 'stacked' ), true ) ) {
			return $raw;
		}

		if ( class_exists( '\FFL_Filters\Settings\Repository' ) ) {
			$all = ( new \FFL_Filters\Settings\Repository() )->all();
			if ( isset( $all['display']['layout'] ) ) {
				return \FFL_Filters\Settings\Repository::sanitize_layout( $all['display']['layout'] );
			}
		}

		return 'auto';
	}

	/**
	 * Whether the panel inherits the current archive or Product Collection query.
	 *
	 * @param array<string, mixed> $atts Attributes.
	 * @return bool
	 */
	public static function inherit( $atts ) {
		$value = isset( $atts['inherit'] ) ? $atts['inherit'] : 'yes';
		if ( is_bool( $value ) ) {
			return $value;
		}
		$flag = self::parse_flag( $value, true );
		return false !== $flag;
	}

	/**
	 * Parse a yes/no flag. Returns null when the value is a slug or other string.
	 *
	 * @param mixed $value    Raw value.
	 * @param mixed $fallback Default when empty.
	 * @return bool|null
	 */
	public static function parse_flag( $value, $fallback = null ) {
		if ( is_bool( $value ) ) {
			return $value;
		}
		if ( null === $value || '' === $value ) {
			return $fallback;
		}
		if ( is_int( $value ) || is_float( $value ) ) {
			return (bool) $value;
		}

		$normalized = strtolower( trim( (string) $value ) );
		if ( in_array( $normalized, array( 'no', 'false', '0', 'off' ), true ) ) {
			return false;
		}
		if ( in_array( $normalized, array( 'yes', 'true', '1', 'on' ), true ) ) {
			return true;
		}

		return null;
	}

	/**
	 * Whether a facet should appear for these attributes.
	 *
	 * @param array<string, string> $facet Facet descriptor.
	 * @param array<string, mixed>  $atts  Attributes.
	 * @return bool
	 */
	public static function allows_facet( $facet, $atts ) {
		$id   = isset( $facet['id'] ) ? (string) $facet['id'] : '';
		$type = isset( $facet['type'] ) ? (string) $facet['type'] : '';
		$atts = self::normalize( $atts );

		if ( 'product_cat' === $id && false === self::parse_flag( $atts['category'], null ) ) {
			return false;
		}
		if ( 'product_tag' === $id && false === self::parse_flag( $atts['tag'], null ) ) {
			return false;
		}

		$allowed = self::taxonomy_ids( $atts );
		if ( null === $allowed ) {
			return true;
		}

		foreach ( $allowed as $token ) {
			if ( $token === $id || $token === $type ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Facet IDs requested via taxonomies= plus category/tag=yes, or null for the full list.
	 *
	 * @param array<string, mixed> $atts Attributes.
	 * @return array<int, string>|null
	 */
	public static function taxonomy_ids( $atts ) {
		$atts = self::normalize( $atts );
		$raw  = isset( $atts['taxonomies'] ) ? $atts['taxonomies'] : '';

		if ( is_array( $raw ) ) {
			$parts = $raw;
		} else {
			$parts = preg_split( '/\s*,\s*/', trim( (string) $raw ) );
			if ( ! is_array( $parts ) ) {
				$parts = array();
			}
		}

		$ids = array();
		foreach ( $parts as $part ) {
			$token = self::normalize_taxonomy_token( (string) $part );
			if ( '' !== $token ) {
				$ids[] = $token;
			}
		}

		if ( true === self::parse_flag( $atts['category'], null ) ) {
			$ids[] = 'product_cat';
		}
		if ( true === self::parse_flag( $atts['tag'], null ) ) {
			$ids[] = 'product_tag';
		}

		$ids = array_values( array_unique( $ids ) );
		if ( array() === $ids ) {
			return null;
		}

		return $ids;
	}

	/**
	 * Map a shortcode token onto a facet id.
	 *
	 * @param string $token Token.
	 * @return string
	 */
	public static function normalize_taxonomy_token( $token ) {
		$token = strtolower( trim( $token ) );
		if ( '' === $token ) {
			return '';
		}

		$aliases = array(
			'cat'           => 'product_cat',
			'category'      => 'product_cat',
			'product_cat'   => 'product_cat',
			'tag'           => 'product_tag',
			'product_tag'   => 'product_tag',
			'brand'         => 'product_brand',
			'product_brand' => 'product_brand',
			'price'         => 'price',
			'min_price'     => 'price',
			'max_price'     => 'price',
			'instock'       => 'instock',
			'stock'         => 'instock',
		);
		if ( isset( $aliases[ $token ] ) ) {
			return $aliases[ $token ];
		}

		if ( 0 !== strpos( $token, 'pa_' ) && 0 !== strpos( $token, 'product_' ) && ! in_array( $token, array( 'price', 'instock' ), true ) ) {
			return 'pa_' . $token;
		}

		return $token;
	}

	/**
	 * Category slug when the attribute is not a yes/no flag.
	 *
	 * @param array<string, mixed> $atts Attributes.
	 * @return string
	 */
	public static function category_slug( $atts ) {
		return self::slug_attribute( isset( $atts['category'] ) ? $atts['category'] : '' );
	}

	/**
	 * Tag slug when the attribute is not a yes/no flag.
	 *
	 * @param array<string, mixed> $atts Attributes.
	 * @return string
	 */
	public static function tag_slug( $atts ) {
		return self::slug_attribute( isset( $atts['tag'] ) ? $atts['tag'] : '' );
	}

	/**
	 * A slug string, or empty when the attribute is a yes/no flag.
	 *
	 * @param mixed $value Raw attribute.
	 * @return string
	 */
	private static function slug_attribute( $value ) {
		if ( null !== self::parse_flag( $value, null ) || ! is_scalar( $value ) ) {
			return '';
		}
		$slug = sanitize_title( (string) $value );
		return is_string( $slug ) ? $slug : '';
	}
}
