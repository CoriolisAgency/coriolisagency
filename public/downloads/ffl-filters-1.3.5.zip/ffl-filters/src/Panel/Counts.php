<?php
/**
 * Facet counts from the Woo lookup tables, cached by generation.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Panel;

use FFL_Filters\Cache\Fingerprint;
use FFL_Filters\Cache\Repository;
use FFL_Filters\Query\Clause_Builder;
use FFL_Filters\Query\Parsed_Request;

defined( 'ABSPATH' ) || exit;

/**
 * One GROUP BY (or range) query per facet on a miss; zero count queries on a hit.
 */
class Counts {

	/**
	 * Cache repository.
	 *
	 * @var Repository
	 */
	private $repository;

	/**
	 * Clause builder (other-filter constraints).
	 *
	 * @var Clause_Builder
	 */
	private $builder;

	/**
	 * Constructor.
	 *
	 * @param Repository|null     $repository Cache repository.
	 * @param Clause_Builder|null $builder    Clause builder.
	 */
	public function __construct( $repository = null, $builder = null ) {
		$this->repository = $repository ? $repository : new Repository();
		$this->builder    = $builder ? $builder : new Clause_Builder();
	}

	/**
	 * Term counts for a taxonomy facet, keyed by term_id.
	 *
	 * Constraints from other facets apply; this facet's own selection does not.
	 *
	 * @param string         $taxonomy Taxonomy.
	 * @param string         $scope    Archive scope.
	 * @param Parsed_Request $request  Current request.
	 * @return array<int, int>
	 */
	public function terms( $taxonomy, $scope, Parsed_Request $request ) {
		$constrained = $this->without_group( $request, $taxonomy );
		$fingerprint = Fingerprint::for_counts( $scope, $constrained, $taxonomy );
		$self        = $this;

		$data = $this->repository->remember_counts(
			$fingerprint,
			function () use ( $self, $taxonomy, $constrained ) {
				return $self->query_term_counts( $taxonomy, $constrained );
			}
		);

		return is_array( $data ) ? $data : array();
	}

	/**
	 * Min and max price of products matching the other filters.
	 *
	 * @param string         $scope   Archive scope.
	 * @param Parsed_Request $request Current request.
	 * @return array{min: float|null, max: float|null}
	 */
	public function price_range( $scope, Parsed_Request $request ) {
		$constrained = $this->without_prices( $request );
		$fingerprint = Fingerprint::for_counts( $scope, $constrained, 'price' );
		$self        = $this;

		$data = $this->repository->remember_counts(
			$fingerprint,
			function () use ( $self, $constrained ) {
				return $self->query_price_range( $constrained );
			}
		);

		if ( ! is_array( $data ) ) {
			return array(
				'min' => null,
				'max' => null,
			);
		}

		return array(
			'min' => isset( $data['min'] ) ? $data['min'] : null,
			'max' => isset( $data['max'] ) ? $data['max'] : null,
		);
	}

	/**
	 * In-stock product count under the other filters.
	 *
	 * @param string         $scope   Archive scope.
	 * @param Parsed_Request $request Current request.
	 * @return int
	 */
	public function instock( $scope, Parsed_Request $request ) {
		$constrained = $this->without_instock( $request );
		$fingerprint = Fingerprint::for_counts( $scope, $constrained, 'instock' );
		$self        = $this;

		$data = $this->repository->remember_counts(
			$fingerprint,
			function () use ( $self, $constrained ) {
				return $self->query_instock_count( $constrained );
			}
		);

		return (int) $data;
	}

	/**
	 * Matching published-product count for a constrained request.
	 *
	 * Used when the main query is not a product archive, so found_posts
	 * would be the page itself rather than the catalog beside the panel.
	 *
	 * @param string         $scope   Archive scope.
	 * @param Parsed_Request $request Current request.
	 * @return int
	 */
	public function matching( $scope, Parsed_Request $request ) {
		$fingerprint = Fingerprint::for_counts( $scope, $request, 'matching' );
		$self        = $this;

		$data = $this->repository->remember_counts(
			$fingerprint,
			function () use ( $self, $request ) {
				return $self->query_matching_count( $request );
			}
		);

		return (int) $data;
	}

	/**
	 * Run the taxonomy GROUP BY.
	 *
	 * @param string         $taxonomy Taxonomy.
	 * @param Parsed_Request $request  Request without this facet.
	 * @return array<int, int>
	 */
	public function query_term_counts( $taxonomy, Parsed_Request $request ) {
		global $wpdb;

		$product_sql = $this->product_subquery( $request );

		if ( 0 === strpos( (string) $taxonomy, 'pa_' ) || ( function_exists( 'taxonomy_is_product_attribute' ) && taxonomy_is_product_attribute( $taxonomy ) ) ) {
			$lookup = $wpdb->prefix . 'wc_product_attributes_lookup';
			$sql    = "SELECT l.term_id AS term_id, COUNT(DISTINCT l.product_or_parent_id) AS term_count
				FROM {$lookup} l
				WHERE l.taxonomy = %s
				AND l.product_or_parent_id IN ( {$product_sql} )
				GROUP BY l.term_id";
		} else {
			$sql = "SELECT tt.term_id AS term_id, COUNT(DISTINCT tr.object_id) AS term_count
				FROM {$wpdb->term_relationships} tr
				INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
				WHERE tt.taxonomy = %s
				AND tr.object_id IN ( {$product_sql} )
				GROUP BY tt.term_id";
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $taxonomy ), ARRAY_A );

		$counts = array();
		if ( is_array( $rows ) ) {
			foreach ( $rows as $row ) {
				$term_id = isset( $row['term_id'] ) ? (int) $row['term_id'] : 0;
				if ( $term_id > 0 ) {
					$counts[ $term_id ] = isset( $row['term_count'] ) ? (int) $row['term_count'] : 0;
				}
			}
		}

		return $counts;
	}

	/**
	 * Run the price range query.
	 *
	 * @param Parsed_Request $request Request without price bounds.
	 * @return array{min: float|null, max: float|null}
	 */
	public function query_price_range( Parsed_Request $request ) {
		global $wpdb;

		$product_sql = $this->product_subquery( $request );
		$table       = $wpdb->prefix . 'wc_product_meta_lookup';
		$sql         = "SELECT MIN(m.min_price) AS min_price, MAX(m.max_price) AS max_price
			FROM {$table} m
			WHERE m.product_id IN ( {$product_sql} )";

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $sql, ARRAY_A );

		$min = ( is_array( $row ) && isset( $row['min_price'] ) && '' !== $row['min_price'] ) ? (float) $row['min_price'] : null;
		$max = ( is_array( $row ) && isset( $row['max_price'] ) && '' !== $row['max_price'] ) ? (float) $row['max_price'] : null;

		return array(
			'min' => $min,
			'max' => $max,
		);
	}

	/**
	 * Run the in-stock count query.
	 *
	 * @param Parsed_Request $request Request without the instock flag.
	 * @return int
	 */
	public function query_instock_count( Parsed_Request $request ) {
		global $wpdb;

		$with_stock  = new Parsed_Request( $request->groups(), $request->min_price(), $request->max_price(), true, $request->dropped() );
		$product_sql = $this->product_subquery( $with_stock );
		// The subquery is built from prepared Clause_Builder fragments.
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$count = $wpdb->get_var( "SELECT COUNT(*) FROM ( {$product_sql} ) fflf_in_stock_src" );

		return (int) $count;
	}

	/**
	 * Run the matching-product count query.
	 *
	 * @param Parsed_Request $request Constrained request.
	 * @return int
	 */
	public function query_matching_count( Parsed_Request $request ) {
		global $wpdb;

		if ( ! isset( $wpdb ) || ! is_object( $wpdb ) ) {
			return 0;
		}

		$product_sql = $this->product_subquery( $request );
		// The subquery is built from prepared Clause_Builder fragments.
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$count = $wpdb->get_var( "SELECT COUNT(*) FROM ( {$product_sql} ) fflf_matching_src" );

		return (int) $count;
	}

	/**
	 * SELECT of published product IDs, with optional filter clauses.
	 *
	 * @param Parsed_Request $request Constraints.
	 * @return string
	 */
	public function product_subquery( Parsed_Request $request ) {
		global $wpdb;

		$clauses = array(
			'join'  => '',
			'where' => '',
		);

		if ( $request->has_filters() ) {
			$clauses = $this->builder->apply( $clauses, $request );
		}

		$join  = isset( $clauses['join'] ) ? $clauses['join'] : '';
		$where = isset( $clauses['where'] ) ? $clauses['where'] : '';

		return "SELECT {$wpdb->posts}.ID FROM {$wpdb->posts} {$join} WHERE {$wpdb->posts}.post_type = 'product' AND {$wpdb->posts}.post_status = 'publish' {$where}";
	}

	/**
	 * In-store product count for a constrained request.
	 *
	 * @param string         $scope   Scope.
	 * @param Parsed_Request $request Request.
	 * @return int
	 */
	public function instore( $scope, Parsed_Request $request ) {
		unset( $scope );
		$config   = new \FFL_Filters\Presets\Config();
		$taxonomy = $config->instore_taxonomy();
		$slug     = $config->instore_slug();
		$term     = function_exists( 'get_term_by' ) ? get_term_by( 'slug', $slug, $taxonomy ) : null;
		if ( ! $term || is_wp_error( $term ) ) {
			return 0;
		}
		$counts = $this->terms( $taxonomy, '', $this->without_instore( $request ) );
		$id     = (int) $term->term_id;
		return isset( $counts[ $id ] ) ? (int) $counts[ $id ] : 0;
	}

	/**
	 * Drop one taxonomy group from the request.
	 *
	 * @param Parsed_Request $request  Request.
	 * @param string         $taxonomy Taxonomy to exclude.
	 * @return Parsed_Request
	 */
	public function without_group( Parsed_Request $request, $taxonomy ) {
		$groups = $request->groups();
		unset( $groups[ $taxonomy ] );
		return $request->with( array( 'groups' => $groups ) );
	}

	/**
	 * Drop a numeric range from the request.
	 *
	 * @param Parsed_Request $request  Request.
	 * @param string         $taxonomy Taxonomy to exclude.
	 * @return Parsed_Request
	 */
	public function without_range( Parsed_Request $request, $taxonomy ) {
		$ranges = $request->ranges();
		unset( $ranges[ (string) $taxonomy ] );
		return $request->with( array( 'ranges' => $ranges ) );
	}

	/**
	 * Drop price bounds from the request.
	 *
	 * @param Parsed_Request $request Request.
	 * @return Parsed_Request
	 */
	public function without_prices( Parsed_Request $request ) {
		return $request->with(
			array(
				'min_price' => null,
				'max_price' => null,
			)
		);
	}

	/**
	 * Drop the instock flag from the request.
	 *
	 * @param Parsed_Request $request Request.
	 * @return Parsed_Request
	 */
	public function without_instock( Parsed_Request $request ) {
		return $request->with( array( 'instock' => false ) );
	}

	/**
	 * Drop the instore flag from the request.
	 *
	 * @param Parsed_Request $request Request.
	 * @return Parsed_Request
	 */
	public function without_instore( Parsed_Request $request ) {
		return $request->with( array( 'instore' => false ) );
	}
}
