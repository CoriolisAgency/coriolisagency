<?php
/**
 * Visible facet list for the storefront panel.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Panel;

use FFL_Filters\Url\Normalizer;

defined( 'ABSPATH' ) || exit;

/**
 * Discovers default facets, then applies the dealer settings list.
 */
class Facets {

	/**
	 * URL normalizer (taxonomy → request key).
	 *
	 * @var Normalizer
	 */
	private $normalizer;

	/**
	 * Constructor.
	 *
	 * @param Normalizer|null $normalizer URL normalizer.
	 */
	public function __construct( $normalizer = null ) {
		$this->normalizer = $normalizer ? $normalizer : new Normalizer();
	}

	/**
	 * Default facets: in stock, price, brand, category, product attributes, tags.
	 *
	 * @return array<int, array<string, string>>
	 */
	public function all() {
		$facets = array(
			array(
				'id'    => 'instock',
				'type'  => 'instock',
				'label' => __( 'In stock', 'ffl-filters' ),
				'param' => 'instock',
			),
			array(
				'id'    => 'price',
				'type'  => 'price',
				'label' => __( 'Price', 'ffl-filters' ),
				'param' => 'min_price',
			),
		);

		if ( taxonomy_exists( 'product_brand' ) ) {
			$facets[] = $this->taxonomy_facet( 'product_brand', __( 'Brand', 'ffl-filters' ) );
		}

		if ( taxonomy_exists( 'product_cat' ) ) {
			$facets[] = $this->taxonomy_facet( 'product_cat', __( 'Category', 'ffl-filters' ) );
		}

		if ( function_exists( 'wc_get_attribute_taxonomies' ) ) {
			$attributes = wc_get_attribute_taxonomies();
			if ( is_array( $attributes ) ) {
				foreach ( $attributes as $attribute ) {
					$slug = isset( $attribute->attribute_name ) ? (string) $attribute->attribute_name : '';
					if ( '' === $slug ) {
						continue;
					}
					$taxonomy = function_exists( 'wc_attribute_taxonomy_name' )
						? wc_attribute_taxonomy_name( $slug )
						: 'pa_' . $slug;
					if ( ! taxonomy_exists( $taxonomy ) ) {
						continue;
					}
					$label    = isset( $attribute->attribute_label ) ? (string) $attribute->attribute_label : $slug;
					$facets[] = $this->taxonomy_facet( $taxonomy, $label );
				}
			}
		}

		if ( taxonomy_exists( 'product_tag' ) ) {
			$facets[] = $this->taxonomy_facet( 'product_tag', __( 'Tag', 'ffl-filters' ) );
		}

		$facets = $this->apply_presets( $facets );

		if ( class_exists( '\FFL_Filters\Settings\Applicator' ) ) {
			$facets = ( new \FFL_Filters\Settings\Applicator() )->facets( $facets );
		}

		/**
		 * Filters the storefront facet list.
		 *
		 * @since 0.0.1
		 * @param array<int, array<string, mixed>> $facets Facet descriptors.
		 */
		return apply_filters( 'fflf_panel_facets', $facets );
	}

	/**
	 * Top-N terms rendered per group.
	 *
	 * @return int
	 */
	public function top_n() {
		$n = 8;
		if ( function_exists( 'apply_filters' ) ) {
			/**
			 * Filters how many terms are server-rendered in a group.
			 *
			 * @since 0.0.1
			 * @param int $n Top-N terms per group.
			 */
			$n = (int) apply_filters( 'fflf_panel_top_n', $n );
		}
		return $n > 0 ? $n : 8;
	}

	/**
	 * Hard cap when a group is expanded without JavaScript (fflf_expand fallback).
	 *
	 * @return int
	 */
	public function expand_cap() {
		$n = 250;
		if ( function_exists( 'apply_filters' ) ) {
			/**
			 * Filters the cap on a server-rendered expanded group.
			 *
			 * @since 0.0.1
			 * @param int $n Maximum terms when a group is expanded.
			 */
			$n = (int) apply_filters( 'fflf_panel_expand_cap', $n );
		}
		return $n > 0 ? $n : 250;
	}

	/**
	 * Mobile presentation: drawer, collapsible, or sidebar.
	 *
	 * @return string
	 */
	public function mobile_display() {
		$mode = 'drawer';
		if ( class_exists( '\FFL_Filters\Settings\Repository' ) ) {
			$settings = ( new \FFL_Filters\Settings\Repository() )->all();
			if ( isset( $settings['display']['mobile'] ) ) {
				$mode = (string) $settings['display']['mobile'];
			}
		}
		if ( function_exists( 'apply_filters' ) ) {
			/**
			 * Filters the mobile panel presentation.
			 *
			 * @since 0.0.1
			 * @param string $mode drawer, collapsible, or sidebar.
			 */
			$mode = (string) apply_filters( 'fflf_panel_mobile_display', $mode );
		}
		if ( ! in_array( $mode, array( 'drawer', 'collapsible', 'sidebar' ), true ) ) {
			return 'drawer';
		}
		return $mode;
	}

	/**
	 * Inject firearm presets: in-store toggle, merged caliber, firearm type label, range types.
	 *
	 * @param array<int, array<string, mixed>> $facets Discovered facets.
	 * @return array<int, array<string, mixed>>
	 */
	private function apply_presets( $facets ) {
		$config  = new \FFL_Filters\Presets\Config();
		$numeric = $config->numeric();
		$out     = array();

		if ( $config->instore_enabled() && $this->instore_available( $config ) ) {
			$out[] = array(
				'id'    => 'instore',
				'type'  => 'instore',
				'label' => $config->instore_label(),
				'param' => 'instore',
			);
		}

		$caliber_taxes = $config->caliber_taxonomies();
		$caliber_on    = $config->caliber_enabled();
		$has_backing   = false;
		if ( $caliber_on ) {
			foreach ( $caliber_taxes as $taxonomy ) {
				if ( function_exists( 'taxonomy_exists' ) && taxonomy_exists( $taxonomy ) ) {
					$has_backing = true;
					break;
				}
			}
		}

		if ( $has_backing ) {
			$out[] = array(
				'id'    => \FFL_Filters\Presets\Defaults::CALIBER_ID,
				'type'  => 'terms',
				'label' => $config->caliber_label(),
				'param' => 'filter_caliber',
			);
		}

		foreach ( $facets as $facet ) {
			if ( ! is_array( $facet ) || empty( $facet['id'] ) ) {
				continue;
			}
			$id = (string) $facet['id'];
			if ( $has_backing && in_array( $id, $caliber_taxes, true ) ) {
				continue;
			}
			if ( $config->is_firearm_type_taxonomy( $id ) ) {
				if ( ! $config->firearm_type_enabled() ) {
					continue;
				}
				$facet['label'] = $config->firearm_type_label();
			}
			if ( $numeric->is_range_taxonomy( $id ) && ( ! isset( $facet['type'] ) || 'terms' === $facet['type'] ) ) {
				$facet['type'] = 'range';
			}
			$out[] = $facet;
		}

		return $out;
	}

	/**
	 * Whether the configured in-store tag exists in the catalog.
	 *
	 * @param \FFL_Filters\Presets\Config $config Presets.
	 * @return bool
	 */
	private function instore_available( $config ) {
		$taxonomy = $config->instore_taxonomy();
		if ( ! function_exists( 'taxonomy_exists' ) || ! taxonomy_exists( $taxonomy ) ) {
			return false;
		}
		$term = function_exists( 'get_term_by' ) ? get_term_by( 'slug', $config->instore_slug(), $taxonomy ) : null;
		return $term && ! is_wp_error( $term );
	}

	/**
	 * Build a taxonomy facet descriptor.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @param string $label    Label.
	 * @return array<string, string>
	 */
	private function taxonomy_facet( $taxonomy, $label ) {
		return array(
			'id'    => $taxonomy,
			'type'  => 'terms',
			'label' => $label,
			'param' => $this->normalizer->param_for_taxonomy( $taxonomy ),
		);
	}
}
