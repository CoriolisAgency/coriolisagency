<?php
/**
 * Gutenberg / site-editor block for the filter panel.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Panel;

defined( 'ABSPATH' ) || exit;

/**
 * Registers the ffl-filters/panel block with a server-side render.
 *
 * The inherit attribute (true by default) uses the current product archive or, when the
 * block is nested in a Product Collection, that collection's query context.
 */
class Block {

	/**
	 * Panel controller.
	 *
	 * @var Controller|null
	 */
	private $controller;

	/**
	 * Constructor.
	 *
	 * @param Controller|null $controller Panel controller.
	 */
	public function __construct( $controller = null ) {
		$this->controller = $controller;
	}

	/**
	 * Register the block type and editor assets.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! function_exists( 'register_block_type' ) ) {
			return;
		}

		$dir = $this->block_dir();
		if ( '' === $dir || ! is_readable( $dir . 'block.json' ) ) {
			return;
		}

		$this->register_editor_assets();

		register_block_type(
			$dir,
			array(
				'render_callback' => array( $this, 'render' ),
				'editor_script'   => 'fflf-filters-block-editor',
				'editor_style'    => 'fflf-filters-block-editor',
			)
		);
	}

	/**
	 * Server-side render for the block.
	 *
	 * @param array<string, mixed> $attributes Block attributes.
	 * @param string               $content    Saved content (unused).
	 * @param \WP_Block|null       $block      Parsed block, when provided.
	 * @return string
	 */
	public function render( $attributes = array(), $content = '', $block = null ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
		$shortcode = new Shortcode( $this->controller );
		if ( function_exists( 'fflf_is_passive' ) ? fflf_is_passive() : ( function_exists( 'fflf_compare_plugin_is_active' ) && fflf_compare_plugin_is_active() ) ) {
			return $shortcode->placeholder();
		}

		$atts = Attributes::normalize( is_array( $attributes ) ? $attributes : array() );
		if ( Attributes::inherit( $atts ) && $block && isset( $block->context['query'] ) && is_array( $block->context['query'] ) ) {
			$atts['query'] = $block->context['query'];
		}

		$controller = $this->controller ? $this->controller : Controller::instance();
		if ( ! $controller ) {
			return '';
		}

		$controller->mark_manual();

		return $controller->render( Attributes::resolve_title( $atts ) );
	}

	/**
	 * Editor script, style, and the official small icon URL.
	 *
	 * @return void
	 */
	private function register_editor_assets() {
		if ( ! function_exists( 'wp_register_script' ) ) {
			return;
		}

		$dir = $this->block_dir();
		$ver = defined( 'FFLF_VERSION' ) ? FFLF_VERSION : '0.0.1';
		$url = defined( 'FFLF_URL' ) ? FFLF_URL : '';

		$script = $dir . 'editor.js';
		$style  = $dir . 'editor.css';

		wp_register_script(
			'fflf-filters-block-editor',
			$url . 'blocks/ffl-filters/editor.js',
			array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-i18n', 'wp-server-side-render' ),
			is_readable( $script ) ? (string) filemtime( $script ) : $ver,
			true
		);

		wp_register_style(
			'fflf-filters-block-editor',
			$url . 'blocks/ffl-filters/editor.css',
			array(),
			is_readable( $style ) ? (string) filemtime( $style ) : $ver
		);

		if ( function_exists( 'wp_localize_script' ) ) {
			wp_localize_script(
				'fflf-filters-block-editor',
				'fflfBlockEditor',
				array(
					'iconUrl' => $url . 'assets/images/ffl-filters-icon-small.svg',
				)
			);
		}
	}

	/**
	 * Absolute path to the block folder, with a trailing slash.
	 *
	 * @return string
	 */
	private function block_dir() {
		if ( ! defined( 'FFLF_DIR' ) ) {
			return '';
		}
		return FFLF_DIR . 'blocks/ffl-filters/';
	}
}
