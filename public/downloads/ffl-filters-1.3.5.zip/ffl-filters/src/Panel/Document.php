<?php
/**
 * Assemble the panel view-model from facets, counts and the request.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Panel;

use FFL_Filters\Query\Parsed_Request;
use FFL_Filters\Query\Request_Parser;
use FFL_Filters\Url\Normalizer;

defined( 'ABSPATH' ) || exit;

/**
 * Turns live catalog data into the structure the renderer prints.
 */
class Document {

	/**
	 * Facet catalog.
	 *
	 * @var Facets
	 */
	private $facets;

	/**
	 * Counts.
	 *
	 * @var Counts
	 */
	private $counts;

	/**
	 * Archive scope.
	 *
	 * @var Scope
	 */
	private $scope;

	/**
	 * Request parser.
	 *
	 * @var Request_Parser
	 */
	private $parser;

	/**
	 * URL normalizer.
	 *
	 * @var Normalizer
	 */
	private $normalizer;

	/**
	 * JSON endpoint (lazy).
	 *
	 * @var Endpoint|null
	 */
	private $endpoint;

	/**
	 * Settings applicator (lazy).
	 *
	 * @var \FFL_Filters\Settings\Applicator|null
	 */
	private $applicator;

	/**
	 * Constructor.
	 *
	 * @param Facets|null         $facets     Facet catalog.
	 * @param Counts|null         $counts     Counts.
	 * @param Scope|null          $scope      Archive scope.
	 * @param Request_Parser|null $parser     Request parser.
	 * @param Normalizer|null     $normalizer URL normalizer.
	 * @param Endpoint|null       $endpoint   JSON endpoint.
	 */
	public function __construct( $facets = null, $counts = null, $scope = null, $parser = null, $normalizer = null, $endpoint = null ) {
		$this->facets     = $facets ? $facets : new Facets();
		$this->counts     = $counts ? $counts : new Counts();
		$this->scope      = $scope ? $scope : new Scope();
		$this->parser     = $parser ? $parser : new Request_Parser();
		$this->normalizer = $normalizer ? $normalizer : new Normalizer();
		$this->endpoint   = $endpoint;
	}

	/**
	 * Settings applicator.
	 *
	 * @return \FFL_Filters\Settings\Applicator
	 */
	private function applicator() {
		if ( ! $this->applicator ) {
			$this->applicator = new \FFL_Filters\Settings\Applicator();
		}
		return $this->applicator;
	}

	/**
	 * JSON endpoint (lazy to avoid a constructor cycle).
	 *
	 * @return Endpoint
	 */
	private function endpoint() {
		if ( ! $this->endpoint ) {
			$this->endpoint = new Endpoint( null, $this->counts, $this->facets, $this );
		}
		return $this->endpoint;
	}

	/**
	 * Public term list for the static JSON endpoint (no selection state).
	 *
	 * @param string          $taxonomy Taxonomy.
	 * @param array<int, int> $counts   Term ID => count.
	 * @return array<int, array{slug: string, label: string, count: int}>
	 */
	public function terms_for_json( $taxonomy, $counts ) {
		$terms = $this->prepare_terms( $taxonomy, $this->terms_for_counts( $taxonomy, $counts, array() ) );

		$out = array();
		foreach ( $terms as $term ) {
			$out[] = array(
				'slug'  => $term['slug'],
				'label' => $term['label'],
				'count' => (int) $term['count'],
			);
		}
		return $out;
	}

	/**
	 * Build the view-model used by the renderer.
	 *
	 * @param array|null           $source       Optional request array.
	 * @param int|null             $result_count Visible result count.
	 * @param array<string, mixed> $options      Shortcode / block attributes.
	 * @return array<string, mixed>
	 */
	public function build( $source = null, $result_count = null, $options = array() ) {
		if ( ! is_array( $source ) ) {
			$source = function_exists( 'wp_unslash' ) ? wp_unslash( $_GET ) : $_GET; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			if ( ! is_array( $source ) ) {
				$source = array();
			}
		}
		if ( ! is_array( $options ) ) {
			$options = array();
		}

		$request     = $this->parser->parse( $source );
		$constrained = $this->scope->constrain_for( $request, $options );
		$scope_id    = $this->scope->id_for( $options );
		$top_n       = $this->facets->top_n();
		$expand_cap  = $this->facets->expand_cap();
		$expanded    = $this->expanded_facets( $source );
		$groups      = array();

		foreach ( $this->facets->all() as $facet ) {
			if ( ! Attributes::allows_facet( $facet, $options ) ) {
				continue;
			}
			$type = isset( $facet['type'] ) ? $facet['type'] : '';
			if ( 'price' === $type ) {
				$group = $this->price_group( $facet, $scope_id, $constrained, $request );
			} elseif ( 'instock' === $type ) {
				$group = $this->instock_group( $facet, $scope_id, $constrained, $request );
			} elseif ( 'instore' === $type ) {
				$group = $this->instore_group( $facet, $scope_id, $constrained, $request );
			} elseif ( 'range' === $type ) {
				$group = $this->numeric_range_group( $facet, $scope_id, $constrained, $request );
			} else {
				$group = $this->terms_group( $facet, $scope_id, $constrained, $request, $top_n, $expand_cap, $expanded );
			}

			if ( null !== $group ) {
				$groups[] = $group;
			}
		}

		$action = $this->scope->url_for( $options );
		$chips  = $this->chips( $request, $action );
		if ( ! Attributes::show_chips( $options ) ) {
			$chips = array();
		}

		$above = isset( $options['placement'] ) && 'above' === $options['placement'];
		if ( $above ) {
			$active = $this->active_source( $request );
			foreach ( $groups as $i => $group ) {
				$groups[ $i ]['clear_url'] = $this->build_url( $action, $this->without_group( $active, $group ) );
			}
		}

		return array(
			'action'       => $action,
			'clear_url'    => $action,
			'groups'       => $groups,
			'chips'        => $chips,
			'result_count' => null === $result_count ? $this->visible_result_count( $constrained, $scope_id ) : (int) $result_count,
			'mobile'       => $this->facets->mobile_display(),
			'hidden'       => $this->hidden_fields( $source ),
			'has_filters'  => $request->has_filters(),
			'show_title'   => Attributes::show_title( $options ),
			'heading'      => Attributes::heading( $options ),
			'layout'       => Attributes::layout( $options ),
			'placement'    => $above ? 'above' : 'sidebar',
			'panel_style'  => $this->panel_style(),
			'sort'         => $above ? $this->sort_options( $source ) : array(),
		);
	}

	/**
	 * Panel style setting (auto, light or dark).
	 *
	 * @return string
	 */
	private function panel_style() {
		$all = ( new \FFL_Filters\Settings\Repository() )->all();
		return isset( $all['display']['panel_style'] ) ? \FFL_Filters\Settings\Repository::sanitize_panel_style( $all['display']['panel_style'] ) : 'auto';
	}

	/**
	 * Sorting choices for the results row: WooCommerce's own list and labels, through its own filter.
	 *
	 * @param array $source Request.
	 * @return array{options: array<string, string>, current: string}
	 */
	private function sort_options( $source ) {
		if ( ! function_exists( 'wc_get_loop_prop' ) && ! function_exists( 'woocommerce_catalog_ordering' ) ) {
			return array(
				'options' => array(),
				'current' => '',
			);
		}
		$default = function_exists( 'get_option' ) ? (string) get_option( 'woocommerce_default_catalog_orderby', 'menu_order' ) : 'menu_order';
		/**
		 * WooCommerce's own sorting filter, applied so the results row offers the same choices as the theme's sort box.
		 *
		 * @since 1.3.0
		 */
		$default = function_exists( 'apply_filters' ) ? (string) apply_filters( 'woocommerce_default_catalog_orderby', $default ) : $default; // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce's own filter.
		// phpcs:disable WordPress.WP.I18n.TextDomainMismatch -- WooCommerce's own sorting labels, so they match the theme's sort box.
		$options = array(
			'menu_order' => __( 'Default sorting', 'woocommerce' ),
			'popularity' => __( 'Sort by popularity', 'woocommerce' ),
			'rating'     => __( 'Sort by average rating', 'woocommerce' ),
			'date'       => __( 'Sort by latest', 'woocommerce' ),
			'price'      => __( 'Sort by price: low to high', 'woocommerce' ),
			'price-desc' => __( 'Sort by price: high to low', 'woocommerce' ),
		);
		// phpcs:enable WordPress.WP.I18n.TextDomainMismatch
		if ( function_exists( 'wc_review_ratings_enabled' ) && ! wc_review_ratings_enabled() ) {
			unset( $options['rating'] );
		}
		/**
		 * WooCommerce's own sorting filter, applied so the results row offers the same choices as the theme's sort box.
		 *
		 * @since 1.3.0
		 */
		$options = function_exists( 'apply_filters' ) ? apply_filters( 'woocommerce_catalog_orderby', $options ) : $options; // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce's own filter.
		if ( ! is_array( $options ) || empty( $options ) ) {
			return array(
				'options' => array(),
				'current' => '',
			);
		}
		$current = isset( $source['orderby'] ) && is_scalar( $source['orderby'] ) && '' !== (string) $source['orderby'] ? (string) $source['orderby'] : $default;
		if ( ! isset( $options[ $current ] ) ) {
			$current = (string) key( $options );
		}
		$clean = array();
		foreach ( $options as $value => $label ) {
			$clean[ (string) $value ] = wp_strip_all_tags( (string) $label );
		}
		return array(
			'options' => $clean,
			'current' => $current,
		);
	}

	/**
	 * Active filter params, as the chips and group Clear links rebuild them.
	 *
	 * @param Parsed_Request $request Request.
	 * @return array<string, mixed>
	 */
	private function active_source( Parsed_Request $request ) {
		$source = array();
		foreach ( $request->groups() as $taxonomy => $slugs ) {
			$source[ $this->normalizer->param_for_taxonomy( $taxonomy ) ] = $slugs;
		}
		if ( null !== $request->min_price() ) {
			$source['min_price'] = $this->format_price( $request->min_price() );
		}
		if ( null !== $request->max_price() ) {
			$source['max_price'] = $this->format_price( $request->max_price() );
		}
		if ( $request->instock() ) {
			$source['instock'] = '1';
		}
		if ( $request->instore() ) {
			$source['instore'] = '1';
		}
		$numeric = ( new \FFL_Filters\Presets\Config() )->numeric();
		foreach ( $request->ranges() as $taxonomy => $range ) {
			if ( ! is_array( $range ) ) {
				continue;
			}
			if ( isset( $range['min'] ) ) {
				$source[ $numeric->min_param( $taxonomy ) ] = $this->format_price( $range['min'] );
			}
			if ( isset( $range['max'] ) ) {
				$source[ $numeric->max_param( $taxonomy ) ] = $this->format_price( $range['max'] );
			}
		}
		return $source;
	}

	/**
	 * Active params without one group's own params (for "Clear <group>").
	 *
	 * @param array<string, mixed> $active Active params.
	 * @param array<string, mixed> $group  Group view-model.
	 * @return array<string, mixed>
	 */
	private function without_group( $active, $group ) {
		$type = isset( $group['type'] ) ? (string) $group['type'] : '';
		if ( 'price' === $type ) {
			unset( $active['min_price'], $active['max_price'] );
		}
		foreach ( array( 'param', 'param_min', 'param_max' ) as $key ) {
			if ( ! empty( $group[ $key ] ) ) {
				unset( $active[ (string) $group[ $key ] ] );
			}
		}
		return $active;
	}

	/**
	 * Taxonomies expanded via fflf_expand.
	 *
	 * @param array $source Request.
	 * @return array<int, string>
	 */
	private function expanded_facets( $source ) {
		if ( ! isset( $source['fflf_expand'] ) ) {
			return array();
		}

		$raw = $source['fflf_expand'];
		if ( ! is_array( $raw ) ) {
			$raw = array( $raw );
		}

		$out = array();
		foreach ( $raw as $value ) {
			if ( is_string( $value ) && '' !== $value ) {
				$out[] = $value;
			}
		}

		return $out;
	}

	/**
	 * Term group view-model, or null when the facet has nothing to show.
	 *
	 * @param array<string, string> $facet      Facet.
	 * @param string                $scope_id   Scope.
	 * @param Parsed_Request        $constrained Constrained request.
	 * @param Parsed_Request        $request    Raw parsed request.
	 * @param int                   $top_n      Top N.
	 * @param int                   $expand_cap Expand cap.
	 * @param array<int, string>    $expanded   Expanded facet ids.
	 * @return array<string, mixed>|null
	 */
	private function terms_group( $facet, $scope_id, Parsed_Request $constrained, Parsed_Request $request, $top_n, $expand_cap, $expanded ) {
		$taxonomy = isset( $facet['id'] ) ? $facet['id'] : '';
		if ( '' === $taxonomy ) {
			return null;
		}

		if ( \FFL_Filters\Presets\Defaults::CALIBER_ID === $taxonomy ) {
			return $this->caliber_group( $facet, $scope_id, $constrained, $request, $top_n, $expand_cap, $expanded );
		}

		$counts = $this->counts->terms( $taxonomy, $scope_id, $constrained );
		if ( empty( $counts ) ) {
			return null;
		}

		$selected = array();
		if ( isset( $request->groups()[ $taxonomy ] ) ) {
			$selected = $request->groups()[ $taxonomy ];
		}

		$terms = $this->prepare_terms( $taxonomy, $this->terms_for_counts( $taxonomy, $counts, $selected ) );

		$total   = count( $terms );
		$is_open = in_array( $taxonomy, $expanded, true );
		$large   = $total > $top_n;
		// A long list renders in full (to the expand cap) with live counts in count order, so it opens straight to its values.
		// It scrolls inside its own box; the static JSON file only covers lists longer than the cap.
		$limit   = $large ? $expand_cap : $top_n;
		$visible = $this->slice_terms( $terms, $limit );
		$type    = isset( $facet['type'] ) ? (string) $facet['type'] : 'terms';
		// 'dropdown' was dropped in 1.2.0; a saved dropdown facet renders as the checkbox list.
		if ( in_array( $type, array( 'checkbox', 'range', 'dropdown', '' ), true ) ) {
			$type = 'terms';
		}

		return array(
			'id'       => $taxonomy,
			'type'     => $type,
			'label'    => isset( $facet['label'] ) ? $facet['label'] : $taxonomy,
			'param'    => isset( $facet['param'] ) ? $facet['param'] : $this->normalizer->param_for_taxonomy( $taxonomy ),
			// 1.2.1: closed by default; a group with a picked value opens on load.
			'expanded' => $is_open || ! empty( $selected ),
			'large'    => $large,
			'total'    => $total,
			'show_all' => $large && $total > $expand_cap && ! $is_open,
			'json'     => $large && $total > $expand_cap ? $this->endpoint()->url( $scope_id, $taxonomy ) : '',
			'terms'    => $visible,
		);
	}

	/**
	 * Map term IDs to labels and selection state, dropping zero-count unselected terms.
	 *
	 * @param string             $taxonomy Taxonomy.
	 * @param array<int, int>    $counts   Term ID => count.
	 * @param array<int, string> $selected Selected slugs.
	 * @return array<int, array<string, mixed>>
	 */
	private function terms_for_counts( $taxonomy, $counts, $selected ) {
		$terms = array();
		$ids   = array_map( 'intval', array_keys( $counts ) );

		$objects = array();
		if ( function_exists( 'get_terms' ) && ! empty( $ids ) ) {
			$found = get_terms(
				array(
					'taxonomy'   => $taxonomy,
					'include'    => $ids,
					'hide_empty' => false,
				)
			);
			if ( ! is_wp_error( $found ) && is_array( $found ) ) {
				foreach ( $found as $term ) {
					$objects[ (int) $term->term_id ] = $term;
				}
			}
		}

		foreach ( $counts as $term_id => $count ) {
			$term_id = (int) $term_id;
			$count   = (int) $count;
			if ( ! isset( $objects[ $term_id ] ) ) {
				continue;
			}
			$slug        = (string) $objects[ $term_id ]->slug;
			$is_selected = in_array( $slug, $selected, true );
			if ( $count <= 0 && ! $is_selected ) {
				continue;
			}
			$terms[] = array(
				'id'       => $term_id,
				'parent'   => (int) $objects[ $term_id ]->parent,
				'slug'     => $slug,
				'label'    => (string) $objects[ $term_id ]->name,
				'count'    => $count,
				'selected' => $is_selected,
			);
		}

		// Keep a selected slug visible even if it had no count row.
		$have = array();
		foreach ( $terms as $term ) {
			$have[] = $term['slug'];
		}
		foreach ( $selected as $slug ) {
			if ( in_array( $slug, $have, true ) ) {
				continue;
			}
			$term = function_exists( 'get_term_by' ) ? get_term_by( 'slug', $slug, $taxonomy ) : null;
			if ( ! $term || is_wp_error( $term ) ) {
				continue;
			}
			$terms[] = array(
				'id'       => (int) $term->term_id,
				'parent'   => (int) $term->parent,
				'slug'     => (string) $term->slug,
				'label'    => (string) $term->name,
				'count'    => 0,
				'selected' => true,
			);
		}

		return $terms;
	}

	/**
	 * Apply hidden-term, category-mode, and pinned-tag settings, then sort.
	 *
	 * @param string                           $taxonomy Taxonomy.
	 * @param array<int, array<string, mixed>> $terms    Terms.
	 * @return array<int, array<string, mixed>>
	 */
	private function prepare_terms( $taxonomy, $terms ) {
		$terms = $this->applicator()->filter_terms( $taxonomy, $terms );
		if ( $this->applicator()->is_nested( $taxonomy ) ) {
			return $this->applicator()->sort_tree( $terms );
		}
		usort(
			$terms,
			static function ( $a, $b ) {
				if ( $a['count'] === $b['count'] ) {
					return strcasecmp( $a['label'], $b['label'] );
				}
				return ( $a['count'] > $b['count'] ) ? -1 : 1;
			}
		);
		return $terms;
	}

	/**
	 * Keep selected terms and the highest-count remainder up to $limit.
	 *
	 * @param array<int, array<string, mixed>> $terms Terms sorted by count.
	 * @param int                              $limit Limit.
	 * @return array<int, array<string, mixed>>
	 */
	private function slice_terms( $terms, $limit ) {
		$visible = array_slice( $terms, 0, $limit );
		$have    = array();
		foreach ( $visible as $term ) {
			$have[] = $term['slug'];
		}

		foreach ( $terms as $term ) {
			if ( empty( $term['selected'] ) || in_array( $term['slug'], $have, true ) ) {
				continue;
			}
			$visible[] = $term;
			$have[]    = $term['slug'];
		}

		return $visible;
	}

	/**
	 * Price group view-model.
	 *
	 * @param array<string, string> $facet       Facet.
	 * @param string                $scope_id    Scope.
	 * @param Parsed_Request        $constrained Constrained request.
	 * @param Parsed_Request        $request     Raw request.
	 * @return array<string, mixed>
	 */
	private function price_group( $facet, $scope_id, Parsed_Request $constrained, Parsed_Request $request ) {
		$range  = $this->counts->price_range( $scope_id, $constrained );
		$symbol = function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol() : '$';

		return array(
			'id'        => 'price',
			'type'      => 'price',
			'label'     => isset( $facet['label'] ) ? $facet['label'] : __( 'Price', 'ffl-filters' ),
			'expanded'  => null !== $request->min_price() || null !== $request->max_price(),
			'large'     => false,
			'total'     => 0,
			'show_all'  => false,
			'min'       => $request->min_price(),
			'max'       => $request->max_price(),
			'bound_min' => $range['min'],
			'bound_max' => $range['max'],
			'symbol'    => is_string( $symbol ) ? $symbol : '$',
		);
	}

	/**
	 * In-stock group view-model.
	 *
	 * @param array<string, string> $facet       Facet.
	 * @param string                $scope_id    Scope.
	 * @param Parsed_Request        $constrained Constrained request.
	 * @param Parsed_Request        $request     Raw request.
	 * @return array<string, mixed>
	 */
	private function instock_group( $facet, $scope_id, Parsed_Request $constrained, Parsed_Request $request ) {
		$count = $this->counts->instock( $scope_id, $constrained );

		return array(
			'id'       => 'instock',
			'type'     => 'instock',
			'label'    => isset( $facet['label'] ) ? $facet['label'] : __( 'In stock', 'ffl-filters' ),
			'expanded' => true,
			'large'    => false,
			'total'    => 0,
			'show_all' => false,
			'count'    => $count,
			'selected' => $request->instock(),
		);
	}

	/**
	 * In-store group view-model.
	 *
	 * @param array<string, mixed> $facet       Facet.
	 * @param string               $scope_id    Scope.
	 * @param Parsed_Request       $constrained Constrained request.
	 * @param Parsed_Request       $request     Raw request.
	 * @return array<string, mixed>
	 */
	private function instore_group( $facet, $scope_id, Parsed_Request $constrained, Parsed_Request $request ) {
		return array(
			'id'       => 'instore',
			'type'     => 'instore',
			'label'    => isset( $facet['label'] ) ? $facet['label'] : __( 'In store', 'ffl-filters' ),
			'expanded' => true,
			'large'    => false,
			'total'    => 0,
			'show_all' => false,
			'count'    => $this->counts->instore( $scope_id, $constrained ),
			'selected' => $request->instore(),
		);
	}

	/**
	 * Numeric range group view-model.
	 *
	 * @param array<string, mixed> $facet       Facet.
	 * @param string               $scope_id    Scope.
	 * @param Parsed_Request       $constrained Constrained request.
	 * @param Parsed_Request       $request     Raw request.
	 * @return array<string, mixed>|null
	 */
	private function numeric_range_group( $facet, $scope_id, Parsed_Request $constrained, Parsed_Request $request ) {
		$taxonomy = isset( $facet['id'] ) ? (string) $facet['id'] : '';
		if ( '' === $taxonomy ) {
			return null;
		}

		$numeric   = ( new \FFL_Filters\Presets\Config() )->numeric();
		$without   = $this->counts->without_range( $constrained, $taxonomy );
		$counts    = $this->counts->terms( $taxonomy, $scope_id, $without );
		$selected  = $request->range( $taxonomy );
		$terms     = $this->terms_for_counts( $taxonomy, $counts, array() );
		$bound_min = null;
		$bound_max = null;
		$parsed    = 0;

		foreach ( $terms as $term ) {
			$interval = $numeric->interval( $taxonomy, $term['slug'], $term['label'] );
			if ( ! $interval ) {
				continue;
			}
			++$parsed;
			if ( null === $bound_min || $interval['min'] < $bound_min ) {
				$bound_min = $interval['min'];
			}
			if ( null === $bound_max || $interval['max'] > $bound_max ) {
				$bound_max = $interval['max'];
			}
		}

		if ( 0 === $parsed ) {
			return $this->terms_group( array_merge( $facet, array( 'type' => 'terms' ) ), $scope_id, $constrained, $request, $this->facets->top_n(), $this->facets->expand_cap(), array() );
		}

		return array(
			'id'        => $taxonomy,
			'type'      => 'range',
			'label'     => isset( $facet['label'] ) ? $facet['label'] : $taxonomy,
			'expanded'  => ! empty( $selected ),
			'large'     => false,
			'total'     => $parsed,
			'show_all'  => false,
			'min'       => $selected ? $selected['min'] : null,
			'max'       => $selected ? $selected['max'] : null,
			'bound_min' => $bound_min,
			'bound_max' => $bound_max,
			'unit'      => $numeric->unit( $taxonomy ),
			'param_min' => $numeric->min_param( $taxonomy ),
			'param_max' => $numeric->max_param( $taxonomy ),
		);
	}

	/**
	 * Merged caliber group from backing attribute taxonomies.
	 *
	 * @param array<string, mixed> $facet       Facet.
	 * @param string               $scope_id    Scope.
	 * @param Parsed_Request       $constrained Constrained request.
	 * @param Parsed_Request       $request     Raw request.
	 * @param int                  $top_n       Top-N.
	 * @param int                  $expand_cap  Expand cap.
	 * @param array<int, string>   $expanded    Expanded facet ids.
	 * @return array<string, mixed>|null
	 */
	private function caliber_group( $facet, $scope_id, Parsed_Request $constrained, Parsed_Request $request, $top_n, $expand_cap, $expanded ) {
		$config   = new \FFL_Filters\Presets\Config();
		$synonyms = $config->synonyms();
		$selected = array();
		if ( isset( $request->groups()[ \FFL_Filters\Presets\Defaults::CALIBER_ID ] ) ) {
			$selected = $request->groups()[ \FFL_Filters\Presets\Defaults::CALIBER_ID ];
		}

		$raw = array();
		foreach ( $config->caliber_taxonomies() as $taxonomy ) {
			$counts = $this->counts->terms( $taxonomy, $scope_id, $constrained );
			if ( empty( $counts ) ) {
				continue;
			}
			$mapped = array();
			foreach ( $selected as $slug ) {
				foreach ( $synonyms->lookup_slugs( (string) $slug ) as $member ) {
					$mapped[] = $member;
				}
			}
			foreach ( $this->terms_for_counts( $taxonomy, $counts, $mapped ) as $term ) {
				$raw[] = $term;
			}
		}

		$terms = $synonyms->merge_terms( $raw );
		if ( empty( $terms ) ) {
			return null;
		}

		usort(
			$terms,
			static function ( $a, $b ) {
				if ( $a['count'] === $b['count'] ) {
					return strcasecmp( $a['label'], $b['label'] );
				}
				return ( $a['count'] > $b['count'] ) ? -1 : 1;
			}
		);

		$total   = count( $terms );
		$is_open = in_array( \FFL_Filters\Presets\Defaults::CALIBER_ID, $expanded, true );
		$large   = $total > $top_n;
		// No static JSON for the merged caliber list, so a long list renders in full (to the expand cap) and opens straight to its values.
		$limit   = $large ? $expand_cap : $top_n;
		$visible = $this->slice_terms( $terms, $limit );

		return array(
			'id'       => \FFL_Filters\Presets\Defaults::CALIBER_ID,
			'type'     => 'terms',
			'label'    => isset( $facet['label'] ) ? $facet['label'] : __( 'Caliber', 'ffl-filters' ),
			'param'    => 'filter_caliber',
			// 1.2.1: closed by default; a group with a picked value opens on load.
			'expanded' => $is_open || ! empty( $selected ),
			'large'    => $large,
			'total'    => $total,
			'show_all' => $large && $total > $expand_cap && ! $is_open,
			'json'     => '',
			'terms'    => $visible,
		);
	}

	/**
	 * Removable chips for the current selection.
	 *
	 * @param Parsed_Request $request Request.
	 * @param string         $action  Archive URL.
	 * @return array<int, array{label: string, url: string}>
	 */
	private function chips( Parsed_Request $request, $action ) {
		$chips  = array();
		$source = array();

		foreach ( $request->groups() as $taxonomy => $slugs ) {
			$param            = $this->normalizer->param_for_taxonomy( $taxonomy );
			$source[ $param ] = $slugs;
		}
		if ( null !== $request->min_price() ) {
			$source['min_price'] = $this->format_price( $request->min_price() );
		}
		if ( null !== $request->max_price() ) {
			$source['max_price'] = $this->format_price( $request->max_price() );
		}
		if ( $request->instock() ) {
			$source['instock'] = '1';
		}
		if ( $request->instore() ) {
			$source['instore'] = '1';
		}
		$numeric = ( new \FFL_Filters\Presets\Config() )->numeric();
		foreach ( $request->ranges() as $taxonomy => $range ) {
			if ( ! is_array( $range ) ) {
				continue;
			}
			if ( isset( $range['min'] ) ) {
				$source[ $numeric->min_param( $taxonomy ) ] = $this->format_price( $range['min'] );
			}
			if ( isset( $range['max'] ) ) {
				$source[ $numeric->max_param( $taxonomy ) ] = $this->format_price( $range['max'] );
			}
		}

		foreach ( $request->groups() as $taxonomy => $slugs ) {
			foreach ( $slugs as $slug ) {
				$without = $source;
				$param   = $this->normalizer->param_for_taxonomy( $taxonomy );
				if ( isset( $without[ $param ] ) && is_array( $without[ $param ] ) ) {
					$without[ $param ] = array_values(
						array_filter(
							$without[ $param ],
							function ( $item ) use ( $slug ) {
								return (string) $item !== (string) $slug;
							}
						)
					);
					if ( empty( $without[ $param ] ) ) {
						unset( $without[ $param ] );
					}
				}
				$term  = function_exists( 'get_term_by' ) ? get_term_by( 'slug', $slug, $taxonomy ) : null;
				$label = ( $term && ! is_wp_error( $term ) ) ? (string) $term->name : (string) $slug;
				if ( \FFL_Filters\Presets\Defaults::CALIBER_ID === $taxonomy ) {
					$label = ( new \FFL_Filters\Presets\Config() )->synonyms()->canonical_label( (string) $slug );
				}
				$chips[] = array(
					/* translators: 1: filter name, 2: chosen value */
					'label' => sprintf( __( '%1$s: %2$s', 'ffl-filters' ), $this->chip_group_label( $taxonomy ), $label ),
					'url'   => $this->build_url( $action, $without ),
				);
			}
		}

		if ( null !== $request->min_price() || null !== $request->max_price() ) {
			$without = $source;
			unset( $without['min_price'], $without['max_price'] );
			$price_label = $this->price_chip_label( $request->min_price(), $request->max_price() );
			$chips[]     = array(
				'label' => $price_label,
				'url'   => $this->build_url( $action, $without ),
			);
		}

		if ( $request->instock() ) {
			$without = $source;
			unset( $without['instock'] );
			$chips[] = array(
				'label' => __( 'In stock', 'ffl-filters' ),
				'url'   => $this->build_url( $action, $without ),
			);
		}

		if ( $request->instore() ) {
			$without = $source;
			unset( $without['instore'] );
			$chips[] = array(
				'label' => ( new \FFL_Filters\Presets\Config() )->instore_label(),
				'url'   => $this->build_url( $action, $without ),
			);
		}

		foreach ( $request->ranges() as $taxonomy => $range ) {
			if ( ! is_array( $range ) ) {
				continue;
			}
			$without = $source;
			unset( $without[ $numeric->min_param( $taxonomy ) ], $without[ $numeric->max_param( $taxonomy ) ] );
			$label   = $this->chip_group_label( $taxonomy );
			$chips[] = array(
				'label' => $label,
				'url'   => $this->build_url( $action, $without ),
			);
		}

		return $chips;
	}

	/**
	 * Group name shown before a chip value, e.g. "Brand" in "Brand: Glock".
	 *
	 * @param string $taxonomy Taxonomy or facet id.
	 * @return string
	 */
	private function chip_group_label( $taxonomy ) {
		$taxonomy = (string) $taxonomy;
		$row      = ( new \FFL_Filters\Settings\Repository() )->facet( $taxonomy );
		if ( $row && ! empty( $row['label'] ) ) {
			return (string) $row['label'];
		}
		$config = new \FFL_Filters\Presets\Config();
		if ( \FFL_Filters\Presets\Defaults::CALIBER_ID === $taxonomy ) {
			return $config->caliber_label();
		}
		if ( $config->is_firearm_type_taxonomy( $taxonomy ) ) {
			return $config->firearm_type_label();
		}
		$labels = array(
			'product_brand' => __( 'Brand', 'ffl-filters' ),
			'product_cat'   => __( 'Category', 'ffl-filters' ),
			'product_tag'   => __( 'Tag', 'ffl-filters' ),
		);
		if ( isset( $labels[ $taxonomy ] ) ) {
			return $labels[ $taxonomy ];
		}
		if ( 0 === strpos( $taxonomy, 'pa_' ) && function_exists( 'wc_attribute_label' ) ) {
			return (string) wc_attribute_label( $taxonomy );
		}
		return $taxonomy;
	}

	/**
	 * Price chip text: "Price: up to $28", "Price: from $10" or "Price: $10 – $28".
	 *
	 * @param float|null $min Min price.
	 * @param float|null $max Max price.
	 * @return string
	 */
	private function price_chip_label( $min, $max ) {
		$symbol = function_exists( 'get_woocommerce_currency_symbol' ) ? html_entity_decode( (string) get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8' ) : '$';
		if ( null !== $min && null !== $max ) {
			/* translators: 1: the low price, 2: the high price */
			$phrase = sprintf( __( '%1$s – %2$s', 'ffl-filters' ), $symbol . $this->format_price( $min ), $symbol . $this->format_price( $max ) );
			/* translators: 1: filter label, 2: the value or price phrase */
			return sprintf( __( '%1$s: %2$s', 'ffl-filters' ), __( 'Price', 'ffl-filters' ), $phrase );
		}
		if ( null !== $max ) {
			/* translators: %s: a formatted price */
			$phrase = sprintf( __( 'up to %s', 'ffl-filters' ), $symbol . $this->format_price( $max ) );
			/* translators: 1: filter label, 2: the value or price phrase */
			return sprintf( __( '%1$s: %2$s', 'ffl-filters' ), __( 'Price', 'ffl-filters' ), $phrase );
		}
		/* translators: %s: a formatted price */
		$phrase = sprintf( __( 'from %s', 'ffl-filters' ), $symbol . $this->format_price( (float) $min ) );
		/* translators: 1: filter label, 2: the value or price phrase */
		return sprintf( __( '%1$s: %2$s', 'ffl-filters' ), __( 'Price', 'ffl-filters' ), $phrase );
	}

	/**
	 * Preserve orderby and search when the form is submitted.
	 *
	 * @param array $source Request.
	 * @return array<string, string>
	 */
	private function hidden_fields( $source ) {
		$hidden = array();
		foreach ( array( 'orderby', 's', 'post_type' ) as $key ) {
			if ( ! isset( $source[ $key ] ) || is_array( $source[ $key ] ) ) {
				continue;
			}
			$value = (string) $source[ $key ];
			if ( '' === $value ) {
				continue;
			}
			if ( 'post_type' === $key && 'product' !== $value ) {
				continue;
			}
			$hidden[ $key ] = $value;
		}
		return $hidden;
	}

	/**
	 * Visible matching-product count for the live region.
	 *
	 * On a shop or product-taxonomy archive the main query already holds the
	 * filtered catalog count. On a singular page (an Elementor shop page, a
	 * shortcode on a regular page) the main query is the page itself, so
	 * found_posts is 1. Fall back to a catalog count of the panel's scoped
	 * request. When no product grid is detectable, that is the shop-scoped
	 * published-product count, honouring category / tag / collection attrs.
	 *
	 * @param Parsed_Request $request Constrained request.
	 * @param string         $scope   Scope identifier.
	 * @return int
	 */
	private function visible_result_count( Parsed_Request $request, $scope ) {
		if ( $this->main_query_has_product_results() ) {
			return $this->found_posts();
		}

		return $this->counts->matching( $scope, $request );
	}

	/**
	 * Whether the main query is already a product results set.
	 *
	 * @return bool
	 */
	private function main_query_has_product_results() {
		if ( ! isset( $GLOBALS['wp_query'] ) || ! is_object( $GLOBALS['wp_query'] ) ) {
			return false;
		}

		$query = $GLOBALS['wp_query'];

		// Do not treat is_shop() alone as product results. The shop is a
		// WordPress page; until Woo replaces the main query with products,
		// found_posts is 1 (the page) and the drawer reads "Show 1 product".
		if ( function_exists( 'is_product_taxonomy' ) && is_product_taxonomy() ) {
			return true;
		}
		if ( function_exists( 'is_post_type_archive' ) && is_post_type_archive( 'product' ) ) {
			return true;
		}

		if ( method_exists( $query, 'get' ) ) {
			if ( 'product_query' === $query->get( 'wc_query' ) ) {
				return true;
			}
			foreach ( (array) $query->get( 'post_type' ) as $post_type ) {
				if ( 'product' === $post_type ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Main-query found posts when available.
	 *
	 * @return int
	 */
	private function found_posts() {
		if ( isset( $GLOBALS['wp_query'] ) && is_object( $GLOBALS['wp_query'] ) && isset( $GLOBALS['wp_query']->found_posts ) ) {
			return (int) $GLOBALS['wp_query']->found_posts;
		}
		return 0;
	}

	/**
	 * Build a GET URL from an archive path and params.
	 *
	 * @param string $action Archive URL.
	 * @param array  $params Params.
	 * @return string
	 */
	private function build_url( $action, $params ) {
		$query = array();
		foreach ( $params as $key => $value ) {
			if ( is_array( $value ) ) {
				foreach ( $value as $item ) {
					$query[] = rawurlencode( $key . '[]' ) . '=' . rawurlencode( (string) $item );
				}
			} else {
				$query[] = rawurlencode( (string) $key ) . '=' . rawurlencode( (string) $value );
			}
		}

		$base = strtok( (string) $action, '?' );
		if ( empty( $query ) ) {
			return (string) $base;
		}

		return $base . '?' . implode( '&', $query );
	}

	/**
	 * Whole prices stay integers, matching the URL contract.
	 *
	 * @param float $price Price.
	 * @return string
	 */
	private function format_price( $price ) {
		if ( floor( $price ) == $price ) { // phpcs:ignore Universal.Operators.StrictComparisons.LooseEqual
			return (string) (int) $price;
		}
		return (string) $price;
	}
}
