<?php
/**
 * Storefront panel styles and script.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Panel;

defined( 'ABSPATH' ) || exit;

/**
 * Enqueues tokens, panel CSS, the Kadence adapter when needed, and panel JS.
 * Assets load only where the panel renders.
 */
class Assets {

	/**
	 * Whether the assets have been enqueued this request.
	 *
	 * @var bool
	 */
	private $enqueued = false;

	/**
	 * Whether the inline resolver has been printed on this request (later panels only call it).
	 *
	 * @var bool
	 */
	private static $resolver_printed = false;

	/**
	 * The inline resolver, read once per request.
	 *
	 * @var string|null
	 */
	private static $resolver = null;

	/**
	 * Whether the button edge helper has been printed on this request (later buttons only call it).
	 *
	 * @var bool
	 */
	private static $edge_printed = false;

	/**
	 * The button edge helper, read once per request.
	 *
	 * @var string|null
	 */
	private static $edge = null;

	/**
	 * 1.3.5: whether the no-JS drawer opener has been printed on this request (later buttons only call it).
	 *
	 * @var bool
	 */
	private static $opener_printed = false;

	/**
	 * 1.3.5: the no-JS drawer opener, read once per request.
	 *
	 * @var string|null
	 */
	private static $opener = null;

	/**
	 * Enqueue the panel stylesheet and script once.
	 *
	 * 1.3.1 first paint: when the server knows in advance that the panel renders on this request, the CSS goes in
	 * the head, so the panel paints styled; the inline resolver (paint_script()) sets its colours before it paints.
	 * panel.js never blocks rendering: it is deferred, in the footer (in the head it shares the connection with the
	 * render-blocking CSS and delays the first paint on slow networks). A slow or failed panel.js leaves a styled,
	 * readable panel (the no-JS Show products button stays until panel.js runs).
	 *
	 * @param bool $in_head Enqueued before wp_head (the panel is known to render). Kept for callers; panel.js is in the
	 *                      footer either way.
	 * @return void
	 */
	public function enqueue( $in_head = false ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
		if ( $this->enqueued ) {
			return;
		}
		if ( ! function_exists( 'wp_enqueue_style' ) ) {
			return;
		}

		$this->enqueued = true;

		$base = defined( 'FFLF_URL' ) ? FFLF_URL : '';
		$ver  = defined( 'FFLF_VERSION' ) ? FFLF_VERSION : '0.0.1';

		wp_enqueue_style(
			'fflf-filters-tokens',
			$base . 'assets/css/tokens.css',
			array(),
			$this->file_version( 'assets/css/tokens.css', $ver )
		);

		wp_enqueue_style(
			'fflf-filters-panel',
			$base . 'assets/css/panel.css',
			array( 'fflf-filters-tokens' ),
			$this->file_version( 'assets/css/panel.css', $ver )
		);

		// The adaptive accent, stepped in PHP and cached; nothing is computed per page view once cached.
		if ( function_exists( 'wp_add_inline_style' ) ) {
			wp_add_inline_style( 'fflf-filters-panel', Accent::inline_css() );
		}

		if ( $this->is_kadence() ) {
			wp_enqueue_style(
				'fflf-filters-kadence',
				$base . 'assets/css/kadence-adapter.css',
				array( 'fflf-filters-tokens', 'fflf-filters-panel' ),
				$this->file_version( 'assets/css/kadence-adapter.css', $ver )
			);
		}

		wp_enqueue_script(
			'fflf-filters-panel',
			$base . 'assets/js/panel.js',
			array(),
			$this->file_version( 'assets/js/panel.js', $ver ),
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);

		if ( function_exists( 'wp_localize_script' ) ) {
			wp_localize_script(
				'fflf-filters-panel',
				'fflfPanel',
				array(
					'matchOne'  => __( '1 match', 'ffl-filters' ),
					/* translators: %s: number of matching terms */
					'matchMany' => __( '%s matches', 'ffl-filters' ),
					// Shown over the products while new results load.
					// The paint cache key (sessionStorage) includes it, so an update never applies an old look.
					'version'   => $ver,
					'updating'  => __( 'Updating results…', 'ffl-filters' ),
				)
			);
		}
	}

	/**
	 * The inline script printed just inside each panel's opening tag: the resolver (assets/js/resolver.js) sets the
	 * panel's colour vars and data-fflf-* markers before any of the panel paints. The first panel on a request
	 * carries the resolver itself (under 2 KB); later panels only call it. Uses WordPress's inline script tag so
	 * CSP plugins can add a nonce (wp_inline_script_attributes). 1.3.4: the call also clears the resolver's JS-coming
	 * mark (data-fflf-boot) after 3 s with a timer, so the no-JS Show products button comes back if panel.js never
	 * runs; a timer is not cut short by reduce-motion settings the way a CSS animation is.
	 *
	 * @return string
	 */
	public static function paint_script() {
		return self::inline_script( self::resolver_prefix() . 'window.fflfR&&fflfR(document.currentScript.parentElement);setTimeout(e=>delete e.dataset.fflfBoot,3e3,document.currentScript.parentElement)' );
	}

	/**
	 * 1.3.2: the inline script printed right after a "Filter products" button (the one above the products, or the
	 * panel's own drawer button). It sets data-fflf-edge on the button's host before the button paints, with the same
	 * rule panel.js uses later, so the ring does not change when panel.js runs. The first one carries the resolver
	 * (when no panel came first) and the edge helper (assets/js/edge.js, under 320 bytes); later ones only call it.
	 * 1.3.5: the first one also carries the no-JS drawer opener (assets/js/opener.js, under 400 bytes), and each one
	 * calls it: a capture-phase click listener on the button that opens the drawer (data-fflf-open) while panel.js has
	 * not run, so a theme script that takes the link cannot keep the drawer shut.
	 *
	 * @param bool $in_panel The panel's own drawer button (host: the panel); otherwise the opener (host: its wrap).
	 * @return string
	 */
	public static function edge_script( $in_panel = false ) {
		$js = self::resolver_prefix();
		if ( ! self::$edge_printed ) {
			$edge = self::edge_js();
			if ( '' !== $edge ) {
				self::$edge_printed = true;
				$js                .= $edge;
			}
		}
		if ( ! self::$opener_printed ) {
			$opener = self::opener_js();
			if ( '' !== $opener ) {
				self::$opener_printed = true;
				$js                  .= $opener;
			}
		}
		$s    = 'document.currentScript';
		$host = $in_panel ? $s . '.closest("[data-fflf-panel]")' : $s . '.parentElement';
		return self::inline_script( $js . 'window.fflfE&&fflfE(' . $host . ',' . $s . '.previousElementSibling);window.fflfO&&fflfO()' );
	}

	/**
	 * The resolver itself the first time on a request, then nothing.
	 *
	 * @return string
	 */
	private static function resolver_prefix() {
		if ( self::$resolver_printed ) {
			return '';
		}
		$resolver = self::resolver_js();
		if ( '' !== $resolver ) {
			self::$resolver_printed = true;
		}
		return $resolver;
	}

	/**
	 * WordPress's inline script tag, so CSP plugins can add a nonce (wp_inline_script_attributes).
	 *
	 * @param string $js Script.
	 * @return string
	 */
	private static function inline_script( $js ) {
		if ( function_exists( 'wp_get_inline_script_tag' ) ) {
			return wp_get_inline_script_tag( $js, array( 'data-fflf-paint' => '1' ) );
		}
		return '<script data-fflf-paint="1">' . $js . '</script>';
	}

	/**
	 * The resolver as printed inline: assets/js/resolver.js without its block comments and line breaks.
	 *
	 * @return string
	 */
	public static function resolver_js() {
		if ( null === self::$resolver ) {
			self::$resolver = self::printed_js( 'assets/js/resolver.js' );
		}
		return self::$resolver;
	}

	/**
	 * The button edge helper as printed inline: assets/js/edge.js without its block comments and line breaks.
	 *
	 * @return string
	 */
	public static function edge_js() {
		if ( null === self::$edge ) {
			self::$edge = self::printed_js( 'assets/js/edge.js' );
		}
		return self::$edge;
	}

	/**
	 * 1.3.5: the no-JS drawer opener as printed inline: assets/js/opener.js without its block comments and line breaks.
	 *
	 * @return string
	 */
	public static function opener_js() {
		if ( null === self::$opener ) {
			self::$opener = self::printed_js( 'assets/js/opener.js' );
		}
		return self::$opener;
	}

	/**
	 * A plugin script without its block comments and line breaks (only block comments in these files).
	 *
	 * @param string $relative Path under the plugin root.
	 * @return string
	 */
	private static function printed_js( $relative ) {
		$path = ( defined( 'FFLF_DIR' ) ? FFLF_DIR : dirname( __DIR__, 2 ) . '/' ) . $relative;
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local plugin file.
		$src = is_readable( $path ) ? (string) file_get_contents( $path ) : '';
		$src = (string) preg_replace( '#/\*.*?\*/#s', '', $src );
		return implode( '', array_map( 'trim', preg_split( '/\R/', $src ) ) );
	}

	/**
	 * Print the resolver again on the next panel (tests, and a fresh render pass).
	 *
	 * @return void
	 */
	public static function reset_paint() {
		self::$resolver_printed = false;
		self::$edge_printed     = false;
		self::$opener_printed   = false;
	}

	/**
	 * Whether the active (or parent) theme is Kadence.
	 *
	 * @return bool
	 */
	public function is_kadence() {
		if ( ! function_exists( 'wp_get_theme' ) ) {
			return false;
		}

		$theme = wp_get_theme();
		if ( ! $theme ) {
			return false;
		}

		$candidates = array(
			strtolower( (string) $theme->get_stylesheet() ),
			strtolower( (string) $theme->get_template() ),
			strtolower( (string) $theme->get( 'Name' ) ),
		);

		$is = in_array( 'kadence', $candidates, true );

		/**
		 * Filters whether the Kadence adapter stylesheet should load.
		 *
		 * @since 0.0.1
		 * @param bool $is Whether the active theme is Kadence.
		 */
		return function_exists( 'apply_filters' ) ? (bool) apply_filters( 'fflf_is_kadence', $is ) : $is;
	}

	/**
	 * Prefer a filemtime version so caches see CSS/JS updates.
	 *
	 * @param string $relative Path under the plugin root.
	 * @param string $fallback Fallback version.
	 * @return string
	 */
	private function file_version( $relative, $fallback ) {
		$path = ( defined( 'FFLF_DIR' ) ? FFLF_DIR : '' ) . $relative;
		if ( '' !== $path && is_readable( $path ) ) {
			return (string) filemtime( $path );
		}
		return $fallback;
	}
}
