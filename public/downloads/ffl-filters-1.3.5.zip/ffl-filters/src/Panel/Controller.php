<?php
/**
 * Storefront panel hooks.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Panel;

use FFL_Filters\Cache\Fingerprint;
use FFL_Filters\Cache\Repository;
use FFL_Filters\Query\Clause_Builder;
use FFL_Filters\Query\Request_Parser;

defined( 'ABSPATH' ) || exit;

/**
 * Auto-renders the panel on product archives and exposes fflf_get_filters().
 */
class Controller {

	/**
	 * Shared instance for template tags.
	 *
	 * @var Controller|null
	 */
	private static $instance = null;

	/**
	 * Cache repository.
	 *
	 * @var Repository
	 */
	private $repository;

	/**
	 * Assets.
	 *
	 * @var Assets
	 */
	private $assets;

	/**
	 * Document assembler.
	 *
	 * @var Document
	 */
	private $document;

	/**
	 * Renderer.
	 *
	 * @var Renderer
	 */
	private $renderer;

	/**
	 * Progressive-enhancement fragments.
	 *
	 * @var Fragments
	 */
	private $fragments;

	/**
	 * Whether the auto-inserted copy has been printed this request.
	 *
	 * @var bool
	 */
	private $auto_rendered = false;

	/**
	 * Whether the current request should show the panel.
	 *
	 * @var bool|null
	 */
	private $should_render = null;

	/**
	 * Whether the small-screen opener has been printed this request.
	 *
	 * @var bool
	 */
	private $opener_printed = false;

	/**
	 * Whether this request printed the panel above the products (hook or block injection).
	 *
	 * @var bool
	 */
	private $above_printed = false;

	/**
	 * Constructor.
	 *
	 * @param Repository|null     $repository Cache repository.
	 * @param Clause_Builder|null $builder    Clause builder.
	 * @param Assets|null         $assets     Assets.
	 * @param Document|null       $document   Document assembler.
	 * @param Renderer|null       $renderer   Renderer.
	 */
	public function __construct( $repository = null, $builder = null, $assets = null, $document = null, $renderer = null ) {
		$repository       = $repository ? $repository : new Repository();
		$builder          = $builder ? $builder : new Clause_Builder();
		$counts           = new Counts( $repository, $builder );
		$this->repository = $repository;
		$this->assets     = $assets ? $assets : new Assets();
		$this->document   = $document ? $document : new Document( null, $counts );
		$this->renderer   = $renderer ? $renderer : new Renderer();
		$this->fragments  = new Fragments();
		self::$instance   = $this;
	}

	/**
	 * Registered controller, if any.
	 *
	 * @return Controller|null
	 */
	public static function instance() {
		return self::$instance;
	}

	/**
	 * Wire hooks. No-ops while the compare plugin is active.
	 *
	 * @return void
	 */
	public function register() {
		if ( $this->compare_plugin_is_active() ) {
			return;
		}

		add_action( 'wp', array( $this, 'maybe_enqueue' ) );
		add_action( 'woocommerce_sidebar', array( $this, 'auto_render' ), 20 );
		add_action( 'woocommerce_before_shop_loop', array( $this, 'render_above_products' ), 4 );
		// No results: before_shop_loop does not fire, but the filters must stay so a pick can be undone.
		add_action( 'woocommerce_no_products_found', array( $this, 'render_above_products' ), 0 );
		add_filter( 'body_class', array( $this, 'above_products_body_class' ) );
		add_action( 'woocommerce_before_shop_loop', array( $this, 'auto_render_fallback' ), 5 );
		add_action( 'woocommerce_before_shop_loop', array( $this, 'print_opener' ), 6 );
		add_filter( 'render_block', array( $this, 'inject_before_product_block' ), 10, 2 );

		$endpoint = new Endpoint();
		$endpoint->register();

		$this->fragments->register();
	}

	/**
	 * Enqueue assets in the head when the panel will render on this request (avoids an unstyled first paint):
	 * auto-insert, Above products, or a panel placed by hand (widget, block or shortcode) on a product archive.
	 * Pages without a panel load nothing.
	 *
	 * @return void
	 */
	public function maybe_enqueue() {
		if ( $this->should_auto_render() || $this->should_render_above_products() || $this->will_render_placed() ) {
			$this->assets->enqueue( true );
		}
	}

	/**
	 * A panel placed by hand (widget, block or shortcode) renders on this product archive.
	 *
	 * @return bool
	 */
	public function will_render_placed() {
		return $this->is_product_archive() && Placement::in_request();
	}

	/**
	 * Preferred auto-render location: the shop sidebar.
	 *
	 * @return void
	 */
	public function auto_render() {
		if ( 'above_products' === self::current_placement() ) {
			return;
		}
		if ( ! $this->should_auto_render() ) {
			return;
		}
		$this->print_auto();
	}

	/**
	 * Fallback when the theme has no shop sidebar hook.
	 *
	 * @return void
	 */
	public function auto_render_fallback() {
		if ( 'above_products' === self::current_placement() ) {
			return;
		}
		if ( $this->auto_rendered ) {
			return;
		}
		if ( ! $this->should_auto_render() ) {
			return;
		}
		$this->print_auto();
	}

	/**
	 * Insert the panel above a product collection on block themes.
	 *
	 * Classic hooks often do not fire on Twenty Twenty-Five shop templates.
	 *
	 * @param string $content Block HTML.
	 * @param array  $block   Block being rendered.
	 * @return string
	 */
	public function inject_before_product_block( $content, $block ) {
		$name    = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
		$targets = array(
			'woocommerce/product-collection',
			'woocommerce/legacy-template',
			'woocommerce/product-query',
		);
		// Name check first: should_auto_render() may call Placement::in_request(),
		// which must not run for every inner product block in the shop loop.
		if ( ! in_array( $name, $targets, true ) ) {
			return $content;
		}

		if ( 'above_products' === self::current_placement() ) {
			if ( ! $this->should_render_above_products() ) {
				return $this->opener_html() . $content;
			}
		} elseif ( ! $this->should_auto_render() ) {
			return $this->opener_html() . $content;
		}

		$content = $this->fragments->wrap_grid( $content );

		if ( $this->auto_rendered ) {
			return $content;
		}

		$this->auto_rendered = true;
		$args                = 'above_products' === self::current_placement() ? array( 'placement' => 'above' ) : array();
		$this->above_printed = ! empty( $args );
		return $this->render( $args ) . $content;
	}

	/**
	 * Print the small-screen opener above the products (classic themes).
	 *
	 * @return void
	 */
	public function print_opener() {
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- opener_html() escapes its output.
		echo $this->opener_html();
	}

	/**
	 * A "Filter products" button above the products for phones and tablets.
	 *
	 * Only when the panel was placed by hand in a widget area or the shop template,
	 * where small screens put it below the products. Script hides it again when the
	 * panel already sits above the products, and without script it still opens the
	 * drawer through its #target.
	 *
	 * @return string
	 */
	public function opener_html() {
		if ( $this->opener_printed || ! $this->is_product_archive() ) {
			return '';
		}
		if ( 'sidebar' === ( new Facets() )->mobile_display() ) {
			return '';
		}
		if ( ! Placement::in_widgets() && ! Placement::in_block_template() ) {
			return '';
		}
		$this->opener_printed = true;
		return '<div class="ffl-filters-opener-wrap"><a class="ffl-filters-opener" href="#fflf-1-drawer" data-fflf-remote-open>' . esc_html__( 'Filter products', 'ffl-filters' ) . '</a>' . Assets::edge_script() . '</div>';
	}

	/**
	 * Whether "Show the filter panel automatically" is on (Display tab).
	 *
	 * @return bool
	 */
	public static function auto_insert_enabled() {
		if ( ! class_exists( '\FFL_Filters\Settings\Repository' ) ) {
			return true;
		}
		$settings = ( new \FFL_Filters\Settings\Repository() )->all();
		return ! isset( $settings['display']['auto_insert'] ) || ! empty( $settings['display']['auto_insert'] );
	}

	/**
	 * Render the panel HTML (also used by fflf_get_filters()).
	 *
	 * @param array<string, mixed> $args Optional args (source, result_count).
	 * @return string
	 */
	public function render( $args = array() ) {
		$this->assets->enqueue();

		if ( ! is_array( $args ) ) {
			$args = array();
		}
		$args['layout'] = Attributes::layout( $args );

		$source = isset( $args['source'] ) && is_array( $args['source'] ) ? $args['source'] : null;
		$count  = array_key_exists( 'result_count', $args ) ? (int) $args['result_count'] : null;

		$fingerprint = $this->panel_fingerprint( $source, $count, $args );
		$self        = $this;

		$html = $this->repository->remember_panel(
			$fingerprint,
			function () use ( $self, $source, $count, $args ) {
				return $self->renderer->render( $self->document->build( $source, $count, $args ) );
			}
		);

		if ( ! is_string( $html ) ) {
			return '';
		}

		// The "Filter products" button above the products already printed: the panel's own
		// button would be a second one on phones, so mark the panel to hide it (no-JS too).
		// Added after the cache so cached panel HTML stays the same for every page.
		if ( $this->opener_printed ) {
			$html = (string) preg_replace( '/ data-fflf-panel(?=[ >])/', ' data-fflf-panel data-fflf-remote-opener', $html, 1 );
		}

		// 1.3.1 first paint (after the cache, like the marker above): the inline resolver just inside the panel's
		// opening tag sets its colours before any of it paints. panel.js (deferred) sets the rest up later.
		$script = Assets::paint_script();
		$html   = (string) preg_replace_callback(
			'/^(\s*<div\b[^>]*\sdata-fflf-panel(?=[\s>])[^>]*>)/',
			function ( $m ) use ( $script ) {
				return $m[1] . $script;
			},
			$html,
			1
		);
		// 1.3.2: the panel's own drawer button gets its edge before it paints (same rule as panel.js; no ring change).
		$html = (string) preg_replace_callback(
			'#<a class="ffl-filters__open" [^>]*data-fflf-drawer-open[^>]*>.*?</a>#s',
			function ( $m ) {
				return $m[0] . Assets::edge_script( true );
			},
			$html,
			1
		);
		return $html;
	}

	/**
	 * Panel cache fingerprint for this request.
	 *
	 * @param array<string, mixed>|null $source Request array.
	 * @param int|null                  $count  Optional result count override.
	 * @param array<string, mixed>      $args   Render args.
	 * @return string
	 */
	private function panel_fingerprint( $source, $count, $args ) {
		if ( ! is_array( $source ) ) {
			$source = function_exists( 'wp_unslash' ) ? wp_unslash( $_GET ) : $_GET; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			if ( ! is_array( $source ) ) {
				$source = array();
			}
		}

		$parser  = new Request_Parser();
		$request = $parser->parse( $source );
		$scope   = new Scope();
		$expand  = array();
		if ( isset( $source['fflf_expand'] ) ) {
			$raw = is_array( $source['fflf_expand'] ) ? $source['fflf_expand'] : array( $source['fflf_expand'] );
			foreach ( $raw as $value ) {
				if ( is_string( $value ) && '' !== $value ) {
					$expand[] = $value;
				}
			}
		}

		$locale = function_exists( 'get_locale' ) ? (string) get_locale() : '';
		$hidden = array();
		foreach ( array( 'orderby', 's', 'post_type' ) as $key ) {
			if ( isset( $source[ $key ] ) && ! is_array( $source[ $key ] ) && '' !== (string) $source[ $key ] ) {
				$hidden[ $key ] = (string) $source[ $key ];
			}
		}

		$options = $args;
		unset( $options['source'], $options['result_count'] );

		return Fingerprint::for_panel(
			$scope->id_for( $args ),
			$request,
			array(
				'expand'       => $expand,
				'mobile'       => ( new Facets() )->mobile_display(),
				'options'      => $options,
				'locale'       => $locale,
				'hidden'       => $hidden,
				'result_count' => $count,
			)
		);
	}

	/**
	 * Stored placement setting (sidebar or above_products).
	 *
	 * @return string
	 */
	public static function current_placement() {
		if ( ! class_exists( '\FFL_Filters\Settings\Repository' ) ) {
			return 'sidebar';
		}
		$settings = ( new \FFL_Filters\Settings\Repository() )->all();
		return isset( $settings['display']['placement'] ) ? (string) $settings['display']['placement'] : 'sidebar';
	}

	/**
	 * Render above the product loop when placement is above_products.
	 *
	 * Hooked on woocommerce_before_shop_loop. Does nothing when placement is sidebar.
	 *
	 * @return void
	 */
	public function render_above_products() {
		if ( ! $this->should_render_above_products() ) {
			return;
		}
		$this->print_auto( array( 'placement' => 'above' ) );
	}

	/**
	 * Body class for the Above products placement, so the theme's own result count and sort box can step aside
	 * on desktop and tablet (our results row replaces them). Phones keep the theme's.
	 *
	 * @param array<int, string> $classes Body classes.
	 * @return array<int, string>
	 */
	public function above_products_body_class( $classes ) {
		$classes = is_array( $classes ) ? $classes : array();
		// Block themes render the template before <body>, so the panel may already be printed (injected) here.
		$ours = $this->above_printed || ( ! $this->auto_rendered && ! Placement::in_request() );
		if ( 'above_products' === self::current_placement() && $ours && $this->is_product_archive() ) {
			$classes[] = 'fflf-above-products';
		}
		return $classes;
	}

	/**
	 * Whether the above-products hook should print the panel on this request.
	 *
	 * @return bool
	 */
	public function should_render_above_products() {
		if ( 'above_products' !== self::current_placement() ) {
			return false;
		}
		if ( $this->auto_rendered ) {
			return false;
		}
		if ( Placement::in_request() ) {
			return false;
		}

		$should = $this->is_product_archive();

		/**
		 * Filters whether the above-products hook should render on this request.
		 *
		 * This filter cannot override a sidebar placement, a manual block or
		 * shortcode, or a panel that has already been printed.
		 *
		 * @since 1.3.0
		 * @param bool $should Whether this is a shop or product-taxonomy archive.
		 */
		return function_exists( 'apply_filters' ) ? (bool) apply_filters( 'fflf_should_render_above_products', $should ) : $should;
	}

	/**
	 * Mark this request as having a manually placed panel (shortcode or block).
	 *
	 * Prevents a second auto-inserted copy on the same page.
	 *
	 * @return void
	 */
	public function mark_manual() {
		$this->auto_rendered = true;
	}

	/**
	 * Whether this request is a product archive that should auto-render.
	 *
	 * @return bool
	 */
	public function should_auto_render() {
		if ( null !== $this->should_render ) {
			if ( $this->should_render && Placement::in_request() ) {
				return false;
			}
			return $this->should_render;
		}

		$should = $this->is_product_archive() && self::auto_insert_enabled();

		/**
		 * Filters whether the panel auto-renders on this request.
		 *
		 * @since 0.0.1
		 * @param bool $should Whether to auto-render.
		 */
		$should = function_exists( 'apply_filters' ) ? (bool) apply_filters( 'fflf_should_auto_render', $should ) : $should;

		$this->should_render = $should;
		if ( $this->should_render && Placement::in_request() ) {
			return false;
		}
		return $should;
	}

	/**
	 * Print the auto-inserted panel once.
	 *
	 * @param array<string, mixed> $args Render args (placement).
	 * @return void
	 */
	private function print_auto( $args = array() ) {
		if ( $this->auto_rendered ) {
			return;
		}
		$this->auto_rendered = true;
		if ( isset( $args['placement'] ) && 'above' === $args['placement'] ) {
			$this->above_printed = true;
		}
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Renderer escapes its output.
		echo $this->render( $args );
	}

	/**
	 * Shop or product-taxonomy archive, not admin / ajax / REST / CLI.
	 *
	 * @return bool
	 */
	private function is_product_archive() {
		if ( function_exists( 'is_admin' ) && is_admin() && ! $this->is_wp_unit_test() ) {
			return false;
		}
		if ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) {
			return false;
		}
		if ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ) {
			return false;
		}
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return false;
		}
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			return false;
		}

		if ( function_exists( 'is_shop' ) && is_shop() ) {
			return true;
		}
		if ( function_exists( 'is_product_taxonomy' ) && is_product_taxonomy() ) {
			return true;
		}
		if ( function_exists( 'is_post_type_archive' ) && is_post_type_archive( 'product' ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Running inside the WordPress test suite.
	 *
	 * @return bool
	 */
	private function is_wp_unit_test() {
		return ( defined( 'WP_RUNNING_TESTS' ) && WP_RUNNING_TESTS ) || defined( 'WP_TESTS_DOMAIN' );
	}

	/**
	 * True when Coriolis Product Filters is active (black-box coexistence).
	 *
	 * @return bool
	 */
	private function compare_plugin_is_active() {
		if ( function_exists( 'fflf_is_passive' ) ) {
			return fflf_is_passive();
		}
		return function_exists( 'fflf_compare_plugin_is_active' ) && fflf_compare_plugin_is_active();
	}
}
