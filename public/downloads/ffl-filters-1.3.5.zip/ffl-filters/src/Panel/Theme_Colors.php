<?php
/**
 * Read the active theme's button, main and link colours (inputs for the adaptive accent).
 *
 * Generic first (theme.json global styles and palette), then small readers gated on the theme that owns the setting.
 * Nothing here writes to the theme or targets a store; a missing or see-through value is just skipped.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Panel;

defined( 'ABSPATH' ) || exit;

/**
 * Theme colour reader.
 */
class Theme_Colors {

	/**
	 * Button, main and link colours as #RRGGBB, or '' when the theme does not say.
	 *
	 * @return array{button: string, main: string, link: string}
	 */
	public static function read() {
		$out = array(
			'button' => '',
			'main'   => '',
			'link'   => '',
		);

		$template = function_exists( 'get_template' ) ? strtolower( (string) get_template() ) : '';
		$specific = array();
		if ( 'kadence' === $template ) {
			$specific = self::kadence();
		} elseif ( 'astra' === $template ) {
			$specific = self::astra();
		} elseif ( 'storefront' === $template ) {
			$specific = self::storefront();
		} elseif ( 'oceanwp' === $template ) {
			$specific = self::oceanwp();
		} elseif ( 'blocksy' === $template ) {
			$specific = self::blocksy();
		}
		if ( defined( 'ELEMENTOR_VERSION' ) && ( 'hello-elementor' === $template || empty( $specific ) ) ) {
			$specific = self::merge( $specific, self::elementor_kit() );
		}
		$out = self::merge( $out, $specific );
		if ( '' === $out['button'] || '' === $out['main'] || '' === $out['link'] ) {
			$out = self::merge( $out, self::global_styles() );
		}

		/**
		 * Filters the theme colours FFL Filters reads for its adaptive accent.
		 *
		 * @since 1.3.0
		 * @param array{button: string, main: string, link: string} $out Colours as #RRGGBB, or ''.
		 */
		$out = function_exists( 'apply_filters' ) ? apply_filters( 'fflf_theme_colors', $out ) : $out;
		foreach ( array( 'button', 'main', 'link' ) as $role ) {
			$out[ $role ] = isset( $out[ $role ] ) ? Accent::normalize( $out[ $role ] ) : '';
		}
		return $out;
	}

	/**
	 * Fill empty roles in $base from $more.
	 *
	 * @param array<string, string> $base Base.
	 * @param array<string, string> $more More.
	 * @return array<string, string>
	 */
	private static function merge( $base, $more ) {
		foreach ( (array) $more as $role => $color ) {
			$color = Accent::normalize( $color );
			if ( '' !== $color && ( ! isset( $base[ $role ] ) || '' === $base[ $role ] ) ) {
				$base[ $role ] = $color;
			}
		}
		return $base;
	}

	/**
	 * Block themes and classic themes with theme.json: the button element background, the primary/accent preset, the link element.
	 *
	 * @return array<string, string>
	 */
	private static function global_styles() {
		if ( ! function_exists( 'wp_get_global_styles' ) || ! function_exists( 'wp_get_global_settings' ) ) {
			return array();
		}
		$palette = array();
		$sets    = wp_get_global_settings( array( 'color', 'palette' ) );
		if ( is_array( $sets ) ) {
			foreach ( array( 'theme', 'custom', 'default' ) as $origin ) {
				if ( empty( $sets[ $origin ] ) || ! is_array( $sets[ $origin ] ) ) {
					continue;
				}
				foreach ( $sets[ $origin ] as $entry ) {
					if ( isset( $entry['slug'], $entry['color'] ) && ! isset( $palette[ $entry['slug'] ] ) ) {
						$palette[ (string) $entry['slug'] ] = (string) $entry['color'];
					}
				}
			}
		}
		$resolve = function ( $value ) use ( $palette ) {
			$value = is_string( $value ) ? trim( $value ) : '';
			if ( preg_match( '/^var:preset\|color\|([a-z0-9\-_]+)$/i', $value, $m ) || preg_match( '/^var\(\s*--wp--preset--color--([a-z0-9\-_]+)\s*\)$/i', $value, $m ) ) {
				return isset( $palette[ $m[1] ] ) ? $palette[ $m[1] ] : '';
			}
			return $value;
		};

		$button = wp_get_global_styles( array( 'elements', 'button', 'color', 'background' ) );
		$link   = wp_get_global_styles( array( 'elements', 'link', 'color', 'text' ) );
		$main   = '';
		foreach ( array( 'primary', 'accent', 'accent-1', 'vivid-cyan-blue' ) as $slug ) {
			if ( isset( $palette[ $slug ] ) ) {
				$main = $palette[ $slug ];
				break;
			}
		}
		return array(
			'button' => $resolve( $button ),
			'main'   => $main,
			'link'   => $resolve( $link ),
		);
	}

	/**
	 * Kadence: palette1 is the main colour; buttons and links point at palette entries.
	 *
	 * @return array<string, string>
	 */
	private static function kadence() {
		$palette = array(
			'palette1' => '#2B6CB0',
			'palette2' => '#215387',
			'palette3' => '#1A202C',
		);
		$raw     = function_exists( 'get_option' ) ? get_option( 'kadence_global_palette', '' ) : '';
		$data    = is_string( $raw ) && '' !== $raw ? json_decode( $raw, true ) : ( is_array( $raw ) ? $raw : null );
		if ( is_array( $data ) ) {
			$active = isset( $data['active'] ) ? (string) $data['active'] : 'palette';
			if ( isset( $data[ $active ] ) && is_array( $data[ $active ] ) ) {
				foreach ( $data[ $active ] as $entry ) {
					if ( isset( $entry['slug'], $entry['color'] ) ) {
						$palette[ (string) $entry['slug'] ] = (string) $entry['color'];
					}
				}
			}
		}
		$pick   = function ( $value, $key ) use ( $palette ) {
			if ( is_array( $value ) ) {
				$value = isset( $value[ $key ] ) ? $value[ $key ] : '';
			}
			$value = is_string( $value ) ? trim( $value ) : '';
			if ( isset( $palette[ $value ] ) ) {
				return $palette[ $value ];
			}
			if ( preg_match( '/^var\(\s*--global-(palette\d+)/', $value, $m ) && isset( $palette[ $m[1] ] ) ) {
				return $palette[ $m[1] ];
			}
			return $value;
		};
		$mod    = function_exists( 'get_theme_mod' ) ? 'get_theme_mod' : null;
		$button = $mod ? $mod( 'buttons_background', array( 'color' => 'palette1' ) ) : array( 'color' => 'palette1' );
		$link   = $mod ? $mod( 'link_color', array( 'color' => 'palette1' ) ) : array( 'color' => 'palette1' );
		return array(
			'button' => $pick( $button, 'color' ),
			'main'   => $palette['palette1'],
			'link'   => $pick( $link, 'color' ),
		);
	}

	/**
	 * Astra: theme colour, button colour and link colour in astra-settings (Astra 4 points them at its global palette).
	 *
	 * @return array<string, string>
	 */
	private static function astra() {
		$o       = function_exists( 'get_option' ) ? get_option( 'astra-settings', array() ) : array();
		$o       = is_array( $o ) ? $o : array();
		$palette = array( '#046BD2', '#045CB4', '#1E293B', '#334155', '#F9FAFB', '#FFFFFF', '#E2E8F0', '#CBD5E1', '#94A3B8' );
		if ( isset( $o['global-color-palette']['palette'] ) && is_array( $o['global-color-palette']['palette'] ) ) {
			$palette = array_values( $o['global-color-palette']['palette'] );
		}
		$resolve = function ( $value ) use ( $palette ) {
			$value = is_string( $value ) ? trim( $value ) : '';
			if ( preg_match( '/^var\(\s*--ast-global-color-(\d+)/', $value, $m ) ) {
				return isset( $palette[ (int) $m[1] ] ) ? (string) $palette[ (int) $m[1] ] : '';
			}
			return $value;
		};
		$main    = $resolve( isset( $o['theme-color'] ) ? $o['theme-color'] : 'var(--ast-global-color-0)' );
		return array(
			'button' => $resolve( isset( $o['button-bg-color'] ) ? $o['button-bg-color'] : '' ),
			'main'   => $main,
			'link'   => $resolve( isset( $o['link-color'] ) ? $o['link-color'] : '' ),
		);
	}

	/**
	 * Storefront: Customizer button background and accent (link) colour.
	 *
	 * @return array<string, string>
	 */
	private static function storefront() {
		if ( ! function_exists( 'get_theme_mod' ) ) {
			return array();
		}
		return array(
			'button' => (string) get_theme_mod( 'storefront_button_alt_background_color', '#333333' ),
			'main'   => '',
			'link'   => (string) get_theme_mod( 'storefront_accent_color', '#7F54B3' ),
		);
	}

	/**
	 * OceanWP: primary colour, theme button background and link colour.
	 *
	 * @return array<string, string>
	 */
	private static function oceanwp() {
		if ( ! function_exists( 'get_theme_mod' ) ) {
			return array();
		}
		$main = (string) get_theme_mod( 'ocean_primary_color', '#13AFF0' );
		return array(
			'button' => (string) get_theme_mod( 'ocean_theme_button_bg', $main ),
			'main'   => $main,
			'link'   => (string) get_theme_mod( 'ocean_links_color', '' ),
		);
	}

	/**
	 * Blocksy: colour palette (color1 is the main colour; buttons and links use it unless changed).
	 *
	 * @return array<string, string>
	 */
	private static function blocksy() {
		if ( ! function_exists( 'get_theme_mod' ) ) {
			return array();
		}
		$palette = get_theme_mod( 'colorPalette', array() );
		$colors  = array(
			'1' => '#2872FA',
			'2' => '#1559ED',
		);
		if ( is_array( $palette ) ) {
			foreach ( $palette as $key => $entry ) {
				if ( preg_match( '/^color(\d+)$/', (string) $key, $m ) && isset( $entry['color'] ) ) {
					$colors[ $m[1] ] = (string) $entry['color'];
				}
			}
		}
		$resolve = function ( $value ) use ( $colors ) {
			if ( is_array( $value ) ) {
				$value = isset( $value['default']['color'] ) ? $value['default']['color'] : '';
			}
			$value = is_string( $value ) ? trim( $value ) : '';
			if ( preg_match( '/^var\(\s*--(?:theme-)?palette-color-(\d+)/', $value, $m ) ) {
				return isset( $colors[ $m[1] ] ) ? $colors[ $m[1] ] : '';
			}
			return $value;
		};
		return array(
			'button' => $resolve( get_theme_mod( 'buttonInitialColor', '' ) ),
			'main'   => $colors['1'],
			'link'   => $resolve( get_theme_mod( 'linkColor', '' ) ),
		);
	}

	/**
	 * Elementor active kit: system colours (Elementor's buttons use Accent; Primary is the main colour).
	 *
	 * @return array<string, string>
	 */
	private static function elementor_kit() {
		if ( ! function_exists( 'get_option' ) || ! function_exists( 'get_post_meta' ) ) {
			return array();
		}
		$kit      = (int) get_option( 'elementor_active_kit', 0 );
		$settings = $kit ? get_post_meta( $kit, '_elementor_page_settings', true ) : array();
		$system   = is_array( $settings ) && isset( $settings['system_colors'] ) && is_array( $settings['system_colors'] ) ? $settings['system_colors'] : array();
		$by_id    = array(
			'primary' => '#6EC1E4',
			'accent'  => '#61CE70',
		);
		foreach ( $system as $entry ) {
			if ( isset( $entry['_id'], $entry['color'] ) ) {
				$by_id[ (string) $entry['_id'] ] = (string) $entry['color'];
			}
		}
		return array(
			'button' => $by_id['accent'],
			'main'   => $by_id['primary'],
			'link'   => isset( $by_id['accent'] ) ? $by_id['accent'] : '',
		);
	}
}
