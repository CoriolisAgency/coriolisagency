<?php
/**
 * Progressive-enhancement fragments for Apply.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Panel;

defined( 'ABSPATH' ) || exit;

/**
 * Returns panel, grid and count HTML from the same render path as a full page.
 *
 * Fetch uses the same GET URL plus an X-FFLF-Fragments header. Without JS,
 * the form still submits as a normal GET and the full page is returned.
 */
class Fragments {

	/**
	 * Request header that asks for fragments instead of a full document.
	 *
	 * @var string
	 */
	const HEADER = 'HTTP_X_FFLF_FRAGMENTS';

	/**
	 * Whether a grid wrapper is currently open.
	 *
	 * @var bool
	 */
	private $grid_open = false;

	/**
	 * Output-buffer level started for this request, if any.
	 *
	 * @var int
	 */
	private $ob_level = 0;

	/**
	 * Hook fragment serving and grid wrappers.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'template_redirect', array( $this, 'maybe_start' ), 20 );
		add_filter( 'wp_headers', array( $this, 'vary_headers' ), 1000 );
		// Open right after our own panel (4), fallback (5) and opener (6), before notices (10) and the theme's count and
		// sorting. A theme that wraps its toolbar in a container (opened after 7, closed before the loop) then nests inside
		// the grid instead of crossing it, so its closing tag cannot end the grid early.
		add_action( 'woocommerce_before_shop_loop', array( $this, 'open_grid' ), 7 );
		add_action( 'woocommerce_after_shop_loop', array( $this, 'close_grid' ), 999 );
		add_action( 'woocommerce_no_products_found', array( $this, 'open_grid' ), 1 );
		add_action( 'woocommerce_no_products_found', array( $this, 'close_grid' ), 99 );
	}

	/**
	 * Whether this request asked for fragments.
	 *
	 * @return bool
	 */
	public function is_fragment_request() {
		if ( ! isset( $_SERVER[ self::HEADER ] ) ) {
			return false;
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Header flag, compared to a literal.
		$value = wp_unslash( $_SERVER[ self::HEADER ] );
		$value = is_string( $value ) ? trim( $value ) : '';

		return '1' === $value || 'true' === strtolower( $value );
	}

	/**
	 * Ask caches that honour Vary to keep HTML and JSON apart.
	 *
	 * @param array<string, string> $headers Headers.
	 * @return array<string, string>
	 */
	public function vary_headers( $headers ) {
		if ( ! is_array( $headers ) ) {
			$headers = array();
		}

		$vary = isset( $headers['Vary'] ) ? (string) $headers['Vary'] : '';
		if ( false === stripos( $vary, 'X-FFLF-Fragments' ) ) {
			$headers['Vary'] = trim( $vary . ( '' === $vary ? '' : ', ' ) . 'X-FFLF-Fragments', ', ' );
		}

		return $headers;
	}

	/**
	 * Buffer a product-archive template so we can return fragments.
	 *
	 * @return void
	 */
	public function maybe_start() {
		if ( ! $this->is_fragment_request() ) {
			return;
		}
		if ( ! $this->is_product_archive() ) {
			return;
		}

		ob_start();
		$this->ob_level = ob_get_level();
		add_action( 'shutdown', array( $this, 'emit' ), -5 );
	}

	/**
	 * Swap the buffered document for a JSON fragment payload.
	 *
	 * @return void
	 */
	public function emit() {
		$html = '';
		if ( $this->ob_level > 0 ) {
			while ( ob_get_level() >= $this->ob_level ) {
				$chunk = ob_get_clean();
				$html  = ( is_string( $chunk ) ? $chunk : '' ) . $html;
			}
		}

		$response = $this->respond_from_html( $html );
		$this->send( $response );
	}

	/**
	 * Build the HTTP response for a captured archive page.
	 *
	 * @param string $html Full HTML.
	 * @return array{status: int, headers: array<string, string>, body: string}
	 */
	public function respond_from_html( $html ) {
		$payload = $this->extract( $html );

		return array(
			'status'  => 200,
			'headers' => array(
				'Content-Type'  => 'application/json; charset=UTF-8',
				'Cache-Control' => 'private, no-store',
				'X-Robots-Tag'  => 'noindex, nofollow',
				'Vary'          => 'X-FFLF-Fragments',
			),
			'body'    => wp_json_encode( $payload ),
		);
	}

	/**
	 * Pull panel and grid fragments from a full document.
	 *
	 * @param string $html Full HTML.
	 * @return array<string, mixed>
	 */
	public function extract( $html ) {
		$panel = $this->extract_element( $html, 'data-fflf-panel' );
		$grid  = $this->extract_element( $html, 'data-fflf-grid' );

		return array(
			'url'          => $this->current_url(),
			'title'        => $this->document_title(),
			'panel'        => $panel,
			'grid'         => $grid,
			'result_count' => $this->found_posts(),
		);
	}

	/**
	 * Open the product-loop wrapper (classic themes).
	 *
	 * @return void
	 */
	public function open_grid() {
		if ( $this->grid_open ) {
			return;
		}
		$this->grid_open = true;
		echo '<div class="ffl-filters-grid" data-fflf-grid>';
	}

	/**
	 * Close the product-loop wrapper.
	 *
	 * @return void
	 */
	public function close_grid() {
		if ( ! $this->grid_open ) {
			return;
		}
		$this->grid_open = false;
		echo '</div>';
	}

	/**
	 * Wrap a block or HTML chunk in the grid marker if it is not already wrapped.
	 *
	 * @param string $html HTML.
	 * @return string
	 */
	public function wrap_grid( $html ) {
		if ( false !== strpos( (string) $html, 'data-fflf-grid' ) ) {
			return (string) $html;
		}

		return '<div class="ffl-filters-grid" data-fflf-grid>' . $html . '</div>';
	}

	/**
	 * First element carrying an attribute, as a string, or empty.
	 *
	 * @param string $html Full HTML.
	 * @param string $attr Attribute name.
	 * @return string
	 */
	public function extract_element( $html, $attr ) {
		$html = (string) $html;
		if ( '' === $html || false === strpos( $html, $attr ) ) {
			return '';
		}

		if ( ! class_exists( '\DOMDocument' ) ) {
			return '';
		}

		$document = new \DOMDocument();
		$previous = libxml_use_internal_errors( true );
		$loaded   = $document->loadHTML( '<?xml encoding="utf-8">' . $html );
		libxml_clear_errors();
		libxml_use_internal_errors( $previous );

		if ( ! $loaded ) {
			return '';
		}

		$xpath = new \DOMXPath( $document );
		$nodes = $xpath->query( '//*[@' . $attr . ']' );
		if ( ! $nodes || 0 === $nodes->length ) {
			return '';
		}

		$node = $nodes->item( 0 );
		if ( ! $node instanceof \DOMNode ) {
			return '';
		}

		$out = $document->saveHTML( $node );
		return is_string( $out ) ? $out : '';
	}

	/**
	 * Public URL of the current request (no fragment header).
	 *
	 * @return string
	 */
	public function current_url() {
		$path = '/';
		if ( isset( $_SERVER['REQUEST_URI'] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Request path and query.
			$uri   = (string) wp_unslash( $_SERVER['REQUEST_URI'] );
			$part  = wp_parse_url( $uri, PHP_URL_PATH );
			$query = wp_parse_url( $uri, PHP_URL_QUERY );
			$path  = is_string( $part ) && '' !== $part ? $part : '/';
			if ( is_string( $query ) && '' !== $query ) {
				$path .= '?' . $query;
			}
		} elseif ( function_exists( 'home_url' ) ) {
			return home_url( add_query_arg( array() ) );
		}

		if ( function_exists( 'home_url' ) ) {
			$home = wp_parse_url( home_url( '/' ), PHP_URL_PATH );
			$home = is_string( $home ) ? rtrim( $home, '/' ) : '';
			if ( '' !== $home && 0 === strpos( $path, $home ) ) {
				$path = substr( $path, strlen( $home ) );
				$path = '' === $path ? '/' : $path;
			}
			return home_url( $path );
		}

		return $path;
	}

	/**
	 * Send a response and halt when not in the test suite.
	 *
	 * @param array{status: int, headers: array<string, string>, body: string} $response Response.
	 * @return void
	 */
	private function send( $response ) {
		if ( function_exists( 'status_header' ) ) {
			status_header( (int) $response['status'] );
		}
		foreach ( $response['headers'] as $name => $value ) {
			header( $name . ': ' . $value );
		}

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON body.
		echo $response['body'];

		if ( $this->is_unit_test() ) {
			return;
		}
		exit;
	}

	/**
	 * Shop or product-taxonomy archive.
	 *
	 * @return bool
	 */
	private function is_product_archive() {
		if ( function_exists( 'is_shop' ) && is_shop() ) {
			return true;
		}
		if ( function_exists( 'is_product_taxonomy' ) && is_product_taxonomy() ) {
			return true;
		}
		if ( function_exists( 'is_post_type_archive' ) && is_post_type_archive( 'product' ) ) {
			return true;
		}
		return false;
	}

	/**
	 * Main-query found posts when available.
	 *
	 * @return int
	 */
	private function found_posts() {
		if ( isset( $GLOBALS['wp_query'] ) && is_object( $GLOBALS['wp_query'] ) && isset( $GLOBALS['wp_query']->found_posts ) ) {
			return (int) $GLOBALS['wp_query']->found_posts;
		}
		return 0;
	}

	/**
	 * Document title for pushState replacements.
	 *
	 * @return string
	 */
	private function document_title() {
		if ( function_exists( 'wp_get_document_title' ) ) {
			return wp_get_document_title();
		}
		return '';
	}

	/**
	 * Running inside the WordPress test suite.
	 *
	 * @return bool
	 */
	private function is_unit_test() {
		return ( defined( 'WP_RUNNING_TESTS' ) && WP_RUNNING_TESTS ) || defined( 'WP_TESTS_DOMAIN' );
	}
}
