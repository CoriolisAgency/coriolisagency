<?php
/**
 * Static per-generation facet JSON for large groups.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Panel;

use FFL_Filters\Cache\Generation;
use FFL_Filters\Query\Parsed_Request;

defined( 'ABSPATH' ) || exit;

/**
 * Serves GET /ffl-filters/facets/{generation}/{scope}/{facet}.json.
 *
 * Page-cacheable, noindex, and never registered on admin-ajax.
 */
class Endpoint {

	/**
	 * URL prefix under the site root.
	 *
	 * @var string
	 */
	const BASE_PATH = 'ffl-filters/facets';

	/**
	 * Generation source.
	 *
	 * @var Generation
	 */
	private $generation;

	/**
	 * Counts.
	 *
	 * @var Counts
	 */
	private $counts;

	/**
	 * Facet catalog.
	 *
	 * @var Facets
	 */
	private $facets;

	/**
	 * Document helper (term labels).
	 *
	 * @var Document
	 */
	private $document;

	/**
	 * Constructor.
	 *
	 * @param Generation|null $generation Generation source.
	 * @param Counts|null     $counts     Counts.
	 * @param Facets|null     $facets     Facets.
	 * @param Document|null   $document   Document.
	 */
	public function __construct( $generation = null, $counts = null, $facets = null, $document = null ) {
		$this->generation = $generation ? $generation : new Generation();
		$this->counts     = $counts ? $counts : new Counts();
		$this->facets     = $facets ? $facets : new Facets();
		$this->document   = $document;
	}

	/**
	 * Document used to map term ids to labels (lazy to avoid a constructor cycle).
	 *
	 * @return Document
	 */
	private function document() {
		if ( ! $this->document ) {
			$this->document = new Document( $this->facets, $this->counts, null, null, null, $this );
		}
		return $this->document;
	}

	/**
	 * Hook the JSON path and robots Disallow. No admin-ajax actions.
	 *
	 * @return void
	 */
	public function register() {
		if ( $this->compare_plugin_is_active() ) {
			return;
		}

		add_action( 'parse_request', array( $this, 'maybe_serve' ), 0 );
		add_filter( 'robots_txt', array( $this, 'filter_robots' ), 10, 2 );
	}

	/**
	 * Public JSON URL for a scope and facet, keyed by the current generation.
	 *
	 * @param string   $scope   Archive scope (shop or taxonomy:slug).
	 * @param string   $facet   Facet / taxonomy id.
	 * @param int|null $gen     Generation override.
	 * @return string
	 */
	public function url( $scope, $facet, $gen = null ) {
		$gen  = null === $gen ? $this->generation->current() : (int) $gen;
		$path = self::BASE_PATH . '/' . $gen . '/' . $this->encode_scope( $scope ) . '/' . $this->encode_facet( $facet ) . '.json';

		if ( function_exists( 'home_url' ) ) {
			return home_url( '/' . $path );
		}

		return '/' . $path;
	}

	/**
	 * Parse a request path into generation, scope and facet, or null.
	 *
	 * @param string $path Path relative to the site root, no leading slash.
	 * @return array{generation: int, scope: string, facet: string}|null
	 */
	public function parse_path( $path ) {
		$path = trim( (string) $path, '/' );
		if ( ! preg_match( '#^' . preg_quote( self::BASE_PATH, '#' ) . '/([0-9]+)/([^/]+)/([^/]+)\.json$#', $path, $matches ) ) {
			return null;
		}

		return array(
			'generation' => (int) $matches[1],
			'scope'      => $this->decode_scope( $matches[2] ),
			'facet'      => $this->decode_facet( $matches[3] ),
		);
	}

	/**
	 * Build the HTTP response for a matched JSON request (no I/O).
	 *
	 * @param int    $generation Generation from the URL.
	 * @param string $scope      Decoded scope.
	 * @param string $facet      Decoded facet id.
	 * @return array{status: int, headers: array<string, string>, body: string, redirect: string}
	 */
	public function respond( $generation, $scope, $facet ) {
		$noindex = array(
			'X-Robots-Tag'  => 'noindex, nofollow',
			'Content-Type'  => 'application/json; charset=UTF-8',
			'Cache-Control' => 'no-store',
		);

		$current = $this->generation->current();
		if ( (int) $generation !== (int) $current ) {
			return array(
				'status'   => 301,
				'headers'  => array(
					'X-Robots-Tag'  => 'noindex, nofollow',
					'Cache-Control' => 'public, max-age=60',
				),
				'body'     => '',
				'redirect' => $this->url( $scope, $facet, $current ),
			);
		}

		$payload = $this->payload( $scope, $facet );
		if ( null === $payload ) {
			return array(
				'status'   => 404,
				'headers'  => $noindex,
				'body'     => wp_json_encode( array( 'error' => 'not_found' ) ),
				'redirect' => '',
			);
		}

		return array(
			'status'   => 200,
			'headers'  => array(
				'Content-Type'  => 'application/json; charset=UTF-8',
				'Cache-Control' => 'public, max-age=31536000, immutable',
				'X-Robots-Tag'  => 'noindex, nofollow',
			),
			'body'     => wp_json_encode( $payload ),
			'redirect' => '',
		);
	}

	/**
	 * Term list for a public facet at an archive scope, or null when the request is invalid.
	 *
	 * Counts follow the archive scope only (not other selected filters), so the
	 * URL stays static per generation and scope.
	 *
	 * @param string $scope Archive scope.
	 * @param string $facet Facet / taxonomy id.
	 * @return array<string, mixed>|null
	 */
	public function payload( $scope, $facet ) {
		$facet = $this->allowed_facet( $facet );
		if ( ! $facet ) {
			return null;
		}

		$request = $this->request_for_scope( $scope );
		if ( null === $request ) {
			return null;
		}

		$taxonomy = $facet['id'];
		$counts   = $this->counts->terms( $taxonomy, $scope, $request );
		$terms    = $this->document()->terms_for_json( $taxonomy, $counts );

		return array(
			'generation' => $this->generation->current(),
			'scope'      => $scope,
			'facet'      => $taxonomy,
			'param'      => $facet['param'],
			'terms'      => $terms,
		);
	}

	/**
	 * Serve a matching request and stop WordPress, or fall through.
	 *
	 * @return void
	 */
	public function maybe_serve() {
		$path   = $this->request_path();
		$parsed = $this->parse_path( $path );
		if ( ! $parsed ) {
			return;
		}

		$response = $this->respond( $parsed['generation'], $parsed['scope'], $parsed['facet'] );
		$this->send( $response );
	}

	/**
	 * Disallow the JSON path in robots.txt.
	 *
	 * @param string $output Robots body.
	 * @param bool   $is_public Whether the site is public.
	 * @return string
	 */
	public function filter_robots( $output, $is_public ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
		$path = '/ffl-filters/';
		if ( function_exists( 'home_url' ) && function_exists( 'wp_parse_url' ) ) {
			$parsed = wp_parse_url( home_url( '/ffl-filters/' ), PHP_URL_PATH );
			if ( is_string( $parsed ) && '' !== $parsed ) {
				$path = $parsed;
			}
		}

		if ( false !== strpos( (string) $output, 'Disallow: ' . $path ) ) {
			return $output;
		}

		return rtrim( (string) $output ) . "\nDisallow: " . $path . "\n";
	}

	/**
	 * Path of the current request, relative to the site root.
	 *
	 * @return string
	 */
	public function request_path() {
		$uri = '';
		if ( isset( $_SERVER['REQUEST_URI'] ) ) {
			$uri = sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) );
		}

		$parsed = function_exists( 'wp_parse_url' ) ? wp_parse_url( $uri, PHP_URL_PATH ) : '';
		$path   = is_string( $parsed ) ? $parsed : '';

		$home = '/';
		if ( function_exists( 'home_url' ) && function_exists( 'wp_parse_url' ) ) {
			$home_path = wp_parse_url( home_url( '/' ), PHP_URL_PATH );
			if ( is_string( $home_path ) && '' !== $home_path ) {
				$home = $home_path;
			}
		}

		$home = rtrim( $home, '/' );
		if ( '' !== $home && 0 === strpos( $path, $home ) ) {
			$path = substr( $path, strlen( $home ) );
		}

		return trim( (string) $path, '/' );
	}

	/**
	 * Encode an archive scope for the URL path.
	 *
	 * @param string $scope Scope.
	 * @return string
	 */
	public function encode_scope( $scope ) {
		$scope = str_replace( ':', '~', (string) $scope );
		$scope = preg_replace( '/[^a-z0-9_\-~]/i', '', $scope );
		return is_string( $scope ) && '' !== $scope ? $scope : 'shop';
	}

	/**
	 * Decode a scope path segment.
	 *
	 * @param string $encoded Encoded scope.
	 * @return string
	 */
	public function decode_scope( $encoded ) {
		$encoded = rawurldecode( (string) $encoded );
		return str_replace( '~', ':', $encoded );
	}

	/**
	 * Encode a facet id for the URL path.
	 *
	 * @param string $facet Facet id.
	 * @return string
	 */
	public function encode_facet( $facet ) {
		$facet = preg_replace( '/[^a-z0-9_\-]/i', '', (string) $facet );
		return is_string( $facet ) ? $facet : '';
	}

	/**
	 * Decode a facet path segment.
	 *
	 * @param string $encoded Encoded facet.
	 * @return string
	 */
	public function decode_facet( $encoded ) {
		return rawurldecode( (string) $encoded );
	}

	/**
	 * Send a response and halt when not in the test suite.
	 *
	 * @param array{status: int, headers: array<string, string>, body: string, redirect: string} $response Response.
	 * @return void
	 */
	private function send( $response ) {
		if ( ! empty( $response['redirect'] ) ) {
			if ( function_exists( 'status_header' ) ) {
				status_header( (int) $response['status'] );
			}
			foreach ( $response['headers'] as $name => $value ) {
				header( $name . ': ' . $value );
			}
			if ( function_exists( 'wp_safe_redirect' ) ) {
				wp_safe_redirect( $response['redirect'], (int) $response['status'] );
			} else {
				header( 'Location: ' . $response['redirect'], true, (int) $response['status'] );
			}
			$this->quit();
			return;
		}

		if ( function_exists( 'status_header' ) ) {
			status_header( (int) $response['status'] );
		}
		foreach ( $response['headers'] as $name => $value ) {
			header( $name . ': ' . $value );
		}

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON body.
		echo $response['body'];
		$this->quit();
	}

	/**
	 * Stop execution unless a unit test is running.
	 *
	 * @return void
	 */
	private function quit() {
		if ( $this->is_unit_test() ) {
			return;
		}
		exit;
	}

	/**
	 * Empty or archive-constrained request for a scope id, or null if invalid.
	 *
	 * @param string $scope Scope.
	 * @return Parsed_Request|null
	 */
	private function request_for_scope( $scope ) {
		$scope = (string) $scope;
		if ( 'shop' === $scope ) {
			return new Parsed_Request( array(), null, null, false, array() );
		}

		if ( ! preg_match( '/^([a-z0-9_]+):([a-z0-9_\-]+)$/i', $scope, $matches ) ) {
			return null;
		}

		$taxonomy = $matches[1];
		$slug     = $matches[2];

		if ( 0 !== strpos( $taxonomy, 'product_' ) && 0 !== strpos( $taxonomy, 'pa_' ) ) {
			return null;
		}

		if ( function_exists( 'taxonomy_exists' ) && ! taxonomy_exists( $taxonomy ) ) {
			return null;
		}

		if ( function_exists( 'get_term_by' ) ) {
			$term = get_term_by( 'slug', $slug, $taxonomy );
			if ( ! $term || is_wp_error( $term ) ) {
				return null;
			}
		}

		return new Parsed_Request(
			array(
				$taxonomy => array( $slug ),
			),
			null,
			null,
			false,
			array()
		);
	}

	/**
	 * Allowed term facet descriptor, or null.
	 *
	 * @param string $facet Facet id.
	 * @return array<string, string>|null
	 */
	private function allowed_facet( $facet ) {
		foreach ( $this->facets->all() as $item ) {
			if ( ! isset( $item['id'], $item['type'] ) ) {
				continue;
			}
			if ( 'terms' !== $item['type'] ) {
				continue;
			}
			if ( (string) $item['id'] !== (string) $facet ) {
				continue;
			}
			return $item;
		}

		return null;
	}

	/**
	 * True when Coriolis Product Filters is active.
	 *
	 * @return bool
	 */
	private function compare_plugin_is_active() {
		if ( function_exists( 'fflf_is_passive' ) ) {
			return fflf_is_passive();
		}
		return function_exists( 'fflf_compare_plugin_is_active' ) && fflf_compare_plugin_is_active();
	}

	/**
	 * Running inside the WordPress test suite.
	 *
	 * @return bool
	 */
	private function is_unit_test() {
		return ( defined( 'WP_RUNNING_TESTS' ) && WP_RUNNING_TESTS ) || defined( 'WP_TESTS_DOMAIN' );
	}
}
