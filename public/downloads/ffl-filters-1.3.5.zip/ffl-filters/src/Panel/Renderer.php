<?php
/**
 * Storefront panel markup.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Panel;

defined( 'ABSPATH' ) || exit;

/**
 * Prints fieldset/legend groups, unique IDs, and an aria-live result count.
 */
class Renderer {

	/**
	 * Instance counter so two panels on one page never share IDs.
	 *
	 * @var int
	 */
	private static $counter = 0;

	/**
	 * Rendering the Above products placement (per render call).
	 *
	 * @var bool
	 */
	private $above = false;

	/**
	 * Result count for the panel being rendered.
	 *
	 * @var int
	 */
	private $count = 0;

	/**
	 * Reset the instance counter (tests).
	 *
	 * @return void
	 */
	public static function reset_counter() {
		self::$counter = 0;
	}

	/**
	 * Render a panel from a view-model.
	 *
	 * @param array<string, mixed> $document View-model from Document::build() or a test fixture.
	 * @return string
	 */
	public function render( $document ) {
		++self::$counter;
		$instance = self::$counter;

		$action       = isset( $document['action'] ) ? (string) $document['action'] : '';
		$clear_url    = isset( $document['clear_url'] ) ? (string) $document['clear_url'] : $action;
		$groups       = isset( $document['groups'] ) && is_array( $document['groups'] ) ? $document['groups'] : array();
		$chips        = isset( $document['chips'] ) && is_array( $document['chips'] ) ? $document['chips'] : array();
		$result_count = isset( $document['result_count'] ) ? (int) $document['result_count'] : 0;
		$mobile       = isset( $document['mobile'] ) ? (string) $document['mobile'] : 'drawer';
		$hidden       = isset( $document['hidden'] ) && is_array( $document['hidden'] ) ? $document['hidden'] : array();
		$has_filters  = ! empty( $document['has_filters'] );

		if ( ! in_array( $mobile, array( 'drawer', 'collapsible', 'sidebar' ), true ) ) {
			$mobile = 'drawer';
		}

		$layout = isset( $document['layout'] ) ? (string) $document['layout'] : 'auto';
		if ( ! in_array( $layout, array( 'auto', 'bar', 'stacked' ), true ) ) {
			$layout = 'auto';
		}
		// 1.3.0: Above products prints the results row (count, chips, sorting) and a footer in each popover.
		$above = isset( $document['placement'] ) && 'above' === $document['placement'];
		// Panel style: Auto prints Light (always readable with JavaScript off); panel.js then checks the background.
		$style = isset( $document['panel_style'] ) ? (string) $document['panel_style'] : 'auto';
		if ( ! in_array( $style, array( 'auto', 'light', 'dark' ), true ) ) {
			$style = 'auto';
		}
		$this->above = $above;
		$this->count = $result_count;

		$panel_id  = 'fflf-' . $instance;
		$drawer_id = $panel_id . '-drawer';
		$title_id  = $panel_id . '-title';
		$live_id   = $panel_id . '-live';
		$after_id  = $panel_id . '-after';
		$form_id   = $panel_id . '-form';
		$classes   = 'ffl-filters ffl-filters--' . $mobile . ' ffl-filters--layout-' . $layout . ( $above ? ' ffl-filters--above' : '' );

		$live_text = $this->live_text( $result_count );

		$html  = '<div class="' . esc_attr( $classes ) . '" id="' . esc_attr( $panel_id ) . '" data-fflf-panel data-fflf-layout="' . esc_attr( $layout ) . '"';
		$html .= ' data-fflf-placement="' . ( $above ? 'above' : 'sidebar' ) . '"';
		$html .= ' data-fflf-style="' . esc_attr( 'dark' === $style ? 'dark' : 'light' ) . '" data-fflf-style-mode="' . esc_attr( $style ) . '"';
		$html .= ' data-fflf-accent="saved">';
		$html .= '<a class="ffl-filters__skip" href="#' . esc_attr( $after_id ) . '">' . esc_html__( 'Skip filters', 'ffl-filters' ) . '</a>';

		if ( 'drawer' === $mobile ) {
			$html .= '<a class="ffl-filters__open" href="#' . esc_attr( $drawer_id ) . '" data-fflf-drawer-open aria-expanded="false" aria-controls="' . esc_attr( $drawer_id ) . '">';
			$html .= esc_html__( 'Filter products', 'ffl-filters' );
			$html .= '</a>';
			$html .= '<div class="ffl-filters__backdrop" data-fflf-drawer-close></div>';
		} elseif ( 'collapsible' === $mobile ) {
			// Collapsible opens in place on phones, pushing the products down. No overlay.
			$html .= '<a class="ffl-filters__open ffl-filters__open--collapsible" href="#' . esc_attr( $drawer_id ) . '" data-fflf-collapse-open aria-expanded="false" aria-controls="' . esc_attr( $drawer_id ) . '">';
			$html .= esc_html__( 'Filter products', 'ffl-filters' );
			$html .= '</a>';
		}

		$html .= '<div class="ffl-filters__drawer" id="' . esc_attr( $drawer_id ) . '" data-fflf-drawer role="region" aria-labelledby="' . esc_attr( $title_id ) . '">';

		if ( 'drawer' === $mobile ) {
			$html .= '<a class="ffl-filters__drawer-close" href="#' . esc_attr( $panel_id ) . '" data-fflf-drawer-close>';
			$html .= esc_html__( 'Close filters', 'ffl-filters' );
			$html .= '</a>';
		}

		// A hidden title stays in the markup for screen readers and still shows inside the phone drawer.
		$title_class = ( ! isset( $document['show_title'] ) || ! empty( $document['show_title'] ) ) ? 'ffl-filters__title' : 'ffl-filters__title ffl-filters__title--wide-hidden';
		// A blank heading falls back to Filter products.
		$heading = isset( $document['heading'] ) && is_string( $document['heading'] ) && '' !== trim( $document['heading'] ) ? trim( $document['heading'] ) : __( 'Filter products', 'ffl-filters' );
		$html   .= '<h2 class="' . esc_attr( $title_class ) . '" id="' . esc_attr( $title_id ) . '">' . esc_html( $heading ) . '</h2>';

		$live_html = '<div class="ffl-filters__live" id="' . esc_attr( $live_id ) . '" aria-live="polite">' . esc_html( $live_text ) . '</div>';
		$chip_html = $this->render_chips( $chips, $clear_url, $has_filters );
		if ( ! $above ) {
			$html .= $live_html . $chip_html;
		}

		$html .= '<form class="ffl-filters__form" id="' . esc_attr( $form_id ) . '" method="get" action="' . esc_url( $action ) . '">';

		foreach ( $hidden as $name => $value ) {
			// Above products: the sort control in the results row carries orderby for this form.
			if ( $above && 'orderby' === $name && ! empty( $document['sort'] ) ) {
				continue;
			}
			$html .= '<input type="hidden" name="' . esc_attr( (string) $name ) . '" value="' . esc_attr( (string) $value ) . '" />';
		}

		foreach ( $groups as $group ) {
			$html .= $this->render_group( $panel_id, $group );
		}

		$show_clear    = $has_filters && empty( $chips );
		$actions_class = 'ffl-filters__actions' . ( $show_clear ? '' : ' ffl-filters__actions--bare' );

		$html .= '<div class="' . esc_attr( $actions_class ) . '">';
		// Without JavaScript this button applies the form. Once the script runs, every click applies on its own and CSS hides it.
		$html .= '<button type="submit" class="ffl-filters__apply">' . esc_html__( 'Show products', 'ffl-filters' ) . '</button>';
		if ( 'drawer' === $mobile ) {
			// Phone drawer only: filters already applied, so this just closes the drawer.
			/* translators: %s: number of matching products */
			$done  = sprintf( _n( 'Show %s product', 'Show %s products', max( 0, $result_count ), 'ffl-filters' ), $this->format_count( max( 0, $result_count ) ) );
			$html .= '<button type="button" class="ffl-filters__done" data-fflf-done data-fflf-drawer-close>' . esc_html( $done ) . '</button>';
		}
		if ( $show_clear ) {
			$html .= '<a class="ffl-filters__clear" href="' . esc_url( $clear_url ) . '" rel="nofollow">' . esc_html__( 'Clear all', 'ffl-filters' ) . '</a>';
		}
		$html .= '</div>';
		$html .= '</form>';

		if ( $above ) {
			// Results row: count on the left, one chip per value and Clear all, sorting on the right.
			$html .= '<div class="ffl-filters__results">' . $live_html . $chip_html;
			$html .= $this->render_sort( isset( $document['sort'] ) && is_array( $document['sort'] ) ? $document['sort'] : array(), $form_id );
			$html .= '</div>';
		}

		// Without JavaScript the chevrons cannot open a group, so every group shows open.
		$html .= '<noscript><style>.ffl-filters .ffl-filters__options[hidden]{display:block}</style></noscript>';
		if ( 'stacked' !== $layout ) {
			// With JavaScript off every group is open, so the Bar cannot work as popovers: show them in place.
			$html .= '<noscript><style>.ffl-filters .ffl-filters__form{display:block!important}.ffl-filters .ffl-filters__options{position:static!important;width:auto!important;box-shadow:none!important}</style></noscript>';
		}
		$html .= '</div>';
		$html .= '</div>';
		$html .= '<div id="' . esc_attr( $after_id ) . '"></div>';

		return $html;
	}

	/**
	 * Chips list with Clear all.
	 *
	 * @param array<int, array<string, mixed>> $chips       Chips.
	 * @param string                           $clear_url   Clear-all URL.
	 * @param bool                             $has_filters Whether any filter is on.
	 * @return string
	 */
	private function render_chips( $chips, $clear_url, $has_filters ) {
		$html = '';
		if ( ! empty( $chips ) ) {
			$html .= '<ul class="ffl-filters__chips">';
			foreach ( $chips as $chip ) {
				$label = isset( $chip['label'] ) ? (string) $chip['label'] : '';
				$url   = isset( $chip['url'] ) ? (string) $chip['url'] : $clear_url;
				/* translators: %s: the full chip text */
				$aria  = sprintf( __( 'Remove filter: %s', 'ffl-filters' ), $label );
				$html .= '<li><a class="ffl-filters__chip" href="' . esc_url( $url ) . '" aria-label="' . esc_attr( $aria ) . '">';
				$html .= '<span class="ffl-filters__chip-label">' . esc_html( $label ) . '</span>';
				$html .= '<span class="ffl-filters__chip-x" aria-hidden="true">&times;</span>';
				$html .= '</a></li>';
			}
			if ( $has_filters ) {
				$html .= '<li><a class="ffl-filters__clear ffl-filters__clear--chips" href="' . esc_url( $clear_url ) . '" rel="nofollow">' . esc_html__( 'Clear all', 'ffl-filters' ) . '</a></li>';
			}
			$html .= '</ul>';
		}
		return $html;
	}

	/**
	 * Sorting for the results row (Above products). Options and labels come from WooCommerce's own list.
	 *
	 * @param array<string, mixed> $sort    Sort view-model: options (value => label) and current.
	 * @param string               $form_id Form the control belongs to.
	 * @return string
	 */
	private function render_sort( $sort, $form_id ) {
		$options = isset( $sort['options'] ) && is_array( $sort['options'] ) ? $sort['options'] : array();
		if ( empty( $options ) ) {
			return '';
		}
		$current = isset( $sort['current'] ) ? (string) $sort['current'] : '';
		$id      = $form_id . '-orderby';
		$html    = '<div class="ffl-filters__sort">';
		/* translators: label next to the dropdown that sorts the products */
		$html .= '<label for="' . esc_attr( $id ) . '">' . esc_html__( 'Sort', 'ffl-filters' ) . '</label>';
		$html .= '<select name="orderby" id="' . esc_attr( $id ) . '" form="' . esc_attr( $form_id ) . '" data-fflf-sort>';
		foreach ( $options as $value => $label ) {
			$html .= '<option value="' . esc_attr( (string) $value ) . '"' . ( (string) $value === $current ? ' selected' : '' ) . '>' . esc_html( (string) $label ) . '</option>';
		}
		$html .= '</select></div>';
		return $html;
	}

	/**
	 * Render one facet group.
	 *
	 * @param string               $panel_id Panel prefix.
	 * @param array<string, mixed> $group    Group view-model.
	 * @return string
	 */
	private function render_group( $panel_id, $group ) {
		$type = isset( $group['type'] ) ? (string) $group['type'] : 'terms';
		// 1.2.0 dropped the Dropdown display type: a saved dropdown group renders as the checkbox list.
		if ( 'dropdown' === $type ) {
			$type          = 'terms';
			$group['type'] = 'terms';
		}
		$id    = isset( $group['id'] ) ? (string) $group['id'] : $type;
		$label = isset( $group['label'] ) ? (string) $group['label'] : $id;
		$list  = $panel_id . '-' . $this->id_slug( $id ) . '-list';
		// Above products: every group starts closed on load, picks included (a popover never opens over the products by itself).
		$open   = ! empty( $group['expanded'] ) && ! $this->above;
		$param  = isset( $group['param'] ) ? (string) $group['param'] : '';
		$picked = 0;

		$is_switch = in_array( $type, array( 'instock', 'instore' ), true );
		$html      = '<fieldset class="ffl-filters__group' . ( $is_switch ? ' ffl-filters__group--switch' : '' ) . '" data-fflf-group="' . esc_attr( $id ) . '"';
		if ( '' !== $param ) {
			$html .= ' data-fflf-param="' . esc_attr( $param ) . '"';
		}
		if ( ! empty( $group['large'] ) ) {
			$html .= ' data-fflf-large="1"';
			if ( isset( $group['total'] ) ) {
				$html .= ' data-fflf-total="' . esc_attr( (string) (int) $group['total'] ) . '"';
			}
		}
		$single = in_array( $type, array( 'price', 'instock', 'instore', 'range' ), true );
		if ( $single ) {
			$html .= ' data-fflf-single="1"';
		}
		// Popovers stay open after a tick on multi-select groups and close after the pick on single-select ones.
		$select = isset( $group['select'] ) && 'single' === $group['select'] ? 'single' : ( $single ? 'single' : 'multi' );
		if ( 'single' === $select && ! $single ) {
			$html .= ' data-fflf-select="single"';
		} elseif ( 'multi' === $select ) {
			$html .= ' data-fflf-multi="1"';
		}
		$html .= '>';
		if ( in_array( $type, array( 'instock', 'instore' ), true ) ) {
			// The In Stock and In store switches are a single row with no heading: always shown.
			$html .= '<legend class="ffl-filters__visually-hidden">' . esc_html( $label ) . '</legend>';
			$open  = true;
		} else {
			// 1.2.1: every other group, Price and ranges included, has a chevron header and starts closed.
			// A group opens on load only when it has an active selection (see Document).
			$picked = $this->picked_count( $group );
			if ( $this->above && 0 === $picked && in_array( $type, array( 'price', 'range' ), true ) && $this->range_is_set( $group ) ) {
				$picked = 1;
			}
			$html .= '<legend class="ffl-filters__group-title">';
			$html .= '<button type="button" class="ffl-filters__toggle' . ( $picked > 0 ? ' has-value' : '' ) . '" id="' . esc_attr( $list . '-toggle' ) . '" data-fflf-toggle aria-expanded="' . ( $open ? 'true' : 'false' ) . '" aria-controls="' . esc_attr( $list ) . '">';
			$html .= '<span class="ffl-filters__toggle-label">' . esc_html( $label ) . '</span>';
			if ( $picked > 0 ) {
				$html .= '<span class="ffl-filters__toggle-badge" aria-hidden="true">' . esc_html( $this->format_count( $picked ) ) . '</span>';
			}
			$html .= '<span class="ffl-filters__toggle-icon" aria-hidden="true"></span>';
			$html .= '</button>';
			$html .= '</legend>';
		}

		$html .= '<div class="ffl-filters__options" id="' . esc_attr( $list ) . '"' . ( $open ? '' : ' hidden' ) . '>';

		if ( 'price' === $type ) {
			$html .= $this->render_price( $panel_id, $group );
		} elseif ( 'instock' === $type ) {
			$html .= $this->render_instock( $panel_id, $group );
		} elseif ( 'instore' === $type ) {
			$html .= $this->render_instore( $panel_id, $group );
		} elseif ( 'range' === $type ) {
			$html .= $this->render_numeric_range( $panel_id, $group );
		} else {
			$html .= $this->render_terms( $panel_id, $group );
		}

		if ( $this->above && ! $is_switch ) {
			if ( in_array( $type, array( 'price', 'range' ), true ) ) {
				$html .= '<p class="ffl-filters__pop-hint">' . esc_html__( 'Applies when you press Enter or leave the box.', 'ffl-filters' ) . '</p>';
			}
			$html .= $this->render_pop_foot( $group, $label, $picked );
		}

		$html .= '</div>';
		$html .= '</fieldset>';

		return $html;
	}

	/**
	 * Popover footer: the live count and "Clear <group>" (only when the group has a pick).
	 *
	 * @param array<string, mixed> $group  Group.
	 * @param string               $label  Group label.
	 * @param int                  $picked Picks in this group.
	 * @return string
	 */
	private function render_pop_foot( $group, $label, $picked ) {
		$count = max( 0, (int) $this->count );
		/* translators: %s: number of matching products */
		$html = '<div class="ffl-filters__pop-foot"><span class="ffl-filters__pop-count">' . esc_html( sprintf( _n( '%s product', '%s products', $count, 'ffl-filters' ), $this->format_count( $count ) ) ) . '</span>';
		if ( $picked > 0 && ! empty( $group['clear_url'] ) ) {
			/* translators: %s: filter group name, e.g. Caliber. Short link in the dropdown footer; keep it short. */
			$html .= '<a class="ffl-filters__pop-clear" href="' . esc_url( (string) $group['clear_url'] ) . '" rel="nofollow">' . esc_html( sprintf( __( 'Clear %s', 'ffl-filters' ), $label ) ) . '</a>';
		}
		$html .= '</div>';
		return $html;
	}

	/**
	 * Whether a price or range group has a min or max set.
	 *
	 * @param array<string, mixed> $group Group.
	 * @return bool
	 */
	private function range_is_set( $group ) {
		return ( isset( $group['min'] ) && is_numeric( $group['min'] ) ) || ( isset( $group['max'] ) && is_numeric( $group['max'] ) );
	}

	/**
	 * How many values are picked in a term group.
	 *
	 * @param array<string, mixed> $group Group.
	 * @return int
	 */
	private function picked_count( $group ) {
		$terms  = isset( $group['terms'] ) && is_array( $group['terms'] ) ? $group['terms'] : array();
		$picked = 0;
		foreach ( $terms as $term ) {
			if ( is_array( $term ) && ! empty( $term['selected'] ) ) {
				++$picked;
			}
		}
		return $picked;
	}

	/**
	 * Render term checkboxes: search box on top for long lists, the values in a capped scroll box,
	 * and a Show all link kept as the no-JavaScript fallback.
	 *
	 * @param string               $panel_id Panel prefix.
	 * @param array<string, mixed> $group    Group.
	 * @return string
	 */
	private function render_terms( $panel_id, $group ) {
		$terms = isset( $group['terms'] ) && is_array( $group['terms'] ) ? $group['terms'] : array();
		$large = ! empty( $group['large'] ) && ! empty( $group['id'] );
		$html  = '';

		if ( $large ) {
			$html .= $this->render_search( $panel_id, $group );
		}

		$html .= '<div class="ffl-filters__list' . ( $large ? ' ffl-filters__list--cap' : '' ) . '" data-fflf-list>';
		foreach ( $terms as $term ) {
			$html .= $this->render_term_option( $panel_id, $group, $term );
		}
		$html .= '</div>';

		if ( ! empty( $group['show_all'] ) && ! empty( $group['id'] ) ) {
			$total = isset( $group['total'] ) ? (int) $group['total'] : 0;
			$url   = $this->expand_url( (string) $group['id'] );
			$json  = isset( $group['json'] ) ? (string) $group['json'] : '';
			/* translators: %s: number of terms in the facet */
			$text  = sprintf( __( 'Show all %s', 'ffl-filters' ), $this->format_count( $total ) );
			$html .= '<a class="ffl-filters__show-all" href="' . esc_url( $url ) . '" data-fflf-show-all';
			if ( '' !== $json ) {
				$html .= ' data-fflf-json="' . esc_url( $json ) . '"';
			}
			$html .= '>' . esc_html( $text ) . '</a>';
		}

		return $html;
	}

	/**
	 * Render one term checkbox.
	 *
	 * @param string               $panel_id Panel prefix.
	 * @param array<string, mixed> $group    Group.
	 * @param array<string, mixed> $term     Term.
	 * @return string
	 */
	private function render_term_option( $panel_id, $group, $term ) {
		$param    = isset( $group['param'] ) ? (string) $group['param'] : '';
		$slug     = isset( $term['slug'] ) ? (string) $term['slug'] : '';
		$label    = isset( $term['label'] ) ? (string) $term['label'] : $slug;
		$count    = isset( $term['count'] ) ? (int) $term['count'] : 0;
		$selected = ! empty( $term['selected'] );
		$input_id = $panel_id . '-' . $this->id_slug( isset( $group['id'] ) ? (string) $group['id'] : 'term' ) . '-' . $this->id_slug( $slug );
		$depth    = isset( $term['depth'] ) ? (int) $term['depth'] : 0;
		$class    = 'ffl-filters__option';
		if ( 'toggle' === ( isset( $group['type'] ) ? (string) $group['type'] : '' ) ) {
			$class .= ' ffl-filters__option--toggle';
		}
		if ( $depth > 0 ) {
			$class .= ' ffl-filters__option--depth-' . $depth;
		}

		$html  = '<label class="' . esc_attr( $class ) . '" for="' . esc_attr( $input_id ) . '">';
		$html .= '<input type="checkbox" name="' . esc_attr( $param ) . '[]" value="' . esc_attr( $slug ) . '" id="' . esc_attr( $input_id ) . '"' . ( $selected ? ' checked' : '' ) . ' />';
		$html .= '<span class="ffl-filters__option-label">' . esc_html( $label ) . '</span>';
		$html .= '<span class="ffl-filters__count">' . esc_html( $this->format_count( $count ) ) . '</span>';
		$html .= '</label>';

		return $html;
	}

	/**
	 * Render min/max price boxes (no slider). The currency sits inside the box.
	 *
	 * @param string               $panel_id Panel prefix.
	 * @param array<string, mixed> $group    Group.
	 * @return string
	 */
	private function render_price( $panel_id, $group ) {
		$min_id    = $panel_id . '-min-price';
		$max_id    = $panel_id . '-max-price';
		$symbol    = isset( $group['symbol'] ) ? (string) $group['symbol'] : '';
		$min       = isset( $group['min'] ) && is_numeric( $group['min'] ) ? $this->format_price( $group['min'] ) : '';
		$max       = isset( $group['max'] ) && is_numeric( $group['max'] ) ? $this->format_price( $group['max'] ) : '';
		$bound_min = isset( $group['bound_min'] ) && is_numeric( $group['bound_min'] ) ? (string) (int) floor( (float) $group['bound_min'] ) : '';
		$bound_max = isset( $group['bound_max'] ) && is_numeric( $group['bound_max'] ) ? (string) (int) ceil( (float) $group['bound_max'] ) : '';

		$html  = '<div class="ffl-filters__price" data-fflf-range>';
		$html .= $this->range_field( $min_id, 'min_price', $min, $bound_min, __( 'Min price', 'ffl-filters' ), $symbol, 'pre' );
		$html .= '<span class="ffl-filters__price-sep" aria-hidden="true"></span>';
		$html .= $this->range_field( $max_id, 'max_price', $max, $bound_max, __( 'Max price', 'ffl-filters' ), $symbol, 'pre' );
		$html .= '</div>';

		return $html;
	}

	/**
	 * One min or max box with its unit inside.
	 *
	 * @param string $id          Input id.
	 * @param string $name        Input name.
	 * @param string $value       Current value.
	 * @param string $placeholder Placeholder (catalog bound).
	 * @param string $label       Screen-reader label.
	 * @param string $unit        Currency symbol or unit.
	 * @param string $side        'pre' or 'suf'.
	 * @return string
	 */
	private function range_field( $id, $name, $value, $placeholder, $label, $unit, $side ) {
		$class = 'ffl-filters__price-field';
		if ( '' !== $unit ) {
			$class .= ' ffl-filters__price-field--' . ( 'suf' === $side ? 'suffix' : 'prefix' );
		}
		$html  = '<label class="' . esc_attr( $class ) . '" for="' . esc_attr( $id ) . '">';
		$html .= '<span class="ffl-filters__visually-hidden">' . esc_html( $label ) . '</span>';
		if ( '' !== $unit ) {
			$html .= '<span class="ffl-filters__currency ffl-filters__unit ffl-filters__unit--' . esc_attr( 'suf' === $side ? 'suf' : 'pre' ) . '" aria-hidden="true">' . esc_html( $unit ) . '</span>';
		}
		$html .= '<input type="number" inputmode="decimal" step="any" name="' . esc_attr( $name ) . '" id="' . esc_attr( $id ) . '" value="' . esc_attr( $value ) . '"';
		if ( '' !== $placeholder ) {
			$html .= ' placeholder="' . esc_attr( $placeholder ) . '"';
		}
		$html .= ' data-fflf-range-input />';
		$html .= '</label>';
		return $html;
	}

	/**
	 * Render the in-stock switch.
	 *
	 * @param string               $panel_id Panel prefix.
	 * @param array<string, mixed> $group    Group.
	 * @return string
	 */
	private function render_instock( $panel_id, $group ) {
		$group['option_label'] = __( 'In Stock', 'ffl-filters' );
		return $this->render_toggle_option( $panel_id, $group, 'instock', __( 'In Stock', 'ffl-filters' ) );
	}

	/**
	 * Render the in-store switch.
	 *
	 * @param string               $panel_id Panel prefix.
	 * @param array<string, mixed> $group    Group.
	 * @return string
	 */
	private function render_instore( $panel_id, $group ) {
		return $this->render_toggle_option( $panel_id, $group, 'instore', __( 'In store', 'ffl-filters' ) );
	}

	/**
	 * Render a single named checkbox, styled as a switch, with a count.
	 *
	 * @param string               $panel_id Panel prefix.
	 * @param array<string, mixed> $group    Group.
	 * @param string               $name     Input name and value key.
	 * @param string               $fallback Fallback label.
	 * @return string
	 */
	private function render_toggle_option( $panel_id, $group, $name, $fallback ) {
		$input_id = $panel_id . '-' . $this->id_slug( $name );
		$count    = isset( $group['count'] ) ? (int) $group['count'] : 0;
		$selected = ! empty( $group['selected'] );
		$label    = isset( $group['label'] ) ? (string) $group['label'] : $fallback;
		if ( isset( $group['option_label'] ) ) {
			$label = (string) $group['option_label'];
		}

		$html  = '<label class="ffl-filters__option ffl-filters__option--toggle ffl-filters__option--switch" for="' . esc_attr( $input_id ) . '">';
		$html .= '<input type="checkbox" name="' . esc_attr( $name ) . '" value="1" id="' . esc_attr( $input_id ) . '"' . ( $selected ? ' checked' : '' ) . ' />';
		$html .= '<span class="ffl-filters__option-label">' . esc_html( $label ) . '</span>';
		$html .= '<span class="ffl-filters__count">' . esc_html( $this->format_count( $count ) ) . '</span>';
		$html .= '</label>';

		return $html;
	}

	/**
	 * Render a numeric min/max range (boxes only, unit inside the box).
	 *
	 * @param string               $panel_id Panel prefix.
	 * @param array<string, mixed> $group    Group.
	 * @return string
	 */
	private function render_numeric_range( $panel_id, $group ) {
		$slug      = $this->id_slug( isset( $group['id'] ) ? (string) $group['id'] : 'range' );
		$min_id    = $panel_id . '-' . $slug . '-min';
		$max_id    = $panel_id . '-' . $slug . '-max';
		$param_min = isset( $group['param_min'] ) ? (string) $group['param_min'] : '';
		$param_max = isset( $group['param_max'] ) ? (string) $group['param_max'] : '';
		$unit      = isset( $group['unit'] ) ? (string) $group['unit'] : '';
		$min       = isset( $group['min'] ) && is_numeric( $group['min'] ) ? $this->format_price( $group['min'] ) : '';
		$max       = isset( $group['max'] ) && is_numeric( $group['max'] ) ? $this->format_price( $group['max'] ) : '';
		$bound_min = isset( $group['bound_min'] ) && is_numeric( $group['bound_min'] ) ? $this->format_price( $group['bound_min'] ) : '';
		$bound_max = isset( $group['bound_max'] ) && is_numeric( $group['bound_max'] ) ? $this->format_price( $group['bound_max'] ) : '';

		$html  = '<div class="ffl-filters__price ffl-filters__range" data-fflf-range>';
		$html .= $this->range_field( $min_id, $param_min, $min, $bound_min, __( 'Min', 'ffl-filters' ), $unit, 'suf' );
		$html .= '<span class="ffl-filters__price-sep" aria-hidden="true"></span>';
		$html .= $this->range_field( $max_id, $param_max, $max, $bound_max, __( 'Max', 'ffl-filters' ), $unit, 'suf' );
		$html .= '</div>';

		return $html;
	}

	/**
	 * Live-region text for the result count.
	 *
	 * @param int $count Result count.
	 * @return string
	 */
	private function live_text( $count ) {
		if ( $count <= 0 ) {
			return __( 'No products match these filters. Remove one to see more.', 'ffl-filters' );
		}

		/* translators: %s: number of matching products */
		return sprintf( _n( '%s product', '%s products', $count, 'ffl-filters' ), $this->format_count( $count ) );
	}

	/**
	 * Which locked search copy a group uses: 'brand', 'caliber', or '' for the generic strings.
	 *
	 * @param array<string, mixed> $group Group.
	 * @return string
	 */
	private function search_kind( $group ) {
		$id    = isset( $group['id'] ) ? strtolower( (string) $group['id'] ) : '';
		$label = isset( $group['label'] ) ? strtolower( trim( (string) $group['label'] ) ) : '';
		if ( \FFL_Filters\Presets\Defaults::CALIBER_ID === $id || in_array( $label, array( 'caliber', 'calibers' ), true ) ) {
			return 'caliber';
		}
		if ( 'product_brand' === $id || in_array( $label, array( 'brand', 'brands' ), true ) ) {
			return 'brand';
		}
		return '';
	}

	/**
	 * Search field at the top of a long list.
	 *
	 * @param string               $panel_id Panel prefix.
	 * @param array<string, mixed> $group    Group.
	 * @return string
	 */
	private function render_search( $panel_id, $group ) {
		$search_id = $panel_id . '-' . $this->id_slug( (string) $group['id'] ) . '-search';
		$kind      = $this->search_kind( $group );
		if ( 'brand' === $kind ) {
			$search_label = __( 'Search brands', 'ffl-filters' );
			/* translators: 1: number of brands that match the search, 2: number of brands in the list */
			$count_format = __( '%1$s of %2$s brands', 'ffl-filters' );
		} elseif ( 'caliber' === $kind ) {
			$search_label = __( 'Search calibers', 'ffl-filters' );
			/* translators: 1: number of calibers that match the search, 2: number of calibers in the list */
			$count_format = __( '%1$s of %2$s calibers', 'ffl-filters' );
		} else {
			/* translators: %s: facet group label */
			$search_label = sprintf( __( 'Search %s', 'ffl-filters' ), isset( $group['label'] ) ? (string) $group['label'] : (string) $group['id'] );
			$count_format = '';
		}
		$html = '<div class="ffl-filters__search" data-fflf-search';
		if ( '' !== $count_format ) {
			$html .= ' data-fflf-count-format="' . esc_attr( $count_format ) . '"';
		}
		$html .= '>';
		$html .= '<label class="ffl-filters__visually-hidden" for="' . esc_attr( $search_id ) . '">' . esc_html( $search_label ) . '</label>';
		$html .= '<span class="ffl-filters__search-icon" aria-hidden="true"></span>';
		$html .= '<input type="search" class="ffl-filters__search-input" id="' . esc_attr( $search_id ) . '" placeholder="' . esc_attr( $search_label ) . '" data-fflf-search-input autocomplete="off" />';
		$html .= '<div class="ffl-filters__search-status" data-fflf-search-status aria-live="polite"></div>';
		$html .= '</div>';
		return $html;
	}

	/**
	 * Current-request Show all URL (keeps other query args).
	 *
	 * @param string $facet_id Facet id.
	 * @return string
	 */
	private function expand_url( $facet_id ) {
		if ( function_exists( 'add_query_arg' ) ) {
			return add_query_arg( 'fflf_expand', $facet_id );
		}

		return '?fflf_expand=' . rawurlencode( $facet_id );
	}

	/**
	 * Safe fragment for an element ID.
	 *
	 * @param string $value Raw value.
	 * @return string
	 */
	private function id_slug( $value ) {
		$slug = strtolower( (string) $value );
		$slug = preg_replace( '/[^a-z0-9\-]+/', '-', $slug );
		$slug = is_string( $slug ) ? trim( $slug, '-' ) : '';
		return '' === $slug ? 'item' : $slug;
	}

	/**
	 * Localized count.
	 *
	 * @param int $count Count.
	 * @return string
	 */
	private function format_count( $count ) {
		if ( function_exists( 'number_format_i18n' ) ) {
			return number_format_i18n( (int) $count );
		}
		return number_format( (int) $count );
	}

	/**
	 * Whole prices stay integers.
	 *
	 * @param mixed $price Price.
	 * @return string
	 */
	private function format_price( $price ) {
		if ( ! is_numeric( $price ) ) {
			return '';
		}
		$price = (float) $price;
		if ( floor( $price ) == $price ) { // phpcs:ignore Universal.Operators.StrictComparisons.LooseEqual
			return (string) (int) $price;
		}
		return (string) $price;
	}
}
