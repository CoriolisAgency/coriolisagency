<?php
/**
 * Detects a manually placed panel (shortcode or block).
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Panel;

defined( 'ABSPATH' ) || exit;

/**
 * Used to suppress auto-insert when the merchant already placed the panel.
 *
 * Kadence sidebars typically hold the shortcode in a text or block widget.
 * Block themes keep the panel block in a template or template part.
 */
class Placement {

	/**
	 * Block name.
	 *
	 * @var string
	 */
	const BLOCK = 'ffl-filters/panel';

	/**
	 * Primary shortcode.
	 *
	 * @var string
	 */
	const SHORTCODE = 'ffl_filters';

	/**
	 * CPF-compatible alias.
	 *
	 * @var string
	 */
	const ALIAS = 'coriolis_filters';

	/**
	 * Whether this request already has a manual panel placement.
	 *
	 * @return bool
	 */
	/**
	 * Memoized in_request() result for the current template snapshot.
	 *
	 * @var bool|null
	 */
	private static $request_cache = null;

	/**
	 * Template-content key that $request_cache was computed against.
	 *
	 * @var string|null
	 */
	private static $request_cache_key = null;

	/**
	 * Whether this request already has a manual panel placement.
	 *
	 * The result is memoized for a given block-template snapshot. Auto-render
	 * checks this while `_wp_current_template_content` is still empty and
	 * again after the template is loaded, so the cache key includes that
	 * string. A found placement is not kept once the template snapshot changes.
	 *
	 * @return bool
	 */
	public static function in_request() {
		$template = isset( $GLOBALS['_wp_current_template_content'] ) ? (string) $GLOBALS['_wp_current_template_content'] : '';
		$key      = (string) strlen( $template ) . ':' . md5( $template );

		if ( null !== self::$request_cache && self::$request_cache_key === $key ) {
			return self::$request_cache;
		}

		$found = self::in_post() || self::in_widgets() || self::in_block_template();

		self::$request_cache     = $found;
		self::$request_cache_key = $key;
		return $found;
	}

	/**
	 * Drop the memoized in_request() result (tests, or a new sub-request).
	 *
	 * @return void
	 */
	public static function reset() {
		self::$request_cache     = null;
		self::$request_cache_key = null;
	}

	/**
	 * Whether a string of post or template content contains the panel.
	 *
	 * @param string $content Content.
	 * @return bool
	 */
	public static function in_content( $content ) {
		if ( ! is_string( $content ) || '' === $content ) {
			return false;
		}

		if ( false !== strpos( $content, '[' . self::SHORTCODE ) || false !== strpos( $content, '[' . self::ALIAS ) ) {
			return true;
		}
		if ( false !== strpos( $content, 'wp:' . self::BLOCK ) ) {
			return true;
		}

		if ( function_exists( 'has_shortcode' ) ) {
			if ( has_shortcode( $content, self::SHORTCODE ) || has_shortcode( $content, self::ALIAS ) ) {
				return true;
			}
		}
		if ( function_exists( 'has_block' ) && has_block( self::BLOCK, $content ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Current post content.
	 *
	 * @return bool
	 */
	public static function in_post() {
		if ( ! function_exists( 'get_post' ) ) {
			return false;
		}

		// Use the queried archive object, not the loop post. get_post()
		// follows the shop loop and would scan every product's content
		// from render_block / should_auto_render.
		$post = null;
		if ( function_exists( 'get_queried_object' ) ) {
			$object = get_queried_object();
			if ( $object instanceof \WP_Post ) {
				$post = $object;
			}
		}

		if ( ! $post && function_exists( 'is_shop' ) && is_shop() && function_exists( 'wc_get_page_id' ) ) {
			$shop_id = (int) wc_get_page_id( 'shop' );
			if ( $shop_id > 0 ) {
				$post = get_post( $shop_id );
			}
		}

		if ( ! $post ) {
			return false;
		}
		return self::in_content( (string) $post->post_content );
	}

	/**
	 * Active sidebar widgets (Kadence and classic themes).
	 *
	 * @return bool
	 */
	public static function in_widgets() {
		if ( ! function_exists( 'get_option' ) ) {
			return false;
		}

		$sidebars = get_option( 'sidebars_widgets' );
		if ( ! is_array( $sidebars ) ) {
			return false;
		}

		foreach ( $sidebars as $sidebar => $widgets ) {
			if ( 'wp_inactive_widgets' === $sidebar || ! is_array( $widgets ) ) {
				continue;
			}
			if ( ! self::counts_sidebar( (string) $sidebar ) ) {
				continue;
			}
			foreach ( $widgets as $widget_id ) {
				if ( self::in_widget_id( (string) $widget_id ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Whether a widget area counts as a placement beside the products.
	 *
	 * Widget areas left over from another theme (no longer registered) and footer
	 * areas do not count: a panel there would leave the shop without filters.
	 *
	 * @param string $sidebar Widget area id.
	 * @return bool
	 */
	public static function counts_sidebar( $sidebar ) {
		global $wp_registered_sidebars;
		$counts = true;
		$name   = '';
		if ( is_array( $wp_registered_sidebars ) && ! empty( $wp_registered_sidebars ) ) {
			if ( ! isset( $wp_registered_sidebars[ $sidebar ] ) ) {
				$counts = false;
			} elseif ( isset( $wp_registered_sidebars[ $sidebar ]['name'] ) ) {
				$name = (string) $wp_registered_sidebars[ $sidebar ]['name'];
			}
		}
		if ( $counts && ( false !== stripos( $sidebar, 'footer' ) || false !== stripos( $name, 'footer' ) ) ) {
			$counts = false;
		}
		/**
		 * Filters whether a widget area counts as a manual panel placement.
		 *
		 * @since 1.1.0
		 * @param bool   $counts  Whether it counts.
		 * @param string $sidebar Widget area id.
		 */
		return function_exists( 'apply_filters' ) ? (bool) apply_filters( 'fflf_placement_counts_sidebar', $counts, $sidebar ) : $counts;
	}

	/**
	 * Current block template and any referenced template parts.
	 *
	 * @return bool
	 */
	public static function in_block_template() {
		$template = isset( $GLOBALS['_wp_current_template_content'] ) ? $GLOBALS['_wp_current_template_content'] : '';
		if ( is_string( $template ) && self::in_content( $template ) ) {
			return true;
		}
		if ( ! is_string( $template ) || '' === $template ) {
			return false;
		}

		if ( ! function_exists( 'get_block_template' ) ) {
			return false;
		}

		if ( ! preg_match_all( '/wp:template-part\s+(\{.*?\})/', $template, $matches ) ) {
			return false;
		}

		$theme = function_exists( 'get_stylesheet' ) ? get_stylesheet() : '';
		foreach ( $matches[1] as $json ) {
			$attrs = json_decode( $json, true );
			if ( ! is_array( $attrs ) ) {
				continue;
			}
			$slug       = isset( $attrs['slug'] ) ? (string) $attrs['slug'] : '';
			$part_theme = isset( $attrs['theme'] ) ? (string) $attrs['theme'] : $theme;
			if ( '' === $slug || '' === $part_theme ) {
				continue;
			}
			$part = get_block_template( $part_theme . '//' . $slug, 'wp_template_part' );
			if ( $part && self::in_content( (string) $part->content ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether one active widget instance contains the panel.
	 *
	 * @param string $widget_id Widget id (id_base-number).
	 * @return bool
	 */
	private static function in_widget_id( $widget_id ) {
		if ( ! preg_match( '/^(.+)-(\d+)$/', $widget_id, $matches ) ) {
			return false;
		}
		if ( ! function_exists( 'get_option' ) ) {
			return false;
		}

		$instances = get_option( 'widget_' . $matches[1] );
		if ( ! is_array( $instances ) ) {
			return false;
		}

		$number = (int) $matches[2];
		if ( ! isset( $instances[ $number ] ) ) {
			return false;
		}

		return self::in_value( $instances[ $number ] );
	}

	/**
	 * Recursively search a widget instance for the shortcode or block.
	 *
	 * @param mixed $value Value.
	 * @return bool
	 */
	private static function in_value( $value ) {
		if ( is_string( $value ) ) {
			return self::in_content( $value );
		}
		if ( is_array( $value ) ) {
			foreach ( $value as $item ) {
				if ( self::in_value( $item ) ) {
					return true;
				}
			}
		}
		return false;
	}
}
