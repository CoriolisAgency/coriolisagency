<?php
/**
 * Bounded slow-query log for the Health tab.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Health;

defined( 'ABSPATH' ) || exit;

/**
 * Records filtered catalog queries that exceed a duration threshold.
 *
 * Writes only when a request is slow, never on every front-end hit. The
 * option is not autoloaded and holds a fixed number of entries.
 */
class Slow_Log {

	/**
	 * Option name.
	 *
	 * @var string
	 */
	const OPTION = 'fflf_slow_queries';

	/**
	 * Default threshold in milliseconds.
	 *
	 * @var int
	 */
	const THRESHOLD_MS = 100;

	/**
	 * Maximum stored entries.
	 *
	 * @var int
	 */
	const MAX_ENTRIES = 25;

	/**
	 * Skip a write when the same path+query was logged this recently.
	 *
	 * @var int
	 */
	const DEBOUNCE_SECONDS = 60;

	/**
	 * Read stored entries, newest first.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function all() {
		if ( ! function_exists( 'get_option' ) ) {
			return array();
		}
		$stored = get_option( self::OPTION, array() );
		return is_array( $stored ) ? array_values( $stored ) : array();
	}

	/**
	 * Record a request when it meets the duration threshold.
	 *
	 * @param array<string, mixed> $entry Raw entry.
	 * @return bool Whether an entry was stored.
	 */
	public function maybe_record( $entry ) {
		$clean = $this->sanitize_entry( $entry );
		if ( ! $clean ) {
			return false;
		}
		if ( $clean['duration_ms'] < $this->threshold() ) {
			return false;
		}

		$entries = $this->all();
		$last    = isset( $entries[0] ) && is_array( $entries[0] ) ? $entries[0] : null;
		if ( $last && (string) ( $last['path'] ?? '' ) === $clean['path'] && ( $last['query'] ?? null ) === $clean['query'] && ( $clean['at'] - (int) ( $last['at'] ?? 0 ) ) < self::DEBOUNCE_SECONDS ) {
			return false;
		}
		array_unshift( $entries, $clean );
		$entries = array_slice( $entries, 0, self::MAX_ENTRIES );
		if ( function_exists( 'update_option' ) ) {
			update_option( self::OPTION, $entries, false );
		}
		return true;
	}

	/**
	 * Empty the log.
	 *
	 * @return void
	 */
	public function clear() {
		if ( function_exists( 'update_option' ) ) {
			update_option( self::OPTION, array(), false );
		}
	}

	/**
	 * Recording threshold in milliseconds.
	 *
	 * @return int
	 */
	public function threshold() {
		$threshold = self::THRESHOLD_MS;
		if ( function_exists( 'apply_filters' ) ) {
			/**
			 * Filter the Health-tab slow-query duration threshold in milliseconds.
			 *
			 * @since 0.0.1
			 * @param int $threshold Threshold in milliseconds.
			 */
			$threshold = (int) apply_filters( 'fflf_slow_query_threshold_ms', $threshold );
		}
		return $threshold > 0 ? $threshold : self::THRESHOLD_MS;
	}

	/**
	 * Sanitize a log row.
	 *
	 * @param mixed $entry Raw entry.
	 * @return array<string, mixed>|null
	 */
	private function sanitize_entry( $entry ) {
		if ( ! is_array( $entry ) ) {
			return null;
		}
		$path = isset( $entry['path'] ) ? (string) $entry['path'] : '';
		$path = function_exists( 'sanitize_text_field' ) ? sanitize_text_field( $path ) : $path;
		$path = strlen( $path ) > 200 ? substr( $path, 0, 200 ) : $path;

		$query = isset( $entry['query'] ) && is_array( $entry['query'] ) ? $entry['query'] : array();
		$safe  = array();
		foreach ( $query as $key => $value ) {
			$key = function_exists( 'sanitize_key' ) ? sanitize_key( (string) $key ) : (string) $key;
			if ( '' === $key ) {
				continue;
			}
			if ( is_array( $value ) ) {
				$items = array();
				foreach ( $value as $item ) {
					$items[] = is_scalar( $item ) ? substr( (string) $item, 0, 64 ) : '';
				}
				$safe[ $key ] = array_values( array_filter( $items ) );
			} elseif ( is_scalar( $value ) ) {
				$safe[ $key ] = substr( (string) $value, 0, 64 );
			}
			if ( count( $safe ) >= 20 ) {
				break;
			}
		}

		return array(
			'at'          => isset( $entry['at'] ) ? (int) $entry['at'] : time(),
			'duration_ms' => isset( $entry['duration_ms'] ) ? (int) round( (float) $entry['duration_ms'] ) : 0,
			'query_count' => isset( $entry['query_count'] ) ? (int) $entry['query_count'] : 0,
			'cache'       => isset( $entry['cache'] ) && in_array( $entry['cache'], array( 'hit', 'miss', 'bypass' ), true ) ? $entry['cache'] : 'bypass',
			'path'        => $path,
			'query'       => $safe,
		);
	}
}
