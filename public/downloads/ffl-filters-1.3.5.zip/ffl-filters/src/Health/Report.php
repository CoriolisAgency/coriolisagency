<?php
/**
 * Read-only Health snapshot: index status, cache generation, and environment.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Health;

use FFL_Filters\Cache\Generation;
use FFL_Filters\Cache\Store;

defined( 'ABSPATH' ) || exit;

/**
 * Collects dealer-facing health facts without writing on front-end requests.
 */
class Report {

	/**
	 * Build the snapshot.
	 *
	 * @return array<string, mixed>
	 */
	public function snapshot() {
		$generation = new Generation();
		$store      = new Store();
		$bumped     = $generation->last_bumped_at();

		return array(
			'index'          => $this->index_status(),
			'generation'     => $generation->current(),
			'bumped_at'      => $bumped,
			'bumped_at_text' => $bumped ? $this->format_time( $bumped ) : '',
			'object_cache'   => $store->has_object_cache(),
			'wp_engine'      => $this->is_wp_engine(),
		);
	}

	/**
	 * WooCommerce lookup-table status (FFL Filters has no custom index).
	 *
	 * @return array<string, mixed>
	 */
	public function index_status() {
		$attributes = $this->table_status( 'wc_product_attributes_lookup', true );
		$meta       = $this->table_status( 'wc_product_meta_lookup', false );
		$enabled    = true;
		if ( function_exists( 'get_option' ) ) {
			$raw     = get_option( 'woocommerce_attribute_lookup_enabled', 'yes' );
			$enabled = ( 'no' !== $raw && '0' !== (string) $raw && false !== $raw );
		}

		$status = 'ok';
		if ( ! $attributes['exists'] || ! $meta['exists'] ) {
			$status = 'missing';
		} elseif ( ! $enabled || $attributes['incomplete'] || $meta['incomplete'] ) {
			$status = 'incomplete';
		}

		return array(
			'status'     => $status,
			'enabled'    => $enabled,
			'attributes' => $attributes,
			'meta'       => $meta,
			'engine'     => 'woocommerce_lookup',
		);
	}

	/**
	 * Whether this request is running on WP Engine.
	 *
	 * @return bool
	 */
	public function is_wp_engine() {
		if ( function_exists( 'is_wpe' ) ) {
			return (bool) is_wpe();
		}
		return defined( 'WPE_APIKEY' ) || defined( 'WPE_CLUSTER_TYPE' ) || defined( 'WPE_GOVERNOR' );
	}

	/**
	 * Inspect one lookup table.
	 *
	 * @param string $suffix    Table name without the prefix.
	 * @param bool   $distinct  Whether to count distinct product_id values.
	 * @return array<string, mixed>
	 */
	private function table_status( $suffix, $distinct ) {
		global $wpdb;
		$out = array(
			'exists'     => false,
			'rows'       => 0,
			'products'   => 0,
			'published'  => $this->published_product_count(),
			'incomplete' => true,
		);
		if ( ! isset( $wpdb ) || ! is_object( $wpdb ) || empty( $wpdb->prefix ) ) {
			return $out;
		}

		$table = $wpdb->prefix . $suffix;
		if ( ! $this->table_exists( $table ) ) {
			return $out;
		}
		$out['exists'] = true;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows        = $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
		$out['rows'] = (int) $rows;

		if ( $distinct ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$products        = $wpdb->get_var( "SELECT COUNT(DISTINCT product_id) FROM {$table}" );
			$out['products'] = (int) $products;
		} else {
			$out['products'] = $out['rows'];
		}

		$published         = $out['published'];
		$out['incomplete'] = $published > 0 && $out['products'] < $published;
		return $out;
	}

	/**
	 * Whether a table exists.
	 *
	 * @param string $table Prefixed table name.
	 * @return bool
	 */
	private function table_exists( $table ) {
		global $wpdb;
		if ( ! isset( $wpdb ) || ! is_object( $wpdb ) ) {
			return false;
		}
		$like = str_replace( array( '_', '%' ), array( '\\_', '\\%' ), $table );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $like ) );
		return is_string( $found ) && $found === $table;
	}

	/**
	 * Published product count, or 0 when Woo / posts are unavailable.
	 *
	 * @return int
	 */
	private function published_product_count() {
		if ( function_exists( 'wp_count_posts' ) ) {
			$counts = wp_count_posts( 'product' );
			if ( is_object( $counts ) && isset( $counts->publish ) ) {
				return (int) $counts->publish;
			}
		}
		return 0;
	}

	/**
	 * Format a unix timestamp in the site timezone.
	 *
	 * @param int $timestamp Timestamp.
	 * @return string
	 */
	private function format_time( $timestamp ) {
		if ( function_exists( 'wp_date' ) ) {
			$formatted = wp_date( 'Y-m-d H:i:s T', (int) $timestamp );
			return is_string( $formatted ) ? $formatted : '';
		}
		return (string) (int) $timestamp;
	}
}
