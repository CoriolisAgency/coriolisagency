<?php
/**
 * "Why isn't product X showing" lookup for the Health tab.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Health;

use FFL_Filters\Settings\Repository;

defined( 'ABSPATH' ) || exit;

/**
 * Explains why a catalog product might be missing from a filtered view.
 */
class Why {

	/**
	 * Settings repository.
	 *
	 * @var Repository
	 */
	private $repository;

	/**
	 * Constructor.
	 *
	 * @param Repository|null $repository Settings.
	 */
	public function __construct( $repository = null ) {
		$this->repository = $repository ? $repository : new Repository();
	}

	/**
	 * Inspect a product by ID, SKU, or name.
	 *
	 * @param string $needle Search string.
	 * @param array  $source Optional current request (filter params).
	 * @return array<string, mixed>
	 */
	public function inspect( $needle, $source = array() ) {
		$needle = is_string( $needle ) ? trim( $needle ) : '';
		if ( '' === $needle ) {
			return array(
				'ok'      => false,
				'error'   => 'empty',
				'product' => null,
				'checks'  => array(),
			);
		}

		$product = $this->find_product( $needle );
		if ( ! $product ) {
			return array(
				'ok'      => false,
				'error'   => 'not_found',
				'product' => null,
				'checks'  => array(),
			);
		}

		$source = is_array( $source ) ? $source : array();
		$checks = $this->evaluate( $product, $source );

		$failed = 0;
		foreach ( $checks as $check ) {
			if ( empty( $check['ok'] ) ) {
				++$failed;
			}
		}

		return array(
			'ok'      => 0 === $failed,
			'error'   => '',
			'product' => $product,
			'checks'  => $checks,
			'failed'  => $failed,
		);
	}

	/**
	 * Run the checks against a normalized product row.
	 *
	 * @param array<string, mixed> $product Product.
	 * @param array<string, mixed> $source  Request.
	 * @return array<int, array{code: string, ok: bool, message: string}>
	 */
	public function evaluate( $product, $source = array() ) {
		$checks   = array();
		$status   = isset( $product['status'] ) ? (string) $product['status'] : '';
		$checks[] = $this->check(
			'published',
			'publish' === $status,
			'publish' === $status
				? __( 'The product is published.', 'ffl-filters' )
				: sprintf(
					/* translators: %s: post status */
					__( 'The product is not published (status: %s), so it will not appear in the catalog.', 'ffl-filters' ),
					$status ? $status : __( 'unknown', 'ffl-filters' )
				)
		);

		$type     = isset( $product['type'] ) ? (string) $product['type'] : 'product';
		$checks[] = $this->check(
			'type',
			in_array( $type, array( 'product', 'simple', 'variable', 'variation', 'external', 'grouped' ), true ),
			__( 'The record is a product.', 'ffl-filters' )
		);

		$visibility = isset( $product['catalog_visibility'] ) ? (string) $product['catalog_visibility'] : 'visible';
		$visible    = ! in_array( $visibility, array( 'hidden', 'search' ), true );
		$checks[]   = $this->check(
			'visibility',
			$visible,
			$visible
				? __( 'Catalog visibility allows this product in the shop.', 'ffl-filters' )
				: __( 'Catalog visibility is hidden or search-only, so the product is excluded from the shop catalog.', 'ffl-filters' )
		);

		$stock     = isset( $product['stock_status'] ) ? (string) $product['stock_status'] : 'instock';
		$in_stock  = ( 'outofstock' !== $stock );
		$instock_q = $this->request_has( $source, 'instock' );
		$hide_oos  = ! empty( $product['hide_out_of_stock'] );
		$stock_ok  = $in_stock || ( ! $instock_q && ! $hide_oos );
		$checks[]  = $this->check(
			'stock',
			$stock_ok,
			$stock_ok
				? __( 'Stock status does not exclude this product from the current view.', 'ffl-filters' )
				: __( 'The product is out of stock, and the current view only includes in-stock products.', 'ffl-filters' )
		);

		$lookup = ! empty( $product['in_attributes_lookup'] );
		if ( array_key_exists( 'in_attributes_lookup', $product ) ) {
			$checks[] = $this->check(
				'attributes_lookup',
				$lookup,
				$lookup
					? __( 'The product is present in the WooCommerce attributes lookup table.', 'ffl-filters' )
					: __( 'The product is missing from the WooCommerce attributes lookup table. Regenerating the lookup table usually fixes this.', 'ffl-filters' )
			);
		}

		$settings = $this->repository->all();
		$terms    = isset( $product['terms'] ) && is_array( $product['terms'] ) ? $product['terms'] : array();

		$disabled = array();
		$hidden   = array();
		if ( isset( $settings['facets'] ) && is_array( $settings['facets'] ) ) {
			foreach ( $settings['facets'] as $id => $facet ) {
				if ( ! is_array( $facet ) ) {
					continue;
				}
				if ( isset( $terms[ $id ] ) && empty( $facet['enabled'] ) ) {
					$disabled[] = $id;
				}
				$denied = isset( $facet['hidden_terms'] ) && is_array( $facet['hidden_terms'] ) ? $facet['hidden_terms'] : array();
				if ( isset( $terms[ $id ] ) && is_array( $terms[ $id ] ) ) {
					$match = array_values( array_intersect( $terms[ $id ], $denied ) );
					if ( $match ) {
						$hidden[] = $id . ':' . implode( ',', $match );
					}
				}
			}
		}

		$checks[] = $this->check(
			'hidden_facet',
			array() === $disabled,
			array() === $disabled
				? __( 'No assigned facets are disabled for this product.', 'ffl-filters' )
				: sprintf(
					/* translators: %s: taxonomy ids */
					__( 'This product uses facets that are disabled in FFL Filters settings: %s.', 'ffl-filters' ),
					implode( ', ', $disabled )
				)
		);

		$checks[] = $this->check(
			'hidden_term',
			array() === $hidden,
			array() === $hidden
				? __( 'None of this product\'s terms are hidden in FFL Filters settings.', 'ffl-filters' )
				: sprintf(
					/* translators: %s: taxonomy:term list */
					__( 'This product has terms hidden in FFL Filters settings: %s.', 'ffl-filters' ),
					implode( ', ', $hidden )
				)
		);

		$cat_ok   = $this->category_allowed( $settings, isset( $terms['product_cat'] ) ? $terms['product_cat'] : array() );
		$checks[] = $this->check(
			'category_mode',
			$cat_ok,
			$cat_ok
				? __( 'The product\'s categories are allowed by the category facet mode.', 'ffl-filters' )
				: __( 'The product\'s categories are excluded by the category allow or hide list.', 'ffl-filters' )
		);

		$instore_q = $this->request_has( $source, 'instore' );
		$has_tag   = ! empty( $product['instore'] );
		if ( $instore_q ) {
			$checks[] = $this->check(
				'instore',
				$has_tag,
				$has_tag
					? __( 'The product has the In store tag required by the current view.', 'ffl-filters' )
					: __( 'The current view is limited to In store products, and this product does not have that tag.', 'ffl-filters' )
			);
		}

		return $checks;
	}

	/**
	 * Whether a category list is allowed by settings.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @param array<int, string>   $slugs    Product category slugs.
	 * @return bool
	 */
	private function category_allowed( $settings, $slugs ) {
		$facet = isset( $settings['facets']['product_cat'] ) && is_array( $settings['facets']['product_cat'] ) ? $settings['facets']['product_cat'] : array();
		$mode  = isset( $facet['mode'] ) ? (string) $facet['mode'] : 'all';
		$list  = isset( $facet['slugs'] ) && is_array( $facet['slugs'] ) ? $facet['slugs'] : array();
		if ( 'all' === $mode || array() === $list ) {
			return true;
		}
		$overlap = array_intersect( $slugs, $list );
		if ( 'allow' === $mode ) {
			return array() !== $overlap;
		}
		if ( 'hide' === $mode ) {
			return array() === $overlap;
		}
		return true;
	}

	/**
	 * Locate a product by ID, SKU, or title.
	 *
	 * @param string $needle Search.
	 * @return array<string, mixed>|null
	 */
	private function find_product( $needle ) {
		$post = null;
		if ( ctype_digit( $needle ) && function_exists( 'get_post' ) ) {
			$found = get_post( (int) $needle );
			if ( $found && 'product' === $found->post_type ) {
				$post = $found;
			}
		}

		if ( ! $post && function_exists( 'wc_get_product_id_by_sku' ) ) {
			$id = wc_get_product_id_by_sku( $needle );
			if ( $id && function_exists( 'get_post' ) ) {
				$found = get_post( (int) $id );
				if ( $found ) {
					$post = $found;
				}
			}
		}

		if ( ! $post && function_exists( 'get_posts' ) ) {
			$found = get_posts(
				array(
					'post_type'      => 'product',
					'title'          => $needle,
					'post_status'    => 'any',
					'posts_per_page' => 1,
					'no_found_rows'  => true,
				)
			);
			if ( is_array( $found ) && isset( $found[0] ) ) {
				$post = $found[0];
			}
		}

		if ( ! $post ) {
			return null;
		}

		return $this->normalize_post( $post );
	}

	/**
	 * Normalize a WP_Post (and Woo product, when present) into a row.
	 *
	 * @param \WP_Post $post Post.
	 * @return array<string, mixed>
	 */
	private function normalize_post( $post ) {
		$row = array(
			'id'                   => (int) $post->ID,
			'title'                => (string) $post->post_title,
			'status'               => (string) $post->post_status,
			'type'                 => 'product',
			'catalog_visibility'   => 'visible',
			'stock_status'         => 'instock',
			'hide_out_of_stock'    => function_exists( 'get_option' ) && 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ),
			'in_attributes_lookup' => $this->in_lookup( (int) $post->ID ),
			'terms'                => $this->term_map( (int) $post->ID ),
			'instore'              => false,
			'sku'                  => '',
		);

		if ( function_exists( 'wc_get_product' ) ) {
			$product = wc_get_product( $post->ID );
			if ( $product ) {
				$row['type']               = (string) $product->get_type();
				$row['catalog_visibility'] = (string) $product->get_catalog_visibility();
				$row['stock_status']       = (string) $product->get_stock_status();
				$row['sku']                = (string) $product->get_sku();
			}
		}

		if ( isset( $row['terms']['product_tag'] ) && is_array( $row['terms']['product_tag'] ) ) {
			$row['instore'] = in_array( 'in-store', $row['terms']['product_tag'], true );
		}

		return $row;
	}

	/**
	 * Whether the product appears in the attributes lookup table.
	 *
	 * @param int $product_id Product ID.
	 * @return bool|null Null when the table cannot be queried.
	 */
	private function in_lookup( $product_id ) {
		global $wpdb;
		if ( ! isset( $wpdb ) || ! is_object( $wpdb ) || empty( $wpdb->prefix ) ) {
			return null;
		}
		$table = $wpdb->prefix . 'wc_product_attributes_lookup';
		$like  = str_replace( array( '_', '%' ), array( '\\_', '\\%' ), $table );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $like ) );
		if ( ! is_string( $found ) || $found !== $table ) {
			return null;
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$count = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE product_id = %d", $product_id ) );
		return (int) $count > 0;
	}

	/**
	 * Term slugs for the product, keyed by taxonomy.
	 *
	 * @param int $product_id Product ID.
	 * @return array<string, array<int, string>>
	 */
	private function term_map( $product_id ) {
		$map = array();
		if ( ! function_exists( 'wp_get_object_terms' ) || ! function_exists( 'get_object_taxonomies' ) ) {
			return $map;
		}
		$taxes = get_object_taxonomies( 'product' );
		if ( ! is_array( $taxes ) ) {
			return $map;
		}
		foreach ( $taxes as $tax ) {
			$terms = wp_get_object_terms( $product_id, $tax, array( 'fields' => 'slugs' ) );
			if ( is_wp_error( $terms ) || ! is_array( $terms ) ) {
				continue;
			}
			$map[ $tax ] = array_values( $terms );
		}
		return $map;
	}

	/**
	 * Whether a request flag is present and truthy.
	 *
	 * @param array  $source Request.
	 * @param string $key    Key.
	 * @return bool
	 */
	private function request_has( $source, $key ) {
		if ( ! isset( $source[ $key ] ) ) {
			return false;
		}
		$value = $source[ $key ];
		if ( is_bool( $value ) ) {
			return $value;
		}
		return ! in_array( (string) $value, array( '', '0', 'false', 'off' ), true );
	}

	/**
	 * Build a check row.
	 *
	 * @param string $code    Code.
	 * @param bool   $ok      Whether it passed.
	 * @param string $message Message.
	 * @return array{code: string, ok: bool, message: string}
	 */
	private function check( $code, $ok, $message ) {
		return array(
			'code'    => $code,
			'ok'      => (bool) $ok,
			'message' => $message,
		);
	}
}
