<?php
/**
 * Build posts_clauses fragments for a parsed filter request.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Query;

defined( 'ABSPATH' ) || exit;

/**
 * JOIN / EXISTS (IN-subquery) clauses against the Woo lookup tables.
 *
 * Never emits a literal product-ID list, never creates a temporary table,
 * and never reads wp_postmeta for price or attributes. In stock reads the
 * product's own _stock_status, because wc_product_meta_lookup.stock_status
 * goes stale when a sync or import writes postmeta directly.
 */
class Clause_Builder {

	/**
	 * Term resolver.
	 *
	 * @var Term_Resolver
	 */
	private $resolver;

	/**
	 * Constructor.
	 *
	 * @param Term_Resolver|null $resolver Term resolver.
	 */
	public function __construct( $resolver = null ) {
		$this->resolver = $resolver ? $resolver : new Term_Resolver();
	}

	/**
	 * Apply filter clauses to a posts_clauses array.
	 *
	 * @param array          $clauses Query clauses (join, where, ...).
	 * @param Parsed_Request $request Parsed request.
	 * @return array
	 */
	public function apply( $clauses, Parsed_Request $request ) {
		if ( ! $request->has_filters() ) {
			return $clauses;
		}

		$groups = $request->groups();
		unset( $groups[ \FFL_Filters\Presets\Defaults::CALIBER_ID ] );
		$physical = $request->with( array( 'groups' => $groups ) );
		$term_ids = $this->resolver->resolve( $physical );

		$attribute_groups = array();
		$taxonomy_groups  = array();

		foreach ( $groups as $taxonomy => $slugs ) {
			$ids   = isset( $term_ids[ $taxonomy ] ) ? $term_ids[ $taxonomy ] : array();
			$group = array(
				'taxonomy' => $taxonomy,
				'term_ids' => $ids,
			);
			if ( $this->uses_attributes_lookup( $taxonomy ) ) {
				$attribute_groups[] = $group;
			} else {
				$taxonomy_groups[] = $group;
			}
		}

		foreach ( $request->ranges() as $taxonomy => $range ) {
			$ids   = $this->term_ids_for_range( $taxonomy, $range );
			$group = array(
				'taxonomy' => $taxonomy,
				'term_ids' => $ids,
			);
			if ( $this->uses_attributes_lookup( $taxonomy ) ) {
				$attribute_groups[] = $group;
			} else {
				$taxonomy_groups[] = $group;
			}
		}

		// A requested group whose slugs did not resolve must match nothing.
		foreach ( array_merge( $attribute_groups, $taxonomy_groups ) as $group ) {
			if ( empty( $group['term_ids'] ) ) {
				$clauses['where'] .= ' AND 1=0 ';
				return $clauses;
			}
		}

		$caliber_union = $this->caliber_union_groups( $request );
		if ( is_array( $caliber_union ) ) {
			if ( array() === $caliber_union ) {
				$clauses['where'] .= ' AND 1=0 ';
				return $clauses;
			}
			$clauses['where'] .= $this->attribute_union_where( $caliber_union, $request->instock() && empty( $attribute_groups ) );
		}

		if ( $request->instore() ) {
			$instore = $this->instore_group();
			if ( empty( $instore['term_ids'] ) ) {
				$clauses['where'] .= ' AND 1=0 ';
				return $clauses;
			}
			$clauses['where'] .= $this->term_relationship_where( $instore );
		}

		if ( ! empty( $attribute_groups ) ) {
			$clauses['where'] .= $this->attribute_where( $attribute_groups, $request->instock() );
		}

		if ( $request->instock() ) {
			$clauses['where'] .= $this->instock_where();
		}

		foreach ( $taxonomy_groups as $group ) {
			$clauses['where'] .= $this->term_relationship_where( $group );
		}

		$needs_meta = ( null !== $request->min_price() || null !== $request->max_price() );

		if ( $needs_meta ) {
			$clauses['join']   = $this->join_meta_lookup( isset( $clauses['join'] ) ? $clauses['join'] : '', true );
			$clauses['where'] .= $this->meta_lookup_where( $request );
			// The meta lookup join is 1:1 on product_id, so GROUP BY only adds a filesort.
			$clauses['groupby'] = '';
		}

		return $clauses;
	}

	/**
	 * Product-attribute taxonomies go through wc_product_attributes_lookup.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @return bool
	 */
	private function uses_attributes_lookup( $taxonomy ) {
		if ( 0 === strpos( $taxonomy, 'pa_' ) ) {
			return true;
		}
		if ( function_exists( 'taxonomy_is_product_attribute' ) ) {
			return (bool) taxonomy_is_product_attribute( $taxonomy );
		}
		return false;
	}

	/**
	 * AND-across-groups, OR-within-group subquery on the attributes lookup.
	 *
	 * Variable products share a variation (same product_id) when both groups
	 * are variation attributes; product-level attributes combine with either.
	 *
	 * @param array<int, array{taxonomy: string, term_ids: array<int, int>}> $groups  Attribute groups.
	 * @param bool                                                           $instock Whether to honour variation stock.
	 * @return string
	 */
	private function attribute_where( $groups, $instock ) {
		global $wpdb;

		$lookup  = $wpdb->prefix . 'wc_product_attributes_lookup';
		$aliases = array();
		$joins   = array();
		$wheres  = array();
		$params  = array();
		$from    = '';

		foreach ( $groups as $i => $group ) {
			$alias     = 'fflf_al' . (int) $i;
			$aliases[] = $alias;

			if ( 0 === $i ) {
				$from = " FROM {$lookup} {$alias} ";
			} else {
				$anchor  = $aliases[0];
				$joins[] = " INNER JOIN {$lookup} {$alias} ON {$alias}.product_or_parent_id = {$anchor}.product_or_parent_id AND ( {$alias}.product_id = {$anchor}.product_id OR {$alias}.is_variation_attribute = 0 OR {$anchor}.is_variation_attribute = 0 ) ";
			}

			$placeholders = implode( ',', array_fill( 0, count( $group['term_ids'] ), '%d' ) );
			$wheres[]     = "{$alias}.taxonomy = %s AND {$alias}.term_id IN ({$placeholders})";
			$params[]     = $group['taxonomy'];
			foreach ( $group['term_ids'] as $term_id ) {
				$params[] = (int) $term_id;
			}

			if ( $instock ) {
				if ( 1 === count( $groups ) ) {
					$wheres[] = "{$alias}.in_stock = 1";
				} else {
					$wheres[] = "( {$alias}.in_stock = 1 OR {$alias}.is_variation_attribute = 0 )";
				}
			}
		}

		$anchor = $aliases[0];
		$sql    = "SELECT {$anchor}.product_or_parent_id {$from} " . implode( ' ', $joins ) . ' WHERE ' . implode( ' AND ', $wheres );

		// phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber,WordPress.DB.PreparedSQL.NotPrepared
		$prepared = $wpdb->prepare( $sql, $params );

		return " AND {$wpdb->posts}.ID IN ( {$prepared} ) ";
	}

	/**
	 * Taxonomy filter for categories, brands, tags, etc.
	 *
	 * @param array{taxonomy: string, term_ids: array<int, int>} $group Group.
	 * @return string
	 */
	private function term_relationship_where( $group ) {
		global $wpdb;

		if ( $this->pinned_tags_and() && 'product_tag' === $group['taxonomy'] && count( $group['term_ids'] ) > 1 ) {
			$sql = '';
			foreach ( $group['term_ids'] as $term_id ) {
				$sql .= $this->term_relationship_where(
					array(
						'taxonomy' => 'product_tag',
						'term_ids' => array( (int) $term_id ),
					)
				);
			}
			return $sql;
		}

		$placeholders = implode( ',', array_fill( 0, count( $group['term_ids'] ), '%d' ) );
		$params       = array_merge( array( $group['taxonomy'] ), array_map( 'intval', $group['term_ids'] ) );

		// Placeholders are built from the capped term-ID list.
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
		$sub = $wpdb->prepare(
			"SELECT tr.object_id
			FROM {$wpdb->term_relationships} tr
			INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
			WHERE tt.taxonomy = %s AND tt.term_id IN ({$placeholders})",
			$params
		);
		// phpcs:enable

		return " AND {$wpdb->posts}.ID IN ( {$sub} ) ";
	}

	/**
	 * Join wc_product_meta_lookup if Woo has not already joined it.
	 *
	 * @param string $join  Existing join clause.
	 * @param bool   $inner Use INNER JOIN when stock or price is required.
	 * @return string
	 */
	private function join_meta_lookup( $join, $inner = false ) {
		global $wpdb;

		if ( false !== strpos( $join, 'wc_product_meta_lookup' ) ) {
			return $join;
		}

		$table = $wpdb->prefix . 'wc_product_meta_lookup';
		$type  = $inner ? 'INNER' : 'LEFT';
		return $join . " {$type} JOIN {$table} wc_product_meta_lookup ON {$wpdb->posts}.ID = wc_product_meta_lookup.product_id ";
	}

	/**
	 * Price range on meta_lookup.
	 *
	 * @param Parsed_Request $request Parsed request.
	 * @return string
	 */
	private function meta_lookup_where( Parsed_Request $request ) {
		global $wpdb;

		$sql = '';
		$min = $request->min_price();
		$max = $request->max_price();

		if ( null !== $min || null !== $max ) {
			$min_bound = null !== $min ? $min : 0.0;
			$max_bound = null !== $max ? $max : 1.0e18;
			$sql      .= $wpdb->prepare(
				' AND NOT ( %f < wc_product_meta_lookup.min_price OR %f > wc_product_meta_lookup.max_price ) ',
				$max_bound,
				$min_bound
			);
		}

		return $sql;
	}

	/**
	 * In stock, from the source the storefront itself uses.
	 *
	 * WC_Product::is_in_stock() reads _stock_status postmeta (it is what turns
	 * Add to cart into Read more), so any product whose _stock_status is set
	 * to something other than instock is excluded. The exclusion form keeps
	 * the subquery to the smaller out-of-stock set. When Woo hides out-of-stock
	 * items, its
	 * archive query also drops products carrying the product_visibility
	 * outofstock term, so that exclusion applies here too. The main query and
	 * every count share this clause, so the In stock count equals the results.
	 *
	 * @return string
	 */
	private function instock_where() {
		global $wpdb;

		$sql = $wpdb->prepare(
			" AND {$wpdb->posts}.ID NOT IN ( SELECT fflf_ss.post_id FROM {$wpdb->postmeta} fflf_ss WHERE fflf_ss.meta_key = %s AND fflf_ss.meta_value <> %s ) ",
			'_stock_status',
			'instock'
		);

		if ( 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) ) {
			$term = get_term_by( 'slug', 'outofstock', 'product_visibility' );
			if ( $term instanceof \WP_Term ) {
				$sql .= $wpdb->prepare(
					" AND {$wpdb->posts}.ID NOT IN ( SELECT fflf_vis.object_id FROM {$wpdb->term_relationships} fflf_vis WHERE fflf_vis.term_taxonomy_id = %d ) ",
					(int) $term->term_taxonomy_id
				);
			}
		}

		return $sql;
	}

	/**
	 * Whether pinned tags use AND matching.
	 *
	 * @return bool
	 */
	/**
	 * Term IDs whose parsed values overlap a selected numeric range.
	 *
	 * @param string                                  $taxonomy Taxonomy.
	 * @param array{min: float|null, max: float|null} $range    Selected range.
	 * @return array<int, int>
	 */
	private function term_ids_for_range( $taxonomy, $range ) {
		$numeric = ( new \FFL_Filters\Presets\Config() )->numeric();
		$min     = isset( $range['min'] ) ? $range['min'] : null;
		$max     = isset( $range['max'] ) ? $range['max'] : null;
		$ids     = array();

		if ( ! function_exists( 'get_terms' ) ) {
			return $ids;
		}

		$terms = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
				'number'     => 250,
			)
		);
		if ( is_wp_error( $terms ) || ! is_array( $terms ) ) {
			return $ids;
		}

		foreach ( $terms as $term ) {
			$interval = $numeric->interval( $taxonomy, (string) $term->slug, (string) $term->name );
			if ( $interval && $numeric->overlaps( $interval, $min, $max ) ) {
				$ids[] = (int) $term->term_id;
			}
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Attribute lookup groups that should OR together for the merged caliber facet.
	 *
	 * @param Parsed_Request $request Request.
	 * @return array<int, array{taxonomy: string, term_ids: array<int, int>}>|null
	 */
	private function caliber_union_groups( Parsed_Request $request ) {
		$groups = $request->groups();
		if ( ! isset( $groups[ \FFL_Filters\Presets\Defaults::CALIBER_ID ] ) ) {
			return null;
		}

		$config   = new \FFL_Filters\Presets\Config();
		$synonyms = $config->synonyms();
		$slugs    = $groups[ \FFL_Filters\Presets\Defaults::CALIBER_ID ];
		$lookups  = array();
		foreach ( $slugs as $slug ) {
			foreach ( $synonyms->lookup_slugs( (string) $slug ) as $member ) {
				$lookups[] = $member;
			}
		}
		$lookups = array_values( array_unique( $lookups ) );
		$union   = array();

		foreach ( $config->caliber_taxonomies() as $taxonomy ) {
			$expanded = $request->with(
				array(
					'groups' => array(
						$taxonomy => $lookups,
					),
				)
			);
			$resolved = $this->resolver->resolve( $expanded );
			$ids      = isset( $resolved[ $taxonomy ] ) ? $resolved[ $taxonomy ] : array();
			if ( $ids ) {
				$union[] = array(
					'taxonomy' => $taxonomy,
					'term_ids' => $ids,
				);
			}
		}

		return $union;
	}

	/**
	 * OR across attribute taxonomies (one logical facet, two backing attributes).
	 *
	 * @param array<int, array{taxonomy: string, term_ids: array<int, int>}> $groups  Union groups.
	 * @param bool                                                           $instock Also require in-stock variations.
	 * @return string
	 */
	private function attribute_union_where( $groups, $instock ) {
		global $wpdb;

		$lookup = $wpdb->prefix . 'wc_product_attributes_lookup';
		$wheres = array();
		$params = array();
		foreach ( $groups as $group ) {
			if ( empty( $group['term_ids'] ) ) {
				continue;
			}
			$placeholders = implode( ',', array_fill( 0, count( $group['term_ids'] ), '%d' ) );
			$wheres[]     = "( lookup.taxonomy = %s AND lookup.term_id IN ({$placeholders}) )";
			$params[]     = $group['taxonomy'];
			foreach ( $group['term_ids'] as $term_id ) {
				$params[] = (int) $term_id;
			}
		}
		if ( ! $wheres ) {
			return ' AND 1=0 ';
		}

		$stock = '';
		if ( $instock ) {
			$stock = ' AND ( lookup.in_stock = 1 OR lookup.is_variation_attribute = 0 )';
		}

		// Placeholders are built from capped term-ID lists; values are passed to prepare().
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$sub = $wpdb->prepare(
			"SELECT lookup.product_or_parent_id FROM {$lookup} lookup WHERE (" . implode( ' OR ', $wheres ) . "){$stock}",
			$params
		);
		// phpcs:enable

		return " AND {$wpdb->posts}.ID IN ( {$sub} ) ";
	}

	/**
	 * In-store tag group.
	 *
	 * @return array{taxonomy: string, term_ids: array<int, int>}
	 */
	private function instore_group() {
		$config   = new \FFL_Filters\Presets\Config();
		$taxonomy = $config->instore_taxonomy();
		$slug     = $config->instore_slug();
		$ids      = array();
		$term     = function_exists( 'get_term_by' ) ? get_term_by( 'slug', $slug, $taxonomy ) : null;
		if ( $term && ! is_wp_error( $term ) ) {
			$ids[] = (int) $term->term_id;
		}
		return array(
			'taxonomy' => $taxonomy,
			'term_ids' => $ids,
		);
	}

	/**
	 * Whether pinned tags use AND matching.
	 *
	 * @return bool
	 */
	private function pinned_tags_and() {
		if ( ! class_exists( '\FFL_Filters\Settings\Repository' ) ) {
			return false;
		}
		$settings = ( new \FFL_Filters\Settings\Repository() )->all();
		$pin      = isset( $settings['pinned'] ) && is_array( $settings['pinned'] ) ? $settings['pinned'] : array();
		return ! empty( $pin['enabled'] ) && isset( $pin['match'] ) && 'and' === $pin['match'];
	}
}
