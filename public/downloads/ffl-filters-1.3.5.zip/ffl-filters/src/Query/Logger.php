<?php
/**
 * Query-engine logger.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Query;

defined( 'ABSPATH' ) || exit;

/**
 * Writes cap-drop and parse notices to the Woo / PHP error log.
 */
class Logger {

	/**
	 * Log a warning. Never throws.
	 *
	 * @param string $message Message.
	 * @return void
	 */
	public static function warning( $message ) {
		$message = is_string( $message ) ? $message : '';
		if ( '' === $message ) {
			return;
		}

		if ( function_exists( 'wc_get_logger' ) ) {
			try {
				wc_get_logger()->warning( $message, array( 'source' => 'ffl-filters' ) );
				return;
			} catch ( \Exception $e ) {
				unset( $e );
			}
		}

		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		error_log( 'fflf: ' . $message );
	}
}
