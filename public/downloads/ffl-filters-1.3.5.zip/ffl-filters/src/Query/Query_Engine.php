<?php
/**
 * Hook the filter query engine into the main shop and archive query.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Query;

use FFL_Filters\Cache\Fingerprint;
use FFL_Filters\Cache\Repository;
use FFL_Filters\Health\Slow_Log;
use FFL_Filters\Panel\Scope;

defined( 'ABSPATH' ) || exit;

/**
 * Applies parsed filter params through posts_clauses on the main product query.
 */
class Query_Engine {

	/**
	 * Parser.
	 *
	 * @var Request_Parser
	 */
	private $parser;

	/**
	 * Clause builder.
	 *
	 * @var Clause_Builder
	 */
	private $builder;

	/**
	 * Cache repository (found-posts).
	 *
	 * @var Repository
	 */
	private $repository;

	/**
	 * Request parsed for the current main query, if any.
	 *
	 * @var Parsed_Request|null
	 */
	private $parsed = null;

	/**
	 * Timer start for a filtered main query.
	 *
	 * @var float
	 */
	private $timed_at = 0.0;

	/**
	 * $wpdb->num_queries at timer start.
	 *
	 * @var int
	 */
	private $timed_query_count = 0;

	/**
	 * COUNT() SQL for the current filtered query, when SQL_CALC_FOUND_ROWS is skipped.
	 *
	 * @var string
	 */
	private $count_sql = '';

	/**
	 * Constructor.
	 *
	 * @param Request_Parser|null $parser     Parser.
	 * @param Clause_Builder|null $builder    Clause builder.
	 * @param Repository|null     $repository Cache repository.
	 */
	public function __construct( $parser = null, $builder = null, $repository = null ) {
		$this->parser     = $parser ? $parser : new Request_Parser();
		$this->builder    = $builder ? $builder : new Clause_Builder();
		$this->repository = $repository ? $repository : new Repository();
	}

	/**
	 * Register hooks. No-ops when a compare plugin (CPF) is already active.
	 *
	 * @return void
	 */
	public function register() {
		if ( $this->compare_plugin_is_active() ) {
			return;
		}

		add_action( 'pre_get_posts', array( $this, 'prime' ), 9 );
		add_filter( 'posts_clauses', array( $this, 'filter_posts_clauses' ), 20, 2 );
		add_filter( 'posts_request', array( $this, 'skip_sql_calc_found_rows' ), 20, 2 );
		add_filter( 'found_posts', array( $this, 'filtered_found_posts' ), 20, 2 );
		add_filter( 'posts_results', array( $this, 'record_slow_query' ), 20, 2 );
		add_filter( 'woocommerce_enable_post_clause_filtering', array( $this, 'disable_woo_clause_filtering' ), 5, 2 );
		add_filter( 'woocommerce_product_query_tax_query', array( $this, 'strip_woo_attribute_tax_queries' ) );
	}

	/**
	 * Parse the request once for the main query.
	 *
	 * @param \WP_Query $query Query.
	 * @return void
	 */
	public function prime( $query ) {
		if ( ! $this->is_main_product_query( $query ) ) {
			return;
		}

		$source       = wp_unslash( $_GET ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$this->parsed = $this->parser->parse( $source );
	}

	/**
	 * Add lookup-table clauses to the main shop / archive query.
	 *
	 * @param array     $clauses Clauses.
	 * @param \WP_Query $query   Query.
	 * @return array
	 */
	public function filter_posts_clauses( $clauses, $query ) {
		if ( ! $this->is_main_product_query( $query ) ) {
			return $clauses;
		}

		if ( ! $this->parsed instanceof Parsed_Request ) {
			$source       = wp_unslash( $_GET ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$this->parsed = $this->parser->parse( $source );
		}

		if ( ! $this->parsed->has_filters() ) {
			// Still rewrite default orderby so an unfiltered shop avoids a title filesort.
			return $this->apply_lookup_orderby( $clauses, $query );
		}

		global $wpdb;
		$this->timed_at          = microtime( true );
		$this->timed_query_count = ( isset( $wpdb ) && is_object( $wpdb ) && isset( $wpdb->num_queries ) ) ? (int) $wpdb->num_queries : 0;

		$clauses         = $this->builder->apply( $clauses, $this->parsed );
		$clauses         = $this->apply_lookup_orderby( $clauses, $query );
		$this->count_sql = $this->build_count_sql( $clauses );
		return $clauses;
	}

	/**
	 * Drop SQL_CALC_FOUND_ROWS on filtered catalog queries; found_posts uses a cheaper COUNT.
	 *
	 * @param string    $sql   Request SQL.
	 * @param \WP_Query $query Query.
	 * @return string
	 */
	public function skip_sql_calc_found_rows( $sql, $query ) {
		if ( '' === $this->count_sql || ! $this->is_main_product_query( $query ) ) {
			return $sql;
		}
		return (string) preg_replace( '/SQL_CALC_FOUND_ROWS\s+/i', '', (string) $sql, 1 );
	}

	/**
	 * Replace SQL_CALC_FOUND_ROWS with a COUNT of matching product IDs.
	 *
	 * @param int       $found Found posts.
	 * @param \WP_Query $query Query.
	 * @return int
	 */
	public function filtered_found_posts( $found, $query ) {
		if ( '' === $this->count_sql || ! $this->is_main_product_query( $query ) ) {
			return (int) $found;
		}
		global $wpdb;
		if ( ! isset( $wpdb ) || ! is_object( $wpdb ) ) {
			return (int) $found;
		}
		$sql             = $this->count_sql;
		$this->count_sql = '';
		$scope           = $this->found_scope( $query );
		$fingerprint     = Fingerprint::for_found( $scope, $this->parsed );

		$count = $this->repository->remember_found(
			$fingerprint,
			static function () use ( $sql ) {
				global $wpdb;
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
				return (int) $wpdb->get_var( $sql );
			}
		);

		return (int) $count;
	}

	/**
	 * Prefer an indexed lookup-table order when the meta lookup is already joined.
	 *
	 * Default shop merchandising (menu_order + title) filesorts the whole
	 * matching set. When "Honor the page order" is on (the default) the
	 * catalog's own order is kept. When it is off and there is no explicit
	 * `orderby` request, order by the lookup primary key instead. Explicit
	 * title, date, and menu_order are honoured. Price, popularity, and rating
	 * also use lookup columns.
	 *
	 * @param array     $clauses Clauses.
	 * @param \WP_Query $query   Query.
	 * @return array
	 */
	public function apply_lookup_orderby( $clauses, $query ) {
		$requested = $this->requested_orderby( $query );
		if ( in_array( $requested, array( 'date', 'title', 'menu_order', 'rand', 'relevance', 'modified' ), true ) ) {
			return $clauses;
		}
		if ( '' === $requested && $this->honor_page_order() ) {
			return $clauses;
		}

		$clauses = $this->ensure_meta_lookup_join( $clauses );
		$join    = isset( $clauses['join'] ) ? (string) $clauses['join'] : '';
		if ( false === strpos( $join, 'wc_product_meta_lookup' ) ) {
			return $clauses;
		}

		$order = 'ASC';
		if ( $query instanceof \WP_Query ) {
			$qorder = strtoupper( (string) $query->get( 'order' ) );
			if ( in_array( $qorder, array( 'ASC', 'DESC' ), true ) ) {
				$order = $qorder;
			}
		}

		if ( 'price' === $requested ) {
			$clauses['orderby'] = 'wc_product_meta_lookup.min_price ' . $order . ', wc_product_meta_lookup.product_id ' . $order;
			return $clauses;
		}
		if ( 'popularity' === $requested ) {
			$clauses['orderby'] = 'wc_product_meta_lookup.total_sales DESC, wc_product_meta_lookup.product_id DESC';
			return $clauses;
		}
		if ( 'rating' === $requested ) {
			$clauses['orderby'] = 'wc_product_meta_lookup.average_rating DESC, wc_product_meta_lookup.product_id DESC';
			return $clauses;
		}
		// Default catalog: lookup PK, no title filesort.
		$clauses['orderby'] = 'wc_product_meta_lookup.product_id ASC';
		return $clauses;
	}

	/**
	 * Whether the Display setting "Honor the page order" is on.
	 *
	 * @return bool
	 */
	private function honor_page_order() {
		$settings = ( new \FFL_Filters\Settings\Repository() )->all();
		return ! isset( $settings['sort']['honor_page_order'] ) || ! empty( $settings['sort']['honor_page_order'] );
	}

	/**
	 * Left-join the Woo product meta lookup when a rewrite needs its columns.
	 *
	 * @param array $clauses Clauses.
	 * @return array
	 */
	private function ensure_meta_lookup_join( $clauses ) {
		$join = isset( $clauses['join'] ) ? (string) $clauses['join'] : '';
		if ( false !== strpos( $join, 'wc_product_meta_lookup' ) ) {
			return $clauses;
		}

		global $wpdb;
		if ( ! isset( $wpdb ) || ! is_object( $wpdb ) ) {
			return $clauses;
		}

		$posts           = $wpdb->posts;
		$lookup          = $wpdb->prefix . 'wc_product_meta_lookup';
		$clauses['join'] = $join . ' LEFT JOIN ' . $lookup . ' wc_product_meta_lookup ON wc_product_meta_lookup.product_id = ' . $posts . '.ID';

		return $clauses;
	}

	/**
	 * Customer or Woo orderby key for this request.
	 *
	 * @param \WP_Query $query Query.
	 * @return string
	 */
	private function requested_orderby( $query ) {
		if ( isset( $_GET['orderby'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$raw = wp_unslash( $_GET['orderby'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			if ( is_string( $raw ) && '' !== $raw ) {
				$key = sanitize_title( $raw );
				if ( 'price-desc' === $key ) {
					return 'price';
				}
				return $key;
			}
		}

		if ( ! $query instanceof \WP_Query ) {
			return '';
		}

		$raw = $query->get( 'orderby' );
		if ( is_array( $raw ) ) {
			$raw = implode( ' ', array_keys( $raw ) );
		}
		$key = strtolower( trim( (string) $raw ) );
		if ( in_array( $key, array( '', 'menu_order title', 'menu_order', 'menu_order title date' ), true ) ) {
			return '';
		}
		if ( false !== strpos( $key, 'price' ) ) {
			return 'price';
		}
		if ( false !== strpos( $key, 'popularity' ) || false !== strpos( $key, 'total_sales' ) ) {
			return 'popularity';
		}
		if ( false !== strpos( $key, 'rating' ) ) {
			return 'rating';
		}
		if ( false !== strpos( $key, 'date' ) ) {
			return 'date';
		}
		if ( false !== strpos( $key, 'title' ) ) {
			return 'title';
		}
		if ( false !== strpos( $key, 'menu_order' ) ) {
			return 'menu_order';
		}
		return $key;
	}

	/**
	 * Archive scope for the found-posts cache key.
	 *
	 * @param \WP_Query $query Query.
	 * @return string
	 */
	private function found_scope( $query ) {
		unset( $query );
		return ( new Scope() )->id();
	}

	/**
	 * Build a COUNT query from the same join/where as the catalog query, without ORDER BY.
	 *
	 * @param array<string, string> $clauses Clauses.
	 * @return string
	 */
	private function build_count_sql( $clauses ) {
		global $wpdb;
		if ( ! isset( $wpdb ) || ! is_object( $wpdb ) ) {
			return '';
		}
		$join  = isset( $clauses['join'] ) ? $clauses['join'] : '';
		$where = isset( $clauses['where'] ) ? $clauses['where'] : '';
		return "SELECT COUNT(*) FROM {$wpdb->posts} {$join} WHERE 1=1 {$where}";
	}

	/**
	 * Record a slow filtered catalog query after it runs.
	 *
	 * @param array     $posts Posts.
	 * @param \WP_Query $query Query.
	 * @return array
	 */
	public function record_slow_query( $posts, $query ) {
		if ( $this->timed_at <= 0 ) {
			return $posts;
		}
		if ( ! $this->is_main_product_query( $query ) ) {
			return $posts;
		}

		$duration       = ( microtime( true ) - $this->timed_at ) * 1000;
		$this->timed_at = 0.0;

		global $wpdb;
		$query_count = 0;
		if ( isset( $wpdb ) && is_object( $wpdb ) && isset( $wpdb->num_queries ) ) {
			$query_count = (int) $wpdb->num_queries - $this->timed_query_count;
		}

		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$path = function_exists( 'wp_parse_url' ) ? wp_parse_url( $uri, PHP_URL_PATH ) : '';
		$path = is_string( $path ) ? $path : '';

		( new Slow_Log() )->maybe_record(
			array(
				'at'          => time(),
				'duration_ms' => $duration,
				'query_count' => $query_count,
				'cache'       => 'bypass',
				'path'        => $path,
				'query'       => $this->filter_query_for_log(),
			)
		);

		return $posts;
	}

	/**
	 * Compact filter params for the slow-query log.
	 *
	 * @return array<string, mixed>
	 */
	private function filter_query_for_log() {
		$out = array();
		if ( ! $this->parsed instanceof Parsed_Request ) {
			return $out;
		}
		if ( $this->parsed->instock() ) {
			$out['instock'] = '1';
		}
		if ( $this->parsed->instore() ) {
			$out['instore'] = '1';
		}
		if ( null !== $this->parsed->min_price() ) {
			$out['min_price'] = $this->parsed->min_price();
		}
		if ( null !== $this->parsed->max_price() ) {
			$out['max_price'] = $this->parsed->max_price();
		}
		foreach ( $this->parsed->groups() as $taxonomy => $terms ) {
			$out[ (string) $taxonomy ] = $terms;
		}
		return $out;
	}

	/**
	 * Let this engine own filter_* / min_price / max_price on the main product query
	 * so Woo does not also apply them with a different (AND-within-group) default.
	 *
	 * @param bool      $enable Whether Woo should add its filter clauses.
	 * @param \WP_Query $query  Query.
	 * @return bool
	 */
	public function disable_woo_clause_filtering( $enable, $query ) {
		if ( $this->is_main_product_query( $query ) && $this->current_request_has_filters() ) {
			return false;
		}
		return (bool) $enable;
	}

	/**
	 * Remove Woo layered-nav tax queries for taxonomies this engine already handles.
	 *
	 * @param array $tax_query Tax query.
	 * @return array
	 */
	public function strip_woo_attribute_tax_queries( $tax_query ) {
		if ( ! is_array( $tax_query ) || ! $this->current_request_has_filters() ) {
			return $tax_query;
		}

		$ours = $this->parsed instanceof Parsed_Request ? array_keys( $this->parsed->groups() ) : array();

		$filtered = array();
		foreach ( $tax_query as $key => $item ) {
			if ( ! is_array( $item ) ) {
				$filtered[ $key ] = $item;
				continue;
			}
			$taxonomy = isset( $item['taxonomy'] ) ? (string) $item['taxonomy'] : '';
			if ( '' !== $taxonomy && ( in_array( $taxonomy, $ours, true ) || 0 === strpos( $taxonomy, 'pa_' ) ) ) {
				continue;
			}
			$filtered[ $key ] = $item;
		}

		return $filtered;
	}

	/**
	 * Main shop or product-taxonomy archive query only.
	 *
	 * @param mixed $query Query.
	 * @return bool
	 */
	private function is_main_product_query( $query ) {
		if ( ! $query instanceof \WP_Query ) {
			return false;
		}
		if ( is_admin() && ! $this->is_wp_unit_test() ) {
			return false;
		}
		if ( ! $query->is_main_query() ) {
			return false;
		}

		if ( 'product_query' === $query->get( 'wc_query' ) ) {
			return true;
		}

		$post_types = $query->get( 'post_type' );
		if ( empty( $post_types ) && ( $query->is_post_type_archive( 'product' ) || $this->is_shop_or_product_taxonomy() ) ) {
			return true;
		}

		foreach ( (array) $post_types as $post_type ) {
			if ( 'product' === $post_type ) {
				return true;
			}
		}

		return $this->is_shop_or_product_taxonomy();
	}

	/**
	 * Whether the current main request is a shop or product taxonomy archive.
	 *
	 * @return bool
	 */
	private function is_shop_or_product_taxonomy() {
		if ( function_exists( 'is_shop' ) && is_shop() ) {
			return true;
		}
		if ( function_exists( 'is_product_taxonomy' ) && is_product_taxonomy() ) {
			return true;
		}
		if ( function_exists( 'is_post_type_archive' ) && is_post_type_archive( 'product' ) ) {
			return true;
		}
		return false;
	}

	/**
	 * Whether the current request is a WP unit-test run.
	 *
	 * @return bool
	 */
	private function is_wp_unit_test() {
		return ( defined( 'WP_TESTS_DOMAIN' ) && WP_TESTS_DOMAIN ) || defined( 'WP_RUNNING_TESTS' );
	}

	/**
	 * Whether the current request has any recognized filters.
	 *
	 * @return bool
	 */
	private function current_request_has_filters() {
		if ( $this->parsed instanceof Parsed_Request ) {
			return $this->parsed->has_filters();
		}

		return fflf_request_has_filters();
	}

	/**
	 * Passive while Coriolis Product Filters is active (coexistence guard).
	 *
	 * @return bool
	 */
	private function compare_plugin_is_active() {
		if ( function_exists( 'fflf_is_passive' ) ) {
			return fflf_is_passive();
		}
		return function_exists( 'fflf_compare_plugin_is_active' ) && fflf_compare_plugin_is_active();
	}
}
