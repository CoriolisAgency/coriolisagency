<?php
/**
 * Parse and validate CPF-compatible filter request parameters.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Query;

defined( 'ABSPATH' ) || exit;

/**
 * Reads filter_*, min_price, max_price and instock from a request array.
 *
 * This class only parses and validates, silently dropping anything over
 * the clause caps. URL normalization and 301s live in FFL_Filters\Url.
 */
class Request_Parser {

	/**
	 * Request keys that map to a non-attribute taxonomy.
	 *
	 * @var array<string, string>
	 */
	const SPECIAL_TAXONOMIES = array(
		'filter_brand'    => 'product_brand',
		'filter_category' => 'product_cat',
		'filter_tag'      => 'product_tag',
		'filter_pa_tag'   => 'pa_tag',
		'filter_caliber'  => 'caliber',
	);

	/**
	 * Parse a request array (typically $_GET).
	 *
	 * @param array $source Request parameters.
	 * @return Parsed_Request
	 */
	public function parse( $source ) {
		if ( ! is_array( $source ) ) {
			$source = array();
		}

		$dropped = array();
		$groups  = $this->parse_filter_groups( $source, $dropped );
		$prices  = $this->parse_prices( $source, $dropped );
		$instock = $this->parse_instock( $source, $dropped );
		$instore = $this->parse_toggle( $source, 'instore', $dropped );
		$ranges  = $this->parse_ranges( $source, $dropped );

		if ( $this->ignore_price() ) {
			$prices = array(
				'min' => null,
				'max' => null,
			);
		}

		if ( ! $this->config()->instore_enabled() ) {
			$instore = false;
		}

		foreach ( $dropped as $notice ) {
			Logger::warning( $notice );
		}

		return new Parsed_Request( $groups, $prices['min'], $prices['max'], $instock, $dropped, $instore, $ranges );
	}

	/**
	 * Extract filter_* groups, applying caps.
	 *
	 * @param array              $source  Request.
	 * @param array<int, string> $dropped Drop notices, passed by reference.
	 * @return array<string, array<int, string>>
	 */
	private function parse_filter_groups( $source, &$dropped ) {
		$max_groups = Caps::max_groups();
		$groups     = array();

		foreach ( $source as $key => $value ) {
			if ( ! is_string( $key ) || 0 !== strpos( $key, 'filter_' ) ) {
				continue;
			}

			$taxonomy = $this->taxonomy_for_param( $key );
			if ( '' === $taxonomy ) {
				$dropped[] = 'Dropped filter param with an empty taxonomy name: ' . $key;
				continue;
			}

			$slugs = $this->normalize_slugs( $value, $taxonomy, $dropped );
			if ( empty( $slugs ) ) {
				continue;
			}

			if ( isset( $groups[ $taxonomy ] ) ) {
				$groups[ $taxonomy ] = $this->cap_slugs( array_values( array_unique( array_merge( $groups[ $taxonomy ], $slugs ) ) ), $taxonomy, $dropped );
				continue;
			}

			if ( count( $groups ) >= $max_groups ) {
				$dropped[] = sprintf( 'Dropped filter group "%s" over the cap of %d groups.', $taxonomy, $max_groups );
				continue;
			}

			$groups[ $taxonomy ] = $slugs;
		}

		return $groups;
	}

	/**
	 * Map a filter_* request key to a taxonomy.
	 *
	 * @param string $key Request key.
	 * @return string
	 */
	private function taxonomy_for_param( $key ) {
		if ( isset( self::SPECIAL_TAXONOMIES[ $key ] ) ) {
			return self::SPECIAL_TAXONOMIES[ $key ];
		}

		$attribute = substr( $key, strlen( 'filter_' ) );
		// filter_pa_<attr> is an alias of filter_<attr>, except specials like filter_pa_tag.
		if ( 0 === strpos( $attribute, 'pa_' ) ) {
			$attribute = substr( $attribute, 3 );
		}
		$attribute = $this->sanitize_taxonomy_name( $attribute );
		if ( '' === $attribute ) {
			return '';
		}

		return 'pa_' . $attribute;
	}

	/**
	 * Sanitize an attribute / taxonomy fragment.
	 *
	 * @param string $name Raw name.
	 * @return string
	 */
	private function sanitize_taxonomy_name( $name ) {
		$name = strtolower( (string) $name );
		$name = str_replace( array( ' ', '_' ), '-', $name );
		$name = preg_replace( '/[^a-z0-9\-]/', '', $name );
		return is_string( $name ) ? $name : '';
	}

	/**
	 * Accept arrays, comma-separated strings, or a single slug. Drop nested values.
	 *
	 * @param mixed              $value   Raw request value.
	 * @param string             $taxonomy Taxonomy for log messages.
	 * @param array<int, string> $dropped Drop notices, passed by reference.
	 * @return array<int, string>
	 */
	private function normalize_slugs( $value, $taxonomy, &$dropped ) {
		$raw = array();

		if ( is_array( $value ) ) {
			foreach ( $value as $item ) {
				if ( is_array( $item ) ) {
					$dropped[] = sprintf( 'Dropped a nested value on filter group "%s".', $taxonomy );
					continue;
				}
				if ( is_bool( $item ) || is_object( $item ) ) {
					$dropped[] = sprintf( 'Dropped a non-scalar value on filter group "%s".', $taxonomy );
					continue;
				}
				$raw[] = (string) $item;
			}
		} elseif ( is_bool( $value ) || is_object( $value ) ) {
			$dropped[] = sprintf( 'Dropped a non-scalar value on filter group "%s".', $taxonomy );
		} elseif ( is_string( $value ) || is_numeric( $value ) ) {
			$raw = explode( ',', (string) $value );
		} else {
			$dropped[] = sprintf( 'Dropped an invalid value on filter group "%s".', $taxonomy );
		}

		$slugs = array();
		foreach ( $raw as $item ) {
			$slug = $this->sanitize_slug( $item );
			if ( '' === $slug ) {
				continue;
			}
			$slugs[] = $slug;
		}

		return $this->cap_slugs( array_values( array_unique( $slugs ) ), $taxonomy, $dropped );
	}

	/**
	 * Sanitize a single slug and drop it when it exceeds the length cap.
	 *
	 * @param string $value Raw slug.
	 * @return string
	 */
	private function sanitize_slug( $value ) {
		$value = trim( (string) $value );
		if ( '' === $value ) {
			return '';
		}

		if ( function_exists( 'sanitize_title' ) ) {
			$value = sanitize_title( $value );
		} else {
			$value = strtolower( $value );
			$value = preg_replace( '/[^a-z0-9\-_]/', '', str_replace( ' ', '-', $value ) );
			$value = is_string( $value ) ? $value : '';
		}

		return $value;
	}

	/**
	 * Apply the per-group value cap, logging overflow slugs as dropped.
	 *
	 * @param array<int, string> $slugs    Unique slugs.
	 * @param string             $taxonomy Taxonomy.
	 * @param array<int, string> $dropped  Drop notices, passed by reference.
	 * @return array<int, string>
	 */
	private function cap_slugs( $slugs, $taxonomy, &$dropped ) {
		$max = Caps::max_values_per_group();
		if ( $max <= 0 ) {
			if ( ! empty( $slugs ) ) {
				$dropped[] = sprintf( 'Dropped all %d values on filter group "%s" over the cap of %d values.', count( $slugs ), $taxonomy, $max );
			}
			return array();
		}

		// Length cap is also applied here so over-long slugs are logged (sanitize_slug already emptied them).
		$kept = array();
		foreach ( $slugs as $slug ) {
			if ( strlen( $slug ) > Caps::max_slug_length() ) {
				$dropped[] = sprintf( 'Dropped slug "%s" on filter group "%s" over the cap of %d characters.', $this->clip( $slug ), $taxonomy, Caps::max_slug_length() );
				continue;
			}
			$kept[] = $slug;
		}

		if ( count( $kept ) > $max ) {
			$overflow  = array_slice( $kept, $max );
			$kept      = array_slice( $kept, 0, $max );
			$dropped[] = sprintf(
				'Dropped %d value(s) on filter group "%s" over the cap of %d values: %s.',
				count( $overflow ),
				$taxonomy,
				$max,
				implode( ', ', array_map( array( $this, 'clip' ), $overflow ) )
			);
		}

		return $kept;
	}

	/**
	 * Parse min_price / max_price, dropping non-numeric values.
	 *
	 * @param array              $source  Request.
	 * @param array<int, string> $dropped Drop notices, passed by reference.
	 * @return array{min: float|null, max: float|null}
	 */
	private function parse_prices( $source, &$dropped ) {
		$min = $this->parse_price_value( isset( $source['min_price'] ) ? $source['min_price'] : null, 'min_price', $dropped );
		$max = $this->parse_price_value( isset( $source['max_price'] ) ? $source['max_price'] : null, 'max_price', $dropped );

		if ( null !== $min && null !== $max && $min > $max ) {
			$tmp       = $min;
			$min       = $max;
			$max       = $tmp;
			$dropped[] = 'Swapped min_price and max_price because min was greater than max.';
		}

		return array(
			'min' => $min,
			'max' => $max,
		);
	}

	/**
	 * Parse a single price parameter.
	 *
	 * @param mixed              $value   Raw value.
	 * @param string             $name    Param name.
	 * @param array<int, string> $dropped Drop notices, passed by reference.
	 * @return float|null
	 */
	private function parse_price_value( $value, $name, &$dropped ) {
		if ( null === $value || '' === $value ) {
			return null;
		}
		if ( is_array( $value ) ) {
			$dropped[] = sprintf( 'Dropped non-scalar %s.', $name );
			return null;
		}
		if ( is_bool( $value ) || is_object( $value ) ) {
			$dropped[] = sprintf( 'Dropped invalid %s.', $name );
			return null;
		}

		$raw = trim( (string) $value );
		if ( '' === $raw || ! is_numeric( $raw ) ) {
			$dropped[] = sprintf( 'Dropped non-numeric %s.', $name );
			return null;
		}

		$number = (float) $raw;
		if ( $number < 0 ) {
			$dropped[] = sprintf( 'Dropped negative %s.', $name );
			return null;
		}

		return $number;
	}

	/**
	 * Accept 1, true, yes, on. Other values (including 0) are not an instock filter.
	 *
	 * @param array              $source  Request.
	 * @param array<int, string> $dropped Drop notices, passed by reference.
	 * @return bool
	 */
	private function parse_instock( $source, &$dropped ) {
		if ( ! array_key_exists( 'instock', $source ) ) {
			return false;
		}

		$value = $source['instock'];
		if ( is_array( $value ) || is_object( $value ) ) {
			$dropped[] = 'Dropped invalid instock value.';
			return false;
		}

		if ( is_bool( $value ) ) {
			return $value;
		}

		$normalized = strtolower( trim( (string) $value ) );
		return in_array( $normalized, array( '1', 'true', 'yes', 'on' ), true );
	}

	/**
	 * Shorten a slug for a log line.
	 *
	 * @param string $slug Slug.
	 * @return string
	 */
	private function clip( $slug ) {
		if ( strlen( $slug ) <= 64 ) {
			return $slug;
		}
		return substr( $slug, 0, 61 ) . '...';
	}

	/**
	 * Whether the price facet is hidden, so min/max in the request are ignored.
	 *
	 * @return bool
	 */
	/**
	 * Parse a 1/true/yes/on toggle param.
	 *
	 * @param array              $source  Request.
	 * @param string             $key     Param name.
	 * @param array<int, string> $dropped Drop notices, passed by reference.
	 * @return bool
	 */
	private function parse_toggle( $source, $key, &$dropped ) {
		if ( ! array_key_exists( $key, $source ) ) {
			return false;
		}
		$value = $source[ $key ];
		if ( is_array( $value ) || is_object( $value ) ) {
			$dropped[] = sprintf( 'Dropped invalid %s value.', $key );
			return false;
		}
		if ( is_bool( $value ) ) {
			return $value;
		}
		$normalized = strtolower( trim( (string) $value ) );
		if ( in_array( $normalized, array( '1', 'true', 'yes', 'on' ), true ) ) {
			return true;
		}
		if ( '' !== $normalized ) {
			$dropped[] = sprintf( 'Dropped invalid %s value.', $key );
		}
		return false;
	}

	/**
	 * Parse min_/max_ numeric range params.
	 *
	 * @param array              $source  Request.
	 * @param array<int, string> $dropped Drop notices, passed by reference.
	 * @return array<string, array{min: float|null, max: float|null}>
	 */
	private function parse_ranges( $source, &$dropped ) {
		$numeric = $this->config()->numeric();
		$raw     = array();
		foreach ( $source as $key => $value ) {
			if ( ! is_string( $key ) || ! $numeric->is_range_param( $key ) ) {
				continue;
			}
			$taxonomy = $numeric->taxonomy_for_param( $key );
			if ( '' === $taxonomy ) {
				continue;
			}
			if ( is_array( $value ) || is_object( $value ) ) {
				$dropped[] = 'Dropped invalid range value for ' . $key . '.';
				continue;
			}
			if ( ! is_numeric( $value ) ) {
				if ( '' !== trim( (string) $value ) ) {
					$dropped[] = 'Dropped non-numeric range value for ' . $key . '.';
				}
				continue;
			}
			if ( ! isset( $raw[ $taxonomy ] ) ) {
				$raw[ $taxonomy ] = array(
					'min' => null,
					'max' => null,
				);
			}
			$field                      = 0 === strpos( $key, 'min_' ) ? 'min' : 'max';
			$raw[ $taxonomy ][ $field ] = (float) $value;
		}

		$out = array();
		foreach ( $raw as $taxonomy => $range ) {
			$min = $range['min'];
			$max = $range['max'];
			if ( null !== $min && null !== $max && $min > $max ) {
				$dropped[] = 'Swapped range bounds for ' . $taxonomy . ' because min was greater than max.';
				$tmp       = $min;
				$min       = $max;
				$max       = $tmp;
			}
			$out[ $taxonomy ] = array(
				'min' => $min,
				'max' => $max,
			);
		}
		return $out;
	}

	/**
	 * Firearm preset configuration.
	 *
	 * @return \FFL_Filters\Presets\Config
	 */
	private function config() {
		return new \FFL_Filters\Presets\Config();
	}

	/**
	 * Whether the price facet is hidden, so min/max in the request are ignored.
	 *
	 * @return bool
	 */
	private function ignore_price() {
		if ( ! class_exists( '\FFL_Filters\Settings\Applicator' ) ) {
			return false;
		}
		return ( new \FFL_Filters\Settings\Applicator() )->ignore_price();
	}
}
