<?php
/**
 * Resolve filter slugs to term IDs.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Query;

use FFL_Filters\Cache\Fingerprint;
use FFL_Filters\Cache\Repository;

defined( 'ABSPATH' ) || exit;

/**
 * One bounded lookup of term IDs for every slug in a parsed request.
 */
class Term_Resolver {

	/**
	 * Optional generation-key cache.
	 *
	 * @var Repository|null
	 */
	private $repository;

	/**
	 * Constructor.
	 *
	 * @param Repository|null $repository Generation-key cache, if any.
	 */
	public function __construct( $repository = null ) {
		$this->repository = $repository instanceof Repository ? $repository : null;
	}

	/**
	 * Map taxonomy => term IDs for the slugs in a parsed request.
	 *
	 * A group that had slugs but resolves to no term IDs is returned as an
	 * empty list so the clause builder can constrain the query to zero rows.
	 *
	 * @param Parsed_Request $request Parsed request.
	 * @return array<string, array<int, int>>
	 */
	public function resolve( Parsed_Request $request ) {
		$groups = $request->groups();
		if ( empty( $groups ) ) {
			return array();
		}

		if ( ! $this->repository instanceof Repository ) {
			return $this->lookup( $request );
		}

		$fingerprint = Fingerprint::for_terms( $request );
		return $this->repository->remember_terms(
			$fingerprint,
			function () use ( $request ) {
				return $this->lookup( $request );
			}
		);
	}

	/**
	 * Uncached slug-to-term lookup, including descendants of hierarchical terms.
	 *
	 * @param Parsed_Request $request Parsed request.
	 * @return array<string, array<int, int>>
	 */
	private function lookup( Parsed_Request $request ) {
		$groups = $request->groups();

		global $wpdb;

		$taxonomies = array_keys( $groups );
		$slugs      = array();
		foreach ( $groups as $group_slugs ) {
			foreach ( $group_slugs as $slug ) {
				$slugs[] = $slug;
			}
		}
		$slugs = array_values( array_unique( $slugs ) );

		$tax_placeholders  = implode( ',', array_fill( 0, count( $taxonomies ), '%s' ) );
		$slug_placeholders = implode( ',', array_fill( 0, count( $slugs ), '%s' ) );
		$params            = array_merge( $taxonomies, $slugs );

		// Placeholders are built from counts; values are passed to prepare().
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare,WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
		$sql = $wpdb->prepare(
			"SELECT t.slug, tt.taxonomy, t.term_id
			FROM {$wpdb->terms} AS t
			INNER JOIN {$wpdb->term_taxonomy} AS tt ON t.term_id = tt.term_id
			WHERE tt.taxonomy IN ({$tax_placeholders})
			AND t.slug IN ({$slug_placeholders})",
			$params
		);
		// phpcs:enable

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results( $sql );

		$resolved = array();
		foreach ( $taxonomies as $taxonomy ) {
			$resolved[ $taxonomy ] = array();
		}

		if ( is_array( $rows ) ) {
			foreach ( $rows as $row ) {
				$taxonomy = (string) $row->taxonomy;
				$slug     = (string) $row->slug;
				if ( ! isset( $groups[ $taxonomy ] ) || ! in_array( $slug, $groups[ $taxonomy ], true ) ) {
					continue;
				}
				$resolved[ $taxonomy ][] = (int) $row->term_id;
			}
		}

		foreach ( $resolved as $taxonomy => $ids ) {
			$resolved[ $taxonomy ] = $this->with_descendants( $taxonomy, $ids );
		}

		return $resolved;
	}

	/**
	 * Expand resolved term IDs to include descendants of hierarchical taxonomies.
	 *
	 * Matches WooCommerce category archives and the Store API, which use
	 * include_children by default. Flat taxonomies are unchanged.
	 *
	 * @param string          $taxonomy Taxonomy.
	 * @param array<int, int> $ids      Resolved term IDs.
	 * @return array<int, int>
	 */
	private function with_descendants( $taxonomy, $ids ) {
		$ids = array_values( array_unique( array_filter( array_map( 'intval', $ids ) ) ) );
		if ( empty( $ids ) ) {
			return $ids;
		}
		if ( ! function_exists( 'is_taxonomy_hierarchical' ) || ! is_taxonomy_hierarchical( $taxonomy ) ) {
			return $ids;
		}
		if ( ! function_exists( 'get_term_children' ) ) {
			return $ids;
		}

		$expanded = $ids;
		foreach ( $ids as $term_id ) {
			$children = get_term_children( $term_id, $taxonomy );
			if ( is_wp_error( $children ) || ! is_array( $children ) ) {
				continue;
			}
			foreach ( $children as $child_id ) {
				$expanded[] = (int) $child_id;
			}
		}

		return array_values( array_unique( array_filter( $expanded ) ) );
	}
}
