<?php
/**
 * A parsed, capped filter request.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Query;

defined( 'ABSPATH' ) || exit;

/**
 * Immutable result of Request_Parser::parse().
 */
class Parsed_Request {

	/**
	 * Filter groups keyed by taxonomy, each a list of slugs.
	 *
	 * @var array<string, array<int, string>>
	 */
	private $groups = array();

	/**
	 * Minimum price, or null when unset.
	 *
	 * @var float|null
	 */
	private $min_price = null;

	/**
	 * Maximum price, or null when unset.
	 *
	 * @var float|null
	 */
	private $max_price = null;

	/**
	 * Whether instock=1 (or an accepted alias) was requested.
	 *
	 * @var bool
	 */
	private $instock = false;

	/**
	 * Human-readable drop notices (caps, invalid values).
	 *
	 * @var array<int, string>
	 */
	private $dropped = array();

	/**
	 * Whether instore=1 was requested.
	 *
	 * @var bool
	 */
	private $instore = false;

	/**
	 * Numeric range selections keyed by taxonomy.
	 *
	 * @var array<string, array{min: float|null, max: float|null}>
	 */
	private $ranges = array();

	/**
	 * Constructor.
	 *
	 * @param array<string, array<int, string>>                      $groups    Taxonomy => slugs.
	 * @param float|null                                             $min_price Minimum price.
	 * @param float|null                                             $max_price Maximum price.
	 * @param bool                                                   $instock   In-stock flag.
	 * @param array<int, string>                                     $dropped   Drop notices.
	 * @param bool                                                   $instore   In-store flag.
	 * @param array<string, array{min: float|null, max: float|null}> $ranges  Numeric ranges.
	 */
	public function __construct( $groups = array(), $min_price = null, $max_price = null, $instock = false, $dropped = array(), $instore = false, $ranges = array() ) {
		$this->groups    = $groups;
		$this->min_price = $min_price;
		$this->max_price = $max_price;
		$this->instock   = (bool) $instock;
		$this->dropped   = $dropped;
		$this->instore   = (bool) $instore;
		$this->ranges    = is_array( $ranges ) ? $ranges : array();
	}

	/**
	 * Copy this request with selected overrides.
	 *
	 * @param array<string, mixed> $overrides Overrides.
	 * @return self
	 */
	public function with( $overrides ) {
		$overrides = is_array( $overrides ) ? $overrides : array();
		return new self(
			array_key_exists( 'groups', $overrides ) ? $overrides['groups'] : $this->groups,
			array_key_exists( 'min_price', $overrides ) ? $overrides['min_price'] : $this->min_price,
			array_key_exists( 'max_price', $overrides ) ? $overrides['max_price'] : $this->max_price,
			array_key_exists( 'instock', $overrides ) ? $overrides['instock'] : $this->instock,
			array_key_exists( 'dropped', $overrides ) ? $overrides['dropped'] : $this->dropped,
			array_key_exists( 'instore', $overrides ) ? $overrides['instore'] : $this->instore,
			array_key_exists( 'ranges', $overrides ) ? $overrides['ranges'] : $this->ranges
		);
	}

	/**
	 * Whether any recognized filter remains after parsing and caps.
	 *
	 * @return bool
	 */
	public function has_filters() {
		return ! empty( $this->groups ) || null !== $this->min_price || null !== $this->max_price || $this->instock || $this->instore || ! empty( $this->ranges );
	}

	/**
	 * Taxonomy => list of slugs.
	 *
	 * @return array<string, array<int, string>>
	 */
	public function groups() {
		return $this->groups;
	}

	/**
	 * Minimum price, or null when unset.
	 *
	 * @return float|null
	 */
	public function min_price() {
		return $this->min_price;
	}

	/**
	 * Maximum price, or null when unset.
	 *
	 * @return float|null
	 */
	public function max_price() {
		return $this->max_price;
	}

	/**
	 * Whether an in-stock filter was requested.
	 *
	 * @return bool
	 */
	public function instock() {
		return $this->instock;
	}

	/**
	 * Whether an in-store filter was requested.
	 *
	 * @return bool
	 */
	public function instore() {
		return $this->instore;
	}

	/**
	 * Numeric range selections keyed by taxonomy.
	 *
	 * @return array<string, array{min: float|null, max: float|null}>
	 */
	public function ranges() {
		return $this->ranges;
	}

	/**
	 * One numeric range, or null.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @return array{min: float|null, max: float|null}|null
	 */
	public function range( $taxonomy ) {
		$taxonomy = (string) $taxonomy;
		return isset( $this->ranges[ $taxonomy ] ) && is_array( $this->ranges[ $taxonomy ] ) ? $this->ranges[ $taxonomy ] : null;
	}

	/**
	 * Drop notices recorded during parsing.
	 *
	 * @return array<int, string>
	 */
	public function dropped() {
		return $this->dropped;
	}
}
