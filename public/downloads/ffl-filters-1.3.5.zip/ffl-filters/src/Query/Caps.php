<?php
/**
 * Hard caps for filter request clauses.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Query;

defined( 'ABSPATH' ) || exit;

/**
 * Tunable limits for parsed filter requests.
 *
 * Values over these caps are dropped and logged; the request never errors.
 */
class Caps {

	/**
	 * Default maximum number of filter groups (taxonomies plus special maps).
	 *
	 * @var int
	 */
	const MAX_GROUPS = 24;

	/**
	 * Default maximum number of slugs kept in one group.
	 *
	 * @var int
	 */
	const MAX_VALUES_PER_GROUP = 50;

	/**
	 * Default maximum character length of a single slug.
	 *
	 * @var int
	 */
	const MAX_SLUG_LENGTH = 200;

	/**
	 * Maximum number of filter groups.
	 *
	 * @return int
	 */
	public static function max_groups() {
		$cap = self::MAX_GROUPS;
		if ( function_exists( 'apply_filters' ) ) {
			/**
			 * Filters the maximum number of filter groups kept from a request.
			 *
			 * @since 0.0.1
			 * @param int $cap Maximum groups.
			 */
			$cap = (int) apply_filters( 'fflf_query_max_groups', $cap );
		}
		return max( 0, $cap );
	}

	/**
	 * Maximum number of values kept in one group.
	 *
	 * @return int
	 */
	public static function max_values_per_group() {
		$cap = self::MAX_VALUES_PER_GROUP;
		if ( function_exists( 'apply_filters' ) ) {
			/**
			 * Filters the maximum number of slugs kept in one filter group.
			 *
			 * @since 0.0.1
			 * @param int $cap Maximum values per group.
			 */
			$cap = (int) apply_filters( 'fflf_query_max_values_per_group', $cap );
		}
		return max( 0, $cap );
	}

	/**
	 * Maximum slug length in characters.
	 *
	 * @return int
	 */
	public static function max_slug_length() {
		$cap = self::MAX_SLUG_LENGTH;
		if ( function_exists( 'apply_filters' ) ) {
			/**
			 * Filters the maximum character length of a filter slug.
			 *
			 * @since 0.0.1
			 * @param int $cap Maximum slug length.
			 */
			$cap = (int) apply_filters( 'fflf_query_max_slug_length', $cap );
		}
		return max( 0, $cap );
	}
}
