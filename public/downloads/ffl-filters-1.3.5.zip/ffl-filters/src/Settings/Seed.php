<?php
/**
 * First-run and incremental facet seeding.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Discovers catalog taxonomies and auto-hides newly arrived pa_* attributes.
 */
class Seed {

	/**
	 * Transient that holds the count of newly hidden attributes.
	 *
	 * @var string
	 */
	const NOTICE_TRANSIENT = 'fflf_new_attributes_hidden';

	/**
	 * Settings repository.
	 *
	 * @var Repository
	 */
	private $repository;

	/**
	 * Constructor.
	 *
	 * @param Repository|null $repository Settings.
	 */
	public function __construct( $repository = null ) {
		$this->repository = $repository ? $repository : new Repository();
	}

	/**
	 * Hook admin_init.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_init', array( $this, 'on_admin_init' ) );
		add_action( 'admin_notices', array( $this, 'render_notice' ) );
	}

	/**
	 * Admin-init callback. Seeding itself is tested via maybe_seed().
	 *
	 * @return void
	 */
	public function on_admin_init() {
		$this->maybe_seed();
	}

	/**
	 * Merge newly appeared taxonomies into settings.
	 *
	 * @return int Number of newly hidden attributes.
	 */
	public function maybe_seed() {
		if ( ! $this->user_can() ) {
			return 0;
		}

		$discovered = $this->discover();
		if ( ! $discovered ) {
			return 0;
		}

		$settings = $this->repository->all();
		$facets   = isset( $settings['facets'] ) && is_array( $settings['facets'] ) ? $settings['facets'] : array();
		$known    = isset( $settings['seed']['known'] ) && is_array( $settings['seed']['known'] ) ? $settings['seed']['known'] : array();
		$first    = array() === $facets;
		$hidden   = 0;
		$dirty    = false;
		$order    = 0;
		$min      = null;
		foreach ( $facets as $row ) {
			if ( isset( $row['order'] ) && (int) $row['order'] >= $order ) {
				$order = (int) $row['order'] + 1;
			}
			if ( isset( $row['order'] ) ) {
				$min = null === $min ? (int) $row['order'] : min( $min, (int) $row['order'] );
			}
		}
		$config = new \FFL_Filters\Presets\Config( isset( $settings['presets'] ) ? $settings['presets'] : null );

		foreach ( $discovered as $id => $meta ) {
			if ( isset( $facets[ $id ] ) ) {
				if ( ! in_array( $id, $known, true ) ) {
					$known[] = $id;
					$dirty   = true;
				}
				continue;
			}

			$is_attr = ( 0 === strpos( $id, 'pa_' ) );
			$virtual = in_array( $id, array( 'instore', \FFL_Filters\Presets\Defaults::CALIBER_ID ), true );
			$enable  = $first && ! $is_attr && 'product_tag' !== $id;
			if ( $first && $is_attr && ( $config->is_firearm_type_taxonomy( $id ) || $config->numeric()->is_range_taxonomy( $id ) ) ) {
				// Presets say these are on; do not leave them switched off behind a second gate.
				$enable = true;
			}
			if ( $virtual ) {
				// Already visible before they had rows, so keep them visible.
				$enable = true;
			}
			$row_order = $order;
			if ( \FFL_Filters\Presets\Defaults::CALIBER_ID === $id ) {
				$row_order = $this->caliber_order( $facets, $config, $order );
			} elseif ( 'instore' === $id && null !== $min ) {
				$row_order = $min - 1;
			}

			$dirty         = true;
			$facets[ $id ] = array(
				'id'           => $id,
				'enabled'      => $enable,
				'label'        => isset( $meta['label'] ) ? (string) $meta['label'] : '',
				'type'         => isset( $meta['type'] ) ? (string) $meta['type'] : 'checkbox',
				'order'        => $row_order,
				'hidden_terms' => array(),
				'mode'         => 'all',
				'slugs'        => array(),
				'nested'       => false,
				'large_ok'     => false,
			);
			if ( $row_order === $order ) {
				++$order;
			}

			if ( ! $first && $is_attr && ! in_array( $id, $known, true ) ) {
				++$hidden;
			}
			if ( ! in_array( $id, $known, true ) ) {
				$known[] = $id;
				$dirty   = true;
			}
		}

		if ( ! $dirty ) {
			return 0;
		}

		$settings['facets']        = $facets;
		$settings['seed']['known'] = array_values( array_unique( $known ) );
		$this->repository->save( $settings );

		if ( $hidden > 0 && function_exists( 'set_transient' ) ) {
			set_transient( self::NOTICE_TRANSIENT, $hidden, WEEK_IN_SECONDS );
		}

		return $hidden;
	}

	/**
	 * Where a new Caliber row goes: at the first of its merged attributes, else at the end.
	 *
	 * @param array<string, mixed>        $facets Saved rows.
	 * @param \FFL_Filters\Presets\Config $config Presets.
	 * @param int                         $next   Next free order.
	 * @return int
	 */
	private function caliber_order( $facets, $config, $next ) {
		$order = null;
		foreach ( $config->caliber_taxonomies() as $taxonomy ) {
			if ( isset( $facets[ $taxonomy ]['order'] ) ) {
				$value = (int) $facets[ $taxonomy ]['order'];
				$order = null === $order ? $value : min( $order, $value );
			}
		}
		return null === $order ? $next : $order;
	}

	/**
	 * Admin notice when new attributes were auto-hidden.
	 *
	 * @return void
	 */
	public function render_notice() {
		if ( ! $this->user_can() || ! function_exists( 'get_transient' ) ) {
			return;
		}
		$count = (int) get_transient( self::NOTICE_TRANSIENT );
		if ( $count <= 0 ) {
			return;
		}

		$url = function_exists( 'admin_url' ) ? admin_url( 'admin.php?page=ffl-filters' ) : '';
		echo '<div class="notice notice-warning is-dismissible fflf-new-attributes-notice"><p>';
		echo esc_html(
			sprintf(
				/* translators: %d: number of newly arrived attributes */
				_n(
					'%d new attribute arrived and was hidden. Review the filter list.',
					'%d new attributes arrived and were hidden. Review the filter list.',
					$count,
					'ffl-filters'
				),
				$count
			)
		);
		if ( '' !== $url ) {
			echo ' <a href="' . esc_url( $url ) . '">' . esc_html__( 'Open FFL Filters', 'ffl-filters' ) . '</a>';
		}
		echo '</p></div>';
	}

	/**
	 * Discover default + catalog facets.
	 *
	 * @return array<string, array<string, string>>
	 */
	public function discover() {
		$list = array(
			'instock' => array(
				'label' => __( 'In stock', 'ffl-filters' ),
				'type'  => 'instock',
			),
			'price'   => array(
				'label' => __( 'Price', 'ffl-filters' ),
				'type'  => 'price',
			),
		);

		if ( function_exists( 'taxonomy_exists' ) && taxonomy_exists( 'product_brand' ) ) {
			$list['product_brand'] = array(
				'label' => __( 'Brand', 'ffl-filters' ),
				'type'  => 'checkbox',
			);
		}
		if ( function_exists( 'taxonomy_exists' ) && taxonomy_exists( 'product_cat' ) ) {
			$list['product_cat'] = array(
				'label' => __( 'Category', 'ffl-filters' ),
				'type'  => 'checkbox',
			);
		}

		if ( function_exists( 'wc_get_attribute_taxonomies' ) ) {
			$attributes = wc_get_attribute_taxonomies();
			if ( is_array( $attributes ) ) {
				foreach ( $attributes as $attribute ) {
					$slug = isset( $attribute->attribute_name ) ? (string) $attribute->attribute_name : '';
					if ( '' === $slug ) {
						continue;
					}
					$taxonomy          = function_exists( 'wc_attribute_taxonomy_name' )
						? wc_attribute_taxonomy_name( $slug )
						: 'pa_' . $slug;
					$label             = isset( $attribute->attribute_label ) ? (string) $attribute->attribute_label : $slug;
					$list[ $taxonomy ] = array(
						'label' => $label,
						'type'  => 'checkbox',
					);
				}
			}
		}

		if ( function_exists( 'taxonomy_exists' ) && taxonomy_exists( 'product_tag' ) ) {
			$list['product_tag'] = array(
				'label' => __( 'Tag', 'ffl-filters' ),
				'type'  => 'checkbox',
			);
		}

		// Caliber and In store are built from presets; they get real rows so their order is saved.
		$config = new \FFL_Filters\Presets\Config();
		if ( $config->caliber_enabled() && function_exists( 'taxonomy_exists' ) ) {
			foreach ( $config->caliber_taxonomies() as $taxonomy ) {
				if ( taxonomy_exists( $taxonomy ) ) {
					$list[ \FFL_Filters\Presets\Defaults::CALIBER_ID ] = array(
						'label' => '',
						'type'  => 'checkbox',
					);
					break;
				}
			}
		}
		if ( $config->instore_enabled() && function_exists( 'taxonomy_exists' ) && taxonomy_exists( $config->instore_taxonomy() ) && function_exists( 'get_term_by' ) ) {
			$term = get_term_by( 'slug', $config->instore_slug(), $config->instore_taxonomy() );
			if ( $term && ! is_wp_error( $term ) ) {
				$list['instore'] = array(
					'label' => '',
					'type'  => 'checkbox',
				);
			}
		}
		$front = array();
		foreach ( array( 'instore', \FFL_Filters\Presets\Defaults::CALIBER_ID ) as $key ) {
			if ( isset( $list[ $key ] ) ) {
				$front[ $key ] = $list[ $key ];
				unset( $list[ $key ] );
			}
		}
		$list = array_merge( $front, $list );

		/**
		 * Filters the discovered facet catalog used to seed settings.
		 *
		 * @since 0.0.1
		 * @param array<string, array<string, string>> $list Facet id => meta.
		 */
		$filtered = apply_filters( 'fflf_seed_facets', $list );
		return is_array( $filtered ) ? $filtered : $list;
	}

	/**
	 * User can.
	 *
	 * @return bool
	 */
	private function user_can() {
		if ( ! function_exists( 'current_user_can' ) ) {
			return false;
		}
		return current_user_can( 'manage_woocommerce' ) || current_user_can( 'manage_options' );
	}
}
