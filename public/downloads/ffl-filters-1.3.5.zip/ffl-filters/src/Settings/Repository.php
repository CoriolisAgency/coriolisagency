<?php
/**
 * Stored dealer settings for the admin UI and the storefront panel.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Owns the fflf_settings option: sanitise, export, import, reset.
 *
 * Shape follows ANALYSIS.md §5.2. Missing SEO and sort flags default to true.
 */
class Repository {

	/**
	 * Option name.
	 *
	 * @var string
	 */
	const OPTION = 'fflf_settings';

	/**
	 * Allowed per-facet display types. 'dropdown' was dropped in 1.2.0; a saved or imported dropdown falls back to 'checkbox'.
	 *
	 * @var array<int, string>
	 */
	const TYPES = array( 'checkbox', 'range', 'toggle', 'price', 'instock' );

	/**
	 * Cached settings for this request.
	 *
	 * @var array<string, mixed>|null
	 */
	private $memo = null;

	/**
	 * Load and normalise the stored settings.
	 *
	 * @return array<string, mixed>
	 */
	public function all() {
		if ( null !== $this->memo ) {
			return $this->memo;
		}
		$stored     = function_exists( 'get_option' ) ? get_option( self::OPTION, array() ) : array();
		$this->memo = $this->sanitize( is_array( $stored ) ? $stored : array() );
		return $this->memo;
	}

	/**
	 * Drop the request memo so the next read hits the option.
	 *
	 * @return void
	 */
	public function flush_memo() {
		$this->memo = null;
	}

	/**
	 * Sanitise a settings payload into the stored shape.
	 *
	 * @param mixed $input Raw input.
	 * @return array<string, mixed>
	 */
	public function sanitize( $input ) {
		$input  = is_array( $input ) ? $input : array();
		$facets = array();
		$raw    = isset( $input['facets'] ) && is_array( $input['facets'] ) ? $input['facets'] : array();
		$order  = 0;
		foreach ( $raw as $id => $facet ) {
			$id = $this->sanitize_id( is_string( $id ) ? $id : ( isset( $facet['id'] ) ? $facet['id'] : '' ) );
			if ( '' === $id || ! is_array( $facet ) ) {
				continue;
			}
			$facets[ $id ] = $this->sanitize_facet( $id, $facet, $order );
			$order         = $facets[ $id ]['order'] + 1;
		}

		$pinned_in  = isset( $input['pinned'] ) && is_array( $input['pinned'] ) ? $input['pinned'] : array();
		$seed_in    = isset( $input['seed'] ) && is_array( $input['seed'] ) ? $input['seed'] : array();
		$display    = isset( $input['display'] ) && is_array( $input['display'] ) ? $input['display'] : array();
		$sort       = isset( $input['sort'] ) && is_array( $input['sort'] ) ? $input['sort'] : array();
		$seo        = isset( $input['seo'] ) && is_array( $input['seo'] ) ? $input['seo'] : array();
		$wizard     = isset( $input['wizard'] ) && is_array( $input['wizard'] ) ? $input['wizard'] : array();
		$sets_in    = isset( $input['sets'] ) && is_array( $input['sets'] ) ? $input['sets'] : array();
		$presets_in = isset( $input['presets'] ) ? $input['presets'] : array();

		$mobile = isset( $display['mobile'] ) ? (string) $display['mobile'] : 'drawer';
		if ( ! in_array( $mobile, array( 'drawer', 'collapsible', 'sidebar' ), true ) ) {
			$mobile = 'drawer';
		}

		$placement = self::sanitize_placement( isset( $display['placement'] ) ? $display['placement'] : 'sidebar' );
		$layout    = self::sanitize_layout( isset( $display['layout'] ) ? $display['layout'] : 'auto' );
		$style     = self::sanitize_panel_style( isset( $display['panel_style'] ) ? $display['panel_style'] : 'auto' );
		$a_source  = isset( $display['accent_source'] ) && 'custom' === $display['accent_source'] ? 'custom' : 'theme';
		$a_color   = self::sanitize_hex( isset( $display['accent_color'] ) ? $display['accent_color'] : '' );

		$match = isset( $pinned_in['match'] ) ? strtolower( (string) $pinned_in['match'] ) : 'or';
		if ( ! in_array( $match, array( 'and', 'or' ), true ) ) {
			$match = 'or';
		}

		return array(
			'facets'  => $facets,
			'pinned'  => array(
				'enabled'    => $this->bool( isset( $pinned_in['enabled'] ) ? $pinned_in['enabled'] : false ),
				'match'      => $match,
				'tags'       => $this->sanitize_pinned_tags( isset( $pinned_in['tags'] ) ? $pinned_in['tags'] : array() ),
				'categories' => $this->sanitize_slug_list( isset( $pinned_in['categories'] ) ? $pinned_in['categories'] : array() ),
				'shop'       => $this->bool( isset( $pinned_in['shop'] ) ? $pinned_in['shop'] : true, true ),
			),
			'seed'    => array(
				'known' => $this->sanitize_slug_list( isset( $seed_in['known'] ) ? $seed_in['known'] : array() ),
			),
			'display' => array(
				'mobile'        => $mobile,
				'auto_insert'   => $this->bool( isset( $display['auto_insert'] ) ? $display['auto_insert'] : true, true ),
				'heading'       => isset( $display['heading'] ) && is_scalar( $display['heading'] ) ? mb_substr( trim( sanitize_text_field( (string) $display['heading'] ) ), 0, 100 ) : '',
				'placement'     => $placement,
				'layout'        => $layout,
				'panel_style'   => $style,
				'accent_source' => $a_source,
				'accent_color'  => $a_color,
			),
			'sort'    => array(
				'honor_page_order' => $this->bool( isset( $sort['honor_page_order'] ) ? $sort['honor_page_order'] : true, true ),
			),
			'seo'     => array(
				'robots_disallow'   => $this->bool( isset( $seo['robots_disallow'] ) ? $seo['robots_disallow'] : true, true ),
				'canonical_noindex' => $this->bool( isset( $seo['canonical_noindex'] ) ? $seo['canonical_noindex'] : true, true ),
				'nofollow_facets'   => $this->bool( isset( $seo['nofollow_facets'] ) ? $seo['nofollow_facets'] : true, true ),
				'index_shallow'     => $this->bool( isset( $seo['index_shallow'] ) ? $seo['index_shallow'] : false ),
			),
			'sets'    => $this->sanitize_sets( $sets_in ),
			'presets' => \FFL_Filters\Presets\Config::sanitize( $presets_in ),
			'wizard'  => array(
				'completed' => $this->bool( isset( $wizard['completed'] ) ? $wizard['completed'] : false ),
			),
		);
	}

	/**
	 * Persist settings and bump the cache generation.
	 *
	 * @param mixed $input Raw input.
	 * @return array<string, mixed>
	 */
	public function save( $input ) {
		$clean      = $this->sanitize( $input );
		$this->memo = $clean;
		if ( function_exists( 'update_option' ) ) {
			update_option( self::OPTION, $clean, false );
		}
		if ( class_exists( '\FFL_Filters\Cache\Generation' ) ) {
			( new \FFL_Filters\Cache\Generation() )->bump();
		}
		return $clean;
	}

	/**
	 * Replace settings with the empty default structure.
	 *
	 * @return array<string, mixed>
	 */
	public function reset() {
		return $this->save( array() );
	}

	/**
	 * JSON export of the current settings.
	 *
	 * @return string
	 */
	public function export() {
		$json = wp_json_encode( $this->all() );
		return is_string( $json ) ? $json : '{}';
	}

	/**
	 * Import a JSON settings document.
	 *
	 * @param string $json JSON.
	 * @return array<string, mixed>|null Null when the payload is not JSON.
	 */
	public function import( $json ) {
		$data = json_decode( (string) $json, true );
		if ( ! is_array( $data ) ) {
			return null;
		}
		return $this->save( $data );
	}

	/**
	 * A single facet row, or null.
	 *
	 * @param string $id Facet id.
	 * @return array<string, mixed>|null
	 */
	public function facet( $id ) {
		$all = $this->all();
		$id  = (string) $id;
		return isset( $all['facets'][ $id ] ) && is_array( $all['facets'][ $id ] ) ? $all['facets'][ $id ] : null;
	}

	/**
	 * Whether a facet is enabled. Missing rows default to enabled.
	 *
	 * @param string $id Facet id.
	 * @return bool
	 */
	public function is_enabled( $id ) {
		$facet = $this->facet( $id );
		if ( ! $facet ) {
			return true;
		}
		return ! empty( $facet['enabled'] );
	}

	/**
	 * Hidden term slugs for a facet.
	 *
	 * @param string $id Facet id.
	 * @return array<int, string>
	 */
	public function hidden_terms( $id ) {
		$facet = $this->facet( $id );
		if ( ! $facet || ! isset( $facet['hidden_terms'] ) || ! is_array( $facet['hidden_terms'] ) ) {
			return array();
		}
		return $facet['hidden_terms'];
	}

	/**
	 * Whether the first-run wizard has been completed.
	 *
	 * @return bool
	 */
	public function wizard_completed() {
		$all = $this->all();
		return ! empty( $all['wizard']['completed'] );
	}

	/**
	 * Allowed placement values. 'above' is accepted as an alias of 'above_products'.
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	public static function sanitize_placement( $value ) {
		$value = is_scalar( $value ) ? strtolower( trim( (string) $value ) ) : '';
		if ( 'above' === $value ) {
			$value = 'above_products';
		}
		if ( ! in_array( $value, array( 'sidebar', 'above_products' ), true ) ) {
			return 'sidebar';
		}
		return $value;
	}

	/**
	 * Allowed layout values. Invalid or empty input falls back to Auto.
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	public static function sanitize_layout( $value ) {
		$value = is_scalar( $value ) ? strtolower( trim( (string) $value ) ) : '';
		if ( ! in_array( $value, array( 'auto', 'bar', 'stacked' ), true ) ) {
			return 'auto';
		}
		return $value;
	}

	/**
	 * Panel style: auto (detect the background behind the panel), light, or dark.
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	public static function sanitize_panel_style( $value ) {
		$value = is_scalar( $value ) ? strtolower( trim( (string) $value ) ) : '';
		return in_array( $value, array( 'auto', 'light', 'dark' ), true ) ? $value : 'auto';
	}

	/**
	 * A #RRGGBB colour (3-digit hex is expanded), or '' when invalid.
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	public static function sanitize_hex( $value ) {
		$value = is_scalar( $value ) ? strtolower( trim( (string) $value ) ) : '';
		if ( preg_match( '/^#?([0-9a-f]{3})$/', $value, $m ) ) {
			$value = '#' . $m[1][0] . $m[1][0] . $m[1][1] . $m[1][1] . $m[1][2] . $m[1][2];
		}
		if ( preg_match( '/^#?([0-9a-f]{6})$/', $value, $m ) ) {
			return '#' . strtoupper( $m[1] );
		}
		return '';
	}

	/**
	 * Sanitize facet.
	 *
	 * @param string               $id    Facet id.
	 * @param array<string, mixed> $facet Raw row.
	 * @param int                  $order Default order.
	 * @return array<string, mixed>
	 */
	private function sanitize_facet( $id, $facet, $order ) {
		$type = isset( $facet['type'] ) ? (string) $facet['type'] : 'checkbox';
		if ( 'instock' === $id ) {
			$type = 'instock';
		} elseif ( 'price' === $id ) {
			$type = 'price';
		} elseif ( ! in_array( $type, self::TYPES, true ) ) {
			$type = 'checkbox';
		}

		$mode = isset( $facet['mode'] ) ? (string) $facet['mode'] : 'all';
		if ( ! in_array( $mode, array( 'all', 'allow', 'hide' ), true ) ) {
			$mode = 'all';
		}

		$label = isset( $facet['label'] ) ? sanitize_text_field( (string) $facet['label'] ) : '';

		return array(
			'id'              => $id,
			'enabled'         => $this->bool( isset( $facet['enabled'] ) ? $facet['enabled'] : true, true ),
			'label'           => $label,
			'type'            => $type,
			'order'           => isset( $facet['order'] ) ? (int) $facet['order'] : (int) $order,
			'hidden_terms'    => $this->sanitize_slug_list( isset( $facet['hidden_terms'] ) ? $facet['hidden_terms'] : array() ),
			'hidden_term_ids' => $this->sanitize_id_list( isset( $facet['hidden_term_ids'] ) ? $facet['hidden_term_ids'] : array() ),
			'mode'            => $mode,
			'slugs'           => $this->sanitize_slug_list( isset( $facet['slugs'] ) ? $facet['slugs'] : array() ),
			'nested'          => $this->bool( isset( $facet['nested'] ) ? $facet['nested'] : false ),
			'large_ok'        => $this->bool( isset( $facet['large_ok'] ) ? $facet['large_ok'] : false ),
		);
	}

	/**
	 * Sanitize pinned tags.
	 *
	 * @param mixed $tags Raw tags.
	 * @return array<int, array{slug: string, label: string}>
	 */
	private function sanitize_pinned_tags( $tags ) {
		$out = array();
		if ( ! is_array( $tags ) ) {
			return $out;
		}
		foreach ( $tags as $row ) {
			if ( is_string( $row ) ) {
				$slug = sanitize_title( $row );
				if ( '' !== $slug ) {
					$out[] = array(
						'slug'  => $slug,
						'label' => $slug,
					);
				}
				continue;
			}
			if ( ! is_array( $row ) ) {
				continue;
			}
			$slug = isset( $row['slug'] ) ? sanitize_title( (string) $row['slug'] ) : '';
			if ( '' === $slug ) {
				continue;
			}
			$label = isset( $row['label'] ) ? sanitize_text_field( (string) $row['label'] ) : $slug;
			$out[] = array(
				'slug'  => $slug,
				'label' => '' !== $label ? $label : $slug,
			);
		}
		return $out;
	}

	/**
	 * Sanitize sets.
	 *
	 * @param mixed $sets Raw per-category sets.
	 * @return array<int, array{categories: array<int, string>, facets: array<int, string>}>
	 */
	private function sanitize_sets( $sets ) {
		$out = array();
		if ( ! is_array( $sets ) ) {
			return $out;
		}
		foreach ( $sets as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$categories = $this->sanitize_slug_list( isset( $row['categories'] ) ? $row['categories'] : array() );
			$facets     = $this->sanitize_slug_list( isset( $row['facets'] ) ? $row['facets'] : array() );
			if ( array() === $categories && array() === $facets ) {
				continue;
			}
			$out[] = array(
				'categories' => $categories,
				'facets'     => $facets,
			);
		}
		return $out;
	}

	/**
	 * Sanitize slug list.
	 *
	 * @param mixed $items Raw list or comma string.
	 * @return array<int, string>
	 */
	private function sanitize_slug_list( $items ) {
		if ( is_string( $items ) ) {
			$items = preg_split( '/\s*,\s*/', $items );
		}
		if ( ! is_array( $items ) ) {
			return array();
		}
		$out = array();
		foreach ( $items as $item ) {
			$slug = sanitize_title( (string) $item );
			if ( '' !== $slug ) {
				$out[] = $slug;
			}
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * Bool.
	 *
	 * @param mixed $value   Raw value.
	 * @param bool  $fallback Default when empty/missing.
	 * @return bool
	 */
	private function bool( $value, $fallback = false ) {
		if ( is_bool( $value ) ) {
			return $value;
		}
		if ( null === $value || '' === $value ) {
			return $fallback;
		}
		if ( is_int( $value ) || is_float( $value ) ) {
			return (bool) $value;
		}
		$normalized = strtolower( trim( (string) $value ) );
		if ( in_array( $normalized, array( 'no', 'false', '0', 'off' ), true ) ) {
			return false;
		}
		if ( in_array( $normalized, array( 'yes', 'true', '1', 'on' ), true ) ) {
			return true;
		}
		return $fallback;
	}

	/**
	 * Sanitize a list of positive integers (term IDs).
	 *
	 * @param mixed $items Raw list.
	 * @return array<int, int>
	 */
	private function sanitize_id_list( $items ) {
		if ( ! is_array( $items ) ) {
			return array();
		}
		$out = array();
		foreach ( $items as $item ) {
			$id = (int) $item;
			if ( $id > 0 ) {
				$out[] = $id;
			}
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * Sanitize id.
	 *
	 * @param mixed $id Raw id.
	 * @return string
	 */
	private function sanitize_id( $id ) {
		$id = strtolower( trim( (string) $id ) );
		$id = preg_replace( '/[^a-z0-9_\-]/', '', $id );
		return is_string( $id ) ? $id : '';
	}
}
