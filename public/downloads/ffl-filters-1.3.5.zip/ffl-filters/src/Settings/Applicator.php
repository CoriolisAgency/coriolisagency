<?php
/**
 * Apply stored settings to the storefront facet list and term lists.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Settings-aware shaping of facets and terms. Pure given a repository snapshot.
 */
class Applicator {

	/**
	 * Settings repository.
	 *
	 * @var Repository
	 */
	private $repository;

	/**
	 * Facets whose display type is fixed by the plugin.
	 *
	 * @var array<int, string>
	 */
	const LOCKED_TYPES = array( 'price', 'instock', 'instore', 'caliber' );

	/**
	 * Constructor.
	 *
	 * @param Repository|null $repository Settings.
	 */
	public function __construct( $repository = null ) {
		$this->repository = $repository ? $repository : new Repository();
	}

	/**
	 * Reorder, relabel, retype, and drop disabled facets. Apply per-category sets.
	 *
	 * @param array<int, array<string, mixed>> $facets Discovered facets.
	 * @return array<int, array<string, mixed>>
	 */
	public function facets( $facets ) {
		if ( ! is_array( $facets ) ) {
			return array();
		}

		$settings = $this->repository->all();
		$rows     = isset( $settings['facets'] ) && is_array( $settings['facets'] ) ? $settings['facets'] : array();
		$allowed  = $this->allowed_ids_for_context( $settings );
		$has_rows = array() !== $rows;

		$out   = array();
		$index = 0;
		$max   = null;
		foreach ( $rows as $row_id => $row ) {
			if ( is_array( $row ) && isset( $row['order'] ) ) {
				$max = null === $max ? (int) $row['order'] : max( $max, (int) $row['order'] );
			}
		}
		$caliber_order = $this->caliber_fallback_order( $rows );
		foreach ( $facets as $facet ) {
			if ( ! is_array( $facet ) || empty( $facet['id'] ) ) {
				continue;
			}
			$id = (string) $facet['id'];
			if ( ! $this->repository->is_enabled( $id ) ) {
				continue;
			}
			if ( null !== $allowed && ! in_array( $id, $allowed, true ) ) {
				continue;
			}
			if ( isset( $rows[ $id ] ) && is_array( $rows[ $id ] ) ) {
				$row = $rows[ $id ];
				if ( '' !== (string) $row['label'] ) {
					$facet['label'] = $row['label'];
				}
				if ( ! empty( $row['type'] ) && ! in_array( $id, self::LOCKED_TYPES, true ) ) {
					$type = (string) $row['type'];
					if ( 'checkbox' === $type ) {
						// Checkboxes is the default row type; a preset range stays a range.
						$type = ( isset( $facet['type'] ) && 'range' === $facet['type'] ) ? 'range' : 'terms';
					}
					$facet['type'] = $type;
				}
				$facet['order'] = isset( $row['order'] ) ? (int) $row['order'] : $index;
			} elseif ( \FFL_Filters\Presets\Defaults::CALIBER_ID === $id && null !== $caliber_order ) {
				// Before Caliber has its own row it sits where its merged attributes were saved.
				$facet['order'] = $caliber_order;
			} elseif ( null !== $max ) {
				// A facet with no saved row goes after every saved row, never tied with the first one.
				$facet['order'] = $max + 1 + $index;
			} else {
				$facet['order'] = $index;
			}
			$facet['_seq'] = $index;
			$out[]         = $facet;
			++$index;
		}

		if ( $has_rows ) {
			usort(
				$out,
				static function ( $a, $b ) {
					$ao = isset( $a['order'] ) ? (int) $a['order'] : 0;
					$bo = isset( $b['order'] ) ? (int) $b['order'] : 0;
					if ( $ao === $bo ) {
						return (int) $a['_seq'] - (int) $b['_seq'];
					}
					return ( $ao < $bo ) ? -1 : 1;
				}
			);
		}

		foreach ( $out as $i => $facet ) {
			unset( $out[ $i ]['_seq'] );
		}

		return $out;
	}

	/**
	 * Lowest saved order among the caliber attributes merged into Caliber.
	 *
	 * @param array<string, mixed> $rows Saved rows.
	 * @return int|null
	 */
	private function caliber_fallback_order( $rows ) {
		$config = new \FFL_Filters\Presets\Config();
		if ( ! $config->caliber_enabled() ) {
			return null;
		}
		$order = null;
		foreach ( $config->caliber_taxonomies() as $taxonomy ) {
			if ( isset( $rows[ $taxonomy ]['order'] ) ) {
				$value = (int) $rows[ $taxonomy ]['order'];
				$order = null === $order ? $value : min( $order, $value );
			}
		}
		return $order;
	}

	/**
	 * Drop hidden terms, apply category allow/hide lists, and pin tags.
	 *
	 * @param string                           $taxonomy Taxonomy.
	 * @param array<int, array<string, mixed>> $terms    Terms.
	 * @return array<int, array<string, mixed>>
	 */
	public function filter_terms( $taxonomy, $terms ) {
		if ( ! is_array( $terms ) ) {
			return array();
		}

		$taxonomy = (string) $taxonomy;
		$hidden   = $this->repository->hidden_terms( $taxonomy );
		$out      = array();
		foreach ( $terms as $term ) {
			if ( ! is_array( $term ) || empty( $term['slug'] ) ) {
				continue;
			}
			$slug = (string) $term['slug'];
			if ( in_array( $slug, $hidden, true ) && empty( $term['selected'] ) ) {
				continue;
			}
			$out[] = $term;
		}

		$row = $this->repository->facet( $taxonomy );
		if ( 'product_cat' === $taxonomy && $row ) {
			$mode  = isset( $row['mode'] ) ? (string) $row['mode'] : 'all';
			$slugs = isset( $row['slugs'] ) && is_array( $row['slugs'] ) ? $row['slugs'] : array();
			if ( 'allow' === $mode && $slugs ) {
				$out = $this->only_slugs( $out, $slugs, true );
			} elseif ( 'hide' === $mode && $slugs ) {
				$filtered = array();
				foreach ( $out as $term ) {
					if ( in_array( (string) $term['slug'], $slugs, true ) && empty( $term['selected'] ) ) {
						continue;
					}
					$filtered[] = $term;
				}
				$out = $filtered;
			}
		}

		if ( 'product_tag' === $taxonomy && $this->pinned_active() ) {
			$out = $this->apply_pinned( $out );
		}

		return array_values( $out );
	}

	/**
	 * Whether the category facet should render as a nested tree.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @return bool
	 */
	public function is_nested( $taxonomy ) {
		$row = $this->repository->facet( (string) $taxonomy );
		return $row && ! empty( $row['nested'] );
	}

	/**
	 * Sort terms into a depth-first parent/child tree.
	 *
	 * @param array<int, array<string, mixed>> $terms Terms (may include parent).
	 * @return array<int, array<string, mixed>>
	 */
	public function sort_tree( $terms ) {
		$by_parent = array();
		foreach ( $terms as $term ) {
			$parent = isset( $term['parent'] ) ? (int) $term['parent'] : 0;
			if ( ! isset( $by_parent[ $parent ] ) ) {
				$by_parent[ $parent ] = array();
			}
			$by_parent[ $parent ][] = $term;
		}

		$out = array();
		$this->walk_tree( $by_parent, 0, 0, $out );
		return $out;
	}

	/**
	 * Whether min/max price in the request should be ignored.
	 *
	 * @return bool
	 */
	public function ignore_price() {
		return ! $this->repository->is_enabled( 'price' );
	}

	/**
	 * Allowed ids for context.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return array<int, string>|null Null means no set restriction.
	 */
	private function allowed_ids_for_context( $settings ) {
		$sets = isset( $settings['sets'] ) && is_array( $settings['sets'] ) ? $settings['sets'] : array();
		if ( ! $sets ) {
			return null;
		}
		$slug = $this->current_category_slug();
		if ( '' === $slug ) {
			return null;
		}
		foreach ( $sets as $set ) {
			if ( ! is_array( $set ) ) {
				continue;
			}
			$categories = isset( $set['categories'] ) && is_array( $set['categories'] ) ? $set['categories'] : array();
			if ( in_array( $slug, $categories, true ) ) {
				$facets = isset( $set['facets'] ) && is_array( $set['facets'] ) ? $set['facets'] : array();
				return $facets;
			}
		}
		return null;
	}

	/**
	 * Pinned active.
	 *
	 * @return bool
	 */
	private function pinned_active() {
		$all = $this->repository->all();
		$pin = isset( $all['pinned'] ) && is_array( $all['pinned'] ) ? $all['pinned'] : array();
		if ( empty( $pin['enabled'] ) ) {
			return false;
		}

		if ( function_exists( 'is_shop' ) && is_shop() ) {
			return ! empty( $pin['shop'] );
		}

		$slug = $this->current_category_slug();
		$cats = isset( $pin['categories'] ) && is_array( $pin['categories'] ) ? $pin['categories'] : array();
		if ( '' === $slug ) {
			return false;
		}
		if ( ! $cats ) {
			return true;
		}
		return in_array( $slug, $cats, true );
	}

	/**
	 * Apply pinned.
	 *
	 * @param array<int, array<string, mixed>> $terms Terms.
	 * @return array<int, array<string, mixed>>
	 */
	private function apply_pinned( $terms ) {
		$all  = $this->repository->all();
		$tags = isset( $all['pinned']['tags'] ) && is_array( $all['pinned']['tags'] ) ? $all['pinned']['tags'] : array();
		$by   = array();
		foreach ( $terms as $term ) {
			$by[ (string) $term['slug'] ] = $term;
		}

		$out = array();
		foreach ( $tags as $row ) {
			if ( ! is_array( $row ) || empty( $row['slug'] ) ) {
				continue;
			}
			$slug = (string) $row['slug'];
			$term = isset( $by[ $slug ] ) ? $by[ $slug ] : array(
				'slug'     => $slug,
				'label'    => $slug,
				'count'    => 0,
				'selected' => false,
			);
			if ( ! empty( $row['label'] ) ) {
				$term['label'] = (string) $row['label'];
			}
			$out[] = $term;
		}
		return $out;
	}

	/**
	 * Only slugs.
	 *
	 * @param array<int, array<string, mixed>> $terms    Terms.
	 * @param array<int, string>               $slugs    Allowed slugs.
	 * @param bool                             $keep_sel Keep selected even if not listed.
	 * @return array<int, array<string, mixed>>
	 */
	private function only_slugs( $terms, $slugs, $keep_sel ) {
		$out = array();
		foreach ( $terms as $term ) {
			$slug = (string) $term['slug'];
			if ( in_array( $slug, $slugs, true ) || ( $keep_sel && ! empty( $term['selected'] ) ) ) {
				$out[] = $term;
			}
		}
		return $out;
	}

	/**
	 * Walk tree.
	 *
	 * @param array<int, array<int, array<string, mixed>>> $by_parent Children by parent id.
	 * @param int                                          $parent_id Parent term id (0 = root).
	 * @param int                                          $depth     Depth.
	 * @param array<int, array<string, mixed>>             $out       Collector.
	 * @return void
	 */
	private function walk_tree( $by_parent, $parent_id, $depth, &$out ) {
		if ( ! isset( $by_parent[ $parent_id ] ) ) {
			return;
		}
		foreach ( $by_parent[ $parent_id ] as $term ) {
			$term['depth'] = $depth;
			$out[]         = $term;
			$id            = isset( $term['id'] ) ? (int) $term['id'] : 0;
			if ( $id > 0 ) {
				$this->walk_tree( $by_parent, $id, $depth + 1, $out );
			}
		}
	}

	/**
	 * Current product category slug, if any.
	 *
	 * @return string
	 */
	private function current_category_slug() {
		if ( ! function_exists( 'get_queried_object' ) ) {
			return '';
		}
		$object = get_queried_object();
		if ( $object instanceof \WP_Term && 'product_cat' === $object->taxonomy && ! empty( $object->slug ) ) {
			return (string) $object->slug;
		}
		return '';
	}
}
