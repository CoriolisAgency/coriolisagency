<?php
/**
 * Storefront SEO for filtered catalog URLs.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Seo;

use FFL_Filters\Panel\Scope;

defined( 'ABSPATH' ) || exit;

/**
 * Matches CPF's live crawler behaviour, measured on Allegheny and Naples:
 * robots.txt Disallow for filter query params, noindex+follow (meta and
 * X-Robots-Tag), no rel=canonical on filtered views, and rel=nofollow on
 * Clear and pagination. Yoast and Rank Math hooks keep the same stance.
 *
 * Stance: noindex+follow, not a canonical to the unfiltered page. The two
 * are not combined. Indexable filter landings are out of scope until §9 Q6.
 *
 * Passive while Coriolis Product Filters is active so robots lines and
 * headers are never emitted twice.
 */
class Controller {

	/**
	 * Hook front-end SEO and, when needed, the physical robots.txt notice.
	 *
	 * @return void
	 */
	public function register() {
		if ( $this->compare_plugin_is_active() ) {
			return;
		}

		add_filter( 'robots_txt', array( $this, 'filter_robots' ), 9, 2 );
		add_filter( 'wp_robots', array( $this, 'filter_wp_robots' ), 20 );
		add_filter( 'wp_headers', array( $this, 'filter_headers' ), 1000 );
		add_filter( 'get_canonical_url', array( $this, 'disable_canonical' ), 20 );
		add_filter( 'wpseo_canonical', array( $this, 'disable_canonical' ), 20 );
		add_filter( 'wpseo_opengraph_url', array( $this, 'unfiltered_opengraph_url' ), 20 );
		add_filter( 'wpseo_robots', array( $this, 'filter_yoast_robots' ), 20 );
		add_filter( 'wpseo_robots_array', array( $this, 'filter_yoast_robots_array' ), 20 );
		add_filter( 'rank_math/frontend/canonical', array( $this, 'disable_canonical' ), 20 );
		add_filter( 'rank_math/frontend/robots', array( $this, 'filter_rank_math_robots' ), 20 );
		add_filter( 'paginate_links_output', array( $this, 'nofollow_pagination' ), 20, 2 );
		add_filter( 'render_block', array( $this, 'nofollow_pagination_block' ), 20, 2 );
	}

	/**
	 * Append the measured Product filter URLs Disallow block once.
	 *
	 * @param string $output    Existing robots.txt body.
	 * @param bool   $is_public Whether the site is public.
	 * @return string
	 */
	public function filter_robots( $output, $is_public ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
		if ( ! $this->robots_disallow_enabled() ) {
			return $output;
		}

		$output = (string) $output;
		if ( false !== strpos( $output, '# Product filter URLs' ) || false !== strpos( $output, 'Disallow: /*?*filter_' ) ) {
			return $output;
		}

		$block  = "\n# Product filter URLs\n";
		$block .= "User-agent: *\n";
		foreach ( $this->disallow_paths() as $path ) {
			$block .= 'Disallow: ' . $path . "\n";
		}

		return rtrim( $output ) . $block;
	}

	/**
	 * Disallow paths that match the live CPF robots.txt block.
	 *
	 * @return array<int, string>
	 */
	public function disallow_paths() {
		$paths = array(
			'/*?*filter_',
			'/*?*min_price=',
			'/*?*max_price=',
			'/*?*instock=',
		);

		$paths[] = '/*?*instore=';
		$numeric = new \FFL_Filters\Presets\Numeric_Parser();
		foreach ( $numeric->taxonomies() as $taxonomy ) {
			$paths[] = '/*?*' . $numeric->min_param( $taxonomy ) . '=';
			$paths[] = '/*?*' . $numeric->max_param( $taxonomy ) . '=';
		}

		/**
		 * Filters the robots.txt Disallow paths for filtered catalog URLs.
		 *
		 * @since 0.0.1
		 * @param array<int, string> $paths Paths.
		 */
		$filtered = function_exists( 'apply_filters' ) ? apply_filters( 'fflf_robots_disallow_patterns', $paths ) : $paths;

		return is_array( $filtered ) ? $filtered : $paths;
	}

	/**
	 * Core robots meta: noindex, follow on filtered views.
	 *
	 * @param array<string, mixed> $robots Directives.
	 * @return array<string, mixed>
	 */
	public function filter_wp_robots( $robots ) {
		if ( ! $this->should_noindex() ) {
			return $robots;
		}
		if ( ! is_array( $robots ) ) {
			$robots = array();
		}

		$robots['noindex'] = true;
		$robots['follow']  = true;
		unset( $robots['index'], $robots['nofollow'] );

		return $robots;
	}

	/**
	 * X-Robots-Tag: noindex, follow on filtered views.
	 *
	 * @param array<string, string> $headers Headers.
	 * @return array<string, string>
	 */
	public function filter_headers( $headers ) {
		if ( ! $this->should_noindex() ) {
			return $headers;
		}
		if ( ! is_array( $headers ) ) {
			$headers = array();
		}
		$headers['X-Robots-Tag'] = 'noindex, follow';
		return $headers;
	}

	/**
	 * Drop rel=canonical on filtered views (noindex+follow, not both).
	 *
	 * @param mixed $canonical Current canonical URL.
	 * @return mixed
	 */
	public function disable_canonical( $canonical ) {
		if ( $this->should_noindex() ) {
			return false;
		}
		return $canonical;
	}

	/**
	 * Point Yoast og:url at the unfiltered archive, as measured live.
	 *
	 * @param mixed $url Current Open Graph URL.
	 * @return mixed
	 */
	public function unfiltered_opengraph_url( $url ) {
		if ( ! $this->should_noindex() ) {
			return $url;
		}
		$clean = ( new Scope() )->url();
		return '' !== $clean ? $clean : $url;
	}

	/**
	 * Yoast robots string.
	 *
	 * @param mixed $robots Existing value.
	 * @return mixed
	 */
	public function filter_yoast_robots( $robots ) {
		if ( ! $this->should_noindex() ) {
			return $robots;
		}
		return 'noindex, follow';
	}

	/**
	 * Yoast robots array.
	 *
	 * @param mixed $robots Existing value.
	 * @return mixed
	 */
	public function filter_yoast_robots_array( $robots ) {
		if ( ! $this->should_noindex() ) {
			return $robots;
		}
		if ( ! is_array( $robots ) ) {
			$robots = array();
		}
		$robots['index']    = 'noindex';
		$robots['follow']   = 'follow';
		$robots['noindex']  = 'noindex';
		$robots['nofollow'] = 'follow';
		return $robots;
	}

	/**
	 * Rank Math robots array or string.
	 *
	 * @param mixed $robots Existing value.
	 * @return mixed
	 */
	public function filter_rank_math_robots( $robots ) {
		if ( ! $this->should_noindex() ) {
			return $robots;
		}
		if ( is_array( $robots ) ) {
			$robots['index']    = 'noindex';
			$robots['follow']   = 'follow';
			$robots['noindex']  = 'noindex';
			$robots['nofollow'] = 'follow';
			return $robots;
		}
		return 'noindex, follow';
	}

	/**
	 * Add rel=nofollow to classic theme pagination on filtered views.
	 *
	 * @param string               $output Markup.
	 * @param array<string, mixed> $args   paginate_links args (unused).
	 * @return string
	 */
	public function nofollow_pagination( $output, $args = array() ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
		if ( ! $this->should_nofollow() ) {
			return $output;
		}
		return $this->add_rel_nofollow( (string) $output );
	}

	/**
	 * Add rel=nofollow to block-theme pagination on filtered views.
	 *
	 * @param string               $content Block HTML.
	 * @param array<string, mixed> $block   Parsed block.
	 * @return string
	 */
	public function nofollow_pagination_block( $content, $block ) {
		$name = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
		if ( '' === $name || false === strpos( $name, 'pagination' ) ) {
			return $content;
		}
		if ( ! $this->should_nofollow() ) {
			return $content;
		}
		return $this->add_rel_nofollow( (string) $content );
	}

	/**
	 * Add rel="nofollow" to anchor tags that do not already have it.
	 *
	 * @param string $html HTML.
	 * @return string
	 */
	public function add_rel_nofollow( $html ) {
		if ( '' === $html || false === strpos( $html, '<a' ) ) {
			return $html;
		}

		$updated = preg_replace_callback(
			'/<a\s[^>]*>/i',
			function ( $matches ) {
				$tag = $matches[0];
				if ( preg_match( '/\bnofollow\b/i', $tag ) ) {
					return $tag;
				}
				if ( preg_match( '/\brel\s*=\s*(["\'])(.*?)\1/i', $tag, $rel ) ) {
					$replacement = 'rel=' . $rel[1] . trim( $rel[2] . ' nofollow' ) . $rel[1];
					return preg_replace( '/\brel\s*=\s*(["\']).*?\1/i', $replacement, $tag, 1 );
				}
				return preg_replace( '/<a\s/i', '<a rel="nofollow" ', $tag, 1 );
			},
			$html
		);

		return is_string( $updated ) ? $updated : $html;
	}

	/**
	 * Whether this request should be noindex, follow.
	 *
	 * @return bool
	 */
	public function should_noindex() {
		return $this->noindex_enabled() && $this->request_has_filters();
	}

	/**
	 * Whether Clear/pagination should get rel=nofollow.
	 *
	 * @return bool
	 */
	public function should_nofollow() {
		return $this->nofollow_enabled() && $this->request_has_filters();
	}

	/**
	 * Whether the robots.txt Disallow block should be emitted.
	 *
	 * Missing setting = true (CPF semantics).
	 *
	 * @return bool
	 */
	public function robots_disallow_enabled() {
		$enabled = $this->setting_flag( 'robots_disallow', true );
		/**
		 * Filters whether the Product filter URLs robots.txt block is emitted.
		 *
		 * @since 0.0.1
		 * @param bool $enabled Whether to append the Disallow block. Missing = true.
		 */
		return function_exists( 'apply_filters' ) ? (bool) apply_filters( 'fflf_seo_robots_disallow', $enabled ) : $enabled;
	}

	/**
	 * Whether filtered views are noindex, follow (and not canonicalized).
	 *
	 * @return bool
	 */
	public function noindex_enabled() {
		$enabled = $this->setting_flag( 'canonical_noindex', true );
		/**
		 * Filters whether filtered views are noindex, follow (and not canonicalized).
		 *
		 * @since 0.0.1
		 * @param bool $enabled Whether to noindex filtered views. Missing = true.
		 */
		return function_exists( 'apply_filters' ) ? (bool) apply_filters( 'fflf_seo_canonical_noindex', $enabled ) : $enabled;
	}

	/**
	 * Whether facet/pagination/clear links should be nofollow.
	 *
	 * @return bool
	 */
	public function nofollow_enabled() {
		$enabled = $this->setting_flag( 'nofollow_facets', true );
		/**
		 * Filters whether Clear and pagination links on filtered views are nofollow.
		 *
		 * @since 0.0.1
		 * @param bool $enabled Whether to add rel=nofollow. Missing = true.
		 */
		return function_exists( 'apply_filters' ) ? (bool) apply_filters( 'fflf_seo_nofollow_facets', $enabled ) : $enabled;
	}

	/**
	 * Whether the current request has effective filter params.
	 *
	 * @return bool
	 */
	private function request_has_filters() {
		if ( function_exists( 'fflf_request_has_filters' ) ) {
			return fflf_request_has_filters();
		}
		return false;
	}

	/**
	 * Whether Coriolis Product Filters is active.
	 *
	 * @return bool
	 */
	private function compare_plugin_is_active() {
		if ( function_exists( 'fflf_is_passive' ) ) {
			return fflf_is_passive();
		}
		return function_exists( 'fflf_compare_plugin_is_active' ) && fflf_compare_plugin_is_active();
	}

	/**
	 * A stored SEO flag, defaulting to $fallback when unset.
	 *
	 * @param string $key      Flag key under settings.seo.
	 * @param bool   $fallback Default when missing.
	 * @return bool
	 */
	private function setting_flag( $key, $fallback ) {
		if ( ! class_exists( '\FFL_Filters\Settings\Repository' ) ) {
			return $fallback;
		}
		$settings = ( new \FFL_Filters\Settings\Repository() )->all();
		if ( ! isset( $settings['seo'][ $key ] ) ) {
			return $fallback;
		}
		return ! empty( $settings['seo'][ $key ] );
	}
}
