<?php
/**
 * Map a cpf_settings array onto fflf_settings.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Import;

defined( 'ABSPATH' ) || exit;

/**
 * Pure mapper for every measured CPF settings shape from 0.5.0 through 0.7.2.1.
 *
 * Reads the option array only. It never opens CPF PHP and never writes cpf_*.
 */
class Mapper {

	/**
	 * Keys that are observed on some releases and are intentionally dropped.
	 *
	 * @var array<int, string>
	 */
	const DROPPED_KEYS = array(
		'debug_mode',
		'migrations',
		'taxonomies',
		'attribute_refresh_cron_cleared',
		'attribute_hide_seeded',
	);

	/**
	 * Map a raw cpf_settings payload to the FFL Filters settings shape.
	 *
	 * @param mixed  $cpf_settings Raw option value.
	 * @param string $from_version Detected CPF version, when known.
	 * @return array<string, mixed>
	 */
	public function map( $cpf_settings, $from_version = '' ) {
		$cpf = is_array( $cpf_settings ) ? $cpf_settings : array();

		$hidden     = $this->string_list( isset( $cpf['hidden_taxonomies'] ) ? $cpf['hidden_taxonomies'] : array() );
		$known      = $this->string_list( isset( $cpf['attribute_seed_known'] ) ? $cpf['attribute_seed_known'] : array() );
		$confirmed  = $this->string_list( isset( $cpf['large_facet_confirmed'] ) ? $cpf['large_facet_confirmed'] : array() );
		$hidden_map = isset( $cpf['hidden_terms'] ) && is_array( $cpf['hidden_terms'] ) ? $cpf['hidden_terms'] : array();

		$taxonomies = $this->taxonomy_order( $cpf, $hidden, $known, $confirmed, $hidden_map );

		$facets = array();
		$order  = 0;
		foreach ( $taxonomies as $tax ) {
			$terms = array();
			if ( isset( $hidden_map[ $tax ] ) ) {
				$terms = $this->string_list( $hidden_map[ $tax ] );
			}
			$row = array(
				'id'              => $tax,
				'enabled'         => ! in_array( $tax, $hidden, true ),
				'label'           => '',
				'type'            => 'product_cat' === $tax ? 'checkbox' : 'checkbox',
				'order'           => $order,
				'hidden_terms'    => $terms,
				'hidden_term_ids' => $this->term_ids( $tax, $terms ),
				'mode'            => 'all',
				'slugs'           => array(),
				'nested'          => false,
				'large_ok'        => in_array( $tax, $confirmed, true ),
			);
			if ( 'product_cat' === $tax ) {
				$mode = isset( $cpf['category_facet_mode'] ) ? (string) $cpf['category_facet_mode'] : 'all';
				if ( ! in_array( $mode, array( 'all', 'allow', 'hide' ), true ) ) {
					$mode = 'all';
				}
				$row['mode']   = $mode;
				$row['slugs']  = $this->string_list( isset( $cpf['category_facet_slugs'] ) ? $cpf['category_facet_slugs'] : array() );
				$row['nested'] = $this->is_true( isset( $cpf['category_hierarchy'] ) ? $cpf['category_hierarchy'] : false );
			}
			$facets[ $tax ] = $row;
			++$order;
		}

		$facets['price'] = array(
			'id'              => 'price',
			'enabled'         => ! $this->is_true( isset( $cpf['hide_price'] ) ? $cpf['hide_price'] : false ),
			'label'           => '',
			'type'            => 'price',
			'order'           => $order,
			'hidden_terms'    => array(),
			'hidden_term_ids' => array(),
			'mode'            => 'all',
			'slugs'           => array(),
			'nested'          => false,
			'large_ok'        => false,
		);

		$mobile = isset( $cpf['tablet_mobile_display'] ) ? (string) $cpf['tablet_mobile_display'] : 'drawer';
		if ( ! in_array( $mobile, array( 'drawer', 'collapsible', 'sidebar' ), true ) ) {
			$mobile = 'drawer';
		}

		$mapped = array(
			'facets'  => $facets,
			'pinned'  => $this->map_pinned( $cpf ),
			'seed'    => array(
				'known' => $known,
			),
			'display' => array(
				'mobile' => $mobile,
			),
			'sort'    => array(
				'honor_page_order' => $this->flag( $cpf, 'page_collection_honor_orderby', true ),
			),
			'seo'     => array(
				'robots_disallow'   => $this->flag( $cpf, 'crawl_robots_disallow', true ),
				'canonical_noindex' => $this->flag( $cpf, 'crawl_canonical_noindex', true ),
				'nofollow_facets'   => $this->flag( $cpf, 'crawl_nofollow_facets', true ),
				'index_shallow'     => array_key_exists( 'index_shallow_filters', $cpf ) ? $this->is_true( $cpf['index_shallow_filters'] ) : false,
			),
			'wizard'  => array(
				'completed' => true,
			),
		);

		unset( $from_version );
		return $mapped;
	}

	/**
	 * Build a stable taxonomy order from the observed option keys.
	 *
	 * @param array<string, mixed> $cpf         Raw settings.
	 * @param array<int, string>   $hidden      Hidden taxonomies.
	 * @param array<int, string>   $known       Seeded known attributes.
	 * @param array<int, string>   $confirmed   Large-facet confirmations.
	 * @param array<string, mixed> $hidden_map  Hidden terms map.
	 * @return array<int, string>
	 */
	private function taxonomy_order( $cpf, $hidden, $known, $confirmed, $hidden_map ) {
		$order = array( 'product_cat' );
		foreach ( $known as $tax ) {
			if ( ! in_array( $tax, $order, true ) ) {
				$order[] = $tax;
			}
		}
		foreach ( array_merge( $hidden, $confirmed, array_keys( $hidden_map ) ) as $tax ) {
			$tax = $this->sanitize_id( $tax );
			if ( '' !== $tax && ! in_array( $tax, $order, true ) ) {
				$order[] = $tax;
			}
		}
		unset( $cpf );
		return $order;
	}

	/**
	 * Map pinned tags, including the 0.5.0 legacy tag_facet_* shape.
	 *
	 * Legacy keys are used only when the pinned_tags key is absent.
	 *
	 * @param array<string, mixed> $cpf Raw settings.
	 * @return array<string, mixed>
	 */
	private function map_pinned( $cpf ) {
		if ( array_key_exists( 'pinned_tags', $cpf ) || array_key_exists( 'pinned_tags_enabled', $cpf ) ) {
			$match = isset( $cpf['pinned_tags_match'] ) ? strtolower( (string) $cpf['pinned_tags_match'] ) : 'or';
			if ( ! in_array( $match, array( 'and', 'or' ), true ) ) {
				$match = 'or';
			}
			return array(
				'enabled'    => $this->is_true( isset( $cpf['pinned_tags_enabled'] ) ? $cpf['pinned_tags_enabled'] : false ),
				'match'      => $match,
				'tags'       => $this->tag_rows( isset( $cpf['pinned_tags'] ) ? $cpf['pinned_tags'] : array() ),
				'categories' => $this->string_list( isset( $cpf['pinned_tags_categories'] ) ? $cpf['pinned_tags_categories'] : array() ),
				'shop'       => $this->flag( $cpf, 'pinned_tags_shop', true ),
			);
		}

		$slugs = $this->string_list( isset( $cpf['tag_facet_slugs'] ) ? $cpf['tag_facet_slugs'] : array() );
		$label = isset( $cpf['tag_facet_label'] ) ? sanitize_text_field( (string) $cpf['tag_facet_label'] ) : '';
		$tags  = array();
		foreach ( $slugs as $slug ) {
			$tags[] = array(
				'slug'  => $slug,
				'label' => '' !== $label ? $label : $slug,
			);
		}
		return array(
			'enabled'    => $this->is_true( isset( $cpf['tag_facet_enabled'] ) ? $cpf['tag_facet_enabled'] : false ),
			'match'      => 'or',
			'tags'       => $tags,
			'categories' => array(),
			'shop'       => true,
		);
	}

	/**
	 * Normalize pinned tag rows.
	 *
	 * @param mixed $rows Raw rows.
	 * @return array<int, array{slug: string, label: string}>
	 */
	private function tag_rows( $rows ) {
		$out = array();
		if ( ! is_array( $rows ) ) {
			return $out;
		}
		foreach ( $rows as $row ) {
			if ( is_string( $row ) ) {
				$slug = $this->sanitize_id( $row );
				if ( '' !== $slug ) {
					$out[] = array(
						'slug'  => $slug,
						'label' => $slug,
					);
				}
				continue;
			}
			if ( ! is_array( $row ) ) {
				continue;
			}
			$slug = $this->sanitize_id( isset( $row['slug'] ) ? $row['slug'] : '' );
			if ( '' === $slug ) {
				continue;
			}
			$label = isset( $row['label'] ) ? sanitize_text_field( (string) $row['label'] ) : $slug;
			$out[] = array(
				'slug'  => $slug,
				'label' => '' !== $label ? $label : $slug,
			);
		}
		return $out;
	}

	/**
	 * Look up term IDs for hidden slugs when WordPress term APIs exist.
	 *
	 * @param string             $taxonomy Taxonomy.
	 * @param array<int, string> $slugs    Slugs.
	 * @return array<int, int>
	 */
	private function term_ids( $taxonomy, $slugs ) {
		$ids = array();
		if ( ! function_exists( 'get_term_by' ) ) {
			return $ids;
		}
		foreach ( $slugs as $slug ) {
			$term = get_term_by( 'slug', $slug, $taxonomy );
			if ( $term instanceof \WP_Term ) {
				$ids[] = (int) $term->term_id;
			}
		}
		return $ids;
	}

	/**
	 * Missing-key flag with a default (CPF crawl_* and honor_orderby read as on when missing).
	 *
	 * @param array<string, mixed> $cpf      Raw settings.
	 * @param string               $key      Key.
	 * @param bool                 $fallback Default when missing.
	 * @return bool
	 */
	private function flag( $cpf, $key, $fallback ) {
		if ( ! array_key_exists( $key, $cpf ) ) {
			return $fallback;
		}
		return $this->is_true( $cpf[ $key ] );
	}

	/**
	 * Sanitize a list of slugs or taxonomy names.
	 *
	 * @param mixed $items Raw list.
	 * @return array<int, string>
	 */
	private function string_list( $items ) {
		if ( is_string( $items ) ) {
			$items = preg_split( '/\s*,\s*/', $items );
		}
		if ( ! is_array( $items ) ) {
			return array();
		}
		$out = array();
		foreach ( $items as $item ) {
			$id = $this->sanitize_id( $item );
			if ( '' !== $id ) {
				$out[] = $id;
			}
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * Truthy helper that accepts the shapes observed in option dumps.
	 *
	 * @param mixed $value Raw value.
	 * @return bool
	 */
	private function is_true( $value ) {
		if ( is_bool( $value ) ) {
			return $value;
		}
		if ( is_int( $value ) || is_float( $value ) ) {
			return (bool) $value;
		}
		$normalized = strtolower( trim( (string) $value ) );
		return in_array( $normalized, array( '1', 'true', 'yes', 'on' ), true );
	}

	/**
	 * Sanitize an id or slug.
	 *
	 * @param mixed $id Raw id.
	 * @return string
	 */
	private function sanitize_id( $id ) {
		$id = strtolower( trim( (string) $id ) );
		$id = preg_replace( '/[^a-z0-9_\-]/', '', $id );
		return is_string( $id ) ? $id : '';
	}
}
