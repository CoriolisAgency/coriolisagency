<?php
/**
 * Compatibility shim from the most-used cpf_* hooks to fflf_* equivalents.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Import;

defined( 'ABSPATH' ) || exit;

/**
 * After CPF is no longer serving the storefront, theme or mu-plugin callbacks
 * attached to the old hook names still run through the FFL Filters hooks.
 *
 * The importer never executes CPF plugin code. It only re-applies hooks that
 * a site owner registered themselves.
 */
class Shim {

	/**
	 * Hook map: cpf_* => fflf_*.
	 *
	 * @var array<string, string>
	 */
	const MAP = array(
		'cpf_filter_config'             => 'fflf_filter_config',
		'cpf_default_filter_taxonomies' => 'fflf_default_filter_taxonomies',
		'cpf_robots_disallow_patterns'  => 'fflf_robots_disallow_patterns',
		'cpf_facet_cache_ttl'           => 'fflf_facet_cache_ttl',
	);

	/**
	 * Register forwarding filters.
	 *
	 * @return void
	 */
	public function register() {
		foreach ( self::MAP as $from => $to ) {
			add_filter( $to, array( $this, 'forward' ), 5, 6 );
		}
	}

	/**
	 * Forward the current fflf_* hook's arguments through the matching cpf_* hook.
	 *
	 * @param mixed $value First argument.
	 * @return mixed
	 */
	public function forward( $value ) {
		$current = function_exists( 'current_filter' ) ? current_filter() : '';
		$from    = array_search( $current, self::MAP, true );
		if ( ! is_string( $from ) || '' === $from ) {
			return $value;
		}
		$args = array( $value );
		if ( function_exists( 'func_get_args' ) ) {
			// Capture original arguments before any later mutation.
			$args = func_get_args(); // phpcs:ignore PHPCompatibility.FunctionUse.ArgumentFunctionsReportCurrentValue.NeedsInspection
		}
		if ( function_exists( 'apply_filters_ref_array' ) ) {
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound -- Forwards a documented cpf_* alias.
			return apply_filters_ref_array( $from, $args );
		}
		return $value;
	}
}
