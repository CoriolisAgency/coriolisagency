<?php
/**
 * Dry-run and commit of a CPF settings import.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Import;

use FFL_Filters\Settings\Repository;

defined( 'ABSPATH' ) || exit;

/**
 * Reads cpf_settings (never writes or deletes it), maps, diffs, and saves fflf_settings.
 */
class Service {

	/**
	 * Option that records the last import.
	 *
	 * @var string
	 */
	const IMPORT_OPTION = 'fflf_import';

	/**
	 * Settings repository.
	 *
	 * @var Repository
	 */
	private $repository;

	/**
	 * Detector.
	 *
	 * @var Detector
	 */
	private $detector;

	/**
	 * Mapper.
	 *
	 * @var Mapper
	 */
	private $mapper;

	/**
	 * Diff.
	 *
	 * @var Diff
	 */
	private $diff;

	/**
	 * Constructor.
	 *
	 * @param Repository|null $repository Settings.
	 * @param Detector|null   $detector   Detector.
	 * @param Mapper|null     $mapper     Mapper.
	 * @param Diff|null       $diff       Diff.
	 */
	public function __construct( $repository = null, $detector = null, $mapper = null, $diff = null ) {
		$this->repository = $repository ? $repository : new Repository();
		$this->detector   = $detector ? $detector : new Detector();
		$this->mapper     = $mapper ? $mapper : new Mapper();
		$this->diff       = $diff ? $diff : new Diff();
	}

	/**
	 * Raw cpf_settings option, or an empty array.
	 *
	 * @return array<string, mixed>
	 */
	public function cpf_settings() {
		if ( ! function_exists( 'get_option' ) ) {
			return array();
		}
		$stored = get_option( 'cpf_settings', array() );
		return is_array( $stored ) ? $stored : array();
	}

	/**
	 * Build a dry-run report without writing fflf_settings.
	 *
	 * @param array<string, mixed>|null $cpf Optional override (tests / fixtures).
	 * @return array<string, mixed>
	 */
	public function dry_run( $cpf = null ) {
		$cpf     = is_array( $cpf ) ? $cpf : $this->cpf_settings();
		$version = $this->detector->version();
		$mapped  = $this->mapper->map( $cpf, $version );
		$current = $this->repository->all();
		$merged  = $this->merge( $current, $mapped );
		$diff    = $this->diff->compare( $current, $merged );

		return array(
			'from_version'         => $version,
			'cpf_active'           => $this->detector->is_active(),
			'cpf_installed'        => $this->detector->is_installed(),
			'dual_folder'          => $this->detector->has_dual_folder(),
			'basenames'            => $this->detector->installed_basenames(),
			'hooks'                => $this->detector->hooked_filters(),
			'github_token_defined' => $this->detector->github_token_defined(),
			'dropped_keys'         => $this->present_dropped_keys( $cpf ),
			'mapped'               => $mapped,
			'proposed'             => $merged,
			'diff'                 => $diff,
			'unchanged'            => $this->diff->is_empty( $diff ),
		);
	}

	/**
	 * Write the mapped settings to fflf_settings and record fflf_import.
	 *
	 * @param array<string, mixed>|null $cpf Optional override.
	 * @return array<string, mixed> The dry-run report plus the saved settings.
	 */
	public function commit( $cpf = null ) {
		$report = $this->dry_run( $cpf );
		$saved  = $this->repository->save( $report['proposed'] );
		$record = array(
			'from_version' => $report['from_version'],
			'at'           => function_exists( 'time' ) ? time() : 0,
			'diff'         => $report['diff'],
		);
		if ( function_exists( 'update_option' ) ) {
			update_option( self::IMPORT_OPTION, $record, false );
		}
		$report['saved']  = $saved;
		$report['import'] = $record;
		return $report;
	}

	/**
	 * Last import record, if any.
	 *
	 * @return array<string, mixed>
	 */
	public function last_import() {
		if ( ! function_exists( 'get_option' ) ) {
			return array();
		}
		$stored = get_option( self::IMPORT_OPTION, array() );
		return is_array( $stored ) ? $stored : array();
	}

	/**
	 * Merge mapped CPF values onto current FFL Filters settings, keeping
	 * FFL-only keys such as presets and per-category sets.
	 *
	 * @param array<string, mixed> $current Current settings.
	 * @param array<string, mixed> $mapped  Mapped CPF settings.
	 * @return array<string, mixed>
	 */
	private function merge( $current, $mapped ) {
		$out = is_array( $current ) ? $current : array();
		foreach ( array( 'facets', 'pinned', 'seed', 'display', 'sort', 'seo', 'wizard' ) as $key ) {
			if ( isset( $mapped[ $key ] ) ) {
				$out[ $key ] = $mapped[ $key ];
			}
		}
		// Display also holds FFL-only keys (automatic placement, panel heading) that the
		// previous plugin has no value for: keep them, so a re-import is a no-op.
		if ( isset( $mapped['display'] ) && is_array( $mapped['display'] ) && isset( $current['display'] ) && is_array( $current['display'] ) ) {
			$out['display'] = array_merge( $current['display'], $mapped['display'] );
		}
		return $out;
	}

	/**
	 * Dropped keys that are present on the CPF option (reported, not imported).
	 *
	 * @param array<string, mixed> $cpf Raw settings.
	 * @return array<int, string>
	 */
	private function present_dropped_keys( $cpf ) {
		$out = array();
		foreach ( Mapper::DROPPED_KEYS as $key ) {
			if ( array_key_exists( $key, $cpf ) ) {
				$out[] = $key;
			}
		}
		return $out;
	}
}
