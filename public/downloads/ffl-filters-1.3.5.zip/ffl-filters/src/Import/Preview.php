<?php
/**
 * Admin-only storefront preview while CPF still serves everyone else.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Import;

defined( 'ABSPATH' ) || exit;

/**
 * Cookie + user-meta preview flag. Capability-checked and nonce'd at the
 * admin-post boundary. While the flag is on for this admin, FFL Filters
 * is not passive and CPF callbacks are unhooked for this request only.
 */
class Preview {

	/**
	 * Cookie / user-meta key.
	 *
	 * @var string
	 */
	const KEY = 'fflf_preview';

	/**
	 * Cookie lifetime in seconds.
	 *
	 * @var int
	 */
	const TTL = 7200;

	/**
	 * Detector.
	 *
	 * @var Detector
	 */
	private $detector;

	/**
	 * Constructor.
	 *
	 * @param Detector|null $detector Detector.
	 */
	public function __construct( $detector = null ) {
		$this->detector = $detector ? $detector : new Detector();
	}

	/**
	 * Hook the late unhook of CPF callbacks when preview is on.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'init', array( $this, 'maybe_unhook_compare_plugin' ), 1 );
	}

	/**
	 * Whether the current user may preview FFL Filters on the storefront.
	 *
	 * @return bool
	 */
	public function is_active() {
		if ( ! function_exists( 'is_user_logged_in' ) || ! is_user_logged_in() ) {
			return false;
		}
		if ( ! $this->user_can() ) {
			return false;
		}
		$user_id = function_exists( 'get_current_user_id' ) ? get_current_user_id() : 0;
		if ( $user_id <= 0 ) {
			return false;
		}

		$meta = function_exists( 'get_user_meta' ) ? get_user_meta( $user_id, self::KEY, true ) : array();
		if ( ! $this->record_is_valid( $meta, $user_id ) ) {
			return false;
		}

		$cookie = '';
		if ( isset( $_COOKIE[ self::KEY ] ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$cookie = sanitize_text_field( wp_unslash( $_COOKIE[ self::KEY ] ) );
		}
		if ( '' === $cookie ) {
			return false;
		}
		$expected = $this->token( $user_id, isset( $meta['nonce'] ) ? (string) $meta['nonce'] : '' );
		return hash_equals( $expected, $cookie );
	}

	/**
	 * Turn preview on for the current user.
	 *
	 * @return bool
	 */
	public function enable() {
		if ( ! $this->user_can() ) {
			return false;
		}
		$user_id = get_current_user_id();
		$nonce   = function_exists( 'wp_generate_password' ) ? wp_generate_password( 20, false ) : bin2hex( random_bytes( 10 ) );
		$record  = array(
			'user_id' => $user_id,
			'exp'     => time() + self::TTL,
			'nonce'   => $nonce,
		);
		update_user_meta( $user_id, self::KEY, $record );
		if ( ! headers_sent() ) {
			setcookie( self::KEY, $this->token( $user_id, $nonce ), time() + self::TTL, defined( 'COOKIEPATH' ) ? COOKIEPATH : '/', defined( 'COOKIE_DOMAIN' ) ? COOKIE_DOMAIN : '', is_ssl(), true );
		}
		$_COOKIE[ self::KEY ] = $this->token( $user_id, $nonce );
		return true;
	}

	/**
	 * Turn preview off for the current user.
	 *
	 * @return void
	 */
	public function disable() {
		$user_id = function_exists( 'get_current_user_id' ) ? get_current_user_id() : 0;
		if ( $user_id && function_exists( 'delete_user_meta' ) ) {
			delete_user_meta( $user_id, self::KEY );
		}
		if ( ! headers_sent() ) {
			setcookie( self::KEY, '', time() - 3600, defined( 'COOKIEPATH' ) ? COOKIEPATH : '/', defined( 'COOKIE_DOMAIN' ) ? COOKIE_DOMAIN : '', is_ssl(), true );
		}
		unset( $_COOKIE[ self::KEY ] );
	}

	/**
	 * Unhook CPF callbacks for this request when preview is active.
	 *
	 * Identifies callbacks by the file path WordPress already loaded, never
	 * by opening CPF source.
	 *
	 * @return void
	 */
	public function maybe_unhook_compare_plugin() {
		if ( ! $this->is_active() || ! $this->detector->is_active() ) {
			return;
		}
		if ( ! isset( $GLOBALS['wp_filter'] ) ) {
			return;
		}
		foreach ( $GLOBALS['wp_filter'] as $tag => $hook ) {
			if ( ! is_object( $hook ) || empty( $hook->callbacks ) || ! is_array( $hook->callbacks ) ) {
				continue;
			}
			foreach ( $hook->callbacks as $priority => $callbacks ) {
				if ( ! is_array( $callbacks ) ) {
					continue;
				}
				foreach ( $callbacks as $cb ) {
					if ( empty( $cb['function'] ) ) {
						continue;
					}
					if ( ! $this->callback_belongs_to_cpf( $cb['function'] ) ) {
						continue;
					}
					remove_filter( (string) $tag, $cb['function'], (int) $priority );
				}
			}
		}
	}

	/**
	 * Current user can manage the importer.
	 *
	 * @return bool
	 */
	private function user_can() {
		return function_exists( 'current_user_can' ) && current_user_can( 'manage_woocommerce' );
	}

	/**
	 * Validate a stored preview record.
	 *
	 * @param mixed $record Record.
	 * @param int   $user_id Current user.
	 * @return bool
	 */
	private function record_is_valid( $record, $user_id ) {
		if ( ! is_array( $record ) ) {
			return false;
		}
		if ( (int) ( isset( $record['user_id'] ) ? $record['user_id'] : 0 ) !== (int) $user_id ) {
			return false;
		}
		$exp = isset( $record['exp'] ) ? (int) $record['exp'] : 0;
		return $exp >= time() && ! empty( $record['nonce'] );
	}

	/**
	 * Build the cookie token.
	 *
	 * @param int    $user_id User id.
	 * @param string $nonce   Secret.
	 * @return string
	 */
	private function token( $user_id, $nonce ) {
		$payload = (string) $user_id . '|' . $nonce;
		if ( function_exists( 'wp_hash' ) ) {
			return wp_hash( $payload );
		}
		return hash( 'sha256', $payload );
	}

	/**
	 * Whether a hook callback lives in a CPF plugin folder.
	 *
	 * @param mixed $callback Callback.
	 * @return bool
	 */
	private function callback_belongs_to_cpf( $callback ) {
		$file = $this->callback_file( $callback );
		if ( '' === $file ) {
			return false;
		}
		$normalized = str_replace( '\\', '/', strtolower( $file ) );
		return false !== strpos( $normalized, '/' . Detector::FOLDER_PREFIX );
	}

	/**
	 * File path for a callable, via Reflection only.
	 *
	 * @param mixed $callback Callback.
	 * @return string
	 */
	private function callback_file( $callback ) {
		try {
			if ( is_string( $callback ) && function_exists( $callback ) ) {
				$ref = new \ReflectionFunction( $callback );
				return (string) $ref->getFileName();
			}
			if ( is_array( $callback ) && isset( $callback[0], $callback[1] ) ) {
				$ref = new \ReflectionMethod( $callback[0], $callback[1] );
				return (string) $ref->getFileName();
			}
			if ( is_object( $callback ) && ! ( $callback instanceof \Closure ) && method_exists( $callback, '__invoke' ) ) {
				$ref = new \ReflectionMethod( $callback, '__invoke' );
				return (string) $ref->getFileName();
			}
			if ( $callback instanceof \Closure ) {
				$ref = new \ReflectionFunction( $callback );
				return (string) $ref->getFileName();
			}
		} catch ( \ReflectionException $e ) {
			return '';
		}
		return '';
	}
}
