<?php
/**
 * Coexistence notice on the Plugins screen and FFL Filters screens.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Import;

defined( 'ABSPATH' ) || exit;

/**
 * One dismissible admin notice pointing at Import & preview and Switch now.
 */
class Notice {

	/**
	 * User meta key for dismissal.
	 *
	 * @var string
	 */
	const DISMISS_META = 'fflf_dismiss_cpf_notice';

	/**
	 * Detector.
	 *
	 * @var Detector
	 */
	private $detector;

	/**
	 * Constructor.
	 *
	 * @param Detector|null $detector Detector.
	 */
	public function __construct( $detector = null ) {
		$this->detector = $detector ? $detector : new Detector();
	}

	/**
	 * Hook the notice and dismiss handler.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_notices', array( $this, 'render' ) );
		add_action( 'admin_post_fflf_dismiss_cpf_notice', array( $this, 'handle_dismiss' ) );
	}

	/**
	 * Render the notice on Plugins and FFL Filters screens only.
	 *
	 * @return void
	 */
	public function render() {
		if ( ! $this->detector->is_active() ) {
			return;
		}
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		if ( ! $this->is_target_screen() ) {
			return;
		}
		$user_id = get_current_user_id();
		if ( $user_id && get_user_meta( $user_id, self::DISMISS_META, true ) ) {
			return;
		}

		$import  = admin_url( 'admin.php?page=ffl-filters&tab=import' );
		$dismiss = wp_nonce_url( admin_url( 'admin-post.php?action=fflf_dismiss_cpf_notice' ), 'fflf_dismiss_cpf_notice' );

		echo '<div class="notice notice-info is-dismissible fflf-cpf-notice">';
		echo '<p>' . esc_html__( 'Your previous filter plugin is active. Import its settings on the FFL Filters Import tab, preview, then switch.', 'ffl-filters' ) . '</p>';
		echo '<p>';
		echo '<a class="button button-primary" href="' . esc_url( $import ) . '">' . esc_html__( 'Import & preview', 'ffl-filters' ) . '</a> ';
		echo '<a class="button" href="' . esc_url( $import ) . '#fflf-switch-now">' . esc_html__( 'Switch now', 'ffl-filters' ) . '</a> ';
		echo '<a class="button-link" href="' . esc_url( $dismiss ) . '">' . esc_html__( 'Dismiss', 'ffl-filters' ) . '</a>';
		echo '</p>';
		echo '</div>';
	}

	/**
	 * Persist dismissal.
	 *
	 * @return void
	 */
	public function handle_dismiss() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to manage FFL Filters.', 'ffl-filters' ) );
		}
		check_admin_referer( 'fflf_dismiss_cpf_notice' );
		$user_id = get_current_user_id();
		if ( $user_id ) {
			update_user_meta( $user_id, self::DISMISS_META, 1 );
		}
		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : admin_url( 'plugins.php' ) );
		exit;
	}

	/**
	 * Plugins screen or the FFL Filters settings page.
	 *
	 * @return bool
	 */
	private function is_target_screen() {
		if ( function_exists( 'get_current_screen' ) ) {
			$screen = get_current_screen();
			if ( $screen ) {
				$id = (string) $screen->id;
				if ( 'plugins' === $id || false !== strpos( $id, 'ffl-filters' ) ) {
					return true;
				}
			}
		}
		$page    = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$pagenow = isset( $GLOBALS['pagenow'] ) ? (string) $GLOBALS['pagenow'] : '';
		return 'ffl-filters' === $page || 'plugins.php' === $pagenow;
	}
}
