<?php
/**
 * Switch now, rollback, and optional CPF data cleanup.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Import;

defined( 'ABSPATH' ) || exit;

/**
 * Deactivates or reactivates CPF without deleting any of its data.
 *
 * Switch now must finish in well under two minutes: it only calls
 * deactivate_plugins() in the same request. Rollback reactivates CPF
 * and deactivates FFL Filters, restoring CPF exactly.
 */
class Switcher {

	/**
	 * Rollback option name.
	 *
	 * @var string
	 */
	const ROLLBACK_OPTION = 'fflf_rollback';

	/**
	 * Rollback window in seconds (30 days).
	 *
	 * @var int
	 */
	const ROLLBACK_TTL = 2592000;

	/**
	 * Detector.
	 *
	 * @var Detector
	 */
	private $detector;

	/**
	 * Constructor.
	 *
	 * @param Detector|null $detector Detector.
	 */
	public function __construct( $detector = null ) {
		$this->detector = $detector ? $detector : new Detector();
	}

	/**
	 * Deactivate every active CPF copy. FFL Filters stays active.
	 *
	 * Does not delete cpf_settings, transients, or the plugin folder.
	 *
	 * @return array<string, mixed>
	 */
	public function switch_now() {
		$this->ensure_plugin_api();
		$start     = microtime( true );
		$basenames = $this->detector->active_basenames();
		$version   = $this->detector->version();
		$at        = time();

		if ( $basenames && function_exists( 'deactivate_plugins' ) ) {
			deactivate_plugins( $basenames, false, false );
		}

		$elapsed = microtime( true ) - $start;
		$record  = array(
			'cpf_version'       => $version,
			'cpf_was_active_at' => $at,
			'basenames'         => $basenames,
			'switch_seconds'    => $elapsed,
		);
		if ( function_exists( 'update_option' ) ) {
			update_option( self::ROLLBACK_OPTION, $record, false );
		}

		return $record;
	}

	/**
	 * Deactivate FFL Filters and reactivate the stored CPF copy.
	 *
	 * Nothing of CPF's is rewritten: its option, transients, and files stay
	 * as they were, so the storefront returns to CPF exactly.
	 *
	 * @return array<string, mixed>
	 */
	public function rollback() {
		$this->ensure_plugin_api();
		$record    = $this->record();
		$basenames = isset( $record['basenames'] ) && is_array( $record['basenames'] ) ? $record['basenames'] : array();
		if ( array() === $basenames ) {
			$basenames = $this->detector->installed_basenames();
		}
		if ( ! $basenames ) {
			$basenames = array( $this->detector->primary_basename() );
		}

		if ( function_exists( 'activate_plugins' ) ) {
			activate_plugins( $basenames, '', false, false );
		}

		if ( defined( 'FFLF_BASENAME' ) && function_exists( 'deactivate_plugins' ) ) {
			deactivate_plugins( FFLF_BASENAME, false, false );
		}

		$record['rolled_back_at'] = time();
		if ( function_exists( 'update_option' ) ) {
			update_option( self::ROLLBACK_OPTION, $record, false );
		}
		return $record;
	}

	/**
	 * Delete leftover CPF options and transients only after the plugin folder is gone.
	 *
	 * @return array{ok: bool, deleted: array<int, string>, error: string}
	 */
	public function cleanup_cpf_data() {
		if ( $this->detector->is_installed() || $this->detector->is_active() ) {
			return array(
				'ok'      => false,
				'deleted' => array(),
				'error'   => 'cpf_still_installed',
			);
		}

		$deleted = array();
		if ( function_exists( 'delete_option' ) ) {
			if ( delete_option( 'cpf_settings' ) ) {
				$deleted[] = 'cpf_settings';
			}
			if ( delete_option( 'cpf_facet_cache_misses' ) ) {
				$deleted[] = 'cpf_facet_cache_misses';
			}
		}

		global $wpdb;
		if ( isset( $wpdb ) && $wpdb instanceof \wpdb ) {
			$like         = $wpdb->esc_like( '_transient_cpf_' ) . '%';
			$timeout_like = $wpdb->esc_like( '_transient_timeout_cpf_' ) . '%';
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->query(
				$wpdb->prepare(
					"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
					$like,
					$timeout_like
				)
			);
		}

		return array(
			'ok'      => true,
			'deleted' => $deleted,
			'error'   => '',
		);
	}

	/**
	 * Stored rollback record.
	 *
	 * @return array<string, mixed>
	 */
	public function record() {
		if ( ! function_exists( 'get_option' ) ) {
			return array();
		}
		$stored = get_option( self::ROLLBACK_OPTION, array() );
		return is_array( $stored ) ? $stored : array();
	}

	/**
	 * Whether the Switch-back button should be shown.
	 *
	 * @return bool
	 */
	public function rollback_available() {
		if ( ! $this->detector->is_installed() ) {
			return false;
		}
		$record = $this->record();
		if ( empty( $record['cpf_was_active_at'] ) ) {
			return false;
		}
		$at = (int) $record['cpf_was_active_at'];
		return ( time() - $at ) <= self::ROLLBACK_TTL;
	}

	/**
	 * Load plugin.php when deactivate_plugins is not already available.
	 *
	 * @return void
	 */
	private function ensure_plugin_api() {
		if ( function_exists( 'deactivate_plugins' ) && function_exists( 'activate_plugins' ) ) {
			return;
		}
		if ( ! defined( 'ABSPATH' ) ) {
			return;
		}
		$path = ABSPATH . 'wp-admin/includes/plugin.php';
		if ( is_readable( $path ) ) {
			require_once $path;
		}
	}
}
