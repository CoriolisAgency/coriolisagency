<?php
/**
 * Black-box detection of Coriolis Product Filters.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Import;

defined( 'ABSPATH' ) || exit;

/**
 * Detects CPF presence, version, dual-folder installs, and cpf_* hooks.
 *
 * Never opens CPF PHP source. Version comes from the CPF_VERSION constant
 * when the plugin is loaded, or from WordPress plugin headers otherwise.
 */
class Detector {

	/**
	 * Folder prefix used by every measured CPF install, including dual-folder
	 * leftover copies.
	 *
	 * @var string
	 */
	const FOLDER_PREFIX = 'coriolis-product-filters';

	/**
	 * Most-used cpf_* hooks that the compatibility shim aliases.
	 *
	 * @var array<int, string>
	 */
	const SHIMMED_HOOKS = array(
		'cpf_filter_config',
		'cpf_default_filter_taxonomies',
		'cpf_robots_disallow_patterns',
		'cpf_facet_cache_ttl',
	);

	/**
	 * Whether any CPF copy is active.
	 *
	 * @return bool
	 */
	public function is_active() {
		if ( function_exists( 'fflf_compare_plugin_is_active' ) ) {
			return fflf_compare_plugin_is_active();
		}
		if ( defined( 'CPF_VERSION' ) ) {
			return true;
		}
		foreach ( $this->active_basenames() as $basename ) {
			if ( 0 === strpos( $basename, self::FOLDER_PREFIX ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Whether a CPF plugin folder still exists on disk (active or not).
	 *
	 * @return bool
	 */
	public function is_installed() {
		return array() !== $this->installed_basenames();
	}

	/**
	 * Detected CPF version string, or an empty string when unknown.
	 *
	 * @return string
	 */
	public function version() {
		if ( defined( 'CPF_VERSION' ) ) {
			return (string) constant( 'CPF_VERSION' );
		}
		foreach ( $this->plugin_headers() as $header ) {
			if ( ! empty( $header['Version'] ) ) {
				return (string) $header['Version'];
			}
		}
		return '';
	}

	/**
	 * Active plugin basenames whose folder starts with the CPF prefix.
	 *
	 * @return array<int, string>
	 */
	public function active_basenames() {
		if ( ! function_exists( 'get_option' ) ) {
			return array();
		}
		$out = array();
		foreach ( (array) get_option( 'active_plugins', array() ) as $plugin ) {
			$plugin = (string) $plugin;
			if ( 0 === strpos( $plugin, self::FOLDER_PREFIX ) ) {
				$out[] = $plugin;
			}
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * Installed plugin basenames (active or not) under the CPF prefix.
	 *
	 * @return array<int, string>
	 */
	public function installed_basenames() {
		$out = array();
		foreach ( $this->plugin_headers() as $basename => $header ) {
			$out[] = (string) $basename;
		}
		if ( array() === $out ) {
			$out = $this->active_basenames();
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * Whether more than one CPF folder is present (the Naples dual-folder case).
	 *
	 * @return bool
	 */
	public function has_dual_folder() {
		$folders = array();
		foreach ( $this->installed_basenames() as $basename ) {
			$parts = explode( '/', str_replace( '\\', '/', $basename ) );
			if ( isset( $parts[0] ) && '' !== $parts[0] ) {
				$folders[ $parts[0] ] = true;
			}
		}
		return count( $folders ) > 1;
	}

	/**
	 * Preferred basename to activate or deactivate.
	 *
	 * @return string
	 */
	public function primary_basename() {
		$active = $this->active_basenames();
		if ( isset( $active[0] ) ) {
			return $active[0];
		}
		$installed = $this->installed_basenames();
		foreach ( $installed as $basename ) {
			if ( self::FOLDER_PREFIX . '/' . self::FOLDER_PREFIX . '.php' === $basename ) {
				return $basename;
			}
		}
		return isset( $installed[0] ) ? $installed[0] : self::FOLDER_PREFIX . '/' . self::FOLDER_PREFIX . '.php';
	}

	/**
	 * Hook names starting with cpf_ that currently have callbacks, via has_filter() only.
	 *
	 * @return array<int, string>
	 */
	public function hooked_filters() {
		$names   = self::SHIMMED_HOOKS;
		$filters = isset( $GLOBALS['wp_filter'] ) ? $GLOBALS['wp_filter'] : null;
		if ( is_array( $filters ) || $filters instanceof \Traversable ) {
			foreach ( $filters as $tag => $unused ) {
				$tag = (string) $tag;
				if ( 0 === strpos( $tag, 'cpf_' ) ) {
					$names[] = $tag;
				}
			}
		}
		$found = array();
		foreach ( array_unique( $names ) as $tag ) {
			if ( function_exists( 'has_filter' ) && has_filter( $tag ) ) {
				$found[] = $tag;
			}
		}
		return $found;
	}

	/**
	 * Whether CPF_GITHUB_TOKEN is defined in the environment.
	 *
	 * @return bool
	 */
	public function github_token_defined() {
		return defined( 'CPF_GITHUB_TOKEN' );
	}

	/**
	 * Plugin headers for installed CPF copies. Uses get_plugins() so this
	 * file never opens CPF source.
	 *
	 * @return array<string, array<string, string>>
	 */
	private function plugin_headers() {
		if ( ! function_exists( 'get_plugins' ) ) {
			$path = defined( 'ABSPATH' ) ? ABSPATH . 'wp-admin/includes/plugin.php' : '';
			if ( $path && is_readable( $path ) ) {
				require_once $path;
			}
		}
		if ( ! function_exists( 'get_plugins' ) ) {
			return array();
		}
		$out = array();
		foreach ( (array) get_plugins() as $basename => $header ) {
			if ( 0 === strpos( (string) $basename, self::FOLDER_PREFIX ) ) {
				$out[ (string) $basename ] = is_array( $header ) ? $header : array();
			}
		}
		return $out;
	}
}
