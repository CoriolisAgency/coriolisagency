<?php
/**
 * Dry-run diff between current FFL Filters settings and a mapped CPF import.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Import;

defined( 'ABSPATH' ) || exit;

/**
 * Produces a list of added, removed, and changed dotted paths.
 */
class Diff {

	/**
	 * Compare two settings arrays.
	 *
	 * @param array<string, mixed> $current Current fflf_settings.
	 * @param array<string, mixed> $proposed Mapped / merged proposal.
	 * @return array{added: array<string, mixed>, removed: array<string, mixed>, changed: array<string, array{from: mixed, to: mixed}>}
	 */
	public function compare( $current, $proposed ) {
		$current  = is_array( $current ) ? $current : array();
		$proposed = is_array( $proposed ) ? $proposed : array();
		$left     = $this->flatten( $current );
		$right    = $this->flatten( $proposed );
		$added    = array();
		$removed  = array();
		$changed  = array();

		foreach ( $right as $path => $value ) {
			if ( ! array_key_exists( $path, $left ) ) {
				$added[ $path ] = $value;
			} elseif ( $left[ $path ] !== $value ) {
				$changed[ $path ] = array(
					'from' => $left[ $path ],
					'to'   => $value,
				);
			}
		}
		foreach ( $left as $path => $value ) {
			if ( ! array_key_exists( $path, $right ) ) {
				$removed[ $path ] = $value;
			}
		}

		return array(
			'added'   => $added,
			'removed' => $removed,
			'changed' => $changed,
		);
	}

	/**
	 * Whether the diff contains any changes.
	 *
	 * @param array<string, mixed> $diff Diff.
	 * @return bool
	 */
	public function is_empty( $diff ) {
		return empty( $diff['added'] ) && empty( $diff['removed'] ) && empty( $diff['changed'] );
	}

	/**
	 * Flatten a nested array to dotted paths. Lists of scalars stay as arrays.
	 *
	 * @param mixed  $data Data.
	 * @param string $prefix Path prefix.
	 * @return array<string, mixed>
	 */
	private function flatten( $data, $prefix = '' ) {
		$out = array();
		if ( ! is_array( $data ) ) {
			$out[ $prefix ] = $data;
			return $out;
		}
		if ( $this->is_scalar_list( $data ) ) {
			$out[ $prefix ] = array_values( $data );
			return $out;
		}
		if ( array() === $data && '' !== $prefix ) {
			$out[ $prefix ] = array();
			return $out;
		}
		foreach ( $data as $key => $value ) {
			$path = '' === $prefix ? (string) $key : $prefix . '.' . $key;
			$out  = array_merge( $out, $this->flatten( $value, $path ) );
		}
		return $out;
	}

	/**
	 * Whether an array is a list of scalars (or empty).
	 *
	 * @param array $data Data.
	 * @return bool
	 */
	private function is_scalar_list( $data ) {
		if ( array() === $data ) {
			return false;
		}
		$i = 0;
		foreach ( $data as $key => $value ) {
			if ( $key !== $i ) {
				return false;
			}
			if ( is_array( $value ) ) {
				return false;
			}
			++$i;
		}
		return true;
	}
}
