<?php
/**
 * Default firearm presets (attribute names and industry synonyms).
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Presets;

defined( 'ABSPATH' ) || exit;

/**
 * Built-in preset catalog.
 *
 * Attribute *names* reflect aggregate public-catalog observations: some shops
 * expose both caliber-gauge and bullet-caliber; a type attribute is often
 * registered as atf-type; barrel-length, capacity, bullet-weight-grains, and
 * magnification are commonly numeric. No live term lists are stored here.
 * Synonym members are industry cartridge names. User-facing type labels are
 * always "Firearm type" and never imply an ATF endorsement.
 */
class Defaults {

	/**
	 * Virtual caliber facet id and request group key.
	 *
	 * @var string
	 */
	const CALIBER_ID = 'caliber';

	/**
	 * Default backing attribute taxonomies for the merged caliber facet.
	 *
	 * @return array<int, string>
	 */
	public static function caliber_taxonomies() {
		return array( 'pa_caliber-gauge', 'pa_bullet-caliber' );
	}

	/**
	 * Industry synonym groups. Members are labels; slugs are derived.
	 *
	 * @return array<int, array{slug: string, label: string, members: array<int, string>}>
	 */
	public static function caliber_merges() {
		return array(
			array(
				'slug'    => '9mm',
				'label'   => '9mm',
				'members' => array( '9mm', '9mm Luger', '9x19', '9x19mm', '9 mm' ),
			),
			array(
				'slug'    => '223-remington',
				'label'   => '.223 Remington',
				'members' => array( '.223', '.223 Remington', '223 rem', '5.56', '5.56 NATO' ),
			),
			array(
				'slug'    => '308-winchester',
				'label'   => '.308 Winchester',
				'members' => array( '.308', '.308 Winchester', '308 win', '7.62 NATO' ),
			),
			array(
				'slug'    => '45-acp',
				'label'   => '.45 ACP',
				'members' => array( '.45 ACP', '45 Auto', '.45 Auto', '45 ACP' ),
			),
			array(
				'slug'    => '40-sw',
				'label'   => '.40 S&W',
				'members' => array( '.40 S&W', '40 SW', '.40', '40 S&W' ),
			),
			array(
				'slug'    => '380-acp',
				'label'   => '.380 ACP',
				'members' => array( '.380 ACP', '380 Auto', '9mm Kurz', '9x17' ),
			),
			array(
				'slug'    => '12-gauge',
				'label'   => '12 Gauge',
				'members' => array( '12 Gauge', '12 GA', '12ga', '12 Ga' ),
			),
			array(
				'slug'    => '20-gauge',
				'label'   => '20 Gauge',
				'members' => array( '20 Gauge', '20 GA', '20ga' ),
			),
			array(
				'slug'    => '22-lr',
				'label'   => '.22 LR',
				'members' => array( '.22 LR', '22 Long Rifle', '.22 Long Rifle', '22lr', '22 LR' ),
			),
			array(
				'slug'    => '7-62x39',
				'label'   => '7.62x39',
				'members' => array( '7.62x39', '7.62×39', '762x39' ),
			),
			array(
				'slug'    => '300-blackout',
				'label'   => '.300 Blackout',
				'members' => array( '.300 BLK', '300 Blackout', '300 AAC', '.300 AAC Blackout' ),
			),
			array(
				'slug'    => '65-creedmoor',
				'label'   => '6.5 Creedmoor',
				'members' => array( '6.5 Creedmoor', '6.5 CM', '6.5 Creed' ),
			),
			array(
				'slug'    => '357-magnum',
				'label'   => '.357 Magnum',
				'members' => array( '.357 Mag', '357 Magnum', '.357 Magnum' ),
			),
			array(
				'slug'    => '38-special',
				'label'   => '.38 Special',
				'members' => array( '.38 Special', '38 Spl', '.38 SPL', '38 Special' ),
			),
		);
	}

	/**
	 * Attributes treated as numeric ranges by default (taxonomy => unit).
	 *
	 * @return array<string, string>
	 */
	public static function range_units() {
		return array(
			'pa_barrel-length'        => 'in',
			'pa_capacity'             => '',
			'pa_bullet-weight-grains' => 'gr',
			'pa_magnification'        => 'x',
		);
	}

	/**
	 * Catalog type-attribute taxonomies, in preference order.
	 *
	 * @return array<int, string>
	 */
	public static function firearm_type_taxonomies() {
		return array( 'pa_atf-type', 'pa_atf_type' );
	}

	/**
	 * User-facing label for the catalog type facet. Never "ATF type".
	 *
	 * @return string
	 */
	public static function firearm_type_label() {
		return 'Firearm type';
	}

	/**
	 * Default in-store tag slug.
	 *
	 * @return string
	 */
	public static function instore_slug() {
		return 'in-store';
	}

	/**
	 * Default in-store taxonomy.
	 *
	 * @return string
	 */
	public static function instore_taxonomy() {
		return 'product_tag';
	}

	/**
	 * User-facing in-store label.
	 *
	 * @return string
	 */
	public static function instore_label() {
		return 'In store';
	}
}
