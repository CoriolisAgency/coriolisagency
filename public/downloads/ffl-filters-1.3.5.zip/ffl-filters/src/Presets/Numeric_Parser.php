<?php
/**
 * Parse catalog term labels into numeric values or intervals.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Presets;

defined( 'ABSPATH' ) || exit;

/**
 * Dealer-reviewable numeric mapping with an automatic parser for common shapes.
 *
 * Understands values like 16", 16 in, 10+1 (summed to 11), and 3-9x (an interval).
 * Overrides in settings always win over the parser.
 */
class Numeric_Parser {

	/**
	 * Attribute taxonomy => unit (may be empty).
	 *
	 * @var array<string, string>
	 */
	private $units;

	/**
	 * Taxonomy => slug => float (single-value overrides).
	 *
	 * @var array<string, array<string, float>>
	 */
	private $overrides;

	/**
	 * Constructor.
	 *
	 * @param array<string, string>               $units     Taxonomy => unit.
	 * @param array<string, array<string, float>> $overrides Taxonomy => slug => value.
	 */
	public function __construct( $units = array(), $overrides = array() ) {
		$this->units     = is_array( $units ) && $units ? $units : Defaults::range_units();
		$this->overrides = is_array( $overrides ) ? $overrides : array();
	}

	/**
	 * Whether this taxonomy is a configured numeric range.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @return bool
	 */
	public function is_range_taxonomy( $taxonomy ) {
		return isset( $this->units[ (string) $taxonomy ] );
	}

	/**
	 * Whether a request key is a min_/max_ param for a configured range.
	 *
	 * @param string $key Request key.
	 * @return bool
	 */
	public function is_range_param( $key ) {
		$key = (string) $key;
		if ( 'min_price' === $key || 'max_price' === $key ) {
			return false;
		}
		if ( 0 !== strpos( $key, 'min_' ) && 0 !== strpos( $key, 'max_' ) ) {
			return false;
		}
		return '' !== $this->taxonomy_for_param( $key );
	}

	/**
	 * Taxonomy for a min_* or max_* range param, or empty.
	 *
	 * @param string $key Request key.
	 * @return string
	 */
	public function taxonomy_for_param( $key ) {
		$key    = (string) $key;
		$prefix = '';
		if ( 0 === strpos( $key, 'min_' ) ) {
			$prefix = 'min_';
		} elseif ( 0 === strpos( $key, 'max_' ) ) {
			$prefix = 'max_';
		}
		if ( '' === $prefix ) {
			return '';
		}
		$slug = substr( $key, strlen( $prefix ) );
		if ( '' === $slug || 'price' === $slug ) {
			return '';
		}
		$taxonomy = 0 === strpos( $slug, 'pa_' ) ? $slug : 'pa_' . $slug;
		return $this->is_range_taxonomy( $taxonomy ) ? $taxonomy : '';
	}

	/**
	 * Request key for the minimum of a taxonomy range.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @return string
	 */
	public function min_param( $taxonomy ) {
		return 'min_' . $this->attribute_slug( $taxonomy );
	}

	/**
	 * Request key for the maximum of a taxonomy range.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @return string
	 */
	public function max_param( $taxonomy ) {
		return 'max_' . $this->attribute_slug( $taxonomy );
	}

	/**
	 * Unit label for a taxonomy.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @return string
	 */
	public function unit( $taxonomy ) {
		$taxonomy = (string) $taxonomy;
		return isset( $this->units[ $taxonomy ] ) ? (string) $this->units[ $taxonomy ] : '';
	}

	/**
	 * Configured range taxonomies.
	 *
	 * @return array<int, string>
	 */
	public function taxonomies() {
		return array_keys( $this->units );
	}

	/**
	 * Parsed interval for a term slug/label, or null when unparseable.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @param string $slug     Term slug.
	 * @param string $label    Term label (optional).
	 * @return array{min: float, max: float}|null
	 */
	public function interval( $taxonomy, $slug, $label = '' ) {
		$taxonomy = (string) $taxonomy;
		$slug     = (string) $slug;
		if ( isset( $this->overrides[ $taxonomy ][ $slug ] ) && is_numeric( $this->overrides[ $taxonomy ][ $slug ] ) ) {
			$value = (float) $this->overrides[ $taxonomy ][ $slug ];
			return array(
				'min' => $value,
				'max' => $value,
			);
		}

		$parsed = $this->parse( '' !== $label ? $label : $slug );
		if ( null === $parsed ) {
			$parsed = $this->parse( $slug );
		}
		return $parsed;
	}

	/**
	 * Whether an interval overlaps an inclusive selected range.
	 *
	 * @param array{min: float, max: float} $interval Term interval.
	 * @param float|null                    $min      Selected min.
	 * @param float|null                    $max      Selected max.
	 * @return bool
	 */
	public function overlaps( $interval, $min, $max ) {
		if ( ! is_array( $interval ) ) {
			return false;
		}
		$low  = isset( $interval['min'] ) ? (float) $interval['min'] : 0.0;
		$high = isset( $interval['max'] ) ? (float) $interval['max'] : $low;
		if ( null !== $min && $high < (float) $min ) {
			return false;
		}
		if ( null !== $max && $low > (float) $max ) {
			return false;
		}
		return true;
	}

	/**
	 * Parse a label into a numeric interval.
	 *
	 * @param string $label Raw label.
	 * @return array{min: float, max: float}|null
	 */
	public function parse( $label ) {
		$label = trim( (string) $label );
		if ( '' === $label ) {
			return null;
		}
		$label = str_replace( array( '×', '−', '–', '—' ), array( 'x', '-', '-', '-' ), $label );

		if ( preg_match( '/(\d+(?:\.\d+)?)\s*\+\s*(\d+(?:\.\d+)?)/', $label, $match ) ) {
			$value = (float) $match[1] + (float) $match[2];
			return array(
				'min' => $value,
				'max' => $value,
			);
		}

		if ( preg_match( '/(\d+(?:\.\d+)?)\s*(?:x|-)\s*(\d+(?:\.\d+)?)\s*x?/i', $label, $match ) ) {
			$first  = (float) $match[1];
			$second = (float) $match[2];
			return array(
				'min' => min( $first, $second ),
				'max' => max( $first, $second ),
			);
		}

		if ( preg_match( '/(\d+(?:\.\d+)?)/', $label, $match ) ) {
			$value = (float) $match[1];
			return array(
				'min' => $value,
				'max' => $value,
			);
		}

		return null;
	}

	/**
	 * Attribute slug.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @return string
	 */
	private function attribute_slug( $taxonomy ) {
		$taxonomy = (string) $taxonomy;
		if ( 0 === strpos( $taxonomy, 'pa_' ) ) {
			return substr( $taxonomy, 3 );
		}
		return $taxonomy;
	}
}
