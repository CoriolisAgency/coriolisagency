<?php
/**
 * Dealer-configured firearm presets, with built-in defaults.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Presets;

use FFL_Filters\Settings\Repository as Settings_Repository;

defined( 'ABSPATH' ) || exit;

/**
 * Reads the presets section of fflf_settings.
 */
class Config {

	/**
	 * Settings snapshot.
	 *
	 * @var array<string, mixed>
	 */
	private $presets;

	/**
	 * Cached synonyms.
	 *
	 * @var Synonyms|null
	 */
	private $synonyms;

	/**
	 * Cached numeric helper.
	 *
	 * @var Numeric_Parser|null
	 */
	private $numeric;

	/**
	 * Constructor.
	 *
	 * @param array<string, mixed>|null $presets Presets slice, or null to load settings.
	 */
	public function __construct( $presets = null ) {
		if ( is_array( $presets ) ) {
			$this->presets = $presets;
			return;
		}
		$all           = ( new Settings_Repository() )->all();
		$this->presets = isset( $all['presets'] ) && is_array( $all['presets'] ) ? $all['presets'] : array();
	}

	/**
	 * Sanitize a presets payload into the stored shape.
	 *
	 * @param mixed $input Raw input.
	 * @return array<string, mixed>
	 */
	public static function sanitize( $input ) {
		$input   = is_array( $input ) ? $input : array();
		$caliber = isset( $input['caliber'] ) && is_array( $input['caliber'] ) ? $input['caliber'] : array();
		$ranges  = isset( $input['ranges'] ) && is_array( $input['ranges'] ) ? $input['ranges'] : array();
		$type    = isset( $input['firearm_type'] ) && is_array( $input['firearm_type'] ) ? $input['firearm_type'] : array();
		$instore = isset( $input['instore'] ) && is_array( $input['instore'] ) ? $input['instore'] : array();

		$taxonomies = self::sanitize_taxonomy_list(
			isset( $caliber['taxonomies'] ) ? $caliber['taxonomies'] : Defaults::caliber_taxonomies()
		);
		if ( array() === $taxonomies ) {
			$taxonomies = Defaults::caliber_taxonomies();
		}

		$type_taxonomy = isset( $type['taxonomy'] ) ? self::sanitize_taxonomy( (string) $type['taxonomy'] ) : '';
		if ( '' === $type_taxonomy ) {
			$type_taxonomy = Defaults::firearm_type_taxonomies()[0];
		}

		$type_label = isset( $type['label'] ) ? sanitize_text_field( (string) $type['label'] ) : '';
		if ( '' === $type_label || self::looks_like_atf_endorsement( $type_label ) ) {
			$type_label = Defaults::firearm_type_label();
		}

		$instore_label = isset( $instore['label'] ) ? sanitize_text_field( (string) $instore['label'] ) : '';
		if ( '' === $instore_label ) {
			$instore_label = Defaults::instore_label();
		}

		$instore_tax = isset( $instore['taxonomy'] ) ? self::sanitize_taxonomy( (string) $instore['taxonomy'] ) : '';
		if ( '' === $instore_tax ) {
			$instore_tax = Defaults::instore_taxonomy();
		}

		$instore_slug = isset( $instore['slug'] ) ? sanitize_title( (string) $instore['slug'] ) : '';
		if ( '' === $instore_slug ) {
			$instore_slug = Defaults::instore_slug();
		}

		return array(
			'caliber'      => array(
				'enabled'    => self::flag( isset( $caliber['enabled'] ) ? $caliber['enabled'] : true, true ),
				'label'      => ( isset( $caliber['label'] ) && '' !== sanitize_text_field( (string) $caliber['label'] ) )
					? sanitize_text_field( (string) $caliber['label'] )
					: 'Caliber',
				'taxonomies' => $taxonomies,
				'merges'     => self::sanitize_merges( isset( $caliber['merges'] ) ? $caliber['merges'] : Defaults::caliber_merges() ),
			),
			'ranges'       => self::sanitize_ranges( $ranges ),
			'firearm_type' => array(
				'enabled'  => self::flag( isset( $type['enabled'] ) ? $type['enabled'] : true, true ),
				'taxonomy' => $type_taxonomy,
				'label'    => $type_label,
			),
			'instore'      => array(
				'enabled'  => self::flag( isset( $instore['enabled'] ) ? $instore['enabled'] : true, true ),
				'label'    => $instore_label,
				'taxonomy' => $instore_tax,
				'slug'     => $instore_slug,
			),
		);
	}

	/**
	 * Whether the merged caliber facet is on.
	 *
	 * @return bool
	 */
	public function caliber_enabled() {
		return ! isset( $this->presets['caliber']['enabled'] ) || ! empty( $this->presets['caliber']['enabled'] );
	}

	/**
	 * Caliber facet label.
	 *
	 * @return string
	 */
	public function caliber_label() {
		$label = isset( $this->presets['caliber']['label'] ) ? (string) $this->presets['caliber']['label'] : '';
		return '' !== $label ? $label : 'Caliber';
	}

	/**
	 * Backing caliber taxonomies.
	 *
	 * @return array<int, string>
	 */
	public function caliber_taxonomies() {
		$list = isset( $this->presets['caliber']['taxonomies'] ) && is_array( $this->presets['caliber']['taxonomies'] )
			? $this->presets['caliber']['taxonomies']
			: Defaults::caliber_taxonomies();
		return array_values( array_filter( array_map( 'strval', $list ) ) );
	}

	/**
	 * Synonym helper for the stored merge list.
	 *
	 * @return Synonyms
	 */
	public function synonyms() {
		if ( ! $this->synonyms ) {
			$merges         = isset( $this->presets['caliber']['merges'] ) ? $this->presets['caliber']['merges'] : array();
			$this->synonyms = new Synonyms( is_array( $merges ) ? $merges : array() );
		}
		return $this->synonyms;
	}

	/**
	 * Numeric helper for the stored range map.
	 *
	 * @return Numeric_Parser
	 */
	public function numeric() {
		if ( ! $this->numeric ) {
			$ranges    = isset( $this->presets['ranges'] ) && is_array( $this->presets['ranges'] ) ? $this->presets['ranges'] : array();
			$units     = array();
			$overrides = array();
			if ( array() === $ranges ) {
				$units = Defaults::range_units();
			} else {
				foreach ( $ranges as $taxonomy => $row ) {
					if ( is_array( $row ) && ! empty( $row['enabled'] ) ) {
						$units[ (string) $taxonomy ] = isset( $row['unit'] ) ? (string) $row['unit'] : '';
						if ( isset( $row['values'] ) && is_array( $row['values'] ) ) {
							$overrides[ (string) $taxonomy ] = $row['values'];
						}
					}
				}
			}
			$this->numeric = new Numeric_Parser( $units, $overrides );
		}
		return $this->numeric;
	}

	/**
	 * Whether the firearm type facet is on.
	 *
	 * @return bool
	 */
	public function firearm_type_enabled() {
		return ! isset( $this->presets['firearm_type']['enabled'] ) || ! empty( $this->presets['firearm_type']['enabled'] );
	}

	/**
	 * Preferred catalog type taxonomy.
	 *
	 * @return string
	 */
	public function firearm_type_taxonomy() {
		$taxonomy = isset( $this->presets['firearm_type']['taxonomy'] ) ? (string) $this->presets['firearm_type']['taxonomy'] : '';
		return '' !== $taxonomy ? $taxonomy : Defaults::firearm_type_taxonomies()[0];
	}

	/**
	 * User-facing firearm type label (never an ATF endorsement).
	 *
	 * @return string
	 */
	public function firearm_type_label() {
		$label = isset( $this->presets['firearm_type']['label'] ) ? (string) $this->presets['firearm_type']['label'] : '';
		if ( '' === $label || self::looks_like_atf_endorsement( $label ) ) {
			return Defaults::firearm_type_label();
		}
		return $label;
	}

	/**
	 * Whether a taxonomy should be presented as Firearm type.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @return bool
	 */
	public function is_firearm_type_taxonomy( $taxonomy ) {
		$taxonomy = (string) $taxonomy;
		if ( $taxonomy === $this->firearm_type_taxonomy() ) {
			return true;
		}
		return in_array( $taxonomy, Defaults::firearm_type_taxonomies(), true );
	}

	/**
	 * Whether the in-store toggle is on.
	 *
	 * @return bool
	 */
	public function instore_enabled() {
		return ! isset( $this->presets['instore']['enabled'] ) || ! empty( $this->presets['instore']['enabled'] );
	}

	/**
	 * In-store toggle label.
	 *
	 * @return string
	 */
	public function instore_label() {
		$label = isset( $this->presets['instore']['label'] ) ? (string) $this->presets['instore']['label'] : '';
		return '' !== $label ? $label : Defaults::instore_label();
	}

	/**
	 * In-store taxonomy.
	 *
	 * @return string
	 */
	public function instore_taxonomy() {
		$taxonomy = isset( $this->presets['instore']['taxonomy'] ) ? (string) $this->presets['instore']['taxonomy'] : '';
		return '' !== $taxonomy ? $taxonomy : Defaults::instore_taxonomy();
	}

	/**
	 * In-store term slug.
	 *
	 * @return string
	 */
	public function instore_slug() {
		$slug = isset( $this->presets['instore']['slug'] ) ? (string) $this->presets['instore']['slug'] : '';
		return '' !== $slug ? $slug : Defaults::instore_slug();
	}

	/**
	 * Flag.
	 *
	 * @param mixed $value    Raw flag.
	 * @param bool  $fallback Default.
	 * @return bool
	 */
	private static function flag( $value, $fallback ) {
		if ( is_bool( $value ) ) {
			return $value;
		}
		if ( null === $value || '' === $value ) {
			return $fallback;
		}
		$normalized = strtolower( trim( (string) $value ) );
		if ( in_array( $normalized, array( 'no', 'false', '0', 'off' ), true ) ) {
			return false;
		}
		if ( in_array( $normalized, array( 'yes', 'true', '1', 'on' ), true ) ) {
			return true;
		}
		return $fallback;
	}

	/**
	 * Sanitize merges.
	 *
	 * @param mixed $merges Raw merges.
	 * @return array<int, array{slug: string, label: string, members: array<int, string>}>
	 */
	private static function sanitize_merges( $merges ) {
		if ( is_string( $merges ) ) {
			$merges = self::parse_merge_text( $merges );
		}
		if ( ! is_array( $merges ) || array() === $merges ) {
			return Defaults::caliber_merges();
		}
		$out      = array();
		$synonyms = new Synonyms( array() );
		foreach ( $merges as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$label   = isset( $row['label'] ) ? sanitize_text_field( (string) $row['label'] ) : '';
			$slug    = isset( $row['slug'] ) ? $synonyms->slugify( (string) $row['slug'] ) : $synonyms->slugify( $label );
			$members = array();
			if ( isset( $row['members'] ) ) {
				$raw = $row['members'];
				if ( is_string( $raw ) ) {
					$raw = preg_split( '/\s*,\s*/', $raw );
				}
				if ( is_array( $raw ) ) {
					foreach ( $raw as $member ) {
						$member = sanitize_text_field( (string) $member );
						if ( '' !== $member ) {
							$members[] = $member;
						}
					}
				}
			}
			if ( '' === $slug ) {
				continue;
			}
			$out[] = array(
				'slug'    => $slug,
				'label'   => '' !== $label ? $label : $slug,
				'members' => $members,
			);
		}
		return $out ? $out : Defaults::caliber_merges();
	}

	/**
	 * Parse merge text.
	 *
	 * @param string $text One rule per line: "9mm = 9mm, 9mm Luger, 9x19".
	 * @return array<int, array{slug: string, label: string, members: array<int, string>}>
	 */
	public static function parse_merge_text( $text ) {
		$out = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $line ) {
			$line = trim( $line );
			if ( '' === $line || 0 === strpos( $line, '#' ) ) {
				continue;
			}
			$label   = $line;
			$members = array();
			if ( false !== strpos( $line, '=' ) ) {
				$parts   = array_map( 'trim', explode( '=', $line, 2 ) );
				$label   = $parts[0];
				$members = preg_split( '/\s*,\s*/', $parts[1] );
			}
			$out[] = array(
				'slug'    => $label,
				'label'   => $label,
				'members' => is_array( $members ) ? $members : array(),
			);
		}
		return $out;
	}

	/**
	 * Sanitize ranges.
	 *
	 * @param mixed $ranges Raw ranges.
	 * @return array<string, array{enabled: bool, unit: string, values: array<string, float>}>
	 */
	private static function sanitize_ranges( $ranges ) {
		$base = Defaults::range_units();
		$out  = array();
		foreach ( $base as $taxonomy => $unit ) {
			$row      = isset( $ranges[ $taxonomy ] ) && is_array( $ranges[ $taxonomy ] ) ? $ranges[ $taxonomy ] : array();
			$values   = array();
			$raw_vals = isset( $row['values'] ) ? $row['values'] : array();
			if ( is_string( $raw_vals ) ) {
				$raw_vals = self::parse_values_text( $raw_vals );
			}
			if ( is_array( $raw_vals ) ) {
				foreach ( $raw_vals as $slug => $value ) {
					$slug = sanitize_title( (string) $slug );
					if ( '' === $slug || ! is_numeric( $value ) ) {
						continue;
					}
					$values[ $slug ] = (float) $value;
				}
			}
			$out[ $taxonomy ] = array(
				'enabled' => self::flag( isset( $row['enabled'] ) ? $row['enabled'] : true, true ),
				'unit'    => isset( $row['unit'] ) ? sanitize_text_field( (string) $row['unit'] ) : $unit,
				'values'  => $values,
			);
		}
		return $out;
	}

	/**
	 * Parse values text.
	 *
	 * @param string $text One "slug=16" pair per line.
	 * @return array<string, float>
	 */
	public static function parse_values_text( $text ) {
		$out = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $line ) {
			$line = trim( $line );
			if ( '' === $line || false === strpos( $line, '=' ) ) {
				continue;
			}
			$parts = array_map( 'trim', explode( '=', $line, 2 ) );
			if ( '' === $parts[0] || ! is_numeric( $parts[1] ) ) {
				continue;
			}
			$out[ $parts[0] ] = (float) $parts[1];
		}
		return $out;
	}

	/**
	 * Sanitize taxonomy list.
	 *
	 * @param mixed $items Raw list.
	 * @return array<int, string>
	 */
	private static function sanitize_taxonomy_list( $items ) {
		if ( is_string( $items ) ) {
			$items = preg_split( '/\s*,\s*/', $items );
		}
		if ( ! is_array( $items ) ) {
			return array();
		}
		$out = array();
		foreach ( $items as $item ) {
			$taxonomy = self::sanitize_taxonomy( (string) $item );
			if ( '' !== $taxonomy ) {
				$out[] = $taxonomy;
			}
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * Sanitize taxonomy.
	 *
	 * @param string $taxonomy Raw taxonomy.
	 * @return string
	 */
	private static function sanitize_taxonomy( $taxonomy ) {
		$taxonomy = strtolower( trim( $taxonomy ) );
		$taxonomy = preg_replace( '/[^a-z0-9_\-]/', '', $taxonomy );
		return is_string( $taxonomy ) ? $taxonomy : '';
	}

	/**
	 * Reject labels that would read as an ATF endorsement.
	 *
	 * @param string $label Proposed label.
	 * @return bool
	 */
	private static function looks_like_atf_endorsement( $label ) {
		$normalized = strtolower( trim( $label ) );
		return (bool) preg_match( '/\batf\b/', $normalized );
	}
}
