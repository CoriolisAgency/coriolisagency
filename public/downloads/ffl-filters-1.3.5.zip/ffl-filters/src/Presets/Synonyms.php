<?php
/**
 * Caliber synonym matching and expansion.
 *
 * @package FFL_Filters
 */

namespace FFL_Filters\Presets;

defined( 'ABSPATH' ) || exit;

/**
 * Maps variant slugs and labels onto a canonical caliber group.
 */
class Synonyms {

	/**
	 * Canonical slug => group.
	 *
	 * @var array<string, array{slug: string, label: string, members: array<int, string>}>
	 */
	private $groups = array();

	/**
	 * Normalized token => canonical slug.
	 *
	 * @var array<string, string>
	 */
	private $index = array();

	/**
	 * Constructor.
	 *
	 * @param array<int, array{slug?: string, label?: string, members?: array<int, string>}> $merges Merge rules.
	 */
	public function __construct( $merges = array() ) {
		if ( ! is_array( $merges ) || array() === $merges ) {
			$merges = Defaults::caliber_merges();
		}
		foreach ( $merges as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$label   = isset( $row['label'] ) ? (string) $row['label'] : '';
			$slug    = isset( $row['slug'] ) ? $this->slugify( (string) $row['slug'] ) : $this->slugify( $label );
			$members = isset( $row['members'] ) && is_array( $row['members'] ) ? $row['members'] : array();
			if ( '' === $slug ) {
				continue;
			}
			if ( '' === $label ) {
				$label = $slug;
			}
			$tokens = array( $slug, $label );
			foreach ( $members as $member ) {
				$tokens[] = (string) $member;
			}
			$unique = array();
			foreach ( $tokens as $token ) {
				$norm = $this->normalize( $token );
				if ( '' === $norm ) {
					continue;
				}
				$unique[]             = $token;
				$this->index[ $norm ] = $slug;
			}
			$this->groups[ $slug ] = array(
				'slug'    => $slug,
				'label'   => $label,
				'members' => array_values( array_unique( $unique ) ),
			);
		}
	}

	/**
	 * Canonical slug for a term slug or label, or a slugified fallback.
	 *
	 * @param string $token Slug or label.
	 * @return string
	 */
	public function canonical_slug( $token ) {
		$norm = $this->normalize( $token );
		if ( '' !== $norm && isset( $this->index[ $norm ] ) ) {
			return $this->index[ $norm ];
		}
		$slug = $this->slugify( $token );
		return '' !== $slug ? $slug : $norm;
	}

	/**
	 * Canonical label for a token.
	 *
	 * @param string $token Slug or label.
	 * @return string
	 */
	public function canonical_label( $token ) {
		$slug = $this->canonical_slug( $token );
		if ( isset( $this->groups[ $slug ] ) ) {
			return $this->groups[ $slug ]['label'];
		}
		return (string) $token;
	}

	/**
	 * Member strings (labels and slugs) in a canonical group, plus the token itself.
	 *
	 * @param string $token Canonical slug, member slug, or label.
	 * @return array<int, string>
	 */
	public function members( $token ) {
		$slug = $this->canonical_slug( $token );
		if ( isset( $this->groups[ $slug ] ) ) {
			return $this->groups[ $slug ]['members'];
		}
		return array( (string) $token );
	}

	/**
	 * Possible lookup slugs for a selected canonical value.
	 *
	 * @param string $token Selected slug or label.
	 * @return array<int, string>
	 */
	public function lookup_slugs( $token ) {
		$out = array();
		foreach ( $this->members( $token ) as $member ) {
			$slug = $this->slugify( $member );
			if ( '' !== $slug ) {
				$out[] = $slug;
			}
		}
		$direct = $this->slugify( $token );
		if ( '' !== $direct ) {
			$out[] = $direct;
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * Fold a list of taxonomy terms into canonical caliber rows.
	 *
	 * @param array<int, array<string, mixed>> $terms Terms with slug, label, count, selected.
	 * @return array<int, array<string, mixed>>
	 */
	public function merge_terms( $terms ) {
		$buckets = array();
		$order   = array();
		if ( ! is_array( $terms ) ) {
			return array();
		}
		foreach ( $terms as $term ) {
			if ( ! is_array( $term ) || empty( $term['slug'] ) ) {
				continue;
			}
			$slug      = (string) $term['slug'];
			$canonical = $this->canonical_slug( $slug );
			if ( ! isset( $buckets[ $canonical ] ) ) {
				$buckets[ $canonical ] = array(
					'slug'     => $canonical,
					'label'    => $this->canonical_label( isset( $term['label'] ) ? (string) $term['label'] : $slug ),
					'count'    => 0,
					'selected' => false,
					'members'  => array(),
				);
				$order[]               = $canonical;
			}
			$buckets[ $canonical ]['count']    += isset( $term['count'] ) ? (int) $term['count'] : 0;
			$buckets[ $canonical ]['selected']  = ! empty( $buckets[ $canonical ]['selected'] ) || ! empty( $term['selected'] );
			$buckets[ $canonical ]['members'][] = $slug;
		}

		$out = array();
		foreach ( $order as $canonical ) {
			$row            = $buckets[ $canonical ];
			$row['members'] = array_values( array_unique( $row['members'] ) );
			$out[]          = $row;
		}
		return $out;
	}

	/**
	 * Normalize.
	 *
	 * @param string $token Raw token.
	 * @return string
	 */
	public function normalize( $token ) {
		$token = strtolower( trim( (string) $token ) );
		$token = str_replace( array( '×', '−' ), array( 'x', '-' ), $token );
		$token = preg_replace( '/[^a-z0-9x]+/', '', $token );
		return is_string( $token ) ? $token : '';
	}

	/**
	 * Slugify.
	 *
	 * @param string $token Raw token.
	 * @return string
	 */
	public function slugify( $token ) {
		$token = strtolower( trim( (string) $token ) );
		$token = str_replace( array( '×', '&' ), array( 'x', '' ), $token );
		$token = preg_replace( '/[^a-z0-9]+/', '-', $token );
		$token = is_string( $token ) ? trim( $token, '-' ) : '';
		return $token;
	}
}
