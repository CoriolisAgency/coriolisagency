/*
 * FFL Filters 1.3.2 button edge helper. Assets::edge_script() prints it inline once, right after the first
 * "Filter products" button (the one above the products, or the panel's own drawer button), and calls it after each
 * such button. It sets data-fflf-edge on the button's host (the opener wrap, or the panel) before the button paints,
 * with the same rule as panel.js edgeFor(): none when the button's fill already clears 3:1 against every colour
 * behind the host, else a light (#F3F5F7) or a dark (#1F2933) 1px edge, else nothing (the no-JS two-tone ring
 * stays). A photo behind gives nothing. The backdrop comes from the inline resolver (fflfR(host, 1)).
 * Reading the button's fill computes its style with the two-tone ring, so a theme transition on links (Kadence:
 * a { transition: .1s linear }) would animate the ring to its edge; the button's transition is off for that one
 * style change and back on (inline transition cleared) once the edge has applied.
 * Budget: 320 bytes once printed (tests/phpunit/without-woocommerce/InlineResolverTest.php).
 */
window.fflfE=(h,b)=>{try{let G=getComputedStyle,t=b.style,[s,P,X]=fflfR(h,1)||[],c=P&&P(G(b).backgroundColor);t.transition='none';
c&&c[3]>=.99&&[c,[243,245,247],[31,41,51]].some((c,i)=>X(c,s)>=3&&(h.dataset.fflfEdge=['none','light','dark'][i]));G(b).boxShadow;t.transition=''}catch{}};
