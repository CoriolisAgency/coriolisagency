/*
 * FFL Filters 1.3.5 no-JS drawer opener. Assets::edge_script() prints it inline once, with the first "Filter products"
 * button's edge script, and each such button's script then calls fflfO() right after the button, before any theme
 * script runs. It adds a capture-phase click listener on that button. While panel.js has not set the panel up (no
 * data-fflf-js), a tap marks the panel data-fflf-open, and panel.css opens the drawer and lifts the Show products hold
 * on that mark, the same way it does on :target. The listener stops the tap from reaching any other listener on the
 * page (a theme's smooth-scroll script would take the link and never set :target), but it does not cancel the link,
 * so the address and :target change as they do with JavaScript off. The same tap adds a capture-phase listener on the
 * drawer's Close filters link that clears the mark (the link's own #target clears :target). Once panel.js runs, both
 * listeners step aside and panel.js takes over (initDrawer picks up an open mark).
 * When the panel is not rendered where it sits (a theme hides its sidebar on phones), the tap moves it to the end of
 * the body first, as panel.js liftPanel() does, since no CSS can show a drawer inside a hidden ancestor.
 * The panel is found from the button's #target, so it serves the panel's own button and the one above the products.
 * No theme names, no per-site values. Budget: 400 bytes once printed (InlineResolverTest), its own, so the resolver
 * (2,048) and the edge helper (320) keep theirs.
 */
window.fflfO=(D=document,b=D.currentScript.previousElementSibling,A='addEventListener',s='stopImmediatePropagation')=>b[A]('click',e=>{
let d=D.querySelector(b.hash)?.closest('[data-fflf-panel]'),j=d?.dataset;
j&&!j.fflfJs&&(e[s](),d.getClientRects().length||D.body.append(d),j.fflfOpen=1,d.querySelector('a[data-fflf-drawer-close]')?.[A]('click',e=>{j.fflfJs||(e[s](),delete j.fflfOpen)},!0))},!0);
