/**
 * FFL Filters storefront panel: group toggles, mobile drawer, long-list search against a static
 * per-generation JSON file, and instant apply.
 *
 * Without JS the panel is a plain GET form with a Show products button. With JS every click applies
 * on its own: the script fetches the same URL and swaps panel and grid fragments from the same renderer.
 * The last click wins; older responses are aborted or ignored. Price and range boxes apply about 0.6 s
 * after typing stops. If a fetch fails, the page falls back to a full load of that URL.
 */
(function () {
	'use strict';

	var REDUCED =
		typeof window.matchMedia === 'function' &&
		window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	var DRAWER_MS = REDUCED ? 0 : 80;
	// Some themes hide the whole sidebar on phones (display: none). The drawer cannot show from inside it,
	// so the panel moves to <body> while the drawer is open and goes back to this marker when it closes.
	var liftMarker = null;

	function isRendered(el) {
		return !!(el && el.getClientRects && el.getClientRects().length);
	}

	function liftPanel(panel) {
		if (liftMarker || isRendered(panel) || !panel.parentNode || !document.body) {
			return;
		}
		liftMarker = document.createComment('fflf-panel');
		panel.parentNode.insertBefore(liftMarker, panel);
		document.body.appendChild(panel);
	}

	function dropPanel(panel) {
		if (!liftMarker) {
			return;
		}
		if (liftMarker.parentNode && panel.parentNode) {
			liftMarker.parentNode.insertBefore(panel, liftMarker);
		}
		if (liftMarker.parentNode) {
			liftMarker.parentNode.removeChild(liftMarker);
		}
		liftMarker = null;
	}
	var SEARCH_MS = 150;
	var RANGE_MS = 600;


	function qs(root, selector) {
		return root.querySelector(selector);
	}

	function qsa(root, selector) {
		return Array.prototype.slice.call(root.querySelectorAll(selector));
	}

	function strings() {
		return window.fflfPanel || {};
	}

	function focusables(root) {
		return qsa(
			root,
			'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
		).filter(function (el) {
			return el.offsetParent !== null || el === document.activeElement;
		});
	}

	function norm(value) {
		return String(value || '')
			.toLowerCase()
			.replace(/\s+/g, ' ')
			.trim();
	}

	// Phones get the drawer: 767px and narrower above the products (Paul, 10:13 AM ET), 1024px in a sidebar (1.2.x).
	function phoneMax(panel) {
		return panel && panel.getAttribute && panel.getAttribute('data-fflf-placement') === 'above' ? 767 : 1024;
	}

	function isMobileWidth(panel) {
		return typeof window.matchMedia === 'function' && window.matchMedia('(max-width: ' + phoneMax(panel) + 'px)').matches;
	}

	function setGroupOpen(group, open) {
		var button = qs(group, '[data-fflf-toggle]');
		var targetId = button ? button.getAttribute('aria-controls') : null;
		var target = targetId ? document.getElementById(targetId) : qs(group, '.ffl-filters__options');
		if (button) {
			button.setAttribute('aria-expanded', open ? 'true' : 'false');
		}
		if (target) {
			if (open) {
				target.removeAttribute('hidden');
			} else {
				target.setAttribute('hidden', 'hidden');
			}
		}
		if (open) {
			autoLoadTerms(group);
		}
	}

	function initGroupToggles(panel) {
		qsa(panel, '[data-fflf-toggle]').forEach(function (button) {
			var targetId = button.getAttribute('aria-controls');
			var target = targetId ? document.getElementById(targetId) : null;
			if (!target) {
				return;
			}
			var group = typeof button.closest === 'function' ? button.closest('[data-fflf-group]') : null;
			button.addEventListener('click', function () {
				var open = button.getAttribute('aria-expanded') === 'true';
				if (group) {
					if (!open && isBar(panel)) {
						// One popover at a time.
						closePopovers(panel, group);
					}
					setGroupOpen(group, !open);
					if (!open && isBar(panel)) {
						focusFirstIn(group);
					}
					return;
				}
				button.setAttribute('aria-expanded', open ? 'false' : 'true');
				if (open) {
					target.setAttribute('hidden', 'hidden');
				} else {
					target.removeAttribute('hidden');
				}
			});
		});
	}

	function trapTab(event, drawer) {
		if (event.key !== 'Tab') {
			return;
		}
		var items = focusables(drawer);
		if (!items.length) {
			return;
		}
		var first = items[0];
		var last = items[items.length - 1];
		if (event.shiftKey && document.activeElement === first) {
			event.preventDefault();
			last.focus();
		} else if (!event.shiftKey && document.activeElement === last) {
			event.preventDefault();
			first.focus();
		}
	}

	function initDrawer(panel) {
		if (!panel.classList.contains('ffl-filters--drawer')) {
			return;
		}

		var openBtn = qs(panel, '[data-fflf-drawer-open]');
		var closeBtns = qsa(panel, '[data-fflf-drawer-close]');
		var drawer = qs(panel, '[data-fflf-drawer]');
		if (!openBtn || !drawer) {
			return;
		}

		var lastFocus = null;
		var keyHandler = null;

		function close() {
			if (!panel.classList.contains('is-open')) {
				return;
			}
			panel.classList.remove('is-open');
			dropPanel(panel);
			openBtn.setAttribute('aria-expanded', 'false');
			drawer.setAttribute('aria-modal', 'false');
			drawer.setAttribute('role', 'region');
			document.body.style.overflow = '';
			if (keyHandler) {
				document.removeEventListener('keydown', keyHandler);
				keyHandler = null;
			}
			var back = lastFocus && document.body.contains && document.body.contains(lastFocus) ? lastFocus : openBtn;
			if (back && typeof back.focus === 'function') {
				back.focus();
			}
		}

		function open(restoring) {
			if (!isMobileWidth(panel)) {
				return;
			}
			if (!restoring) {
				lastFocus = document.activeElement;
			}
			liftPanel(panel);
			panel.classList.add('is-open');
			openBtn.setAttribute('aria-expanded', 'true');
			drawer.setAttribute('aria-modal', 'true');
			drawer.setAttribute('role', 'dialog');
			document.body.style.overflow = 'hidden';

			if (!keyHandler) {
				keyHandler = function (event) {
					if (event.key === 'Escape') {
						event.preventDefault();
						close();
						return;
					}
					trapTab(event, drawer);
				};
				document.addEventListener('keydown', keyHandler);
			}

			if (restoring) {
				return;
			}
			window.setTimeout(function () {
				var heading = qs(drawer, '.ffl-filters__title');
				if (heading && typeof heading.focus === 'function') {
					heading.setAttribute('tabindex', '-1');
					heading.focus();
				}
			}, DRAWER_MS);
		}

		// Called when this panel is swapped out: drop the key handler without moving focus.
		function detach() {
			if (keyHandler) {
				document.removeEventListener('keydown', keyHandler);
				keyHandler = null;
			}
		}

		panel.fflfDrawer = { open: open, close: close, detach: detach };

		openBtn.addEventListener('click', function (event) {
			event.preventDefault();
			if (panel.classList.contains('is-open')) {
				close();
			} else {
				open(false);
			}
		});

		closeBtns.forEach(function (btn) {
			btn.addEventListener('click', function (event) {
				if (btn.tagName === 'A') {
					event.preventDefault();
				}
				close();
			});
		});

		// 1.3.5: the drawer was opened before this ran, through the opener's inline listener (data-fflf-open, see
		// assets/js/opener.js): carry it on as open here, so the drawer stays put and closes the usual way.
		if (panel.hasAttribute('data-fflf-open')) {
			panel.removeAttribute('data-fflf-open');
			open(false);
		}
	}

	function initCollapsible(panel) {
		if (!panel.classList.contains('ffl-filters--collapsible')) {
			return;
		}
		var openBtn = qs(panel, '[data-fflf-collapse-open]');
		if (!openBtn) {
			return;
		}
		openBtn.addEventListener('click', function (event) {
			event.preventDefault();
			var open = panel.classList.toggle('is-open');
			openBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
		});
	}

	function idSlug(value) {
		var slug = String(value || '')
			.toLowerCase()
			.replace(/[^a-z0-9\-]+/g, '-')
			.replace(/^-+|-+$/g, '');
		return slug || 'item';
	}

	function formatCount(count) {
		var n = Number(count) || 0;
		if (typeof n.toLocaleString === 'function') {
			return n.toLocaleString();
		}
		return String(n);
	}

	function listOf(group) {
		return qs(group, '[data-fflf-list]') || qs(group, '.ffl-filters__options');
	}

	function existingValues(list) {
		var have = {};
		qsa(list, 'input[type="checkbox"]').forEach(function (input) {
			have[input.value] = true;
		});
		return have;
	}

	function appendTerm(panel, list, group, term) {
		var slug = term && term.slug ? String(term.slug) : '';
		if (!slug) {
			return;
		}
		var param = group.getAttribute('data-fflf-param') || '';
		var facet = group.getAttribute('data-fflf-group') || 'term';
		var label = term.label ? String(term.label) : slug;
		var count = typeof term.count === 'number' ? term.count : 0;
		var inputId = panel.id + '-' + idSlug(facet) + '-' + idSlug(slug);

		if (document.getElementById(inputId)) {
			return;
		}

		var row = document.createElement('label');
		row.className = 'ffl-filters__option';
		row.setAttribute('for', inputId);
		row.setAttribute('data-fflf-label', label);
		row.setAttribute('data-fflf-slug', slug);

		var input = document.createElement('input');
		input.type = 'checkbox';
		input.name = param ? param + '[]' : '';
		input.value = slug;
		input.id = inputId;

		var name = document.createElement('span');
		name.className = 'ffl-filters__option-label';
		name.textContent = label;

		var badge = document.createElement('span');
		badge.className = 'ffl-filters__count';
		badge.textContent = formatCount(count);

		row.appendChild(input);
		row.appendChild(name);
		row.appendChild(badge);
		var showAll = qs(list, '[data-fflf-show-all]');
		if (showAll && showAll.parentNode === list) {
			list.insertBefore(row, showAll);
		} else {
			list.appendChild(row);
		}
	}

	function applySearch(group) {
		var input = qs(group, '[data-fflf-search-input]');
		var status = qs(group, '[data-fflf-search-status]');
		var search = qs(group, '[data-fflf-search]');
		var query = input ? norm(input.value) : '';
		var shown = 0;
		var total = 0;

		qsa(group, '.ffl-filters__option').forEach(function (option) {
			total += 1;
			var box = qs(option, 'input[type="checkbox"]');
			var selected = box && box.checked;
			var label = option.getAttribute('data-fflf-label') || option.textContent;
			var slug = option.getAttribute('data-fflf-slug') || (box ? box.value : '');
			var match = !query || norm(label).indexOf(query) !== -1 || norm(slug).indexOf(query) !== -1;
			if (match || selected) {
				option.removeAttribute('hidden');
				shown += 1;
			} else {
				option.setAttribute('hidden', 'hidden');
			}
		});

		if (!status) {
			return;
		}
		if (!query) {
			status.textContent = '';
			return;
		}
		var declared = Number(group.getAttribute('data-fflf-total')) || 0;
		if (declared > total) {
			total = declared;
		}
		var format = search ? search.getAttribute('data-fflf-count-format') : null;
		var s = strings();
		if (format) {
			// Locked copy pattern, e.g. "1 of 22 brands".
			status.textContent = format.replace('%1$s', formatCount(shown)).replace('%2$s', formatCount(total));
		} else if (shown === 1 && s.matchOne) {
			status.textContent = s.matchOne;
		} else if (s.matchMany) {
			status.textContent = s.matchMany.replace('%s', formatCount(shown));
		} else {
			status.textContent = shown === 1 ? '1 match' : formatCount(shown) + ' matches';
		}
	}

	function searchLabel(group) {
		var legend = qs(group, '.ffl-filters__toggle-label') || qs(group, '.ffl-filters__group-title');
		var name = legend ? String(legend.textContent || '').replace(/\s+/g, ' ').trim() : '';
		return name ? 'Search ' + name : 'Search';
	}

	function slugify(value) {
		return String(value || 'term')
			.toLowerCase()
			.replace(/[^a-z0-9\-]+/g, '-')
			.replace(/^-|-$/g, '') || 'item';
	}

	function ensureSearch(group) {
		var search = qs(group, '[data-fflf-search]');
		if (search) {
			search.removeAttribute('hidden');
			return qs(group, '[data-fflf-search-input]');
		}

		var panel = group.closest ? group.closest('[data-fflf-panel]') : null;
		var panelId = panel && panel.id ? panel.id : 'fflf';
		var facet = group.getAttribute('data-fflf-group') || 'term';
		var id = panelId + '-' + slugify(facet) + '-search';

		search = document.createElement('div');
		search.className = 'ffl-filters__search';
		search.setAttribute('data-fflf-search', '');

		var label = document.createElement('label');
		label.className = 'ffl-filters__visually-hidden';
		label.setAttribute('for', id);
		label.textContent = searchLabel(group);

		var input = document.createElement('input');
		input.type = 'search';
		input.className = 'ffl-filters__search-input';
		input.id = id;
		input.setAttribute('data-fflf-search-input', '');
		input.setAttribute('autocomplete', 'off');

		var status = document.createElement('div');
		status.className = 'ffl-filters__search-status';
		status.setAttribute('data-fflf-search-status', '');
		status.setAttribute('aria-live', 'polite');

		search.appendChild(label);
		search.appendChild(input);
		search.appendChild(status);

		var options = qs(group, '.ffl-filters__options') || group;
		var list = qs(group, '[data-fflf-list]');
		if (list && list.parentNode) {
			list.parentNode.insertBefore(search, list);
		} else {
			var showAll = qs(group, '[data-fflf-show-all]');
			if (showAll && showAll.parentNode) {
				showAll.parentNode.insertBefore(search, showAll);
			} else {
				options.appendChild(search);
			}
		}

		return input;
	}

	/*
	 * Long lists open straight to their values: the first rows are in the markup, and the rest load from
	 * the static JSON file as soon as the group is open. Show all stays only as the no-JS fallback.
	 * A failed load leaves the Show all link in place.
	 */
	function loadTerms(panel, group, link, options) {
		options = options || {};
		var url = link.getAttribute('data-fflf-json');
		var fallback = link.getAttribute('href');
		if (!url || typeof window.fetch !== 'function') {
			if (!options.auto && fallback) {
				window.location = fallback;
			}
			return;
		}

		if (link.getAttribute('data-fflf-loading') === '1') {
			return;
		}
		link.setAttribute('data-fflf-loading', '1');

		window
			.fetch(url, { credentials: 'same-origin' })
			.then(function (res) {
				if (res.status === 301 || res.status === 302) {
					return res.json ? res.json() : Promise.reject(new Error('redirect'));
				}
				if (!res.ok) {
					throw new Error('facet json ' + res.status);
				}
				return res.json();
			})
			.then(function (data) {
				var list = listOf(group);
				if (!list || !data || !data.terms) {
					throw new Error('facet json missing terms');
				}
				var have = existingValues(list);
				data.terms.forEach(function (term) {
					if (!term || have[term.slug]) {
						return;
					}
					appendTerm(panel, list, group, term);
				});
				ensureSearch(group);
				if (options.focus) {
					var input = qs(group, '[data-fflf-search-input]');
					if (input && typeof input.focus === 'function') {
						input.focus();
					}
				}
				link.setAttribute('hidden', 'hidden');
				link.removeAttribute('data-fflf-loading');
				link.setAttribute('data-fflf-loaded', '1');
				applySearch(group);
				if (typeof options.after === 'function') {
					options.after();
				}
			})
			.catch(function () {
				link.removeAttribute('data-fflf-loading');
				if (!options.auto && fallback) {
					window.location = fallback;
				}
			});
	}

	function autoLoadTerms(group, after) {
		var link = qs(group, '[data-fflf-show-all]');
		if (!link || !link.getAttribute('data-fflf-json') || link.getAttribute('data-fflf-loaded') === '1') {
			if (typeof after === 'function') {
				after();
			}
			return;
		}
		var panel = group.closest ? group.closest('[data-fflf-panel]') : null;
		if (!panel) {
			return;
		}
		loadTerms(panel, group, link, { auto: true, after: after });
	}

	function initLargeFacets(panel) {
		qsa(panel, '[data-fflf-large]').forEach(function (group) {
			var link = qs(group, '[data-fflf-show-all]');

			if (link) {
				link.addEventListener('click', function (event) {
					if (!link.getAttribute('data-fflf-json')) {
						return;
					}
					event.preventDefault();
					loadTerms(panel, group, link, { focus: true });
				});
			}

			var options = qs(group, '.ffl-filters__options');
			if (options && !options.hasAttribute('hidden')) {
				autoLoadTerms(group);
			}
		});

		bindSearchDelegate(panel);
	}

	function bindSearchDelegate(panel) {
		if (panel.getAttribute('data-fflf-search-delegate') === '1') {
			return;
		}
		panel.setAttribute('data-fflf-search-delegate', '1');
		var timer = null;
		panel.addEventListener('input', function (event) {
			var input = event.target;
			if (!input || typeof input.hasAttribute !== 'function' || !input.hasAttribute('data-fflf-search-input')) {
				return;
			}
			var group = typeof input.closest === 'function' ? input.closest('[data-fflf-group]') : null;
			if (!group) {
				return;
			}
			window.clearTimeout(timer);
			timer = window.setTimeout(function () {
				applySearch(group);
			}, SEARCH_MS);
		});
	}

	/* ------------------------------------------------------------------ */
	/* Contrast fallback                                                  */
	/* ------------------------------------------------------------------ */

	function parseColor(value) {
		var m = String(value || '').match(/rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:[,\s/]+([\d.]+%?))?\s*\)/i);
		if (!m) {
			return null;
		}
		var alpha = m[4] === undefined ? 1 : m[4].indexOf('%') !== -1 ? parseFloat(m[4]) / 100 : parseFloat(m[4]);
		return { r: +m[1], g: +m[2], b: +m[3], a: alpha };
	}

	function luminance(c) {
		var ch = [c.r, c.g, c.b].map(function (v) {
			v = v / 255;
			return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
		});
		return 0.2126 * ch[0] + 0.7152 * ch[1] + 0.0722 * ch[2];
	}

	function contrast(a, b) {
		var la = luminance(a);
		var lb = luminance(b);
		return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
	}

	function toHex(c) {
		return (
			'#' +
			[c.r, c.g, c.b]
				.map(function (v) {
					var h = Math.max(0, Math.min(255, Math.round(v))).toString(16);
					return h.length === 1 ? '0' + h : h;
				})
				.join('')
		);
	}

	/* Relative luminance under which a background counts as dark (white text reads better than dark text). */
	var DARK_LUM = 0.18;
	var LIGHT_TEXT = { r: 255, g: 255, b: 255, a: 1 };
	var DARK_TEXT = { r: 15, g: 27, b: 45, a: 1 };
	var SURFACES = {
		light: [{ r: 255, g: 255, b: 255, a: 1 }, { r: 245, g: 246, b: 248, a: 1 }],
		dark: [{ r: 20, g: 25, b: 29, a: 1 }, { r: 30, g: 37, b: 43, a: 1 }],
	};
	var NEUTRAL = { light: '#0F1B2D', dark: '#E6EBF0' };
	var WHITE = { r: 255, g: 255, b: 255, a: 1 };
	var BLACK = { r: 0, g: 0, b: 0, a: 1 };
	// The set colours that sit on the page. They are the starting point; plateTokens() steps them to pass on the
	// background actually behind the panel.
	var SET_TEXT = {
		light: { text: '#1F2933', muted: '#52606D', placeholder: '#5E6B78', border: '#7B8594' },
		dark: { text: '#F3F5F7', muted: '#B6BEC7', placeholder: '#A9B2BC', border: '#8E99A4' },
	};

	function computed(el, pseudo) {
		return typeof window.getComputedStyle === 'function' ? window.getComputedStyle(el, pseudo || null) : null;
	}

	function hexColor(hex) {
		var h = String(hex).replace('#', '');
		return { r: parseInt(h.slice(0, 2), 16), g: parseInt(h.slice(2, 4), 16), b: parseInt(h.slice(4, 6), 16), a: 1 };
	}

	function mix(a, b, t) {
		return { r: a.r + (b.r - a.r) * t, g: a.g + (b.g - a.g) * t, b: a.b + (b.b - a.b) * t, a: 1 };
	}

	function solidify(c) {
		return { r: Math.round(c.r), g: Math.round(c.g), b: Math.round(c.b), a: 1 };
	}

	/*
	 * 1.3.1: what is behind the panel. Walks up from the panel's parent, then body and html, laying each painted
	 * layer over the one under it, so the result is always opaque.
	 * - A solid background-color is one colour.
	 * - A gradient gives every colour stop (each laid over what is under it), so text can be checked against all of
	 *   them and the overlays filled from the worst one.
	 * - 1.3.1: a photo or pattern (url()) cannot be measured. When it is the nearest painted layer, the walk stops
	 *   there: no colour from further up the page is used, because the photo hides it. own is the photo
	 *   element's own background-color when it sets one (else null), and stops is [own] or empty.
	 *   A photo under a see-through layer of its own is skipped (the walk goes on under it).
	 * Returns { stops: [opaque colours], kind: 'solid' | 'gradient' | 'photo', own: colour | null }.
	 */
	var MAX_STOPS = 8;

	function gradientStops(image) {
		if (!image || image === 'none' || image.indexOf('gradient(') === -1) {
			return [];
		}
		return (image.match(/rgba?\([^)]+\)/g) || []).map(parseColor).filter(Boolean).slice(0, MAX_STOPS);
	}

	function resolveBackdrop(el) {
		var nodes = [];
		for (var n = el ? el.parentElement : null; n; n = n.parentElement) {
			nodes.push(n);
		}
		[document.body, document.documentElement].forEach(function (node) {
			if (node && nodes.indexOf(node) === -1) {
				nodes.push(node);
			}
		});
		var layers = [];
		var kind = 'solid';
		for (var i = 0; i < nodes.length; i++) {
			var cs = computed(nodes[i]);
			if (!cs) {
				continue;
			}
			var image = String(cs.backgroundImage || 'none');
			var photo = image.indexOf('url(') !== -1;
			var stops = photo ? [] : gradientStops(image);
			var c = parseColor(cs.backgroundColor);
			if (photo && !layers.length) {
				var own = c && c.a > 0 ? solidify(mix(WHITE, c, Math.min(1, c.a))) : null;
				return { stops: own ? [own] : [], kind: 'photo', own: own };
			}
			if (stops.length) {
				kind = 'gradient';
				layers.push(stops);
			}
			if (c && c.a > 0) {
				layers.push([c]);
				if (c.a >= 0.99) {
					break;
				}
			}
			if (stops.length && stops.every(function (s) { return s.a >= 0.99; })) {
				break;
			}
		}
		var out = [WHITE];
		for (var j = layers.length - 1; j >= 0; j--) {
			var next = [];
			out.forEach(function (under) {
				layers[j].forEach(function (top) {
					next.push(mix(under, top, Math.min(1, top.a)));
				});
			});
			out = next.slice(0, MAX_STOPS);
		}
		var seen = {};
		out = out.map(solidify).filter(function (s) {
			var key = toHex(s);
			if (seen[key]) {
				return false;
			}
			seen[key] = true;
			return true;
		});
		return { stops: out, kind: out.length > 1 ? 'gradient' : 'solid', own: null };
	}

	// The stop the overlays are filled from: the one the set's text reads worst on (only one stop: that one).
	function pickFill(stops, set) {
		if (!set || stops.length < 2) {
			return stops[0];
		}
		var base = hexColor(SET_TEXT[set === 'dark' ? 'dark' : 'light'].text);
		return stops.reduce(function (worst, s) {
			return contrast(base, s) < contrast(base, worst) ? s : worst;
		}, stops[0]);
	}

	/*
	 * 1.3.0: the page colour behind the panel (kept for callers that need one colour): the only stop, or for a
	 * gradient the first. See resolveBackdrop().
	 */
	function resolveBackground(el) {
		return resolveBackdrop(el).stops[0] || WHITE;
	}

	function worstContrast(c, bgs) {
		return Math.min.apply(
			null,
			bgs.map(function (b) {
				return contrast(c, b);
			})
		);
	}

	// The first colour from fg toward black or white (whichever reads better) that clears min on every background.
	function ensureContrast(fg, bgs, min) {
		if (worstContrast(fg, bgs) >= min) {
			return solidify(fg);
		}
		var poles = worstContrast(BLACK, bgs) >= worstContrast(WHITE, bgs) ? [BLACK, WHITE] : [WHITE, BLACK];
		for (var p = 0; p < poles.length; p++) {
			for (var i = 1; i <= 20; i++) {
				var c = solidify(mix(fg, poles[p], i / 20));
				if (worstContrast(c, bgs) >= min) {
					return c;
				}
			}
		}
		return poles[0];
	}

	// 1.3.1: aim for target (headroom over the floor, so rounding on real screens cannot tip it under); where the
	// target cannot be reached on every background, the floor.
	var MUTED_AIM = 5;

	function aimContrast(fg, bgs, target, floor) {
		var c = ensureContrast(fg, bgs, target);
		return worstContrast(c, bgs) >= target ? c : ensureContrast(fg, bgs, floor);
	}

	/*
	 * Tokens computed against the resolved page background. Auto: every surface is the page colour (the pills a
	 * light tint of it), so the closed panel blends in and open overlays are opaque in the page's own colour.
	 * Light or Dark (the admin's choice): the set keeps its own surfaces, and only the text that sits straight on
	 * the transparent plate is stepped against the page. Text 4.5:1 (muted text aims for 5:1), control edges 3:1.
	 * stops: every colour behind the plate (a gradient's stops); bg is the one the overlays are filled with.
	 */
	function plateTokens(bg, set, mode, stops) {
		var base = SET_TEXT[set === 'dark' ? 'dark' : 'light'];
		var page = [bg].concat((stops || []).filter(function (s) {
			return toHex(s) !== toHex(bg);
		}));
		var plateText = ensureContrast(hexColor(base.text), page, 4.5);
		var plateMuted = aimContrast(hexColor(base.muted), page, MUTED_AIM, 4.5);
		var out = { 'plate-text': plateText, 'plate-muted': plateMuted };
		if (mode !== 'auto') {
			return out;
		}
		// Pills are a light tint of the page: lighter on a dark set, darker on a light one. On a mid-tone page that
		// would squeeze the text below 4.5:1, so the tint flips direction, and as a last resort the pill is the page.
		var pills = set === 'dark' ? [mix(bg, WHITE, 0.1), mix(bg, BLACK, 0.1)] : [mix(bg, BLACK, 0.05), mix(bg, WHITE, 0.05)];
		pills.push(bg);
		var pill = bg;
		var text = null;
		for (var i = 0; i < pills.length; i++) {
			var candidate = solidify(pills[i]);
			var t = ensureContrast(hexColor(base.text), page.concat([candidate]), 4.5);
			if (worstContrast(t, page.concat([candidate])) >= 4.5) {
				pill = candidate;
				text = t;
				break;
			}
		}
		if (!text) {
			text = ensureContrast(hexColor(base.text), page, 4.5);
		}
		var border = ensureContrast(hexColor(base.border), page.concat([pill]), 3);
		out['plate-text'] = text;
		out['plate-muted'] = aimContrast(hexColor(base.muted), page.concat([pill]), MUTED_AIM, 4.5);
		out.surface = bg;
		out['surface-2'] = pill;
		out.input = bg;
		out.text = text;
		out.muted = out['plate-muted'];
		out.placeholder = ensureContrast(hexColor(base.placeholder), [bg], 4.5);
		out.border = border;
		out.divider = solidify(mix(bg, text, 0.2));
		out.focus = text;
		out['control-off'] = border;
		out.knob = ensureContrast(bg, [border], 3);
		return out;
	}

	// The surfaces the accent must clear: the resolved ones when present, else the set's own.
	function surfacesFor(panel, set) {
		return panel && panel.fflfSurfaces ? panel.fflfSurfaces : SURFACES[set];
	}

	/*
	 * Panel style: Auto picks the dark set on a dark background (every stop dark), the light set on a light one,
	 * and for a mix the set the worst stop needs. The server prints Light; until this runs (and with JS off) the
	 * text on the see-through plate takes the theme's own colour (panel.css, :not([data-fflf-page-bg])).
	 */
	// Inline --fflf-* tokens from an earlier run are cleared first, so a token the new backdrop does not set falls
	// back to the stylesheet (the set's own value, or currentColor for the plate text).
	function writeTokens(panel, tokens) {
		if (!panel.style || typeof panel.style.setProperty !== 'function') {
			return;
		}
		(panel.fflfTokenKeys || []).forEach(function (key) {
			if (!tokens[key] && typeof panel.style.removeProperty === 'function') {
				panel.style.removeProperty('--fflf-' + key);
			}
		});
		Object.keys(tokens).forEach(function (key) {
			panel.style.setProperty('--fflf-' + key, toHex(tokens[key]));
		});
		panel.fflfTokenKeys = Object.keys(tokens);
	}

	/*
	 * 1.3.1: a photo or pattern right behind the panel. It cannot be measured, so:
	 * - the plate text keeps the theme's own text colour, as before JS runs (data-fflf-plate="theme");
	 * - open overlays and the drawer use the light or dark set's own surfaces, chosen by Panel style. On Auto the
	 *   set follows the photo element's own background-color when it sets one (and the overlays fill with it), or
	 *   else the theme's text colour: light text means a dark photo, so the dark set.
	 */
	function photoStyle(panel, backdrop, behind) {
		var own = backdrop.own;
		var cs = computed(panel.parentElement || panel);
		var themeText = cs ? parseColor(cs.color) : null;
		var bg = own ? (luminance(own) < DARK_LUM ? 'dark' : 'light') : themeText && contrast(themeText, BLACK) > contrast(themeText, WHITE) ? 'dark' : 'light';
		panel.setAttribute('data-fflf-bg', bg);
		var mode = panel.getAttribute('data-fflf-style-mode') || 'auto';
		if (mode === 'auto') {
			panel.setAttribute('data-fflf-style', bg);
		}
		var set = panel.getAttribute('data-fflf-style') === 'dark' ? 'dark' : 'light';
		var tokens = {};
		if (mode === 'auto' && own) {
			tokens = plateTokens(own, set, 'auto', [own]);
		}
		delete tokens['plate-text'];
		delete tokens['plate-muted'];
		writeTokens(panel, tokens);
		panel.fflfSurfaces = tokens.surface ? [tokens.surface, tokens['surface-2']] : SURFACES[set];
		panel.setAttribute('data-fflf-backdrop', 'photo');
		panel.setAttribute('data-fflf-plate', 'theme');
		panel.setAttribute('data-fflf-page-bg', toHex(tokens.surface || SURFACES[set][0]));
		return behind;
	}

	function detectStyle(panel) {
		var backdrop = resolveBackdrop(panel);
		var behind = edgeBackdrop(backdrop);
		if (backdrop.kind === 'photo') {
			return photoStyle(panel, backdrop, behind);
		}
		panel.removeAttribute('data-fflf-plate');
		var stops = backdrop.stops;
		var dark = stops.every(function (c) {
			return luminance(c) < DARK_LUM;
		});
		var light = stops.every(function (c) {
			return luminance(c) >= DARK_LUM;
		});
		var bg = dark ? 'dark' : light ? 'light' : luminance(pickFill(stops, 'light')) < DARK_LUM ? 'dark' : 'light';
		panel.setAttribute('data-fflf-bg', bg);
		var mode = panel.getAttribute('data-fflf-style-mode') || 'auto';
		if (mode === 'auto') {
			panel.setAttribute('data-fflf-style', bg === 'dark' ? 'dark' : 'light');
		}
		var set = panel.getAttribute('data-fflf-style') === 'dark' ? 'dark' : 'light';
		var page = pickFill(stops, set);
		var tokens = plateTokens(page, set, mode, stops);
		writeTokens(panel, tokens);
		// The accent sits on the overlays and on the plate, so it must clear every stop too.
		panel.fflfSurfaces = (tokens.surface ? [tokens.surface, tokens['surface-2']] : SURFACES[set]).concat(stops);
		panel.setAttribute('data-fflf-backdrop', backdrop.kind);
		panel.setAttribute('data-fflf-page-bg', toHex(page));
		return behind;
	}

	/* OKLCH, the same stepping as the PHP resolver (Brandy's accent.py). */
	function lin(c) {
		return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
	}
	function gam(c) {
		return c <= 0.0031308 ? 12.92 * c : 1.055 * Math.pow(c, 1 / 2.4) - 0.055;
	}
	function toOklch(c) {
		var r = lin(c.r / 255), g = lin(c.g / 255), b = lin(c.b / 255);
		var l = Math.cbrt(0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b);
		var m = Math.cbrt(0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b);
		var s2 = Math.cbrt(0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b);
		var A = 1.9779984951 * l - 2.428592205 * m + 0.4505937099 * s2;
		var B = 0.0259040371 * l + 0.7827717662 * m - 0.808675766 * s2;
		return [0.2104542553 * l + 0.793617785 * m - 0.0040720468 * s2, Math.sqrt(A * A + B * B), Math.atan2(B, A)];
	}
	function fromOklch(L, C, H) {
		var A = C * Math.cos(H), B = C * Math.sin(H);
		var l = Math.pow(L + 0.3963377774 * A + 0.2158037573 * B, 3);
		var m = Math.pow(L - 0.1055613458 * A - 0.0638541728 * B, 3);
		var s2 = Math.pow(L - 0.0894841775 * A - 1.291485548 * B, 3);
		return [4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s2, -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s2, -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s2];
	}
	function inGamut(v) {
		return v.every(function (x) {
			return x >= -1e-6 && x <= 1 + 1e-6;
		});
	}
	function oklchColor(L, C, H) {
		var v = fromOklch(L, C, H);
		if (!inGamut(v)) {
			var lo = 0, hi = C;
			for (var i = 0; i < 24; i++) {
				var mid = (lo + hi) / 2;
				if (inGamut(fromOklch(L, mid, H))) {
					lo = mid;
				} else {
					hi = mid;
				}
			}
			v = fromOklch(L, lo, H);
		}
		return { r: Math.round(Math.min(1, Math.max(0, gam(Math.max(0, v[0])))) * 255), g: Math.round(Math.min(1, Math.max(0, gam(Math.max(0, v[1])))) * 255), b: Math.round(Math.min(1, Math.max(0, gam(Math.max(0, v[2])))) * 255), a: 1 };
	}
	function stepAccent(input, set, surfaces) {
		var dark = set === 'dark';
		surfaces = surfaces || SURFACES[set];
		var lch = toOklch(input);
		var texts = dark ? [DARK_TEXT, LIGHT_TEXT] : [LIGHT_TEXT, DARK_TEXT];
		for (var t = 0; t < texts.length; t++) {
			for (var i = 0; i <= 60; i++) {
				var L = dark ? lch[0] + i * 0.01 : lch[0] - i * 0.01;
				if (L < 0 || L > 1) {
					break;
				}
				var c = i === 0 ? input : oklchColor(L, lch[1], lch[2]);
				if (contrast(texts[t], c) >= 4.5 && surfaces.every(function (sf) { return contrast(c, sf) >= 3; })) {
					return { accent: c, text: texts[t] };
				}
			}
		}
		return null;
	}

	/*
	 * Re-check the accent the browser actually resolved against the active panel set. Only when it fails does the
	 * panel get a stepped value inline (data-fflf-accent="checked"). Reads first, then at most one write.
	 */
	function checkAccent(panel) {
		if (!document.createElement || !computed(panel)) {
			return;
		}
		var probe = document.createElement('span');
		probe.setAttribute('aria-hidden', 'true');
		probe.style.cssText =
			'position:absolute;visibility:hidden;pointer-events:none;width:0;height:0;overflow:hidden;' +
			'color:var(--fflf-accent);background-color:var(--fflf-accent-text)';
		panel.appendChild(probe);
		var cs = computed(probe);
		var accent = cs ? parseColor(cs.color) : null;
		var text = cs ? parseColor(cs.backgroundColor) : null;
		panel.removeChild(probe);
		if (!accent || !text) {
			return;
		}
		var set = panel.getAttribute('data-fflf-style') === 'dark' ? 'dark' : 'light';
		var surfaces = surfacesFor(panel, set);
		var ok = contrast(text, accent) >= 4.5 && surfaces.every(function (sf) {
			return contrast(accent, sf) >= 3;
		});
		if (ok) {
			return;
		}
		var fixed = stepAccent({ r: accent.r, g: accent.g, b: accent.b, a: 1 }, set, surfaces);
		panel.style.setProperty('--fflf-accent', fixed ? toHex(fixed.accent) : NEUTRAL[set]);
		panel.style.setProperty('--fflf-accent-text', fixed ? toHex(fixed.text) : set === 'dark' ? '#0F1B2D' : '#FFFFFF');
		panel.setAttribute('data-fflf-accent', 'checked');
	}

	/*
	 * Phone button edge: the button sits on the theme's page, not on our panel. Without JS it keeps a two-tone ring;
	 * here it drops the ring when the fill already clears 3:1 against everything behind it, or keeps one edge.
	 */
	function edgeFor(btn, behind) {
		var cs = btn ? computed(btn) : null;
		var fill = cs ? parseColor(cs.backgroundColor) : null;
		if (!fill || fill.a < 0.99 || !behind || !behind.length) {
			return '';
		}
		var clears = function (c) {
			return behind.every(function (b) {
				return contrast(c, b) >= 3;
			});
		};
		if (clears(fill)) {
			return 'none';
		}
		if (clears({ r: 243, g: 245, b: 247, a: 1 })) {
			return 'light';
		}
		if (clears({ r: 31, g: 41, b: 51, a: 1 })) {
			return 'dark';
		}
		return '';
	}

	// 1.3.2: what the button edge is checked against: the composited backdrop (the same stops the inline resolver and
	// assets/js/edge.js see, so the ring they set before the button paints is the one kept here). A photo: nothing.
	function edgeBackdrop(backdrop) {
		return backdrop.kind === 'photo' ? null : backdrop.stops;
	}

	function checkEdge(panel, behind) {
		var edge = edgeFor(qs(panel, '.ffl-filters__open'), behind);
		if (edge) {
			panel.setAttribute('data-fflf-edge', edge);
		}
	}

	// The "Filter products" button above the products sits on the theme's page too: same check, set on its wrap.
	function checkOpenerEdge(opener, wrap) {
		var edge = wrap ? edgeFor(opener, edgeBackdrop(resolveBackdrop(wrap))) : '';
		if (edge) {
			wrap.setAttribute('data-fflf-edge', edge);
		}
	}

	/*
	 * 1.3.1 first paint: the resolved look (inline --fflf-* vars and the data-fflf-* markers) can be copied from one
	 * panel to another (applyFragments), and kept in sessionStorage keyed by the background chain behind the panel
	 * plus Panel style, so a later page with the same backdrop applies it at once and then confirms it.
	 */
	var RESOLVED_ATTRS = ['data-fflf-bg', 'data-fflf-style', 'data-fflf-backdrop', 'data-fflf-plate', 'data-fflf-page-bg', 'data-fflf-accent', 'data-fflf-edge'];
	var PAINT_PREFIX = 'fflf-paint-2:';

	function snapshotResolved(panel) {
		var vars = {};
		var st = panel && panel.style;
		if (st && typeof st.length === 'number') {
			for (var i = 0; i < st.length; i++) {
				var name = st[i];
				if (String(name).indexOf('--fflf-') === 0) {
					vars[name] = st.getPropertyValue(name);
				}
			}
		}
		var attrs = {};
		RESOLVED_ATTRS.forEach(function (a) {
			var v = panel.getAttribute(a);
			attrs[a] = v === null || v === undefined ? null : String(v);
		});
		return { vars: vars, attrs: attrs, keys: (panel.fflfTokenKeys || []).slice(), surfaces: (panel.fflfSurfaces || []).map(toHex) };
	}

	// The server's own accent marker (data-fflf-accent="saved", or none), kept so a re-check starts from it.
	function rememberAccent(panel) {
		if (panel.fflfAccentOrig === undefined) {
			panel.fflfAccentOrig = panel.getAttribute('data-fflf-accent');
		}
	}

	function applyResolved(panel, snap) {
		if (!panel || !snap) {
			return;
		}
		rememberAccent(panel);
		if (panel.style && typeof panel.style.setProperty === 'function') {
			Object.keys(snap.vars || {}).forEach(function (name) {
				panel.style.setProperty(name, snap.vars[name]);
			});
		}
		Object.keys(snap.attrs || {}).forEach(function (a) {
			if (snap.attrs[a] === null) {
				panel.removeAttribute(a);
			} else {
				panel.setAttribute(a, snap.attrs[a]);
			}
		});
		panel.fflfTokenKeys = (snap.keys || []).slice();
		var surfaces = (snap.surfaces || []).map(parseColor).filter(Boolean);
		if (surfaces.length) {
			panel.fflfSurfaces = surfaces;
		}
	}

	// The background chain behind the panel (colour and image of every painted layer up to the first solid one),
	// the theme text colour (a photo uses it), Panel style, the saved accent (both sets) and the plugin version, so an
	// accent change or a plugin update never applies a stale look.
	function paintKey(panel) {
		var parts = [panel.getAttribute('data-fflf-style-mode') || 'auto'];
		var text = panel.parentElement ? computed(panel.parentElement) : null;
		parts.push(text ? text.color : '');
		var own = computed(panel);
		var accent = own && typeof own.getPropertyValue === 'function' ? own : null;
		parts.push(accent ? String(accent.getPropertyValue('--fflf-accent-saved')).trim() + '/' + String(accent.getPropertyValue('--fflf-accent-saved-dark')).trim() : '');
		parts.push(window.fflfPanel && window.fflfPanel.version ? String(window.fflfPanel.version) : '');
		for (var n = panel.parentElement; n; n = n.parentElement) {
			var cs = computed(n);
			if (!cs) {
				return '';
			}
			var image = String(cs.backgroundImage || 'none');
			var solid = parseColor(cs.backgroundColor);
			if (image !== 'none' || (solid && solid.a > 0)) {
				parts.push(cs.backgroundColor + '|' + image);
			}
			if (image === 'none' && solid && solid.a >= 0.99) {
				break;
			}
		}
		var str = parts.join(';');
		var h = 5381;
		for (var i = 0; i < str.length; i++) {
			h = ((h << 5) + h + str.charCodeAt(i)) | 0;
		}
		return PAINT_PREFIX + (h >>> 0).toString(36) + ':' + str.length;
	}

	function paintStore() {
		try {
			return window.sessionStorage || null;
		} catch (err) {
			return null;
		}
	}

	function readPaint(key) {
		var store = key ? paintStore() : null;
		if (!store) {
			return null;
		}
		try {
			var raw = store.getItem(key);
			return raw ? JSON.parse(raw) : null;
		} catch (err) {
			return null;
		}
	}

	function writePaint(key, snap) {
		var store = key ? paintStore() : null;
		if (!store) {
			return;
		}
		try {
			store.setItem(key, JSON.stringify(snap));
		} catch (err) {
			// Storage full or blocked: the cache is only a head start.
		}
	}

	function resolveNow(panel, key) {
		// The accent is stepped against the backdrop; drop an earlier or copied step so it is checked again from the
		// saved accent (the server's marker comes back).
		rememberAccent(panel);
		if (panel.getAttribute('data-fflf-accent') === 'checked') {
			if (panel.style && typeof panel.style.removeProperty === 'function') {
				panel.style.removeProperty('--fflf-accent');
				panel.style.removeProperty('--fflf-accent-text');
			}
			if (panel.fflfAccentOrig === null || panel.fflfAccentOrig === undefined) {
				panel.removeAttribute('data-fflf-accent');
			} else {
				panel.setAttribute('data-fflf-accent', panel.fflfAccentOrig);
			}
		}
		var behind = detectStyle(panel);
		checkAccent(panel);
		checkEdge(panel, behind);
		writePaint(key, snapshotResolved(panel));
	}

	function laterFrame(fn) {
		if (typeof window.requestAnimationFrame === 'function') {
			window.requestAnimationFrame(fn);
		} else {
			setTimeout(fn, 0);
		}
	}

	function checkContrast(panel) {
		var key = paintKey(panel);
		var hit = readPaint(key);
		if (hit) {
			// Instant apply from the cache, then confirm against the page.
			applyResolved(panel, hit);
			laterFrame(function () {
				resolveNow(panel, paintKey(panel));
			});
			return;
		}
		resolveNow(panel, key);
	}

	// Test hook only (tests/js/panel-plate.test.js sets the flag before loading the file).
	if (window.fflfPanelTestHook === true) {
		window.fflfPanelColor = {
			resolveBackground: resolveBackground,
			resolveBackdrop: resolveBackdrop,
			placeResults: placeResults,
			pickFill: pickFill,
			plateTokens: plateTokens,
			contrast: contrast,
			luminance: luminance,
			parseColor: parseColor,
			toHex: toHex,
			checkContrast: checkContrast,
			snapshotResolved: snapshotResolved,
			applyResolved: applyResolved,
			paintKey: paintKey,
			applyFragments: applyFragments,
			detectStyle: detectStyle,
			edgeFor: edgeFor,
			edgeBackdrop: edgeBackdrop,
		};
	}

	/* ------------------------------------------------------------------ */
	/* Layout (Auto / Bar / Stacked) and Bar popovers                     */
	/* ------------------------------------------------------------------ */

	// The Bar from 720px of the panel's own width; once pinned, 32px of leeway (in at 736, out under 704).
	var BAR_AT = 720;
	var BAR_IN = 736;
	var BAR_OUT = 704;
	var lastLayout = {};
	var resizer = null;

	function isBar(panel) {
		return !!panel && panel.getAttribute('data-fflf-layout-now') === 'bar';
	}

	function layoutFor(panel, width, current) {
		var phoneUi = panel.classList.contains('ffl-filters--drawer') || panel.classList.contains('ffl-filters--collapsible');
		if (phoneUi && isMobileWidth(panel)) {
			return 'stacked';
		}
		var setting = panel.getAttribute('data-fflf-layout');
		if (setting === 'bar' || setting === 'stacked') {
			return setting;
		}
		if (current === 'bar') {
			return width < BAR_OUT ? 'stacked' : 'bar';
		}
		if (current === 'stacked') {
			return width >= BAR_IN ? 'bar' : 'stacked';
		}
		return width >= BAR_AT ? 'bar' : 'stacked';
	}

	/*
	 * 1.3.1: above the products, the results row (count, chips, Clear all, sorting) follows the groups on desktop
	 * and tablet, where it is the row under the Bar. In the phone drawer (767px and narrower) it moves to just
	 * after the heading, so the drawer reads Close, heading, count, chips, groups, Show N like the sidebar drawer.
	 * It is a real DOM move, so the tab order matches what is on screen. Focus inside the row is kept.
	 */
	function placeResults(panel) {
		if (!panel || !panel.getAttribute || panel.getAttribute('data-fflf-placement') !== 'above') {
			return;
		}
		var results = qs(panel, '.ffl-filters__results');
		var form = qs(panel, '.ffl-filters__form');
		if (!results || !form || results.parentNode !== form.parentNode) {
			return;
		}
		var phone = isMobileWidth(panel);
		var before = form.previousElementSibling === results;
		if (phone === before) {
			return;
		}
		var active = document.activeElement;
		var keep = active && typeof results.contains === 'function' && results.contains(active) ? active : null;
		form.parentNode.insertBefore(results, phone ? form : form.nextSibling);
		if (keep && typeof keep.focus === 'function') {
			try {
				keep.focus({ preventScroll: true });
			} catch (err) {
				keep.focus();
			}
		}
	}

	function applyLayout(panel) {
		if (!panel || typeof panel.getBoundingClientRect !== 'function') {
			return;
		}
		placeResults(panel);
		// Content-box width, the same size the CSS container query measures.
		var width = panel.getBoundingClientRect().width;
		var cs = computed(panel);
		if (cs) {
			width -= (parseFloat(cs.paddingLeft) || 0) + (parseFloat(cs.paddingRight) || 0) + (parseFloat(cs.borderLeftWidth) || 0) + (parseFloat(cs.borderRightWidth) || 0);
		}
		var current = panel.getAttribute('data-fflf-layout-now') || lastLayout[panel.id] || '';
		var next = layoutFor(panel, width, current);
		if (next !== panel.getAttribute('data-fflf-layout-now')) {
			if (next !== 'bar') {
				closePopovers(panel, null, true);
			}
			panel.setAttribute('data-fflf-layout-now', next);
		}
		lastLayout[panel.id] = next;
	}

	function watchLayout(panel) {
		applyLayout(panel);
		if (typeof window.ResizeObserver === 'function') {
			if (!resizer) {
				resizer = new window.ResizeObserver(function (entries) {
					entries.forEach(function (entry) {
						applyLayout(entry.target);
					});
				});
			}
			resizer.observe(panel);
		}
	}

	function unwatchLayout(panel) {
		if (resizer && panel) {
			resizer.unobserve(panel);
		}
	}

	function openGroups(panel) {
		return qsa(panel, '[data-fflf-group]').filter(function (group) {
			var toggle = qs(group, '[data-fflf-toggle]');
			return toggle && toggle.getAttribute('aria-expanded') === 'true';
		});
	}

	/* Close every open popover except keep; only in the Bar unless force (leaving the Bar). */
	function closePopovers(panel, keep, force) {
		if (!force && !isBar(panel)) {
			return;
		}
		openGroups(panel).forEach(function (group) {
			if (group !== keep) {
				setGroupOpen(group, false);
			}
		});
	}

	function focusFirstIn(group) {
		var options = qs(group, '.ffl-filters__options');
		var target = options ? qs(options, '[data-fflf-search-input]') || qs(options, 'input, select, a[href], button') : null;
		if (target && typeof target.focus === 'function') {
			try {
				target.focus({ preventScroll: true });
			} catch (err) {
				target.focus();
			}
		}
	}

	function closeGroupToToggle(group) {
		setGroupOpen(group, false);
		var toggle = qs(group, '[data-fflf-toggle]');
		if (toggle && typeof toggle.focus === 'function') {
			toggle.focus();
		}
	}

	function initPopovers(panel) {
		// Esc closes the open popover and returns focus to its button.
		panel.addEventListener('keydown', function (event) {
			if (!isBar(panel) || !event.target || typeof event.target.closest !== 'function') {
				return;
			}
			var group = event.target.closest('[data-fflf-group]');
			if (!group) {
				return;
			}
			if (event.key === 'Escape' || event.key === 'Esc') {
				var toggle = qs(group, '[data-fflf-toggle]');
				if (toggle && toggle.getAttribute('aria-expanded') === 'true') {
					event.preventDefault();
					closeGroupToToggle(group);
				}
				return;
			}
			// Cost Per Round and Price close on Enter (Paul, 10:13 AM ET), and apply at once.
			if (event.key === 'Enter' && isRangeInput(event.target)) {
				event.preventDefault();
				var form = qs(panel, 'form');
				closeGroupToToggle(group);
				if (form) {
					applyForm(form);
				}
			}
		});
		// Tab past the end of a popover closes it.
		panel.addEventListener('focusout', function (event) {
			if (!isBar(panel) || !event.target || typeof event.target.closest !== 'function') {
				return;
			}
			var group = event.target.closest('[data-fflf-group]');
			var next = event.relatedTarget;
			if (group && next && typeof group.contains === 'function' && !group.contains(next)) {
				setGroupOpen(group, false);
			}
		});
		// A pick in a single-select group closes its popover; multi-select popovers stay open after a tick.
		panel.addEventListener('change', function (event) {
			var el = event.target;
			if (!isBar(panel) || !el || typeof el.closest !== 'function' || (el.type !== 'checkbox' && el.type !== 'radio')) {
				return;
			}
			var group = el.closest('[data-fflf-group]');
			if (group && group.getAttribute('data-fflf-select') === 'single') {
				closeGroupToToggle(group);
			}
		});
		// The sort control in the results row belongs to the form (form= attribute) and applies at once.
		var sort = qs(panel, '[data-fflf-sort]');
		if (sort) {
			sort.addEventListener('change', function () {
				var form = qs(panel, 'form');
				if (form) {
					applyForm(form);
				}
			});
		}
	}

	function onDocPointer(event) {
		var target = event.target;
		qsa(document, '[data-fflf-panel]').forEach(function (panel) {
			if (!isBar(panel)) {
				return;
			}
			openGroups(panel).forEach(function (group) {
				if (!target || typeof group.contains !== 'function' || !group.contains(target)) {
					setGroupOpen(group, false);
				}
			});
		});
	}

	/* ------------------------------------------------------------------ */
	/* Instant apply                                                      */
	/* ------------------------------------------------------------------ */

	var requestSeq = 0;
	var inflight = null;
	var rangeTimer = null;

	function sameOrigin(url) {
		try {
			var parsed = new URL(url, window.location.href);
			return parsed.origin === window.location.origin;
		} catch (err) {
			return false;
		}
	}

	function formActionUrl(form) {
		var action = form.getAttribute('action');
		if (!action) {
			action = window.location.href;
		}
		var url = String(action).split('#')[0];
		if (typeof window.FormData !== 'function' || typeof window.URLSearchParams !== 'function') {
			return null;
		}
		var params = new URLSearchParams();
		var data = new FormData(form);
		var rangeNames = {};
		qsa(form, '[data-fflf-range-input]').forEach(function (input) {
			rangeNames[input.name] = true;
		});
		if (typeof data.forEach === 'function') {
			data.forEach(function (value, key) {
				// Empty price and range boxes stay out of the URL.
				if (value === '' && rangeNames[key]) {
					return;
				}
				params.append(key, value);
			});
		} else {
			params = new URLSearchParams(data);
		}
		var query = params.toString();
		if (query) {
			url += (url.indexOf('?') === -1 ? '?' : '&') + query;
		}
		return url;
	}

	function statusText() {
		return strings().updating || '';
	}

	function setPending(isPending) {
		var panel = qs(document, '[data-fflf-panel]');
		var grid = qs(document, '[data-fflf-grid]');
		if (panel) {
			if (isPending) {
				panel.classList.add('is-pending');
				panel.setAttribute('aria-busy', 'true');
			} else {
				panel.classList.remove('is-pending');
				panel.removeAttribute('aria-busy');
			}
		}
		if (!grid) {
			return;
		}
		var status = qs(grid, '.ffl-filters-status');
		if (isPending) {
			grid.classList.add('is-loading');
			grid.setAttribute('aria-busy', 'true');
			if (!status) {
				status = document.createElement('div');
				status.className = 'ffl-filters-status';
				status.setAttribute('role', 'status');
				var bar = document.createElement('div');
				bar.className = 'ffl-filters-status__bar';
				var pcs = panel ? computed(panel) : null;
				var accent = pcs && typeof pcs.getPropertyValue === 'function' ? pcs.getPropertyValue('--fflf-accent').trim() : '';
				if (status.style && typeof status.style.setProperty === 'function') {
					// The panel's resolved accent, surface and text (light or dark set), so the label matches the panel.
					[['--fflf-accent', '--ffl-filters-status-accent'], ['--fflf-surface', '--ffl-filters-status-surface'], ['--fflf-text', '--ffl-filters-status-text']].forEach(function (pair) {
						var value = pair[0] === '--fflf-accent' ? accent : pcs && typeof pcs.getPropertyValue === 'function' ? pcs.getPropertyValue(pair[0]).trim() : '';
						if (value) {
							status.style.setProperty(pair[1], value);
						}
					});
				}
				status.appendChild(bar);
				var text = statusText();
				if (text) {
					var label = document.createElement('div');
					label.className = 'ffl-filters-status__text';
					label.textContent = text;
					status.appendChild(label);
				}
				grid.insertBefore(status, grid.firstChild || null);
			}
		} else {
			grid.classList.remove('is-loading');
			grid.removeAttribute('aria-busy');
			if (status && status.parentNode) {
				status.parentNode.removeChild(status);
			}
		}
	}

	/* Keep what the shopper had open, typed and scrolled when the panel is replaced. */
	function captureState(panel) {
		var state = { groups: {}, focusId: '', selStart: null, selEnd: null, drawerScroll: 0 };
		qsa(panel, '[data-fflf-group]').forEach(function (group) {
			var id = group.getAttribute('data-fflf-group');
			var toggle = qs(group, '[data-fflf-toggle]');
			var search = qs(group, '[data-fflf-search-input]');
			var list = qs(group, '[data-fflf-list]');
			state.groups[id] = {
				open: toggle ? toggle.getAttribute('aria-expanded') === 'true' : null,
				query: search ? search.value : '',
				scroll: list ? list.scrollTop || 0 : 0,
			};
		});
		var active = document.activeElement;
		if (active && active.id && panel.contains && panel.contains(active)) {
			state.focusId = active.id;
			try {
				state.selStart = active.selectionStart;
				state.selEnd = active.selectionEnd;
			} catch (err) {
				state.selStart = null;
			}
		}
		var drawer = qs(panel, '[data-fflf-drawer]');
		state.drawerScroll = drawer ? drawer.scrollTop || 0 : 0;
		return state;
	}

	function restoreState(panel, state) {
		if (!state) {
			return;
		}
		qsa(panel, '[data-fflf-group]').forEach(function (group) {
			var id = group.getAttribute('data-fflf-group');
			var saved = state.groups[id];
			if (!saved) {
				return;
			}
			var toggle = qs(group, '[data-fflf-toggle]');
			if (toggle && saved.open !== null && (toggle.getAttribute('aria-expanded') === 'true') !== saved.open) {
				setGroupOpen(group, saved.open);
			}
			var search = qs(group, '[data-fflf-search-input]');
			if (search && saved.query) {
				search.value = saved.query;
				applySearch(group);
			}
			var list = qs(group, '[data-fflf-list]');
			if (list && saved.scroll) {
				list.scrollTop = saved.scroll;
				autoLoadTerms(group, function () {
					if (search && saved.query) {
						applySearch(group);
					}
					list.scrollTop = saved.scroll;
				});
			}
		});
		var drawer = qs(panel, '[data-fflf-drawer]');
		if (drawer && state.drawerScroll) {
			drawer.scrollTop = state.drawerScroll;
		}
		if (state.focusId) {
			var el = document.getElementById(state.focusId);
			if (el && typeof el.focus === 'function') {
				try {
					el.focus({ preventScroll: true });
				} catch (err) {
					el.focus();
				}
				if (state.selStart !== null && typeof el.setSelectionRange === 'function') {
					try {
						el.setSelectionRange(state.selStart, state.selEnd);
					} catch (err) {
						// Number inputs do not support selection ranges.
					}
				}
			}
		}
	}

	function applyFragments(data, requestedUrl, options) {
		options = options || {};
		var nextUrl = data.url || requestedUrl;
		var panel = qs(document, '[data-fflf-panel]');
		var grid = qs(document, '[data-fflf-grid]');
		if (!panel || !grid || !panel.parentNode || !grid.parentNode) {
			window.location = nextUrl;
			return;
		}

		var wasOpen = panel.classList.contains('is-open');
		var tmp = document.createElement('div');
		tmp.innerHTML = data.panel;
		var nextPanel = qs(tmp, '[data-fflf-panel]');
		if (!nextPanel) {
			window.location = nextUrl;
			return;
		}

		var gridTmp = document.createElement('div');
		gridTmp.innerHTML = data.grid;
		var nextGrid = qs(gridTmp, '[data-fflf-grid]');
		if (!nextGrid) {
			window.location = nextUrl;
			return;
		}

		var state = captureState(panel);
		if (panel.fflfDrawer) {
			// The new panel takes over the drawer below.
			panel.fflfDrawer.detach();
		}

		unwatchLayout(panel);
		// 1.3.1 first paint: the new panel starts with the old one's resolved look (no light-set frame), then init
		// re-resolves it against the page.
		applyResolved(nextPanel, snapshotResolved(panel));
		if (lastLayout[panel.id]) {
			lastLayout[nextPanel.id] = lastLayout[panel.id];
		}
		panel.parentNode.replaceChild(nextPanel, panel);
		grid.parentNode.replaceChild(nextGrid, grid);

		if (data.title) {
			document.title = data.title;
		}
		if (!options.skipHistory && window.history && typeof window.history.pushState === 'function') {
			window.history.pushState({ fflf: 1 }, data.title || '', nextUrl);
		}

		init(nextPanel);
		if (wasOpen && nextPanel.fflfDrawer && isMobileWidth(nextPanel)) {
			nextPanel.fflfDrawer.open(true);
		}
		restoreState(nextPanel, state);
		restorePendingFocus(nextPanel);
	}

	/* After a chip x: focus the next chip, or Clear all. After Clear all: the first group button. */
	var pendingFocus = null;

	function restorePendingFocus(panel) {
		var want = pendingFocus;
		pendingFocus = null;
		if (!want) {
			return;
		}
		var target = null;
		if (want.type === 'chip') {
			var chips = qsa(panel, '.ffl-filters__chip');
			target = chips[want.index] || chips[chips.length - 1] || qs(panel, '.ffl-filters__clear--chips') || qs(panel, '[data-fflf-toggle]');
		} else {
			target = qs(panel, '[data-fflf-toggle]');
		}
		if (target && typeof target.focus === 'function') {
			try {
				target.focus({ preventScroll: true });
			} catch (err) {
				target.focus();
			}
		}
	}

	function fetchFragments(url, options) {
		options = options || {};
		if (!url) {
			return;
		}
		if (typeof window.fetch !== 'function') {
			window.location = url;
			return;
		}

		// Last click wins: abort the request in flight and ignore anything older than this one.
		requestSeq += 1;
		var seq = requestSeq;
		if (inflight && typeof inflight.abort === 'function') {
			inflight.abort();
		}
		inflight = typeof window.AbortController === 'function' ? new window.AbortController() : null;

		setPending(true);
		var init = {
			credentials: 'same-origin',
			headers: { 'X-FFLF-Fragments': '1' },
		};
		if (inflight) {
			init.signal = inflight.signal;
		}
		window
			.fetch(url, init)
			.then(function (res) {
				if (!res.ok) {
					throw new Error('fragments ' + res.status);
				}
				return res.text();
			})
			.then(function (text) {
				if (seq !== requestSeq) {
					return;
				}
				var data;
				try {
					data = JSON.parse(text);
				} catch (err) {
					throw new Error('not fragments');
				}
				if (!data || typeof data.panel !== 'string' || typeof data.grid !== 'string' || !data.panel || !data.grid) {
					throw new Error('missing fragments');
				}
				inflight = null;
				applyFragments(data, url, options);
				setPending(false);
			})
			.catch(function (err) {
				if (seq !== requestSeq || (err && err.name === 'AbortError')) {
					return;
				}
				inflight = null;
				setPending(false);
				window.location = url;
			});
	}

	/* A newer edit makes any response in flight stale. */
	function supersede() {
		requestSeq += 1;
		if (inflight && typeof inflight.abort === 'function') {
			inflight.abort();
		}
		inflight = null;
	}

	function applyForm(form) {
		var method = (form.getAttribute('method') || 'get').toLowerCase();
		if (method !== 'get') {
			return false;
		}
		var url = formActionUrl(form);
		if (!url) {
			return false;
		}
		window.clearTimeout(rangeTimer);
		fetchFragments(url);
		return true;
	}

	function isRangeInput(el) {
		return !!(el && typeof el.hasAttribute === 'function' && el.hasAttribute('data-fflf-range-input'));
	}

	function initProgressive(panel) {
		var form = qs(panel, 'form');
		if (!form) {
			return;
		}
		form.addEventListener('submit', function (event) {
			var method = (form.getAttribute('method') || 'get').toLowerCase();
			if (method !== 'get') {
				return;
			}
			var url = formActionUrl(form);
			if (!url) {
				return;
			}
			event.preventDefault();
			window.clearTimeout(rangeTimer);
			fetchFragments(url);
		});

		// Checkboxes and switches apply on click.
		form.addEventListener('change', function (event) {
			var el = event.target;
			if (!el || el.type !== 'checkbox' || (typeof el.hasAttribute === 'function' && el.hasAttribute('data-fflf-search-input'))) {
				return;
			}
			applyForm(form);
		});

		// Price and range boxes apply about 0.6 s after typing stops.
		form.addEventListener('input', function (event) {
			var el = event.target;
			if (!isRangeInput(el)) {
				return;
			}
			supersede();
			window.clearTimeout(rangeTimer);
			rangeTimer = window.setTimeout(function () {
				applyForm(form);
			}, RANGE_MS);
		});
	}

	function modifierClick(event) {
		return event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button !== 0;
	}

	function onDocClick(event) {
		if (event.defaultPrevented || modifierClick(event)) {
			return;
		}
		var target = event.target;
		if (!target || typeof target.closest !== 'function') {
			return;
		}
		var link = target.closest('a');
		if (!link || !link.href) {
			return;
		}
		if (link.hasAttribute('data-fflf-drawer-open') || link.hasAttribute('data-fflf-drawer-close') || link.hasAttribute('data-fflf-collapse-open')) {
			return;
		}
		if (link.classList.contains('ffl-filters__skip')) {
			return;
		}
		if (link.getAttribute('data-fflf-show-all') && link.getAttribute('data-fflf-json')) {
			return;
		}
		var hrefAttr = link.getAttribute('href') || '';
		if (hrefAttr.charAt(0) === '#') {
			return;
		}
		var inPanel = link.closest('[data-fflf-panel]');
		var inGrid = link.closest('[data-fflf-grid]');
		if (!inPanel && !inGrid) {
			return;
		}
		if (!sameOrigin(link.href)) {
			return;
		}
		event.preventDefault();
		if (inPanel && link.classList.contains('ffl-filters__chip')) {
			pendingFocus = { type: 'chip', index: qsa(inPanel, '.ffl-filters__chip').indexOf(link) };
		} else if (inPanel && link.classList.contains('ffl-filters__clear')) {
			pendingFocus = { type: 'clear' };
		}
		fetchFragments(link.href);
	}

	function onPopState() {
		fetchFragments(window.location.href, { skipHistory: true });
	}

	// 1.3.1: the inline resolver (assets/js/resolver.js) already wrote the colour vars before the panel painted.
	// They are adopted as this panel's tokens, so a later re-check clears the ones a new backdrop does not set.
	function adoptResolved(panel) {
		if (panel.fflfTokenKeys || !panel.style || typeof panel.style.length !== 'number') {
			return;
		}
		var keys = [];
		for (var i = 0; i < panel.style.length; i++) {
			var name = String(panel.style[i]);
			if (name.indexOf('--fflf-') === 0 && name !== '--fflf-accent' && name !== '--fflf-accent-text') {
				keys.push(name.slice(7));
			}
		}
		panel.fflfTokenKeys = keys;
	}

	function init(panel) {
		if (!panel || panel.getAttribute('data-fflf-ready') === '1') {
			return;
		}
		panel.setAttribute('data-fflf-ready', '1');
		// Set up before the page has finished loading (panel.js is deferred, so this is the usual case): the page may
		// still change behind it (styles printed later, a theme script), so the colours are checked again at
		// DOMContentLoaded and at load. The same backdrop gives the same values: no visible change.
		if (document.readyState !== 'complete') {
			panel.fflfEarly = true;
		}
		adoptResolved(panel);
		// Hides the no-JS Show products button; filters apply on click from here on.
		panel.setAttribute('data-fflf-js', '1');
		checkContrast(panel);
		watchLayout(panel);
		syncRemoteOpener(panel);
		initGroupToggles(panel);
		initPopovers(panel);
		initDrawer(panel);
		initCollapsible(panel);
		initLargeFacets(panel);
		initProgressive(panel);
	}

	// One "Filter products" button on phones: when the button above the products is in use,
	// the panel's own button is hidden. Re-applied to panels swapped in after a filter click.
	function syncRemoteOpener(panel) {
		if (qs(document, '[data-fflf-remote-open]')) {
			panel.setAttribute('data-fflf-remote-opener', '1');
		}
	}

	function initRemoteOpeners() {
		qsa(document, '[data-fflf-remote-open]').forEach(function (opener) {
			if (opener.getAttribute('data-fflf-ready') === '1') {
				return;
			}
			opener.setAttribute('data-fflf-ready', '1');
			var panel = qs(document, '[data-fflf-panel]');
			var wrap = opener.parentNode;
			if (!panel) {
				return;
			}
			// 1.2.1: the button above the products is the one phones use. Themes reorder the sidebar on small
			// screens (CSS order, column-reverse, or a sidebar before the content in the markup), so its place in
			// the DOM says nothing about where it shows. The panel's own button hides instead (see syncRemoteOpener).
			if (wrap) {
				wrap.hidden = false;
			}
			checkOpenerEdge(opener, wrap);
			qsa(document, '[data-fflf-panel]').forEach(syncRemoteOpener);
			opener.addEventListener('click', function (event) {
				var current = qs(document, '[data-fflf-panel]') || panel;
				var target = qs(current, '[data-fflf-drawer-open]') || qs(current, '[data-fflf-collapse-open]');
				if (!target) {
					return;
				}
				event.preventDefault();
				target.click();
				if (target.hasAttribute('data-fflf-collapse-open') && typeof current.scrollIntoView === 'function') {
					current.scrollIntoView({ behavior: REDUCED ? 'auto' : 'smooth', block: 'start' });
				}
			});
		});
	}

	// The colours of panels set up early, checked again once the page has settled (same backdrop: no change).
	function recheckEarly() {
		qsa(document, '[data-fflf-panel]').forEach(function (panel) {
			if (panel.fflfEarly && panel.getAttribute('data-fflf-ready') === '1') {
				checkContrast(panel);
			}
		});
	}

	function boot() {
		qsa(document, '[data-fflf-panel]').forEach(init);
		initRemoteOpeners();
		if (document.documentElement.getAttribute('data-fflf-nav') === '1') {
			return;
		}
		document.documentElement.setAttribute('data-fflf-nav', '1');
		document.addEventListener('click', onDocClick);
		document.addEventListener('pointerdown', onDocPointer);
		window.addEventListener('popstate', onPopState);
		window.addEventListener('resize', function () {
			qsa(document, '[data-fflf-panel]').forEach(applyLayout);
		});
	}

	/*
	 * 1.3.1: panel.js is deferred (it never blocks rendering). Panels in the DOM are set up as soon as it runs; their
	 * colours were already set by the inline resolver, so this adopts them. The colours are checked again at
	 * DOMContentLoaded and at load (recheckEarly).
	 */
	qsa(document, '[data-fflf-panel]').forEach(init);
	if (document.readyState !== 'complete') {
		document.addEventListener('DOMContentLoaded', recheckEarly);
		window.addEventListener('load', recheckEarly);
	}
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}
})();
