/* global fflfAdmin */
(function () {
  'use strict';

  function onReady(fn) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn);
    } else {
      fn();
    }
  }

  function i18n(key, fallback) {
    return (window.fflfAdmin && fflfAdmin.i18n && fflfAdmin.i18n[key]) ? fflfAdmin.i18n[key] : fallback;
  }

  function reindexOrders(list) {
    var rows = list.querySelectorAll('[data-fflf-facet]');
    for (var i = 0; i < rows.length; i++) {
      var input = rows[i].querySelector('.fflf-facet__order');
      if (input) {
        input.value = String(i);
      }
      var up = rows[i].querySelector('[data-fflf-move="up"]');
      var down = rows[i].querySelector('[data-fflf-move="down"]');
      if (up) {
        up.disabled = i === 0;
      }
      if (down) {
        down.disabled = i === rows.length - 1;
      }
    }
  }

  function announce(list, row) {
    var status = document.querySelector('[data-fflf-move-status]');
    if (!status || !row) {
      return;
    }
    var rows = Array.prototype.slice.call(list.querySelectorAll('[data-fflf-facet]'));
    var position = rows.indexOf(row) + 1;
    var name = row.getAttribute('data-fflf-name') || row.getAttribute('data-fflf-facet') || '';
    status.textContent = i18n('moved', '%1$s moved to position %2$d of %3$d')
      .replace('%1$s', name)
      .replace('%2$d', String(position))
      .replace('%3$d', String(rows.length));
  }

  function moveRow(button) {
    var row = button.closest('[data-fflf-facet]');
    var list = button.closest('[data-fflf-facet-list]');
    if (!row || !list) {
      return;
    }
    if (button.getAttribute('data-fflf-move') === 'up' && row.previousElementSibling) {
      list.insertBefore(row, row.previousElementSibling);
    } else if (button.getAttribute('data-fflf-move') === 'down' && row.nextElementSibling) {
      list.insertBefore(row.nextElementSibling, row);
    }
    reindexOrders(list);
    announce(list, row);
    if (button.disabled) {
      var other = row.querySelector('[data-fflf-move]:not([disabled])');
      if (other) {
        other.focus();
      }
    } else {
      button.focus();
    }
  }

  function initDrag(list) {
    var dragging = null;
    list.addEventListener('dragstart', function (event) {
      // Drags start from the handle only, so the text fields stay selectable.
      var handle = event.target.closest ? event.target.closest('.fflf-facet__handle') : null;
      var row = handle ? handle.closest('[data-fflf-facet]') : null;
      if (!row) {
        return;
      }
      dragging = row;
      row.classList.add('is-dragging');
      if (event.dataTransfer) {
        event.dataTransfer.effectAllowed = 'move';
        event.dataTransfer.setData('text/plain', row.getAttribute('data-fflf-facet') || '');
        if (event.dataTransfer.setDragImage) {
          event.dataTransfer.setDragImage(row, 16, 16);
        }
      }
    });
    list.addEventListener('dragover', function (event) {
      if (!dragging) {
        return;
      }
      event.preventDefault();
      var over = event.target.closest ? event.target.closest('[data-fflf-facet]') : null;
      if (!over || over === dragging) {
        return;
      }
      var rect = over.getBoundingClientRect();
      var after = (event.clientY - rect.top) > rect.height / 2;
      list.insertBefore(dragging, after ? over.nextElementSibling : over);
    });
    list.addEventListener('dragend', function () {
      if (!dragging) {
        return;
      }
      dragging.classList.remove('is-dragging');
      reindexOrders(list);
      announce(list, dragging);
      dragging = null;
    });
    list.addEventListener('drop', function (event) {
      if (dragging) {
        event.preventDefault();
      }
    });
  }

  function confirmLarge(checkbox) {
    if (!checkbox.checked || !window.fflfAdmin) {
      return;
    }
    var row = checkbox.closest('[data-fflf-facet]');
    var count = row ? parseInt(row.getAttribute('data-term-count') || '0', 10) : 0;
    var threshold = parseInt(fflfAdmin.threshold, 10) || 50;
    if (count < threshold) {
      return;
    }
    if (!window.confirm(fflfAdmin.i18n.largeConfirm)) {
      checkbox.checked = false;
    }
  }

  function debounce(fn, ms) {
    var t;
    return function () {
      var ctx = this;
      var args = arguments;
      window.clearTimeout(t);
      t = window.setTimeout(function () {
        fn.apply(ctx, args);
      }, ms);
    };
  }

  function addChip(picker, slug, label) {
    var chips = picker.querySelector('.fflf-picker__chips');
    var name = picker.getAttribute('data-name') || '';
    var useLabels = picker.getAttribute('data-labels') === '1';
    if (!chips || !slug) {
      return;
    }
    var existing = chips.querySelectorAll('input[type="hidden"]');
    for (var i = 0; i < existing.length; i++) {
      if (existing[i].value === slug) {
        return;
      }
    }
    var shown = label || slug;
    var chip = document.createElement('span');
    chip.className = 'fflf-picker__chip';
    if (useLabels) {
      var index = chips.querySelectorAll('.fflf-picker__chip').length;
      chip.innerHTML =
        '<input type="hidden" name="' + name + '[' + index + '][slug]" value="" />' +
        '<span class="fflf-picker__name"></span> ' +
        '<input type="text" name="' + name + '[' + index + '][label]" value="" />' +
        ' <button type="button" class="fflf-picker__remove" data-fflf-remove>&times;</button>';
      chip.querySelector('input[type="text"]').value = shown;
      chip.querySelector('input[type="text"]').setAttribute('aria-label', shown);
    } else {
      chip.innerHTML =
        '<input type="hidden" name="' + name + '[]" value="" />' +
        '<span class="fflf-picker__name"></span>' +
        ' <button type="button" class="fflf-picker__remove" data-fflf-remove>&times;</button>';
    }
    chip.querySelector('input[type="hidden"]').value = slug;
    chip.querySelector('.fflf-picker__name').textContent = shown;
    chip.querySelector('[data-fflf-remove]').setAttribute('aria-label', i18n('remove', 'Remove %s').replace('%s', shown));
    chips.appendChild(chip);
  }

  function searchTerms(picker, query) {
    var results = picker.querySelector('.fflf-picker__results');
    if (!results || !window.fflfAdmin || !fflfAdmin.restUrl) {
      return;
    }
    if (!query) {
      results.hidden = true;
      results.innerHTML = '';
      return;
    }
    var taxonomy = picker.getAttribute('data-taxonomy') || '';
    var url = fflfAdmin.restUrl + '?taxonomy=' + encodeURIComponent(taxonomy) + '&search=' + encodeURIComponent(query);
    window.fetch(url, {
      credentials: 'same-origin',
      headers: { 'X-WP-Nonce': fflfAdmin.restNonce }
    }).then(function (res) {
      return res.ok ? res.json() : [];
    }).then(function (items) {
      results.innerHTML = '';
      if (!items || !items.length) {
        results.hidden = true;
        return;
      }
      items.forEach(function (item) {
        var button = document.createElement('button');
        button.type = 'button';
        button.className = 'fflf-picker__result';
        button.textContent = item.label || item.slug;
        button.addEventListener('click', function () {
          addChip(picker, item.slug, item.label);
          results.hidden = true;
          results.innerHTML = '';
          var input = picker.querySelector('.fflf-picker__search');
          if (input) {
            input.value = '';
            input.focus();
          }
        });
        results.appendChild(button);
      });
      results.hidden = false;
    }).catch(function () {
      results.hidden = true;
    });
  }

  function copyText(button) {
    var target = document.getElementById(button.getAttribute('data-fflf-copy') || '');
    if (!target) {
      return;
    }
    var text = target.textContent || '';
    var status = button.parentNode ? button.parentNode.querySelector('.fflf-copy__status') : null;
    function done() {
      if (status) {
        status.textContent = i18n('copied', 'Copied');
        window.setTimeout(function () {
          status.textContent = '';
        }, 2500);
      }
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(done, function () {
        selectText(target);
      });
      return;
    }
    selectText(target);
    try {
      if (document.execCommand('copy')) {
        done();
      }
    } catch (e) {
      // Leave the text selected so it can be copied by hand.
    }
  }

  function selectText(node) {
    var range = document.createRange();
    range.selectNodeContents(node);
    var sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
  }

  function showVariant(root, which) {
    var variants = root.querySelectorAll('[data-fflf-variant]');
    for (var i = 0; i < variants.length; i++) {
      variants[i].hidden = variants[i].getAttribute('data-fflf-variant') !== which;
    }
    var shown = root.querySelector('[data-fflf-variant="' + which + '"] h2, [data-fflf-variant="' + which + '"] h3');
    if (shown) {
      shown.setAttribute('tabindex', '-1');
      shown.focus();
    }
  }

  onReady(function () {
    var root = document.querySelector('.fflf-settings');
    if (!root) {
      return;
    }

    var lists = root.querySelectorAll('[data-fflf-facet-list]');
    for (var l = 0; l < lists.length; l++) {
      reindexOrders(lists[l]);
      initDrag(lists[l]);
    }

    root.addEventListener('click', function (event) {
      var move = event.target.closest('[data-fflf-move]');
      if (move) {
        event.preventDefault();
        moveRow(move);
        return;
      }
      var remove = event.target.closest('[data-fflf-remove]');
      if (remove) {
        event.preventDefault();
        var chip = remove.closest('.fflf-picker__chip');
        if (chip) {
          chip.parentNode.removeChild(chip);
        }
        return;
      }
      var copy = event.target.closest('[data-fflf-copy]');
      if (copy) {
        event.preventDefault();
        copyText(copy);
        return;
      }
      var variant = event.target.closest('[data-fflf-show-variant]');
      if (variant) {
        event.preventDefault();
        showVariant(root, variant.getAttribute('data-fflf-show-variant'));
      }
    });

    root.addEventListener('change', function (event) {
      if (event.target.classList.contains('fflf-facet__enabled')) {
        confirmLarge(event.target);
      }
      if (event.target.hasAttribute('data-fflf-consent')) {
        var form = event.target.closest('form');
        var submit = form ? form.querySelector('[data-fflf-consent-submit]') : null;
        if (submit) {
          submit.disabled = !event.target.checked;
        }
      }
    });

    var searches = root.querySelectorAll('.fflf-picker__search');
    for (var i = 0; i < searches.length; i++) {
      searches[i].addEventListener('input', debounce(function (event) {
        searchTerms(event.target.closest('[data-fflf-picker]'), event.target.value.replace(/^\s+|\s+$/g, ''));
      }, 200));
    }

    var resetForm = root.querySelector('[data-fflf-reset]');
    if (resetForm && window.fflfAdmin) {
      resetForm.addEventListener('submit', function (event) {
        if (!window.confirm(fflfAdmin.i18n.resetConfirm)) {
          event.preventDefault();
        }
      });
    }

    function bindConfirm(selector, messageKey) {
      var form = root.querySelector(selector);
      if (!form || !window.fflfAdmin || !fflfAdmin.i18n[messageKey]) {
        return;
      }
      form.addEventListener('submit', function (event) {
        if (!window.confirm(fflfAdmin.i18n[messageKey])) {
          event.preventDefault();
        }
      });
    }
    bindConfirm('[data-fflf-switch]', 'switchConfirm');
    bindConfirm('[data-fflf-rollback]', 'rollbackConfirm');
    bindConfirm('[data-fflf-cleanup]', 'cleanupConfirm');

    // Appearance: "Check my shop page" loads the store's own shop page in a hidden frame (same site, nothing is sent
    // anywhere) and reports the filter area's width and the background behind it, as Auto sees them.
    var check = root.querySelector('[data-fflf-check-shop]');
    if (check && window.fflfAdmin) {
      check.addEventListener('click', function () {
        var t = fflfAdmin.i18n;
        var outLayout = root.querySelector('[data-fflf-check-layout]');
        var outStyle = root.querySelector('[data-fflf-check-style]');
        var fmt = function (s, a, b) { return String(s).replace('%1$s', a).replace('%2$s', b); };
        var frame = document.createElement('iframe');
        frame.setAttribute('aria-hidden', 'true');
        frame.setAttribute('tabindex', '-1');
        frame.style.cssText = 'position:absolute;left:-10000px;top:0;width:1440px;height:900px;border:0;visibility:hidden';
        check.disabled = true;
        var done = function (ok, width, bg) {
          check.disabled = false;
          if (frame.parentNode) { frame.parentNode.removeChild(frame); }
          if (!ok) {
            if (outLayout) { outLayout.textContent = t.checkFailed; }
            if (outStyle) { outStyle.textContent = ''; }
            return;
          }
          var w = Math.round(width);
          if (outLayout) { outLayout.textContent = fmt(t.checkLayout, w.toLocaleString(), w >= 720 ? t.bar : t.stacked); }
          if (outStyle) { outStyle.textContent = bg === 'dark' ? fmt(t.checkStyle, t.darkWord, t.dark) : fmt(t.checkStyle, t.lightWord, t.light); }
        };
        var timer = window.setTimeout(function () { done(false); }, 20000);
        frame.addEventListener('load', function () {
          window.setTimeout(function () {
            window.clearTimeout(timer);
            try {
              var doc = frame.contentDocument;
              var panel = doc && doc.querySelector('[data-fflf-panel]');
              if (!panel) { done(false); return; }
              done(true, panel.getBoundingClientRect().width, panel.getAttribute('data-fflf-bg'));
            } catch (err) {
              done(false);
            }
          }, 1200);
        });
        frame.src = check.getAttribute('data-fflf-check-shop');
        document.body.appendChild(frame);
      });
    }
  });
})();
