/*
 * FFL Filters inline resolver (1.3.1, 1.3.2, 1.3.4). Assets::paint_script() prints it inline just inside the panel's opening
 * tag. It resolves the backdrop behind the panel before any of the panel paints, and writes the same colour vars and
 * data-fflf-* markers that panel.js (detectStyle) writes, so panel.js adopts them with no visible change. It also sets
 * data-fflf-boot ("JS is coming"): panel.css holds the no-JS Show products button back while that mark is set and
 * panel.js has not set the panel up (data-fflf-js). 1.3.4: the paint call clears the mark after 3 s with a timer
 * (Assets::paint_script()), not a CSS animation, so reduce-motion settings cannot cut the hold short. Without
 * JavaScript the mark is never set.
 * fflfR(el, 1) only walks the backdrop and returns [stops, parseColor, worstContrast] (false on a photo): the button
 * edge helper (assets/js/edge.js) uses it so the Filter products ring is decided before the button paints.
 * Budget: 2,048 bytes once printed (tests/phpunit/without-woocommerce/InlineResolverTest.php). The logic mirrors
 * panel.js parseColor, luminance, contrast, mix, resolveBackdrop, pickFill, ensureContrast, aimContrast,
 * plateTokens, photoStyle and detectStyle; tests/js/panel-plate.test.js checks that both give the same result.
 * Names: P parseColor, L luminance, C contrast, X worstContrast, M mix, R solidify, H toHex, Q hexColor
 * (every 2 hex digits; only the first three count where one colour is meant), E ensureContrast, A aimContrast, F pickFill, Y plateTokens, U opaque, V writes vars,
 * T the sets' text, muted, placeholder and border colours. Colours are [r, g, b, a].
 * Differences kept for size, all corrected by panel.js's re-check: no 8-stop cap on very long gradients; body and
 * html are reached through the panel's own ancestors (always so in a page); the photo's theme-text test is the
 * luminance form of panel.js's contrast test.
 * No with (Math): it is a syntax error in strict mode, which a script-combining plugin may turn on.
 * 1.3.4 headroom: luminance's linear-segment cut is .04 (same result as .03928 for every 8-bit channel), and the
 * plate-surface search reuses the last tried stack instead of rebuilding it.
 * Only block comments in this file: Assets strips them and the line breaks.
 */
window.fflfR=(p,q)=>{try{
let G=getComputedStyle,W=[255,255,255],K=[0,0,0],N='light',Z='dark',d=p.dataset,a=!/[tk]$/.test(d.fflfStyleMode),
T=['1F293352606D5E6B787B8594','F3F5F7B6BEC7A9B2BC8E99A4'],
P=v=>/^rgb/.test(v)?[...v.match(/[\d.]+/g),1].map(Number):[0],
L=c=>(c=c.map(v=>(v/=255)<.04?v/12.92:((v+.055)/1.055)**2.4),.2126*c[0]+.7152*c[1]+.0722*c[2]),
C=(a,b)=>(a=L(a)+.05,b=L(b)+.05,a>b?a/b:b/a),
X=(a,b)=>Math.min(...b.map(c=>C(a,c))),
M=(a,b,t)=>a.map((v,i)=>v+(b[i]-v)*t),
R=c=>c.map(v=>v+.5|0),
H=c=>'#'+c.map(v=>(v|256).toString(16).slice(1)).join(''),
Q=h=>h.match(/../g).map(v=>+('0x'+v)),
E=(f,b,n=4.5,o=X(K,b)<X(W,b)?[W,K]:[K,W])=>[...Array(41)].map((_,i)=>R(M(f,o[i>20?(i-=20,1):0],i/20))).find(c=>X(c,b)>=n)||o[0],
A=(f,b,c=E(f,b,5))=>X(c,b)<5?E(f,b):c,
F=(s,t,b=Q(T[t]))=>s.reduce((w,c)=>C(b,c)<C(b,w)?c:w),
D=c=>L(c)<.18?Z:N,U=c=>c[3]>=.99,
V=(k,c,...r)=>(k.split(' ').map(k=>p.style.setProperty('--fflf-'+k,H(c))),r[0]&&V(...r)),
Y=(g,q)=>{let[B,I,J,O]=T[z].match(/.{6}/g).map(Q),j=f?'':'plate-',e=z?.1:.05;
if(!a)return V(j+'text',E(B,q),j+'muted',A(I,q));
u=[M(g,z?W:K,e),M(g,z?K:W,e),g].map(R).find(x=>X(E(B,o=[...q,x]),o)>=4.5)||g;y=E(B,o);k=E(O,o,3);
V(j+'text text focus',y,j+'muted muted',A(I,o),'surface input',g,'surface-2',u,'placeholder',E(J,[g]),'border control-off',k,'divider',R(M(g,y,.2)),'knob',E(g,[k],3))},
l=[],o=[W],u={},k=p,s,c,y,g,z,w,f;
while(k=k.parentElement){y=(s=G(k)).backgroundImage;c=P(s.backgroundColor);
if(/url/.test(y)){if(!l[0]){f=1;w=c[3]&&R(M(W,c,c[3]));break}s=[]}else s=(y.match(/rgba?\(.+?\)/g)||[]).map(P);
s[0]&&l.push(s);c[3]&&l.push([c]);
if(U(c)||s[0]&&s.every(U))break}
for(s of l.reverse())o=o.flatMap(a=>s.map(b=>M(a,b,b[3])));
s=o.map(R).filter(c=>u[c]?0:u[c]=1);
if(q)return!f&&[s,P,X];
d.fflfBoot=1;
d.fflfBg=g=f?w?D(w):L(P(G(p.parentElement).color))>.17913?Z:N:D(F(s,0));
a&&(d.fflfStyle=g);z=+(d.fflfStyle==Z);
d.fflfBackdrop=f?'photo':s[1]?'gradient':'solid';
if(f)(w=a&&w)&&Y(w,[w]),d.fflfPlate='theme',g=w||(z?[20,25,29]:W);
else Y(g=F(s,z),s);
d.fflfPageBg=H(g)
}catch{}};
