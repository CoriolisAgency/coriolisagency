/**
 * FFL Filters panel block: editor sidebar and preview.
 *
 * Uses the official small icon (ffl-filters-icon-small.svg) and the plugin
 * UI tokens. Storefront Apply is a separate script; this file is editor only.
 */
(function (wp) {
	'use strict';

	if (!wp || !wp.blocks || !wp.element) {
		return;
	}

	var el = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var InspectorControls = wp.blockEditor && wp.blockEditor.InspectorControls;
	var useBlockProps = wp.blockEditor && wp.blockEditor.useBlockProps;
	var PanelBody = wp.components && wp.components.PanelBody;
	var ToggleControl = wp.components && wp.components.ToggleControl;
	var TextControl = wp.components && wp.components.TextControl;
	var ServerSideRender = wp.serverSideRender;
	var __ = wp.i18n && wp.i18n.__ ? wp.i18n.__ : function (s) { return s; };
	var iconUrl = (window.fflfBlockEditor && window.fflfBlockEditor.iconUrl) || '';

	var icon = el(
		'svg',
		{
			xmlns: 'http://www.w3.org/2000/svg',
			viewBox: '0 0 512 512',
			width: 24,
			height: 24,
		},
		el('rect', { width: 512, height: 512, rx: 112, fill: '#0F1B2D' }),
		el('rect', { x: 96, y: 89, width: 320, height: 90, rx: 45, fill: '#4A6185' }),
		el('path', {
			d: 'M334 121 L360 147 L386 121',
			fill: 'none',
			stroke: '#D4A017',
			strokeWidth: 22,
			strokeLinecap: 'round',
			strokeLinejoin: 'round',
		}),
		el('rect', { x: 96, y: 211, width: 320, height: 90, rx: 45, fill: '#4A6185' }),
		el('path', {
			d: 'M334 243 L360 269 L386 243',
			fill: 'none',
			stroke: '#D4A017',
			strokeWidth: 22,
			strokeLinecap: 'round',
			strokeLinejoin: 'round',
		}),
		el('rect', { x: 96, y: 333, width: 320, height: 90, rx: 45, fill: '#4A6185' }),
		el('path', {
			d: 'M334 365 L360 391 L386 365',
			fill: 'none',
			stroke: '#D4A017',
			strokeWidth: 22,
			strokeLinecap: 'round',
			strokeLinejoin: 'round',
		})
	);

	function fallbackPreview() {
		return el(
			'div',
			{ className: 'ffl-filters-block-editor' },
			iconUrl
				? el('img', {
						className: 'ffl-filters-block-editor__icon',
						src: iconUrl,
						width: 32,
						height: 32,
						alt: '',
				  })
				: null,
			el(
				'p',
				{ className: 'ffl-filters-block-editor__title' },
				__('FFL Filters', 'ffl-filters')
			),
			el(
				'p',
				{ className: 'ffl-filters-block-editor__hint' },
				__('The filter panel will appear here on the shop catalog.', 'ffl-filters')
			)
		);
	}

	function preview(attributes) {
		if (ServerSideRender) {
			return el(ServerSideRender, {
				block: 'ffl-filters/panel',
				attributes: attributes,
				EmptyResponsePlaceholder: fallbackPreview,
				ErrorResponsePlaceholder: fallbackPreview,
			});
		}
		return fallbackPreview();
	}

	function edit(props) {
		var attributes = props.attributes || {};
		var setAttributes = props.setAttributes;
		var blockProps = useBlockProps
			? useBlockProps({ className: 'ffl-filters-block-editor__wrap' })
			: { className: 'ffl-filters-block-editor__wrap' };

		var chipsOn = attributes.chips !== 'no';
		var inheritOn = attributes.inherit !== false;

		return el(
			Fragment,
			null,
			InspectorControls
				? el(
						InspectorControls,
						null,
						el(
							PanelBody,
							{
								title: __('FFL Filters', 'ffl-filters'),
								initialOpen: true,
								className: 'ffl-filters-block-editor__inspector',
							},
							el(ToggleControl, {
								label: __('Show selected filters as chips', 'ffl-filters'),
								help: __('Shows each filter a shopper has picked at the top of the panel, with an x to remove it.', 'ffl-filters'),
								checked: chipsOn,
								onChange: function (value) {
									setAttributes({ chips: value ? 'yes' : 'no' });
								},
							}),
							el(TextControl, {
								label: __('Panel heading', 'ffl-filters'),
								help: __('Shown at the top of this panel. Leave blank to use the heading from your FFL Filters settings.', 'ffl-filters'),
								value: attributes.heading || '',
								onChange: function (value) {
									setAttributes({ heading: value || '' });
								},
							})
						),
						el(
							PanelBody,
							{
								title: __('Advanced settings', 'ffl-filters'),
								initialOpen: false,
							},
							el(ToggleControl, {
								label: __("Follow the page's products", 'ffl-filters'),
								help: __(
									'On a category page or a Product Collection block, the filters cover only those products. Turn this off to filter the whole shop every time.',
									'ffl-filters'
								),
								checked: inheritOn,
								onChange: function (value) {
									setAttributes({ inherit: !!value });
								},
							}),
							el(TextControl, {
								label: __('Filters to show in this block', 'ffl-filters'),
								help: __(
									'Leave blank to use your Filters tab settings, or list taxonomy names separated by commas, for example pa_caliber, product_cat, product_brand.',
									'ffl-filters'
								),
								value: attributes.taxonomies || '',
								onChange: function (value) {
									setAttributes({ taxonomies: value || '' });
								},
							}),
							el(TextControl, {
								label: __('Category filter', 'ffl-filters'),
								help: __("Type yes to show the category filter, no to hide it, or a category slug to show only that category's products.", 'ffl-filters'),
								value: attributes.category || '',
								onChange: function (value) {
									setAttributes({ category: value || '' });
								},
							}),
							el(TextControl, {
								label: __('Tag filter', 'ffl-filters'),
								help: __('Type yes to show the tag filter, no to hide it, or a tag slug to show only products with that tag.', 'ffl-filters'),
								value: attributes.tag || '',
								onChange: function (value) {
									setAttributes({ tag: value || '' });
								},
							})
						)
				  )
				: null,
			el('div', blockProps, preview(attributes))
		);
	}

	wp.blocks.registerBlockType('ffl-filters/panel', {
		icon: icon,
		edit: edit,
		save: function () {
			return null;
		},
	});
})(window.wp);
