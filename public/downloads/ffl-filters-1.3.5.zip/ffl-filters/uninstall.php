<?php
/**
 * Uninstall handler for FFL Filters.
 *
 * @package FFL_Filters
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'fflf_generation' );
delete_option( 'fflf_generation_bumped_at' );
delete_option( 'fflf_settings' );
delete_option( 'fflf_import' );
delete_option( 'fflf_rollback' );
delete_option( 'fflf_slow_queries' );
delete_option( 'fflf_lead' );
delete_option( 'fflf_lead_prompted' );
delete_option( 'fflf_last_seen_version' );
delete_option( 'fflf_panel_seen' );
delete_option( 'fflf_sidebar_placement' );

if ( function_exists( 'delete_transient' ) ) {
	delete_transient( 'fflf_new_attributes_hidden' );
}

global $wpdb;

if ( isset( $wpdb ) && $wpdb instanceof wpdb ) {
	$fflf_like         = $wpdb->esc_like( '_transient_fflf_' ) . '%';
	$fflf_timeout_like = $wpdb->esc_like( '_transient_timeout_fflf_' ) . '%';

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
			$fflf_like,
			$fflf_timeout_like
		)
	);
}

if ( function_exists( 'wp_unschedule_hook' ) ) {
	wp_unschedule_hook( 'fflf_cache_bump_generation' );
}

if ( function_exists( 'wp_cache_supports' ) && wp_cache_supports( 'flush_group' ) && function_exists( 'wp_cache_flush_group' ) ) {
	wp_cache_flush_group( 'fflf' );
} elseif ( function_exists( 'wp_cache_delete' ) ) {
	wp_cache_delete( 'generation', 'fflf' );
	wp_cache_delete( 'key_index', 'fflf' );
}

// Never touches Coriolis Product Filters options, transients, or tables.
