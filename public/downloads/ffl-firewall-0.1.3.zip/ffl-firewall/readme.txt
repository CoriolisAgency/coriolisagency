=== FFL Firewall ===
Contributors: coriolisagency
Tags: woocommerce, checkout, ffl
Requires at least: 6.5
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 0.1.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

At checkout, FFL Firewall checks each product in the cart by UPC against the zip code the shopper entered.

== Description ==

At checkout, FFL Firewall checks each product in the cart by UPC against the zip code the shopper entered. Set how it handles each result here, and run a test before you turn it on for shoppers.

FFL Firewall is a tool that helps you catch restricted items at checkout. You're still responsible for what you ship, and this is not legal advice.

== Changelog ==

= 0.1.3 =
* Test panel wording updated: a result card for items that need a permit or age check, a card when this network has reached its daily test limit (with the runs your site has left), and a clearer card when a test can't reach the check service.
* A test that can't reach the check service doesn't count against your 10 test runs.
* The notice in the WordPress admin now says "Hide this notice".

= 0.1.2 =
* Test panel on the settings screen for sites with no active license: a UPC and a zip, suggested test pairs, 10 test runs per site.
* Notice in the WordPress admin while there is no active license.

= 0.1.1 =
* Default proxy URL set to production.

= 0.1.0 =
* Sprint 1 skeleton: settings screen, license key check and the proxy client. Not released.
