<?php
/**
 * Plugin bootstrap.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall;

defined( 'ABSPATH' ) || exit;

/**
 * Main plugin controller.
 */
class Plugin {

	/**
	 * Wire hooks once WooCommerce is present.
	 *
	 * @return void
	 */
	public function init() {
		$settings = new Settings\Repository();
		$log      = new Log\Store();
		$client   = new Proxy\Client( $settings );
		$resolver = new Cart\Upc_Resolver( $settings );
		$service  = new Checkout\Service( $settings, $client, $log, $resolver );

		( new Admin\Page( $settings, $client, $log, $resolver ) )->register();
		( new Checkout\Classic( $service ) )->register();
		( new Checkout\Block( $service ) )->register();
		( new Orders\Flag_Column() )->register();
	}
}
