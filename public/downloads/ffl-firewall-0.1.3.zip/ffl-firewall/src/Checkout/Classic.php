<?php
/**
 * Classic (shortcode) checkout: runs the check on every order review refresh
 * (address or shipping change), shows the notices and the permit checkbox,
 * and enforces the rules again on Place Order (server side, so it holds with
 * JavaScript off).
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Checkout;

use FFL_Firewall\Rules\Engine;

defined( 'ABSPATH' ) || exit;

/**
 * Classic checkout integration.
 */
class Classic {

	/**
	 * Service.
	 *
	 * @var Service
	 */
	private $service;

	/**
	 * Optional environment factory (tests).
	 *
	 * @var callable|null
	 */
	private $env_factory;

	/**
	 * Constructor.
	 *
	 * @param Service       $service     Service.
	 * @param callable|null $env_factory Optional environment factory (tests).
	 */
	public function __construct( Service $service, $env_factory = null ) {
		$this->service     = $service;
		$this->env_factory = is_callable( $env_factory ) ? $env_factory : null;
	}

	/**
	 * Checkout environment (WooCommerce, or a test double from the factory).
	 *
	 * @param array<string, mixed> $overrides Request overrides.
	 * @return Environment
	 */
	private function env( $overrides = array() ) {
		return $this->env_factory ? call_user_func( $this->env_factory, $overrides ) : new Woo_Environment( $overrides );
	}

	/**
	 * Hook classic checkout.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'woocommerce_checkout_update_order_review', array( $this, 'on_review' ), 5 );
		add_filter( 'woocommerce_update_order_review_fragments', array( $this, 'fragments' ) );
		add_action( 'woocommerce_before_checkout_form', array( $this, 'print_notices_slot' ), 20 );
		add_action( 'woocommerce_review_order_before_submit', array( $this, 'print_ack' ) );
		add_filter( 'woocommerce_cart_item_name', array( $this, 'badge' ), 20, 3 );
		add_action( 'woocommerce_after_checkout_validation', array( $this, 'validate' ), 20, 2 );
		add_action( 'woocommerce_checkout_order_created', array( $this, 'order_created' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ) );
	}

	/**
	 * Request overrides from an order review post (address fields arrive as country/postcode and s_*).
	 *
	 * @param array<string, mixed> $post Parsed post data.
	 * @return array<string, mixed>
	 */
	public static function review_overrides( $post ) {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- WooCommerce verifies the update_order_review nonce.
		$raw = isset( $_POST ) ? wp_unslash( $_POST ) : array();
		// phpcs:enable
		$get = function ( $key ) use ( $raw ) {
			return isset( $raw[ $key ] ) && is_scalar( $raw[ $key ] ) ? sanitize_text_field( (string) $raw[ $key ] ) : '';
		};
		$methods = isset( $raw['shipping_method'] ) ? array_map( 'sanitize_text_field', (array) $raw['shipping_method'] ) : array();
		unset( $post );
		return array(
			'shipping_postcode' => $get( 's_postcode' ),
			'billing_postcode'  => $get( 'postcode' ),
			'shipping_state'    => $get( 's_state' ),
			'billing_state'     => $get( 'state' ),
			'shipping_methods'  => $methods,
		);
	}

	/**
	 * Order review refresh: run the check (items the rules remove come out before totals).
	 *
	 * @param string $post_data Serialized checkout form.
	 * @return void
	 */
	public function on_review( $post_data ) {
		$post = array();
		parse_str( (string) $post_data, $post );
		$env = $this->env( self::review_overrides( $post ) );
		$this->service->set_permit_ack( $env, ! empty( $post['fflfw_permit_ack'] ) );
		$this->service->evaluate( $env );
	}

	/**
	 * Notices HTML for the current state (removed items, FFL only, permit).
	 *
	 * @return string
	 */
	public function notices_html() {
		$env   = $this->env();
		$state = $this->service->state( $env );
		$html  = '';

		foreach ( $this->service->take_removed( $env, false ) as $removed ) {
			$html .= '<ul class="woocommerce-info fflfw-notice fflfw-notice--info" role="alert"><li><strong>' . esc_html__( "An item in your cart can't ship to your zip", 'ffl-firewall' ) . '</strong>';
			$html .= '<p>' . esc_html( $this->service->message( 'removed', $removed['product'], $removed['zip'] ) ) . '</p>';
			$html .= '<p>' . esc_html__( 'If you think this is a mistake, contact us before you place your order.', 'ffl-firewall' ) . '</p></li></ul>';
		}
		if ( ! empty( $state['status'] ) && 'checked' === $state['status'] ) {
			foreach ( Service::lines_with( $state, Engine::FFL ) as $line ) {
				$html .= '<ul class="woocommerce-info fflfw-notice fflfw-notice--info" role="alert"><li><strong>' . esc_html__( 'This item ships to an FFL or dealer only', 'ffl-firewall' ) . '</strong>';
				$html .= '<p>' . esc_html( $this->service->message( 'ffl', $line['name'], $state['zip'], $state['state'] ) ) . '</p></li></ul>';
			}
			foreach ( Service::lines_with( $state, Engine::PERMIT ) as $line ) {
				$html .= '<ul class="woocommerce-info fflfw-notice fflfw-notice--warn" role="alert"><li><strong>' . esc_html__( 'This item needs a permit or age check', 'ffl-firewall' ) . '</strong>';
				$html .= '<p>' . esc_html( $this->service->message( 'permit', $line['name'], $state['zip'], $state['state'] ) ) . '</p></li></ul>';
			}
		}
		return '<div class="fflfw-notices" aria-live="polite">' . $html . '</div>';
	}

	/**
	 * Empty notices slot at the top of the checkout form; order review refreshes fill it.
	 *
	 * @return void
	 */
	public function print_notices_slot() {
		echo '<div class="fflfw-notices" aria-live="polite"></div>';
	}

	/**
	 * Add our notices to the order review fragments.
	 *
	 * @param array<string, string> $fragments Fragments.
	 * @return array<string, string>
	 */
	public function fragments( $fragments ) {
		$fragments['.fflfw-notices'] = $this->notices_html();
		return $fragments;
	}

	/**
	 * Required permit or age checkbox above Place Order (inside the payment fragment).
	 *
	 * @return void
	 */
	public function print_ack() {
		$env   = $this->env();
		$state = $this->service->state( $env );
		if ( empty( Service::lines_with( $state, Engine::PERMIT ) ) ) {
			return;
		}
		$checked = $this->service->permit_acked( $env );
		echo '<p class="form-row validate-required fflfw-ack" id="fflfw_permit_ack_field">';
		echo '<label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox"><input type="checkbox" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" name="fflfw_permit_ack" id="fflfw_permit_ack" value="1"' . checked( $checked, true, false ) . ' required /> ';
		echo '<span>' . esc_html__( "I understand this item won't ship until the permit or age check is done.", 'ffl-firewall' ) . '</span>&nbsp;<abbr class="required" title="' . esc_attr__( 'required', 'ffl-firewall' ) . '">*</abbr></label></p>';
		echo '<p class="fflfw-ack__req">' . esc_html__( 'Tick the box above to place your order.', 'ffl-firewall' ) . '</p>';
	}

	/**
	 * Badge after the item name in the order review table.
	 *
	 * @param string               $name Name HTML.
	 * @param array<string, mixed> $item Cart item.
	 * @param string               $key  Cart item key.
	 * @return string
	 */
	public function badge( $name, $item, $key ) {
		unset( $item );
		if ( ! function_exists( 'is_checkout' ) || ! is_checkout() ) {
			return $name;
		}
		$state = $this->service->state( $this->env() );
		if ( isset( Service::lines_with( $state, Engine::FFL )[ $key ] ) ) {
			$name .= ' <span class="fflfw-badge">' . esc_html__( 'Ships to an FFL or dealer only', 'ffl-firewall' ) . '</span>';
		} elseif ( isset( Service::lines_with( $state, Engine::PERMIT )[ $key ] ) ) {
			$name .= ' <span class="fflfw-badge">' . esc_html__( 'Needs a permit or age check', 'ffl-firewall' ) . '</span>';
		}
		return $name;
	}

	/**
	 * Place Order: re-run the check with the posted address, then enforce the rules.
	 *
	 * @param array<string, mixed> $data   Posted checkout data.
	 * @param \WP_Error            $errors Errors.
	 * @return void
	 */
	public function validate( $data, $errors ) {
		$overrides = array(
			'shipping_postcode' => ! empty( $data['ship_to_different_address'] ) && isset( $data['shipping_postcode'] ) ? (string) $data['shipping_postcode'] : '',
			'billing_postcode'  => isset( $data['billing_postcode'] ) ? (string) $data['billing_postcode'] : '',
			'shipping_state'    => ! empty( $data['ship_to_different_address'] ) && isset( $data['shipping_state'] ) ? (string) $data['shipping_state'] : '',
			'billing_state'     => isset( $data['billing_state'] ) ? (string) $data['billing_state'] : '',
			'shipping_methods'  => isset( $data['shipping_method'] ) ? (array) $data['shipping_method'] : array(),
		);
		$env = $this->env( $overrides );
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- WooCommerce verifies the checkout nonce.
		$acked = ! empty( $_POST['fflfw_permit_ack'] );
		$this->service->set_permit_ack( $env, $acked );
		$state = $this->service->evaluate( $env );
		if ( empty( $state['status'] ) || 'checked' !== $state['status'] ) {
			return;
		}

		// FFL-only (CC) items show the info notice only and never block the order (Paul, 1:51 PM ET).
		foreach ( $this->service->place_order_errors( $state, $acked ) as $i => $message ) {
			$errors->add( 'fflfw_' . $i, esc_html( $message ) );
		}
	}

	/**
	 * Order created: flag it and add the notes.
	 *
	 * @param \WC_Order $order Order.
	 * @return void
	 */
	public function order_created( $order ) {
		$env = $this->env();
		$this->service->apply_to_order( $order, $this->service->state( $env ) );
		$this->service->set_permit_ack( $env, false );
	}

	/**
	 * Classic checkout script and styles.
	 *
	 * @return void
	 */
	public function enqueue() {
		if ( ! function_exists( 'is_checkout' ) || ! is_checkout() ) {
			return;
		}
		$url = defined( 'FFLFW_URL' ) ? FFLFW_URL : '';
		$ver = defined( 'FFLFW_VERSION' ) ? FFLFW_VERSION : '0.0.0';
		wp_enqueue_style( 'fflfw-checkout', $url . 'assets/css/checkout.css', array(), $ver );
		wp_enqueue_script( 'fflfw-checkout-classic', $url . 'assets/js/checkout-classic.js', array( 'jquery' ), $ver, true );
		wp_localize_script( 'fflfw-checkout-classic', 'fflfwClassic', Strings::checking() );
	}
}
