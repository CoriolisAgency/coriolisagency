<?php
/**
 * WooCommerce-backed checkout environment. Address and shipping values posted
 * with the current request (classic update_order_review or Place Order) win
 * over the saved customer, since WooCommerce saves them only after our hook runs.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Checkout;

defined( 'ABSPATH' ) || exit;

/**
 * WooCommerce environment.
 */
class Woo_Environment implements Environment {

	/**
	 * Request overrides: shipping_postcode, billing_postcode, shipping_state, billing_state, shipping_methods.
	 *
	 * @var array<string, mixed>
	 */
	private $overrides;

	/**
	 * Constructor.
	 *
	 * @param array<string, mixed> $overrides Request overrides.
	 */
	public function __construct( $overrides = array() ) {
		$this->overrides = is_array( $overrides ) ? $overrides : array();
	}

	/**
	 * Cart lines.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public function lines() {
		$lines = array();
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return $lines;
		}
		foreach ( WC()->cart->get_cart() as $key => $item ) {
			$product = isset( $item['data'] ) ? $item['data'] : null;
			if ( ! is_object( $product ) ) {
				continue;
			}
			$lines[ (string) $key ] = array(
				'name'    => $product->get_name(),
				'product' => $product,
			);
		}
		return $lines;
	}

	/**
	 * Override or customer value.
	 *
	 * @param string $key    Override key.
	 * @param string $getter Customer getter.
	 * @return string
	 */
	private function value( $key, $getter ) {
		if ( isset( $this->overrides[ $key ] ) && '' !== trim( (string) $this->overrides[ $key ] ) ) {
			return trim( (string) $this->overrides[ $key ] );
		}
		if ( function_exists( 'WC' ) && WC()->customer && method_exists( WC()->customer, $getter ) ) {
			return trim( (string) WC()->customer->$getter() );
		}
		return '';
	}

	/**
	 * Shipping postcode, falling back to billing.
	 *
	 * @return string
	 */
	public function postcode() {
		$zip = $this->value( 'shipping_postcode', 'get_shipping_postcode' );
		return '' !== $zip ? $zip : $this->value( 'billing_postcode', 'get_billing_postcode' );
	}

	/**
	 * Shipping state, falling back to billing.
	 *
	 * @return string
	 */
	public function state_code() {
		$state = $this->value( 'shipping_state', 'get_shipping_state' );
		return '' !== $state ? $state : $this->value( 'billing_state', 'get_billing_state' );
	}

	/**
	 * Whether the chosen shipping method is local pickup (classic local_pickup or block pickup_location).
	 *
	 * @return bool
	 */
	public function is_local_pickup() {
		$methods = isset( $this->overrides['shipping_methods'] ) ? (array) $this->overrides['shipping_methods'] : array();
		if ( empty( $methods ) && function_exists( 'WC' ) && WC()->session ) {
			$methods = (array) WC()->session->get( 'chosen_shipping_methods', array() );
		}
		foreach ( $methods as $method ) {
			$method = (string) $method;
			if ( 0 === strpos( $method, 'local_pickup' ) || 0 === strpos( $method, 'pickup_location' ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Remove a cart line.
	 *
	 * @param string $key Line key.
	 * @return void
	 */
	public function remove_line( $key ) {
		if ( function_exists( 'WC' ) && WC()->cart ) {
			WC()->cart->remove_cart_item( $key );
		}
	}

	/**
	 * Session read.
	 *
	 * @param string $key      Key.
	 * @param mixed  $fallback Fallback.
	 * @return mixed
	 */
	public function session_get( $key, $fallback = null ) {
		if ( function_exists( 'WC' ) && WC()->session ) {
			$value = WC()->session->get( $key, null );
			return null === $value ? $fallback : $value;
		}
		return $fallback;
	}

	/**
	 * Session write.
	 *
	 * @param string $key   Key.
	 * @param mixed  $value Value.
	 * @return void
	 */
	public function session_set( $key, $value ) {
		if ( function_exists( 'WC' ) && WC()->session ) {
			WC()->session->set( $key, $value );
		}
	}
}
