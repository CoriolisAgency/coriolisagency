<?php
/**
 * The site key the demo test panel counts runs against.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Demo;

defined( 'ABSPATH' ) || exit;

/**
 * Site identity for the demo counter. No license is involved: the key is the sha256 of the
 * normalized home host, so a reinstall or a new database on the same site does not reset it.
 */
class Site {

	/**
	 * Normalized home host: lowercase, no port, no trailing dot, no leading www.
	 *
	 * @param string|null $home_url Home URL; defaults to home_url().
	 * @return string
	 */
	public static function host( $home_url = null ) {
		$url  = null === $home_url ? (string) home_url() : (string) $home_url;
		$host = wp_parse_url( $url, PHP_URL_HOST );
		$host = is_string( $host ) ? strtolower( trim( $host ) ) : '';
		$host = rtrim( $host, '.' );
		if ( 0 === strpos( $host, 'www.' ) ) {
			$host = substr( $host, 4 );
		}
		return $host;
	}

	/**
	 * Site key: sha256 of the normalized host (64 lowercase hex characters).
	 *
	 * @param string|null $home_url Home URL; defaults to home_url().
	 * @return string
	 */
	public static function key( $home_url = null ) {
		return hash( 'sha256', self::host( $home_url ) );
	}
}