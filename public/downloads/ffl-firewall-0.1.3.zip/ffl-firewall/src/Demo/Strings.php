<?php
/**
 * Demo test panel strings. Copy is Brandy's: demo-panel-v1 COPY.md, verbatim. Do not reword here.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Demo;

defined( 'ABSPATH' ) || exit;

/**
 * String table.
 */
class Strings {

	/**
	 * Text for one key. {n}, {upc}, {zip} and {code} are filled by the caller.
	 *
	 * @param string $key Key from COPY.md.
	 * @return string
	 */
	public static function get( $key ) {
		switch ( $key ) {
			case 'intro':
				return __( 'At checkout, FFL Firewall checks each product in the cart by UPC against the zip code the shopper entered. This site has no license key yet, so FFL Firewall isn\'t checking carts, and your orders are left alone.', 'ffl-firewall' );
			case 'top.title':
				return __( 'FFL Firewall isn\'t checking carts on this site yet', 'ffl-firewall' );
			case 'top.body':
				return __( 'There\'s no license key here, so FFL Firewall doesn\'t check carts and leaves every order alone. A license is $79 a month for unlimited transactions; paste the key below and click Check key to turn the checks on. Until then, the test panel below shows what each result looks like.', 'ffl-firewall' );
			case 'top.cta':
				return __( 'Get a license', 'ffl-firewall' );
			case 'top.link':
				return __( 'Try the test panel', 'ffl-firewall' );
			case 'wp.body':
				return __( 'FFL Firewall isn\'t checking carts: this site has no license key, so orders are left alone. A license is $79 a month for unlimited transactions.', 'ffl-firewall' );
			case 'wp.cta':
				return __( 'Get a license', 'ffl-firewall' );
			case 'wp.link':
				return __( 'Open the test panel', 'ffl-firewall' );
			case 'lic.label':
				return __( 'License key', 'ffl-firewall' );
			case 'lic.ph':
				return __( 'Paste your license key', 'ffl-firewall' );
			case 'lic.btn':
				return __( 'Check key', 'ffl-firewall' );
			case 'lic.status':
				return __( 'No license key yet', 'ffl-firewall' );
			case 'lic.help':
				return __( 'Paste the license key we emailed you after checkout, then click Check key. If you don\'t have a key yet, get a license on the FFL Firewall page; it\'s $79 a month for unlimited transactions.', 'ffl-firewall' );
			case 't.label':
				return __( 'Test panel', 'ffl-firewall' );
			case 't.help':
				return __( 'Type a UPC and a zip code to see what a shopper would get once your license is in. Each site gets 10 test runs in total, nothing touches a real cart, and no order is made.', 'ffl-firewall' );
			case 't.upc':
				return __( 'UPC', 'ffl-firewall' );
			case 't.upc.ph':
				return __( '12-digit UPC', 'ffl-firewall' );
			case 't.zip':
				return __( 'Zip code', 'ffl-firewall' );
			case 't.zip.ph':
				return __( '5-digit zip', 'ffl-firewall' );
			case 't.btn':
				return __( 'Run test', 'ffl-firewall' );
			case 't.left':
				return __( '{n} of 10 test runs left on this site', 'ffl-firewall' );
			case 't.left.low':
				return __( '{n} of 10 test runs left on this site. When they\'re used up, the test panel locks until you add a license key.', 'ffl-firewall' );
			case 't.sug.title':
				return __( 'Try one of these to see each result', 'ffl-firewall' );
			case 't.sug.c.res':
				return __( 'Result', 'ffl-firewall' );
			case 't.sug.c.upc':
				return __( 'UPC', 'ffl-firewall' );
			case 't.sug.c.zip':
				return __( 'Zip code', 'ffl-firewall' );
			case 't.sug.c.type':
				return __( 'Type', 'ffl-firewall' );
			case 't.sug.use':
				return __( 'Use these', 'ffl-firewall' );
			case 't.sug.sim':
				return __( 'No test data triggers this one. It happens only when the check service times out, returns an error or can\'t be reached.', 'ffl-firewall' );
			case 't.sug.sim.link':
				return __( 'Show an example', 'ffl-firewall' );
			case 't.sim.badge':
				return __( 'Simulated', 'ffl-firewall' );
			case 't.uncounted':
				return __( 'Simulated example. It doesn\'t use a test run.', 'ffl-firewall' );
			case 'type.firearm':
				return __( 'Firearm', 'ffl-firewall' );
			case 'type.ammo':
				return __( 'Ammunition', 'ffl-firewall' );
			case 'type.roster':
				return __( 'Firearm, roster', 'ffl-firewall' );
			case 'type.nf':
				return __( 'UPC not found', 'ffl-firewall' );
			case 'r.pass':
				return __( 'Item can ship', 'ffl-firewall' );
			case 'r.pass.d':
				return __( 'UPC {upc} to zip {zip}. The check found nothing for this zip, so with a license the item stays in the cart and the shopper sees no message.', 'ffl-firewall' );
			case 'r.rm':
				return __( 'Item would be removed', 'ffl-firewall' );
			case 'r.rm.d':
				return __( 'UPC {upc} to zip {zip}. Once you\'re licensed, this item comes out of the cart, and the shopper sees this message:', 'ffl-firewall' );
			case 'r.rm.q':
				return __( 'We took this item out of your cart because it can\'t ship to zip {zip}. The rest of your order is still here, and you can keep checking out.', 'ffl-firewall' );
			case 'r.flag':
				return __( 'Allowed and flagged', 'ffl-firewall' );
			case 'r.flag.d':
				return __( 'UPC {upc} to zip {zip}. With a license, the shopper can check out with the item and sees no message, while the order is marked Flagged in Orders with a note giving the reason code: {code}.', 'ffl-firewall' );
			case 'r.cc':
				return __( 'CC: ship to an FFL or dealer only', 'ffl-firewall' );
			case 'r.cc.d':
				return __( 'UPC {upc} to zip {zip}. On a licensed store, the item stays in the cart, and the shopper sees this message:', 'ffl-firewall' );
			case 'r.cc.q':
				return __( 'For zip {zip}, we can ship this item to a licensed firearms dealer (FFL) but not to your home address. Choose your dealer in the FFL dealer selection on this page, and you\'ll pick it up there.', 'ffl-firewall' );
			case 'r.nc':
				return __( 'Check couldn\'t run', 'ffl-firewall' );
			case 'r.nc.d':
				return __( 'This is what happens when the check service times out, returns an error or can\'t be reached. With a license, the item passes and stays in the cart, the shopper sees no message, and the order gets an order note and a Flagged label so you can review it before you ship.', 'ffl-firewall' );
			case 't.ipcap.title':
				return __( 'This network has reached today\'s test limit', 'ffl-firewall' );
			case 't.ipcap.d':
				return __( 'One network can run up to 30 tests a day, and that many have already come from yours. Your site still has {n} of 10 test runs left, and you can use them again tomorrow.', 'ffl-firewall' );
			case 't.ipcap.d.nocount':
				return __( 'One network can run up to 30 tests a day, and that many have already come from yours. You can run tests again tomorrow.', 'ffl-firewall' );
			case 'adm.notice.dismiss':
				return __( 'Hide this notice', 'ffl-firewall' );
			case 'r.pm':
				return __( 'Needs a permit or age check', 'ffl-firewall' );
			case 'r.pm.d':
				return __( 'With a license, this item stays in the cart, and the shopper has to tick a box saying it won\'t ship until the permit or age check is done. After the order is placed, you contact the shopper to confirm before you ship; nothing is uploaded at checkout.', 'ffl-firewall' );
			case 'r.nc.live':
				return __( 'This test couldn\'t reach the check service', 'ffl-firewall' );
			case 'r.nc.live.d':
				return __( 'This run didn\'t count against your 10. Try it again in a few minutes, and if it keeps failing, [contact Coriolis support]({support_url}). With a license, an item that can\'t be checked stays in the cart, and the order gets an order note and a Flagged label so you can review it before you ship.', 'ffl-firewall' );
			case 'u.title':
				return __( 'You\'ve used all 10 test runs on this site', 'ffl-firewall' );
			case 'u.body':
				return __( 'To check real carts, buy a license: $79 a month for unlimited transactions, billed monthly through Stripe Checkout, and you can cancel anytime. Your key arrives by email, and you paste it into License key above.', 'ffl-firewall' );
			case 'u.cta':
				return __( 'Buy a license', 'ffl-firewall' );
			case 'u.link':
				return __( 'Already have a key? Paste it above and click Check key.', 'ffl-firewall' );
			case 'disc':
				return __( 'FFL Firewall is a tool that helps you catch restricted items at checkout. You\'re still responsible for what you ship, and this is not legal advice.', 'ffl-firewall' );
			default:
				return '';
		}
	}
}
