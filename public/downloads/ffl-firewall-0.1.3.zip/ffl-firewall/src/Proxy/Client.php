<?php
/**
 * Client for the Coriolis proxy. The plugin sends only the store's license
 * key, the shipping zip and the cart UPCs; the product-check API key lives on
 * the proxy and never in this plugin.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Proxy;

use FFL_Firewall\Demo\Site;
use FFL_Firewall\Log\Store;
use FFL_Firewall\Settings\Repository;

defined( 'ABSPATH' ) || exit;

/**
 * Calls /api/check and /api/license on the proxy.
 */
class Client {

	/**
	 * HTTP timeout in seconds. The proxy answers within its own 3.5 s budget,
	 * so 5 s leaves room for the network both ways.
	 *
	 * @var int
	 */
	const TIMEOUT = 5;

	/**
	 * Settings.
	 *
	 * @var Repository
	 */
	private $settings;

	/**
	 * Check log.
	 *
	 * @var Store|null
	 */
	private $log;

	/**
	 * Constructor.
	 *
	 * @param Repository $settings Settings.
	 * @param Store|null $log      Check log.
	 */
	public function __construct( Repository $settings, $log = null ) {
		$this->settings = $settings;
		$this->log      = $log instanceof Store ? $log : null;
	}

	/**
	 * Proxy base URL (constant, then filter).
	 *
	 * @return string
	 */
	public function base_url() {
		$url = defined( 'FFLFW_PROXY_URL' ) ? (string) FFLFW_PROXY_URL : '';
		$url = (string) apply_filters( 'fflfw_proxy_url', $url );
		return rtrim( $url, '/' );
	}

	/**
	 * Check every cart UPC for one zip in a single proxy call.
	 *
	 * @param string             $zip  Shipping zip (5 digits).
	 * @param array<int, string> $upcs Cart UPCs.
	 * @return array<string, mixed> Proxy answer, or a pass-with-flag answer when the call fails.
	 */
	public function check( $zip, $upcs ) {
		$upcs   = array_values( array_unique( array_filter( array_map( 'strval', (array) $upcs ) ) ) );
		$answer = $this->post(
			'/api/check',
			array(
				'license_key' => (string) $this->settings->get( 'license_key', '' ),
				'zip'         => (string) $zip,
				'upcs'        => $upcs,
			)
		);
		return $answer;
	}

	/**
	 * Ask the proxy for a license key's status.
	 *
	 * @param string $key License key.
	 * @return string 'active', 'inactive', 'invalid' or 'unknown' when the proxy can't be reached.
	 */
	public function license_status( $key ) {
		$answer = $this->post( '/api/license', array( 'license_key' => (string) $key ) );
		if ( isset( $answer['license']['status'] ) && is_string( $answer['license']['status'] ) ) {
			return $answer['license']['status'];
		}
		return 'unknown';
	}

	/**
	 * Runs left on the demo test panel for this site (read-only; no license involved).
	 *
	 * @return array<string, mixed> Proxy answer (ok, used, remaining, cap, state) or an error answer.
	 */
	public function demo_status() {
		return $this->demo_request( 'GET', '/api/demo?site_hash=' . rawurlencode( Site::key() ), null );
	}

	/**
	 * One demo test run: a UPC and a zip, no license key, no cart.
	 *
	 * @param string $upc UPC.
	 * @param string $zip Zip.
	 * @return array<string, mixed> Proxy answer (ok, result, used, remaining) or an error answer.
	 */
	public function demo_run( $upc, $zip ) {
		return $this->demo_request(
			'POST',
			'/api/demo',
			array(
				'site_hash' => Site::key(),
				'zip'       => (string) $zip,
				'upc'       => (string) $upc,
			)
		);
	}

	/**
	 * Demo route call. Any failure comes back as ok=false with an error name; nothing is thrown.
	 *
	 * @param string                    $method GET or POST.
	 * @param string                    $path   Route path.
	 * @param array<string, mixed>|null $body   JSON body for POST.
	 * @return array<string, mixed>
	 */
	private function demo_request( $method, $path, $body ) {
		$args = array(
			'timeout' => self::TIMEOUT,
			'headers' => array(
				'Content-Type' => 'application/json',
				'Accept'       => 'application/json',
			),
		);
		$url  = $this->base_url() . $path;
		if ( 'POST' === $method ) {
			$args['body'] = wp_json_encode( $body );
			$response     = wp_remote_post( $url, $args );
		} else {
			$response = wp_remote_get( $url, $args );
		}
		if ( is_wp_error( $response ) ) {
			return array( 'ok' => false, 'error' => 'proxy_unreachable' );
		}
		$json = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $json ) ) {
			return array( 'ok' => false, 'error' => 'proxy_error' );
		}
		if ( ! isset( $json['ok'] ) ) {
			$json['ok'] = false;
		}
		if ( ! $json['ok'] && ! isset( $json['error'] ) ) {
			$json['error'] = 'proxy_error';
		}
		return $json;
	}
	/**
	 * POST JSON to the proxy.
	 *
	 * @param string               $path Route path.
	 * @param array<string, mixed> $body Body.
	 * @return array<string, mixed>
	 */
	private function post( $path, $body ) {
		$response = wp_remote_post(
			$this->base_url() . $path,
			array(
				'timeout' => self::TIMEOUT,
				'headers' => array(
					'Content-Type' => 'application/json',
					'Accept'       => 'application/json',
				),
				'body'    => wp_json_encode( $body ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return self::pass_with_flag( 'proxy_unreachable' );
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$json = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		if ( 200 !== $code || ! is_array( $json ) ) {
			return self::pass_with_flag( 'proxy_error' );
		}

		return $json;
	}

	/**
	 * The answer used when the proxy can't be reached: checkout passes and the order is flagged.
	 *
	 * @param string $flag Flag name.
	 * @return array<string, mixed>
	 */
	public static function pass_with_flag( $flag ) {
		return array(
			'ok'             => false,
			'pass_with_flag' => true,
			'flag'           => $flag,
			'results'        => array(),
		);
	}
}
