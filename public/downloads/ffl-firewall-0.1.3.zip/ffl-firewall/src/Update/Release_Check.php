<?php
/**
 * GitHub Releases update check (placeholder). The direct-download build will
 * check the public releases repo for updates, following the FFL Filters
 * pattern. Nothing is published yet, so this makes no network calls.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Update;

defined( 'ABSPATH' ) || exit;

/**
 * Release check stub.
 */
class Release_Check {

	const RELEASES_REPO = 'CoriolisAgency/ffl-firewall-releases';

	/**
	 * Boot the release check. Off until the first release exists.
	 *
	 * @return void
	 */
	public static function boot() {
		if ( ! apply_filters( 'fflfw_release_check_enabled', false ) ) {
			return;
		}
		// A later sprint wires the token-less GitHub Releases updater here.
	}
}
