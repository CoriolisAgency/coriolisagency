<?php
/**
 * Check log (Log tab). Keeps the most recent proxy checks in one option.
 *
 * Rows: removed from cart (logged when the item comes out), and allowed and
 * flagged, permit or age check notice and FFL-only items (logged with the order).
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Log;

defined( 'ABSPATH' ) || exit;

/**
 * Ring buffer of recent log rows.
 */
class Store {

	const OPTION = 'fflfw_log';
	const MAX    = 200;

	const ACTION_REMOVED = 'removed';
	const ACTION_FLAGGED = 'flagged';
	const ACTION_PERMIT  = 'permit';
	const ACTION_FFL     = 'ffl';

	/**
	 * Labels for the rule actions (Brandy's Log copy).
	 *
	 * @return array<string, string>
	 */
	public static function action_labels() {
		return array(
			self::ACTION_REMOVED => __( 'Removed from cart', 'ffl-firewall' ),
			self::ACTION_FLAGGED => __( 'Allowed and flagged', 'ffl-firewall' ),
			self::ACTION_PERMIT  => __( 'Permit or age check notice', 'ffl-firewall' ),
			self::ACTION_FFL     => __( 'CC: ship to an FFL or dealer only', 'ffl-firewall' ),
		);
	}

	/**
	 * All rows, newest first.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function rows() {
		$rows = get_option( self::OPTION, array() );
		return is_array( $rows ) ? array_values( $rows ) : array();
	}

	/**
	 * Add a row.
	 *
	 * @param array<string, mixed> $row Row: time, ref, products, zip, state, action.
	 * @return void
	 */
	public function add( $row ) {
		$clean = array(
			'time'     => isset( $row['time'] ) ? (int) $row['time'] : time(),
			'ref'      => isset( $row['ref'] ) ? (string) $row['ref'] : '',
			'products' => isset( $row['products'] ) ? (string) $row['products'] : '',
			'zip'      => isset( $row['zip'] ) ? (string) $row['zip'] : '',
			'state'    => isset( $row['state'] ) ? (string) $row['state'] : '',
			'action'   => isset( $row['action'] ) ? (string) $row['action'] : '',
		);
		$rows = $this->rows();
		array_unshift( $rows, $clean );
		update_option( self::OPTION, array_slice( $rows, 0, self::MAX ), false );
	}

	/**
	 * Rows removed from carts in the last 7 days.
	 *
	 * @param int|null $now Unix time.
	 * @return int
	 */
	public function removed_last_week( $now = null ) {
		$now   = null === $now ? time() : (int) $now;
		$count = 0;
		foreach ( $this->rows() as $row ) {
			if ( self::ACTION_REMOVED === $row['action'] && $row['time'] >= $now - 7 * DAY_IN_SECONDS ) {
				++$count;
			}
		}
		return $count;
	}

	/**
	 * Clear the log (uninstall).
	 *
	 * @return void
	 */
	public static function clear() {
		delete_option( self::OPTION );
	}
}
