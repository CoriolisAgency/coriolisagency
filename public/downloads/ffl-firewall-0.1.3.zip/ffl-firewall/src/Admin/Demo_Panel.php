<?php
/**
 * Demo test panel for sites without an active license (Brandy's mockups D01 to D13).
 *
 * An unlicensed install doesn't check carts. It carries a test panel instead: a UPC and a zip,
 * suggested test pairs, and 10 runs per site for life. The count is kept by the proxy, never here
 * (this class only caches the last answer for a few minutes). Every action is a plain form post or
 * link, so the panel works with JavaScript off.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Admin;

use FFL_Firewall\Demo\Strings;
use FFL_Firewall\Proxy\Client;
use FFL_Firewall\Rules\Engine;
use FFL_Firewall\Settings\Repository;

defined( 'ABSPATH' ) || exit;

/**
 * Renders and handles the demo test panel and its WP admin notice.
 */
class Demo_Panel {

	const BUY_URL        = 'https://coriolisagency.com/ffl-firewall/';
	const SUPPORT_URL    = 'https://www.coriolisagency.com/contact';
	const NONCE          = 'fflfw_demo_run';
	const NONCE_FIELD    = '_fflfw_demo_nonce';
	const DISMISS_NONCE  = 'fflfw_demo_dismiss';
	const STATE_KEY      = 'fflfw_demo_state';
	const STATE_TTL      = 300;
	const CAP            = 10;
	const LOW_AT         = 2;
	const NOTICE_META    = 'fflfw_demo_notice_dismissed';
	const NOTICE_BACK_IN = 1209600; // 14 days.

	/**
	 * Suggested test pairs: result label key, type key, UPC, zip. From the repo's test data.
	 *
	 * @var array<int, array<int, string>>
	 */
	const PAIRS = array(
		array( 'r.pass', 'type.firearm', '090161045156', '21205' ),
		array( 'r.pass', 'type.ammo', '818778023509', '37219' ),
		array( 'r.rm', 'type.firearm', '845737002367', '21205' ),
		array( 'r.rm', 'type.ammo', '818778023509', '90232' ),
		array( 'r.flag', 'type.roster', '022188865813', '21205' ),
		array( 'r.flag', 'type.nf', '123412341234', '21205' ),
		array( 'r.cc', 'type.ammo', '818778023509', '14094' ),
	);

	/**
	 * Settings.
	 *
	 * @var Repository
	 */
	private $settings;

	/**
	 * Proxy client.
	 *
	 * @var Client
	 */
	private $client;

	/**
	 * Constructor.
	 *
	 * @param Repository $settings Settings.
	 * @param Client     $client   Proxy client.
	 */
	public function __construct( Repository $settings, Client $client ) {
		$this->settings = $settings;
		$this->client   = $client;
	}

	/**
	 * Hook the run and dismiss handlers and the admin notice.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_post_fflfw_demo_run', array( $this, 'handle_run' ) );
		add_action( 'admin_post_fflfw_demo_dismiss', array( $this, 'handle_dismiss' ) );
		add_action( 'admin_notices', array( $this, 'render_admin_notice' ) );
	}

	/**
	 * The panel shows whenever the license isn't active, including after a lapse.
	 *
	 * @return bool
	 */
	public function active() {
		return 'active' !== $this->settings->license_status();
	}

	/**
	 * No license key has been entered at all.
	 *
	 * @return bool
	 */
	public function no_key() {
		return $this->active() && '' === trim( (string) $this->settings->get( 'license_key', '' ) );
	}

	/**
	 * Escaped string from the copy table.
	 *
	 * @param string               $key  Key.
	 * @param array<string, mixed> $vars Values for {n}, {upc}, {zip}, {code}.
	 * @return string
	 */
	private function s( $key, $vars = array() ) {
		$text = Strings::get( $key );
		foreach ( $vars as $name => $value ) {
			$text = str_replace( '{' . $name . '}', (string) $value, $text );
		}
		return $text;
	}

	/**
	 * Runs used and left for this site, from the proxy (cached a few minutes).
	 *
	 * @param bool $refresh Ask the proxy now.
	 * @return array<string, int>|null used, remaining, cap; null when the count can't be read.
	 */
	public function state( $refresh = false ) {
		$cached = get_transient( self::STATE_KEY );
		if ( ! $refresh && is_array( $cached ) && isset( $cached['remaining'] ) ) {
			return $cached;
		}
		$answer = $this->client->demo_status();
		if ( ! empty( $answer['ok'] ) && isset( $answer['remaining'] ) ) {
			return $this->remember( $answer );
		}
		return null;
	}

	/**
	 * Cache the counts from a proxy answer.
	 *
	 * @param array<string, mixed> $answer Proxy answer.
	 * @return array<string, int>
	 */
	private function remember( $answer ) {
		$state = array(
			'used'      => (int) ( $answer['used'] ?? 0 ),
			'remaining' => max( 0, (int) $answer['remaining'] ),
			'cap'       => (int) ( $answer['cap'] ?? self::CAP ),
		);
		set_transient( self::STATE_KEY, $state, self::STATE_TTL );
		return $state;
	}

	/**
	 * Notice at the top of WooCommerce > FFL Firewall (no key at all).
	 *
	 * @return void
	 */
	public function render_top_notice() {
		echo '<div class="fflfw-demo-notice" role="note">';
		echo '<b>' . esc_html( $this->s( 'top.title' ) ) . '</b>';
		echo '<p>' . esc_html( $this->s( 'top.body' ) ) . '</p>';
		echo '<p><a class="button button-primary" href="' . esc_url( self::BUY_URL ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $this->s( 'top.cta' ) ) . '</a> ';
		echo '<a href="#fflfw-test-panel">' . esc_html( $this->s( 'top.link' ) ) . '</a></p>';
		echo '</div>';
	}

	/**
	 * Intro line under the tabs.
	 *
	 * @return string
	 */
	public function intro() {
		return $this->s( 'intro' );
	}

	/**
	 * The test panel (a settings row's field HTML). Its inputs belong to the form from form_html().
	 *
	 * @return string
	 */
	public function panel_html() {
		$state     = $this->state();
		$left      = null === $state ? null : $state['remaining'];
		$used_up   = null !== $left && $left <= 0;
		$upc       = isset( $_GET['fflfw_upc'] ) ? preg_replace( '/\D/', '', sanitize_text_field( wp_unslash( $_GET['fflfw_upc'] ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$zip       = isset( $_GET['fflfw_zip'] ) ? preg_replace( '/\D/', '', sanitize_text_field( wp_unslash( $_GET['fflfw_zip'] ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$example   = ! empty( $_GET['fflfw_example'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$disabled  = $used_up ? ' disabled' : '';
		$html      = '<div id="fflfw-test-panel">';
		$html     .= '<p class="fflfw-help fflfw-help--flush">' . esc_html( $this->s( 't.help' ) ) . '</p>';
		$html     .= '<div class="fflfw-test">';
		$html     .= '<div><label for="fflfw-demo-upc">' . esc_html( $this->s( 't.upc' ) ) . '</label><input type="text" id="fflfw-demo-upc" form="fflfw-demo-form" name="upc" class="fflfw-input" inputmode="numeric" pattern="[0-9]{6,14}" maxlength="14" placeholder="' . esc_attr( $this->s( 't.upc.ph' ) ) . '" value="' . esc_attr( (string) $upc ) . '" required' . $disabled . ' /></div>';
		$html     .= '<div><label for="fflfw-demo-zip">' . esc_html( $this->s( 't.zip' ) ) . '</label><input type="text" id="fflfw-demo-zip" form="fflfw-demo-form" name="zip" class="fflfw-input" inputmode="numeric" pattern="[0-9]{5}" maxlength="5" placeholder="' . esc_attr( $this->s( 't.zip.ph' ) ) . '" value="' . esc_attr( (string) $zip ) . '" required' . $disabled . ' /></div>';
		$html     .= '<div><button type="submit" form="fflfw-demo-form" class="button button-primary"' . $disabled . '>' . esc_html( $this->s( 't.btn' ) ) . '</button></div>';
		$html     .= '</div>';

		if ( null !== $left ) {
			$html .= $this->meter( $left );
		}

		$html .= $this->result_html( $example );

		if ( $used_up ) {
			$html .= $this->used_up_html();
		} else {
			$html .= $this->suggestions_html();
		}
		return $html . '</div>';
	}

	/**
	 * The 10-segment counter and its line.
	 *
	 * @param int $left Runs left.
	 * @return string
	 */
	private function meter( $left ) {
		$low  = $left <= self::LOW_AT;
		$html = '<div class="fflfw-meter' . ( $low ? ' fflfw-meter--low' : '' ) . '"><span class="fflfw-meter__bar" aria-hidden="true">';
		for ( $i = 1; $i <= self::CAP; $i++ ) {
			$html .= '<i' . ( $i <= $left ? ' class="on"' : '' ) . '></i>';
		}
		$key   = $low ? 't.left.low' : 't.left';
		$html .= '</span><span class="fflfw-meter__text">' . esc_html( $this->s( $key, array( 'n' => $left ) ) ) . '</span></div>';
		return $html;
	}

	/**
	 * Suggested test pairs.
	 *
	 * @return string
	 */
	private function suggestions_html() {
		$html  = '<p class="fflfw-demo-sugtitle"><b>' . esc_html( $this->s( 't.sug.title' ) ) . '</b></p>';
		$html .= '<table class="widefat fflfw-demo-sug"><thead><tr>';
		foreach ( array( 't.sug.c.res', 't.sug.c.type', 't.sug.c.upc', 't.sug.c.zip' ) as $col ) {
			$html .= '<th scope="col">' . esc_html( $this->s( $col ) ) . '</th>';
		}
		$html .= '<th scope="col"><span class="screen-reader-text">' . esc_html( $this->s( 't.sug.use' ) ) . '</span></th></tr></thead><tbody>';
		foreach ( self::PAIRS as $pair ) {
			$url   = add_query_arg( 'fflfw_zip', $pair[3], add_query_arg( 'fflfw_upc', $pair[2], Page::url( 'settings' ) ) ) . '#fflfw-test-panel';
			$html .= '<tr><td>' . esc_html( $this->s( $pair[0] ) ) . '</td><td>' . esc_html( $this->s( $pair[1] ) ) . '</td><td>' . esc_html( $pair[2] ) . '</td><td>' . esc_html( $pair[3] ) . '</td>';
			$html .= '<td><a href="' . esc_url( $url ) . '">' . esc_html( $this->s( 't.sug.use' ) ) . '</a></td></tr>';
		}
		$example = add_query_arg( 'fflfw_example', '1', Page::url( 'settings' ) ) . '#fflfw-test-panel';
		$html   .= '<tr><td>' . esc_html( $this->s( 'r.nc' ) ) . '</td><td colspan="3">' . esc_html( $this->s( 't.sug.sim' ) ) . '</td><td><a href="' . esc_url( $example ) . '">' . esc_html( $this->s( 't.sug.sim.link' ) ) . '</a></td></tr>';
		return $html . '</tbody></table>';
	}

	/**
	 * Used-up card (D08).
	 *
	 * @return string
	 */
	private function used_up_html() {
		$html  = '<div class="fflfw-demo-used" role="status"><b>' . esc_html( $this->s( 'u.title' ) ) . '</b>';
		$html .= '<p>' . esc_html( $this->s( 'u.body' ) ) . '</p>';
		$html .= '<p><a class="button button-primary" href="' . esc_url( self::BUY_URL ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $this->s( 'u.cta' ) ) . '</a></p>';
		$html .= '<p>' . esc_html( $this->s( 'u.link' ) ) . '</p></div>';
		return $html;
	}

	/**
	 * Result card for this user's last run, or the simulated example.
	 *
	 * @param bool $example Show the simulated "Check couldn't run" example.
	 * @return string
	 */
	private function result_html( $example ) {
		if ( $example ) {
			return $this->card(
				$this->s( 'r.nc' ),
				$this->s( 'r.nc.d' ),
				'',
				true
			);
		}
		$key = 'fflfw_demo_result_' . get_current_user_id();
		$r   = get_transient( $key );
		if ( ! is_array( $r ) ) {
			return '';
		}
		delete_transient( $key );
		$vars = array(
			'upc'  => $r['upc'],
			'zip'  => $r['zip'],
			'code' => $r['reason'],
		);
		switch ( $r['action'] ) {
			case 'error':
				return $this->card( $this->s( 'r.nc.live' ), $this->support_link_html( $this->s( 'r.nc.live.d' ) ), '', false, true );
			case 'used_up':
				return '';
			case 'ip_limit':
				$left = null === $r['left'] ? null : (int) $r['left'];
				$desc = null === $left ? $this->s( 't.ipcap.d.nocount' ) : $this->s( 't.ipcap.d', array( 'n' => $left ) );
				return $this->card( $this->s( 't.ipcap.title' ), $desc, '', false );
			case Engine::REMOVE:
				return $this->card( $this->s( 'r.rm' ), $this->s( 'r.rm.d', $vars ), $this->s( 'r.rm.q', $vars ), false );
			case Engine::FFL:
				return $this->card( $this->s( 'r.cc' ), $this->s( 'r.cc.d', $vars ), $this->s( 'r.cc.q', $vars ), false );
			case Engine::PERMIT:
				$msgs = $this->settings->get( 'messages' );
				$quote = is_array( $msgs ) && isset( $msgs['permit'] ) ? strtr( (string) $msgs['permit'], array( '{product}' => 'this item', '{zip}' => $r['zip'], '{state}' => '' ) ) : '';
				return $this->card( $this->s( 'r.pm' ), $this->s( 'r.pm.d' ), $quote, false );
			case Engine::FLAG:
				return $this->card( $this->s( 'r.flag' ), $this->s( 'r.flag.d', $vars ), '', false );
			default:
				return $this->card( $this->s( 'r.pass' ), $this->s( 'r.pass.d', $vars ), '', false );
		}
	}

	/**
	 * Escaped HTML for a line holding [link text]({support_url}): the link text becomes a link to the support page.
	 *
	 * @param string $text Raw copy.
	 * @return string
	 */
	private function support_link_html( $text ) {
		if ( ! preg_match( '/^(.*)\[([^\]]+)\]\(\{support_url\}\)(.*)$/s', $text, $m ) ) {
			return esc_html( $text );
		}
		return esc_html( $m[1] ) . '<a href="' . esc_url( self::SUPPORT_URL ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $m[2] ) . '</a>' . esc_html( $m[3] );
	}

	/**
	 * One result card.
	 *
	 * @param string $title     Title.
	 * @param string $desc      Description.
	 * @param string $quote     Shopper message, or ''.
	 * @param bool   $simulated Simulated example (doesn't use a run).
	 * @param bool   $desc_is_html Description is already escaped HTML.
	 * @return string
	 */
	private function card( $title, $desc, $quote, $simulated, $desc_is_html = false ) {
		$html = '<div class="fflfw-result" role="status"><b>' . esc_html( $title ) . '</b>';
		if ( $simulated ) {
			$html .= ' <span class="fflfw-demo-badge">' . esc_html( $this->s( 't.sim.badge' ) ) . '</span>';
		}
		$html .= '<div>' . ( $desc_is_html ? $desc : esc_html( $desc ) ) . '</div>';
		if ( '' !== $quote ) {
			$html .= '<q>' . esc_html( $quote ) . '</q>';
		}
		if ( $simulated ) {
			$html .= '<div class="fflfw-help">' . esc_html( $this->s( 't.uncounted' ) ) . '</div>';
		}
		return $html . '</div>';
	}

	/**
	 * The panel's own form (the inputs point at it with form="fflfw-demo-form").
	 *
	 * @return string
	 */
	public function form_html() {
		ob_start();
		echo '<form id="fflfw-demo-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="fflfw_demo_run" />';
		wp_nonce_field( self::NONCE, self::NONCE_FIELD );
		echo '</form>';
		return (string) ob_get_clean();
	}

	/**
	 * Run one demo test through the proxy. No cart, no order, no license key.
	 *
	 * @return void
	 */
	public function handle_run() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'ffl-firewall' ), 403 );
		}
		check_admin_referer( self::NONCE, self::NONCE_FIELD );

		$upc = isset( $_POST['upc'] ) ? preg_replace( '/\D/', '', sanitize_text_field( wp_unslash( $_POST['upc'] ) ) ) : '';
		$zip = isset( $_POST['zip'] ) ? preg_replace( '/\D/', '', sanitize_text_field( wp_unslash( $_POST['zip'] ) ) ) : '';
		if ( $this->active() && preg_match( '/^[0-9]{6,14}$/', (string) $upc ) && preg_match( '/^[0-9]{5}$/', (string) $zip ) ) {
			$answer = $this->client->demo_run( $upc, $zip );
			$stored = array(
				'upc'    => $upc,
				'zip'    => $zip,
				'action' => 'error',
				'reason' => '',
				'left'   => null,
			);
			if ( isset( $answer['remaining'] ) ) {
				$this->remember( $answer );
			}
			if ( ! empty( $answer['ok'] ) && isset( $answer['result'] ) && is_array( $answer['result'] ) ) {
				$out              = Engine::evaluate( array( 'demo' => array( 'upc' => $upc, 'name' => '' ) ), array( 'results' => array( $upc => $answer['result'] ) ), (string) $this->settings->get( 'roster_rule' ) );
				$stored['action'] = $out['lines']['demo']['action'];
				$stored['reason'] = $out['lines']['demo']['reason'];
			} elseif ( isset( $answer['error'] ) && 'ip_limit' === $answer['error'] ) {
				$stored['action'] = 'ip_limit';
				$stored['left']   = isset( $answer['remaining'] ) ? max( 0, (int) $answer['remaining'] ) : null;
			} elseif ( isset( $answer['error'] ) && 'runs_used_up' === $answer['error'] ) {
				$stored['action'] = 'used_up';
			}
			set_transient( 'fflfw_demo_result_' . get_current_user_id(), $stored, HOUR_IN_SECONDS );
		}
		wp_safe_redirect( Page::url( 'settings' ) . '#fflfw-test-panel' );
		exit;
	}

	/**
	 * WP admin notice on admin screens other than this plugin's own.
	 *
	 * @return void
	 */
	public function render_admin_notice() {
		if ( ! current_user_can( 'manage_woocommerce' ) || ! $this->active() ) {
			return;
		}
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( Page::SLUG === $page ) {
			return;
		}
		$until = (int) get_user_meta( get_current_user_id(), self::NOTICE_META, true );
		if ( $until > time() ) {
			return;
		}
		$dismiss = wp_nonce_url( admin_url( 'admin-post.php?action=fflfw_demo_dismiss' ), self::DISMISS_NONCE );
		echo '<div class="notice notice-warning fflfw-demo-wpnotice"><p>' . esc_html( $this->s( 'wp.body' ) ) . '</p>';
		echo '<p><a class="button button-primary" href="' . esc_url( self::BUY_URL ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $this->s( 'wp.cta' ) ) . '</a> ';
		echo '<a href="' . esc_url( Page::url( 'settings' ) . '#fflfw-test-panel' ) . '">' . esc_html( $this->s( 'wp.link' ) ) . '</a> ';
		echo '<a class="fflfw-demo-dismiss" href="' . esc_url( $dismiss ) . '">' . esc_html( $this->s( 'adm.notice.dismiss' ) ) . '</a></p></div>';
	}

	/**
	 * Hide the admin notice for this user for 14 days.
	 *
	 * @return void
	 */
	public function handle_dismiss() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'ffl-firewall' ), 403 );
		}
		check_admin_referer( self::DISMISS_NONCE );
		update_user_meta( get_current_user_id(), self::NOTICE_META, time() + self::NOTICE_BACK_IN );
		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : admin_url() );
		exit;
	}
}