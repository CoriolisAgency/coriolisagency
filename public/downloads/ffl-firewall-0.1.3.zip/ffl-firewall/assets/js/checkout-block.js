/* FFL Firewall, block checkout. The server runs the cart check when the checkout saves the address (so the zip
 * change and the result arrive together); on page load with an address already saved, this asks for the check.
 * Renders the notices, the permit checkbox and the item badges from the cart's fflfw extension data.
 * Place Order stays blocked (checkout validation store) while a check runs or the permit box is unticked. */
( function () {
	'use strict';
	var data = window.wp && window.wp.data;
	var wcbc = window.wc && window.wc.blocksCheckout;
	var S = window.fflfwBlock || {};
	if ( ! data || ! wcbc || ! wcbc.extensionCartUpdate ) {
		return;
	}
	var CART = 'wc/store/cart';
	var VALID = 'wc/store/validation';
	var started = false;
	var checking = false;
	var pushing = false;
	var queued = false;
	var root = null;
	var ack = null;

	function ext() {
		var cart = data.select( CART ).getCartData() || {};
		return ( cart.extensions && cart.extensions.fflfw ) || {};
	}

	function addressOf( cart ) {
		var s = ( cart && cart.shippingAddress ) || {};
		var b = ( cart && cart.billingAddress ) || {};
		var z = String( s.postcode || b.postcode || '' ).trim();
		var m = /^([0-9]{5})(?:[\s-]?[0-9]{4})?$/.exec( z );
		return { zip: m ? m[ 1 ] : '', state: String( ( s.postcode ? s.state : b.state ) || '' ) };
	}

	function el( tag, cls, text ) {
		var n = document.createElement( tag );
		if ( cls ) {
			n.className = cls;
		}
		if ( text ) {
			n.textContent = text;
		}
		return n;
	}

	function notice( kind, title, body, more ) {
		var n = el( 'div', 'wc-block-components-notice-banner is-info fflfw-notice fflfw-notice--' + kind );
		n.setAttribute( 'role', 'load' === kind ? 'status' : 'alert' );
		var c = el( 'div', 'wc-block-components-notice-banner__content' );
		c.appendChild( el( 'strong', '', title ) );
		c.appendChild( el( 'p', '', body ) );
		if ( more ) {
			c.appendChild( el( 'p', '', more ) );
		}
		n.appendChild( c );
		return n;
	}

	function ensureRoot() {
		if ( root && document.body.contains( root ) ) {
			return root;
		}
		var main = document.querySelector( '.wc-block-checkout__main' );
		if ( ! main ) {
			return null;
		}
		root = el( 'div', 'fflfw-block-notices' );
		root.setAttribute( 'aria-live', 'polite' );
		main.insertBefore( root, main.firstChild );
		return root;
	}

	function renderAck( e ) {
		var actions = document.querySelector( '.wc-block-checkout__actions' );
		if ( ! e.permit || ! actions ) {
			if ( ack && ack.parentNode ) {
				ack.parentNode.removeChild( ack );
			}
			ack = null;
			return;
		}
		if ( ack && document.body.contains( ack ) ) {
			return;
		}
		ack = el( 'div', 'fflfw-ack' );
		var label = el( 'label', 'fflfw-ack__label' );
		var box = el( 'input', '' );
		box.type = 'checkbox';
		box.id = 'fflfw-permit-ack';
		box.required = true;
		box.checked = !! e.acked;
		label.appendChild( box );
		label.appendChild( el( 'span', '', ' ' + S.pmAck + ' ' ) );
		var req = el( 'abbr', 'required', '*' );
		req.title = S.required || '';
		label.appendChild( req );
		ack.appendChild( label );
		ack.appendChild( el( 'p', 'fflfw-ack__req', S.pmReq ) );
		box.addEventListener( 'change', function () {
			wcbc.extensionCartUpdate( { namespace: 'fflfw', data: { permit_ack: box.checked } } );
			schedule();
		} );
		actions.parentNode.insertBefore( ack, actions );
	}

	function acked( e ) {
		var box = document.getElementById( 'fflfw-permit-ack' );
		return box ? box.checked : !! e.acked;
	}

	function validation( e ) {
		var v = data.dispatch( VALID );
		if ( ! v ) {
			return;
		}
		var errs = {};
		if ( checking || pushing ) {
			errs[ 'fflfw-checking' ] = { message: S.ckBody, hidden: true };
		} else {
			v.clearValidationError( 'fflfw-checking' );
		}
		if ( e.permit && ! acked( e ) ) {
			errs[ 'fflfw-permit' ] = { message: S.pmReq, hidden: true };
		} else {
			v.clearValidationError( 'fflfw-permit' );
		}
		if ( Object.keys( errs ).length ) {
			v.setValidationErrors( errs );
		}
	}

	function render() {
		queued = false;
		var e = ext();
		var r = ensureRoot();
		if ( r ) {
			r.innerHTML = '';
			if ( checking || pushing ) {
				r.appendChild( notice( 'load', S.ckTitle, S.ckBody ) );
			}
			( e.notices || [] ).forEach( function ( n ) {
				if ( 'removed' === n.type ) {
					r.appendChild( notice( 'info', S.rmTitle, n.body, S.rmMore ) );
				} else if ( 'ffl' === n.type ) {
					r.appendChild( notice( 'info', S.fflTitle, n.body ) );
				} else if ( 'permit' === n.type ) {
					r.appendChild( notice( 'warn', S.pmTitle, n.body ) );
				}
			} );
		}
		renderAck( e );
		validation( e );
	}

	function schedule() {
		if ( ! queued ) {
			queued = true;
			window.requestAnimationFrame( render );
		}
	}

	function runCheck( address ) {
		checking = true;
		schedule();
		wcbc.extensionCartUpdate( { namespace: 'fflfw', data: { check: true, zip: address.zip, state: address.state } } )
			.catch( function () {} )
			.then( function () {
				checking = false;
				schedule();
			} );
	}

	if ( wcbc.registerCheckoutFilters ) {
		wcbc.registerCheckoutFilters( 'fflfw', {
			itemName: function ( name, extensions, args ) {
				var key = args && args.cartItem && args.cartItem.key;
				var badges = ext().badges || {};
				// Plain text after an en dash: many product names already end in parentheses.
				if ( checking || pushing ) {
					return name + ' \u2013 ' + S.ckItem;
				}
				if ( key && 'ffl' === badges[ key ] ) {
					return name + ' \u2013 ' + S.fflBadge;
				}
				if ( key && 'permit' === badges[ key ] ) {
					return name + ' \u2013 ' + S.pmBadge;
				}
				return name;
			},
		} );
	}

	data.subscribe( function () {
		var store = data.select( CART );
		if ( store.hasFinishedResolution && ! store.hasFinishedResolution( 'getCartData' ) && ! ( store.getCartData() || {} ).items ) {
			return;
		}
		var cart    = store.getCartData();
		var busy    = store.isCustomerDataUpdating ? store.isCustomerDataUpdating() : false;
		var address = addressOf( cart );
		var e       = ext();
		pushing     = !! ( busy && address.zip && address.zip !== e.zip );
		if ( ! started && ! busy ) {
			started = true;
			// Address already saved when the page loaded: ask for the check once.
			if ( address.zip && address.zip !== e.zip ) {
				runCheck( address );
			}
		}
		schedule();
	} );
}() );
