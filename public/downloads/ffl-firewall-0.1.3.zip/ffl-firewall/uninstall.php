<?php
/**
 * Uninstall handler for FFL Firewall.
 *
 * @package FFL_Firewall
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'fflfw_settings' );
delete_option( 'fflfw_license_status' );
delete_option( 'fflfw_log' );
