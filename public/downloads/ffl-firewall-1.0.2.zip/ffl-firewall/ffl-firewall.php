<?php
/**
 * Plugin Name:       FFL Firewall
 * Description:       Checks every cart UPC against the shipping zip at checkout, slows and blocks bots and scrapers, and scans your WooCommerce store for waiting updates and setup gaps.
 * Version:           1.0.2
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * Requires Plugins:  woocommerce
 * WC requires at least: 9.2
 * WC tested up to:   11.3
 * Author:            Coriolis Agency
 * Author URI:        https://coriolisagency.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ffl-firewall
 * Domain Path:       /languages
 *
 * @package FFL_Firewall
 */

defined( 'ABSPATH' ) || exit;

define( 'FFLFW_VERSION', '1.0.2' );
define( 'FFLFW_FILE', __FILE__ );
define( 'FFLFW_BASENAME', plugin_basename( __FILE__ ) );
define( 'FFLFW_DIR', plugin_dir_path( __FILE__ ) );
define( 'FFLFW_URL', plugin_dir_url( __FILE__ ) );

/*
 * Coriolis proxy base URL. The plugin only ever sends the store's license key,
 * the shipping zip and the cart UPCs to this URL. A site can override it in
 * wp-config.php with define( 'FFLFW_PROXY_URL', '...' ) or the fflfw_proxy_url filter.
 */
if ( ! defined( 'FFLFW_PROXY_URL' ) ) {
	define( 'FFLFW_PROXY_URL', 'https://ffl-firewall-proxy.vercel.app' );
}

require_once FFLFW_DIR . 'src/Autoloader.php';
\FFL_Firewall\Autoloader::register();

/*
 * Deactivation: leave no license recheck event behind.
 */
register_deactivation_hook( __FILE__, array( 'FFL_Firewall\\Settings\\License_Recheck', 'deactivate' ) );

/*
 * FFLFW-SITEKEY-PROVISION-FIX: activation queues one site key attempt (WP-Cron, never inline), so a store
 * with an active license and ACTIVE DEFENSE on binds its key at install. Deactivation leaves no event.
 */
register_activation_hook( __FILE__, array( 'FFL_Firewall\\Defense\\Provision', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'FFL_Firewall\\Defense\\Provision', 'deactivate' ) );

/*
 * FFLFW-DC-LIST-SEED: deactivation leaves no datacenter feed refresh event behind.
 */
register_deactivation_hook( __FILE__, array( 'FFL_Firewall\\Defense\\Datacenter_Feed', 'deactivate' ) );

/*
 * FFLFW-101-03: one unlicensed first RECON scan. Activation queues the local scan
 * (WP-Cron, +60s). Deactivation leaves the hook, not the proxy allowance.
 */
register_activation_hook( __FILE__, array( 'FFL_Firewall\\Recon\\Module', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'FFL_Firewall\\Recon\\Module', 'deactivate' ) );

/*
 * FFLFW-TERMS-DEFAULT-SHARE: stamp the shared reputation feed's starting point once (fresh install: in by
 * default; existing install with no saved choice: off). Activation covers new installs; plugins_loaded
 * (ahead of the boot below) covers updates that skip activation. A saved choice is never touched.
 */
register_activation_hook( __FILE__, array( 'FFL_Firewall\\Defense\\Feed_Optin', 'stamp' ) );
add_action( 'plugins_loaded', array( 'FFL_Firewall\\Defense\\Feed_Optin', 'stamp' ), 5 );

/* FFLFW_UPDATER_BEGIN */
if ( is_readable( FFLFW_DIR . 'src/Update/Release_Check.php' ) ) {
	\FFL_Firewall\Update\Release_Check::boot();
}
/* FFLFW_UPDATER_END */

/**
 * Declare compatibility with WooCommerce features (HPOS, block checkout).
 *
 * @return void
 */
function fflfw_declare_feature_compatibility() {
	if ( ! class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		return;
	}
	\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', FFLFW_FILE, true );
	\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', FFLFW_FILE, true );
}
add_action( 'before_woocommerce_init', 'fflfw_declare_feature_compatibility' );

/**
 * Boot the plugin, or show a notice when WooCommerce is missing.
 *
 * @return void
 */
function fflfw_bootstrap() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		( new \FFL_Firewall\Admin\Missing_WooCommerce_Notice() )->register();
		return;
	}

	( new \FFL_Firewall\Plugin() )->init();
}
add_action( 'plugins_loaded', 'fflfw_bootstrap' );
