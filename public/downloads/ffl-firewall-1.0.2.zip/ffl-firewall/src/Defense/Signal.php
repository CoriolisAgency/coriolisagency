<?php
/**
 * The ACTIVE DEFENSE "script seen" signal and the 24-hour light.
 *
 * The answer is refreshed on a schedule and when the dealer saves or presses "Check for script",
 * and stored in one option. Requests only read that stored answer, so a slow or failing lookup
 * can never delay or block a page or a checkout. Any failure counts as "not seen".
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

defined( 'ABSPATH' ) || exit;

/**
 * Stores and reads the last-seen answer.
 */
class Signal {

	const OPTION = 'fflfw_defense_seen';
	const CRON   = 'fflfw_defense_refresh_seen';

	/** Seen only counts for this long after the script was last seen (inclusive). */
	const WINDOW = 86400;

	/**
	 * Embed.
	 *
	 * @var Embed
	 */
	private $embed;

	/**
	 * Source.
	 *
	 * @var Seen_Source
	 */
	private $source;

	/**
	 * Clock override for tests.
	 *
	 * @var int|null
	 */
	public static $now = null;

	/**
	 * Constructor.
	 *
	 * @param Embed       $embed  Embed.
	 * @param Seen_Source $source Source.
	 */
	public function __construct( Embed $embed, Seen_Source $source ) {
		$this->embed  = $embed;
		$this->source = $source;
	}

	/**
	 * Add the hooks: the gate filter, the scheduled refresh, and the schedule itself.
	 *
	 * @return void
	 */
	public function register() {
		add_filter( 'fflfw_active_defense_signal_seen', array( $this, 'filter' ) );
		add_action( self::CRON, array( $this, 'refresh' ) );
		add_action( self::CRON, array( $this->embed, 'detect_foreign' ) );
		add_action( 'init', array( $this, 'schedule' ) );
	}

	/**
	 * Current time.
	 *
	 * @return int
	 */
	private function now() {
		return null !== self::$now ? (int) self::$now : time();
	}

	/**
	 * Keep an hourly refresh scheduled while the script is being added, and none otherwise.
	 *
	 * @return void
	 */
	public function schedule() {
		try {
			$next = wp_next_scheduled( self::CRON );
			if ( $this->embed->active() ) {
				if ( ! $next ) {
					wp_schedule_event( $this->now() + 60, 'hourly', self::CRON );
				}
			} elseif ( $next ) {
				wp_clear_scheduled_hook( self::CRON );
			}
		} catch ( \Throwable $e ) {
			return;
		}
	}

	/**
	 * Ask the source and store the answer. Any failure is stored as "not seen".
	 *
	 * @return array<string, mixed> The stored state.
	 */
	public function refresh() {
		$state = array( 'checked' => $this->now(), 'ok' => false, 'last_seen' => 0 );
		try {
			$key = $this->embed->site_key();
			if ( '' !== $key ) {
				$answer = $this->source->fetch( $key );
				if ( is_array( $answer ) && isset( $answer['script_url'] ) ) {
					$this->embed->save_script_url( $answer['script_url'] );
				}
				if ( is_array( $answer ) && ! empty( $answer['ok'] ) ) {
					$state['ok']        = true;
					$state['last_seen'] = isset( $answer['last_seen'] ) ? max( 0, (int) $answer['last_seen'] ) : 0;
				}
				// FFLFW-AD-AUTOBLOCK: high-confidence behavior signals ride on the same answer when present.
				if ( is_array( $answer ) && isset( $answer['behavior'] ) && is_array( $answer['behavior'] ) ) {
					try {
						( new Behavior_Signals() )->ingest( $answer['behavior'] );
					} catch ( \Throwable $e ) {
						unset( $e );
					}
				}
			}
		} catch ( \Throwable $e ) {
			$state['ok'] = false;
		}
		update_option( self::OPTION, $state, false );
		return $state;
	}

	/**
	 * Forget the stored answer (key changed or switch turned off).
	 *
	 * @return void
	 */
	public function clear() {
		delete_option( self::OPTION );
	}

	/**
	 * Stored state.
	 *
	 * @return array{checked: int, ok: bool, last_seen: int}
	 */
	private function state() {
		$s = get_option( self::OPTION, array() );
		$s = is_array( $s ) ? $s : array();
		return array(
			'checked'   => isset( $s['checked'] ) ? (int) $s['checked'] : 0,
			'ok'        => ! empty( $s['ok'] ),
			'last_seen' => isset( $s['last_seen'] ) ? (int) $s['last_seen'] : 0,
		);
	}

	/**
	 * Unix time the script was last seen, or 0 for never or unknown.
	 *
	 * @return int
	 */
	public function last_seen() {
		$s = $this->state();
		return $s['ok'] ? $s['last_seen'] : 0;
	}

	/**
	 * Whether the script was seen in the last 24 hours.
	 *
	 * The stored last-seen stamp is the only age gate. Exactly 24 hours still counts.
	 *
	 * @return bool
	 */
	public function seen() {
		try {
			if ( '' === $this->embed->site_key() || $this->embed->key_mismatch() ) {
				return false;
			}
			$s   = $this->state();
			$now = $this->now();
			return $s['ok']
				&& $s['last_seen'] > 0
				&& ( $now - $s['last_seen'] ) <= self::WINDOW;
		} catch ( \Throwable $e ) {
			return false;
		}
	}

	/**
	 * Filter for the gate.
	 *
	 * @param mixed $value Incoming value (false until this is wired).
	 * @return bool
	 */
	public function filter( $value = false ) {
		return $this->seen();
	}
}