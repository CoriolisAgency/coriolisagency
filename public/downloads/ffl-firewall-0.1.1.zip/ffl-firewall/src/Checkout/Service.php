<?php
/**
 * The cart check shared by block and classic checkout: one proxy call with
 * every cart UPC plus the zip, the rules, removals, the session state the
 * checkout UIs read, and the order flag and notes.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Checkout;

use FFL_Firewall\Cart\Upc_Resolver;
use FFL_Firewall\Log\Store;
use FFL_Firewall\Proxy\Client;
use FFL_Firewall\Rules\Engine;
use FFL_Firewall\Settings\Repository;

defined( 'ABSPATH' ) || exit;

/**
 * Checkout service.
 */
class Service {

	const SESSION_STATE   = 'fflfw_state';
	const SESSION_REMOVED = 'fflfw_removed';
	const SESSION_ACK     = 'fflfw_permit_ack';
	const ORDER_FLAG_META = '_fflfw_flagged';

	/**
	 * Answer flags that mean the check didn't run; the next pass tries again.
	 */
	const RETRY_FLAGS = array( 'proxy_unreachable', 'proxy_error', 'vendor_timeout', 'vendor_error', 'vendor_partial' );

	/**
	 * Flag reasons that mean the item wasn't checked (key not verified or the service unavailable).
	 */
	const UNCHECKED_REASONS = array( 'license_invalid', 'license_inactive', 'proxy_unreachable', 'proxy_error', 'vendor_timeout', 'vendor_error', 'vendor_partial', 'vendor_not_configured', 'test_scope', 'unchecked' );

	/**
	 * Settings.
	 *
	 * @var Repository
	 */
	private $settings;

	/**
	 * Proxy client.
	 *
	 * @var Client
	 */
	private $client;

	/**
	 * Log.
	 *
	 * @var Store
	 */
	private $log;

	/**
	 * UPC resolver.
	 *
	 * @var Upc_Resolver
	 */
	private $resolver;

	/**
	 * Constructor.
	 *
	 * @param Repository   $settings Settings.
	 * @param Client       $client   Proxy client.
	 * @param Store        $log      Log.
	 * @param Upc_Resolver $resolver UPC resolver.
	 */
	public function __construct( Repository $settings, Client $client, Store $log, Upc_Resolver $resolver ) {
		$this->settings = $settings;
		$this->client   = $client;
		$this->log      = $log;
		$this->resolver = $resolver;
	}

	/**
	 * Five-digit zip from a postcode (ZIP or ZIP+4), or ''.
	 *
	 * @param string $postcode Postcode.
	 * @return string
	 */
	public static function zip5( $postcode ) {
		$postcode = trim( (string) $postcode );
		return preg_match( '/^([0-9]{5})(?:[\s\-]?[0-9]{4})?$/', $postcode, $m ) ? $m[1] : '';
	}

	/**
	 * Run (or reuse) the check for the current cart and zip, and remove items the rules remove.
	 *
	 * @param Environment $env Environment.
	 * @return array<string, mixed> State: status (off | pickup | pending | checked), zip, state, result, removed_now.
	 */
	public function evaluate( Environment $env ) {
		if ( ! $this->settings->get( 'enabled', false ) ) {
			return $this->store( $env, array( 'status' => 'off' ) );
		}
		// Until the key is verified, items pass through checkout and each order is flagged (no proxy call).
		$license = $this->settings->license_status();
		$unverified = ! $this->settings->checks_active() && 'unknown' !== $license;
		if ( $env->is_local_pickup() ) {
			return $this->store( $env, array( 'status' => 'pickup' ) );
		}
		$zip = self::zip5( $env->postcode() );
		if ( '' === $zip ) {
			return $this->store( $env, array( 'status' => 'pending' ) );
		}

		$lines = array();
		foreach ( $env->lines() as $key => $line ) {
			$lines[ $key ] = array(
				'upc'  => $this->resolver->resolve( $line['product'] ),
				'name' => (string) $line['name'],
			);
		}

		$roster = (string) $this->settings->get( 'roster_rule' ) . '|' . $license;
		$upcs   = array_values( array_unique( array_filter( self::pluck( $lines, 'upc' ) ) ) );
		sort( $upcs );
		$hash = self::hash( $zip, $lines, $roster );

		$state = $env->session_get( self::SESSION_STATE, array() );
		if ( is_array( $state ) && isset( $state['hash'] ) && $state['hash'] === $hash && 'checked' === $state['status'] ) {
			$state['removed_now'] = array();
			return $state;
		}

		// A fresh check replaces the removed-item notices from the last one.
		$env->session_set( self::SESSION_REMOVED, array() );
		if ( $unverified ) {
			$answer = array(
				'pass_with_flag' => true,
				'flag'           => 'inactive' === $license ? 'license_inactive' : 'license_invalid',
				'results'        => array(),
			);
		} else {
			$answer = empty( $upcs ) ? array( 'results' => array() ) : $this->client->check( $zip, $upcs );
		}
		$result = Engine::evaluate( $lines, $answer, (string) $this->settings->get( 'roster_rule' ) );

		$removed_now      = array();
		$removed_now_keys = $result['remove'];
		$state_code       = $env->state_code();
		foreach ( $result['remove'] as $key ) {
			$name          = $result['lines'][ $key ]['name'];
			$removed_now[] = array(
				'product' => $name,
				'zip'     => $zip,
			);
			$env->remove_line( $key );
			$this->log->add(
				array(
					'ref'      => __( 'Cart (no order yet)', 'ffl-firewall' ),
					'products' => $name,
					'zip'      => $zip,
					'state'    => $state_code,
					'action'   => Store::ACTION_REMOVED,
				)
			);
			unset( $result['lines'][ $key ] );
		}
		$result['remove'] = array();

		if ( ! empty( $removed_now ) ) {
			$env->session_set( self::SESSION_REMOVED, $removed_now );
			// Hash the cart as it is after the removals, so the next evaluate() reuses this result.
			foreach ( $removed_now_keys as $key ) {
				unset( $lines[ $key ] );
			}
			$hash = self::hash( $zip, $lines, $roster );
		}

		$state = array(
			'status'      => 'checked',
			// A failed call (proxy or vendor down) is retried on the next pass instead of reused.
			'hash'        => in_array( isset( $answer['flag'] ) ? $answer['flag'] : '', self::RETRY_FLAGS, true ) ? '' : $hash,
			'zip'         => $zip,
			'state'       => $state_code,
			'flag'        => isset( $answer['flag'] ) ? $answer['flag'] : null,
			'result'      => $result,
			'removed_now' => $removed_now,
		);
		return $this->store( $env, $state );
	}

	/**
	 * Cache key for a cart: zip, sorted UPCs, roster rule and line keys.
	 *
	 * @param string                              $zip    Zip.
	 * @param array<string, array<string, mixed>> $lines  Lines with upc.
	 * @param string                              $roster Roster rule.
	 * @return string
	 */
	private static function hash( $zip, $lines, $roster ) {
		$upcs = array_values( array_unique( array_filter( self::pluck( $lines, 'upc' ) ) ) );
		sort( $upcs );
		return md5( wp_json_encode( array( $zip, $upcs, $roster, array_keys( $lines ) ) ) );
	}

	/**
	 * Save state to the session.
	 *
	 * @param Environment          $env   Environment.
	 * @param array<string, mixed> $state State.
	 * @return array<string, mixed>
	 */
	private function store( Environment $env, $state ) {
		$env->session_set( self::SESSION_STATE, $state );
		return $state;
	}

	/**
	 * Current state from the session, without running a check.
	 *
	 * @param Environment $env Environment.
	 * @return array<string, mixed>
	 */
	public function state( Environment $env ) {
		$state = $env->session_get( self::SESSION_STATE, array() );
		return is_array( $state ) ? $state : array();
	}

	/**
	 * Lines with a given action in a state.
	 *
	 * @param array<string, mixed> $state  State.
	 * @param string               $action Action.
	 * @return array<string, array<string, mixed>>
	 */
	public static function lines_with( $state, $action ) {
		$out = array();
		if ( empty( $state['result']['lines'] ) ) {
			return $out;
		}
		foreach ( $state['result']['lines'] as $key => $line ) {
			if ( $line['action'] === $action ) {
				$out[ $key ] = $line;
			}
		}
		return $out;
	}

	/**
	 * Removed-item notices from the last fresh check (optionally cleared on read).
	 *
	 * @param Environment $env   Environment.
	 * @param bool        $clear Clear after reading.
	 * @return array<int, array<string, string>>
	 */
	public function take_removed( Environment $env, $clear = true ) {
		$removed = (array) $env->session_get( self::SESSION_REMOVED, array() );
		if ( $clear && ! empty( $removed ) ) {
			$env->session_set( self::SESSION_REMOVED, array() );
		}
		return $removed;
	}

	/**
	 * Fill {product}, {zip} and {state} in a message.
	 *
	 * @param string $template Template.
	 * @param string $product  Product name.
	 * @param string $zip      Zip.
	 * @param string $state    State.
	 * @return string
	 */
	public static function fill( $template, $product, $zip, $state = '' ) {
		return strtr(
			(string) $template,
			array(
				'{product}' => (string) $product,
				'{zip}'     => (string) $zip,
				'{state}'   => (string) $state,
			)
		);
	}

	/**
	 * Shopper message for a slot (removed | ffl | permit), filled.
	 *
	 * @param string $slot    Slot.
	 * @param string $product Product.
	 * @param string $zip     Zip.
	 * @param string $state   State.
	 * @return string
	 */
	public function message( $slot, $product, $zip, $state = '' ) {
		$messages = (array) $this->settings->get( 'messages', array() );
		return self::fill( isset( $messages[ $slot ] ) ? $messages[ $slot ] : '', $product, $zip, $state );
	}

	/**
	 * Flag the order and write its notes from the checked state. No email is sent.
	 *
	 * @param \WC_Order|object     $order Order.
	 * @param array<string, mixed> $state State.
	 * @return void
	 */
	public function apply_to_order( $order, $state ) {
		if ( empty( $state['status'] ) || 'checked' !== $state['status'] || ! is_object( $order ) ) {
			return;
		}
		$zip     = (string) $state['zip'];
		$region  = (string) $state['state'];
		$ref     = sprintf( 'Order #%s', method_exists( $order, 'get_order_number' ) ? $order->get_order_number() : '' );
		$flagged = self::lines_with( $state, Engine::FLAG );
		$notes   = array();

		foreach ( $flagged as $line ) {
			$upc  = '' !== $line['upc'] ? $line['upc'] : '-';
			$fill = array( '{product}' => $line['name'], '{upc}' => $upc, '{zip}' => $zip, '{state}' => $region, '{reason}' => self::reason_words( $line['reason'] ), '{code}' => $line['reason'] );
			if ( in_array( $line['reason'], self::UNCHECKED_REASONS, true ) ) {
				$notes[] = self::note( __( "FFL Firewall couldn't check {product} (UPC {upc}) for zip {zip}, {state}: {reason}. The item went through, so review it before you ship. Reason code: {code}.", 'ffl-firewall' ), $fill );
			} else {
				$notes[] = self::note( __( 'FFL Firewall flagged {product} (UPC {upc}) for zip {zip}, {state}: {reason}. Review it before you ship. Reason code: {code}.', 'ffl-firewall' ), $fill );
			}
			$this->log->add( array( 'ref' => $ref, 'products' => $line['name'], 'zip' => $zip, 'state' => $region, 'action' => Store::ACTION_FLAGGED ) );
		}
		foreach ( self::lines_with( $state, Engine::PERMIT ) as $line ) {
			$notes[] = self::note( __( 'FFL Firewall: {product} (UPC {upc}) needs a permit or age check for zip {zip}, {state}. The shopper ticked the box at checkout, so contact them to confirm before you ship.', 'ffl-firewall' ), array( '{product}' => $line['name'], '{upc}' => $line['upc'], '{zip}' => $zip, '{state}' => $region ) );
			$this->log->add( array( 'ref' => $ref, 'products' => $line['name'], 'zip' => $zip, 'state' => $region, 'action' => Store::ACTION_PERMIT ) );
		}
		foreach ( self::lines_with( $state, Engine::FFL ) as $line ) {
			$notes[] = self::note( __( 'FFL Firewall: {product} (UPC {upc}) is CC (ship to an FFL or dealer only) for zip {zip}, {state}. Ship it to the dealer the shopper chose, not to their home address.', 'ffl-firewall' ), array( '{product}' => $line['name'], '{upc}' => $line['upc'], '{zip}' => $zip, '{state}' => $region ) );
			$this->log->add( array( 'ref' => $ref, 'products' => $line['name'], 'zip' => $zip, 'state' => $region, 'action' => Store::ACTION_FFL ) );
		}
		foreach ( $state['result']['lines'] as $line ) {
			if ( '' !== $line['age'] ) {
				$notes[] = self::note( __( "FFL Firewall: age code {age_code} for {product} (UPC {upc}), zip {zip}, {state}: {age_rule}. Check the buyer's age before you ship.", 'ffl-firewall' ), array( '{age_code}' => $line['age'], '{product}' => $line['name'], '{upc}' => $line['upc'], '{zip}' => $zip, '{state}' => $region, '{age_rule}' => self::age_rule( $line['age'] ) ) );
			}
		}

		if ( ! empty( $flagged ) && method_exists( $order, 'update_meta_data' ) ) {
			$order->update_meta_data( self::ORDER_FLAG_META, 'yes' );
			$order->save();
		}
		foreach ( $notes as $note ) {
			if ( method_exists( $order, 'add_order_note' ) ) {
				$order->add_order_note( $note, 0, false );
			}
		}
	}

	/**
	 * Plain words for a reason code, for the {reason} slot in order notes. Internal code names stay out of the words.
	 *
	 * @param string $code Reason code.
	 * @return string
	 */
	public static function reason_words( $code ) {
		switch ( (string) $code ) {
			case 'ammo_A':
				return __( 'this ammo is restricted for the zip', 'ffl-firewall' );
			case 'ammo_FF':
				return __( 'shipping to this zip is restricted', 'ffl-firewall' );
			case 'ammo_FFF':
				return __( 'the age rule for this zip restricts it', 'ffl-firewall' );
			case 'code_2':
				return __( 'this firearm is restricted for the zip', 'ffl-firewall' );
			case 'code_3':
				return __( 'this is a firearm sold under your Roster states setting', 'ffl-firewall' );
			case 'code_5':
				return __( "its UPC wasn't found, so it wasn't checked", 'ffl-firewall' );
			case 'no_upc':
				return __( "the product has no UPC, so it wasn't checked", 'ffl-firewall' );
			case 'license_invalid':
				return __( "your license key isn't verified", 'ffl-firewall' );
			case 'license_inactive':
				return __( "your license isn't active", 'ffl-firewall' );
			case 'proxy_unreachable':
			case 'proxy_error':
			case 'vendor_timeout':
			case 'vendor_error':
			case 'vendor_partial':
				return __( "the checking service didn't return a full result, and it will try again on the next check", 'ffl-firewall' );
			case 'vendor_not_configured':
				return __( "the checking service isn't set up for this site", 'ffl-firewall' );
			case 'test_scope':
				return __( 'the item is outside the test check', 'ffl-firewall' );
			case 'unchecked':
				return __( 'no result came back', 'ffl-firewall' );
			default:
				return __( "the check returned a result FFL Firewall doesn't recognize", 'ffl-firewall' );
		}
	}

	/**
	 * Plain words for an age code, for the {age_rule} slot (order note and Test a check).
	 *
	 * @param string $age_code Age code.
	 * @return string
	 */
	public static function age_rule( $age_code ) {
		switch ( strtoupper( (string) $age_code ) ) {
			case 'AAA':
				return __( '18 or older for long guns, 21 or older for all other firearms', 'ffl-firewall' );
			case 'BBB':
				return __( '21 or older for all ammo', 'ffl-firewall' );
			case 'FFF':
				return __( "restricted, so it can't be sold to a buyer in this area", 'ffl-firewall' );
			case 'ADE':
				return __( '21 or older, or 18 or older with a concealed carry license or for US Armed Forces, National Guard or law enforcement', 'ffl-firewall' );
			case 'AMD':
				return __( '18 or older, or 21 or older for ammo made only for handguns or for the firearms named in Maryland Public Safety 5-101(r)(2)', 'ffl-firewall' );
			case 'ANJ':
				return __( '18 or older for shotgun ammo and rifle ammo no handgun uses, 21 or older for handgun ammo and rifle ammo usable in a handgun', 'ffl-firewall' );
			default:
				// ACOCF, ACORF, SCO and any other code.
				return __( 'no plain-words rule is on file for this code, so check it yourself', 'ffl-firewall' );
		}
	}

	/**
	 * Store-facing note for an item the check removed from the cart. Not attached to an order yet:
	 * the item leaves the cart before any order exists (wiring it is a behaviour change, held).
	 *
	 * @param string $product Product.
	 * @param string $upc     UPC.
	 * @param string $zip     Zip.
	 * @param string $state   State.
	 * @param string $code    Reason code.
	 * @return string
	 */
	public static function removed_note( $product, $upc, $zip, $state, $code ) {
		return self::note(
			__( 'FFL Firewall removed {product} (UPC {upc}) for zip {zip}, {state}: {reason}. Reason code: {code}.', 'ffl-firewall' ),
			array( '{product}' => $product, '{upc}' => '' !== (string) $upc ? $upc : '-', '{zip}' => $zip, '{state}' => $state, '{reason}' => self::reason_words( $code ), '{code}' => $code )
		);
	}

	/**
	 * Fill an order note. With no state, ", {state}" is left out rather than shown empty.
	 *
	 * @param string                $template Template.
	 * @param array<string, string> $fill     Placeholder values.
	 * @return string
	 */
	public static function note( $template, $fill ) {
		if ( isset( $fill['{state}'] ) && '' === (string) $fill['{state}'] ) {
			$template = str_replace( ', {state}', '', $template );
		}
		return strtr( (string) $template, array_map( 'strval', $fill ) );
	}

	/**
	 * Whether the shopper ticked the permit checkbox (session).
	 *
	 * @param Environment $env Environment.
	 * @return bool
	 */
	public function permit_acked( Environment $env ) {
		return (bool) $env->session_get( self::SESSION_ACK, false );
	}

	/**
	 * Store the permit checkbox state.
	 *
	 * @param Environment $env   Environment.
	 * @param bool        $acked Ticked.
	 * @return void
	 */
	public function set_permit_ack( Environment $env, $acked ) {
		$env->session_set( self::SESSION_ACK, (bool) $acked );
	}

	/**
	 * Messages that stop Place Order: an item the check just removed, or an unticked permit box.
	 * FFL-only (CC) items never block; the shopper sees the info notice only.
	 *
	 * @param array<string, mixed> $state State.
	 * @param bool                 $acked Permit box ticked.
	 * @return array<int, string>
	 */
	public function place_order_errors( $state, $acked ) {
		$errors = array();
		if ( empty( $state['status'] ) || 'checked' !== $state['status'] ) {
			return $errors;
		}
		foreach ( (array) ( isset( $state['removed_now'] ) ? $state['removed_now'] : array() ) as $removed ) {
			$errors[] = $this->message( 'removed', $removed['product'], $removed['zip'] );
		}
		if ( ! $acked && ! empty( self::lines_with( $state, Engine::PERMIT ) ) ) {
			$errors[] = __( 'Tick the box above to place your order.', 'ffl-firewall' );
		}
		return $errors;
	}

	/**
	 * Pluck one field from a list of arrays.
	 *
	 * @param array<mixed, array<string, mixed>> $rows  Rows.
	 * @param string                             $field Field.
	 * @return array<mixed, mixed>
	 */
	private static function pluck( $rows, $field ) {
		$out = array();
		foreach ( (array) $rows as $k => $row ) {
			if ( is_array( $row ) && array_key_exists( $field, $row ) ) {
				$out[ $k ] = $row[ $field ];
			}
		}
		return $out;
	}
}
