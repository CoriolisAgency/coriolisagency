<?php
/**
 * What the checkout service needs from WooCommerce, behind one interface so it can be tested.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Checkout;

defined( 'ABSPATH' ) || exit;

/**
 * Checkout environment.
 */
interface Environment {

	/**
	 * Cart lines: key => [ name, product ] (product is a WC_Product or a test double).
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public function lines();

	/**
	 * Shipping postcode, falling back to billing.
	 *
	 * @return string
	 */
	public function postcode();

	/**
	 * Shipping state code, falling back to billing.
	 *
	 * @return string
	 */
	public function state_code();

	/**
	 * Whether the chosen shipping is local pickup.
	 *
	 * @return bool
	 */
	public function is_local_pickup();

	/**
	 * Remove one cart line.
	 *
	 * @param string $key Line key.
	 * @return void
	 */
	public function remove_line( $key );

	/**
	 * Session read.
	 *
	 * @param string $key      Key.
	 * @param mixed  $fallback Fallback.
	 * @return mixed
	 */
	public function session_get( $key, $fallback = null );

	/**
	 * Session write.
	 *
	 * @param string $key   Key.
	 * @param mixed  $value Value.
	 * @return void
	 */
	public function session_set( $key, $value );
}
