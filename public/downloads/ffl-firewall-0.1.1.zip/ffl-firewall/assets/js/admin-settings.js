/* FFL Firewall settings screen. Progressive enhancement only: every control also works as a plain form post. */
( function () {
	'use strict';
	var reset = document.querySelector( '[data-fflfw-reset]' );
	if ( ! reset ) {
		return;
	}
	reset.addEventListener( 'click', function ( event ) {
		var fields = document.querySelectorAll( 'textarea[data-fflfw-default]' );
		if ( ! fields.length ) {
			return;
		}
		event.preventDefault();
		Array.prototype.forEach.call( fields, function ( field ) {
			field.value = field.getAttribute( 'data-fflfw-default' );
		} );
	} );
}() );
