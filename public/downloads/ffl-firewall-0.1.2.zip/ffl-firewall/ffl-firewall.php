<?php
/**
 * Plugin Name:       FFL Firewall
 * Description:       Checks each product in the WooCommerce cart by UPC against the shopper's zip code at checkout.
 * Version:           0.1.2
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * Requires Plugins:  woocommerce
 * WC requires at least: 9.2
 * WC tested up to:   11.2
 * Author:            Coriolis Agency
 * Author URI:        https://coriolisagency.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ffl-firewall
 * Domain Path:       /languages
 *
 * @package FFL_Firewall
 */

defined( 'ABSPATH' ) || exit;

define( 'FFLFW_VERSION', '0.1.2' );
define( 'FFLFW_FILE', __FILE__ );
define( 'FFLFW_BASENAME', plugin_basename( __FILE__ ) );
define( 'FFLFW_DIR', plugin_dir_path( __FILE__ ) );
define( 'FFLFW_URL', plugin_dir_url( __FILE__ ) );

/*
 * Coriolis proxy base URL. The plugin only ever sends the store's license key,
 * the shipping zip and the cart UPCs to this URL. A site can override it in
 * wp-config.php with define( 'FFLFW_PROXY_URL', '...' ) or the fflfw_proxy_url filter.
 */
if ( ! defined( 'FFLFW_PROXY_URL' ) ) {
	define( 'FFLFW_PROXY_URL', 'https://ffl-firewall-proxy.vercel.app' );
}

require_once FFLFW_DIR . 'src/Autoloader.php';
\FFL_Firewall\Autoloader::register();

/* FFLFW_UPDATER_BEGIN */
if ( is_readable( FFLFW_DIR . 'src/Update/Release_Check.php' ) ) {
	\FFL_Firewall\Update\Release_Check::boot();
}
/* FFLFW_UPDATER_END */

/**
 * Declare compatibility with WooCommerce features (HPOS, block checkout).
 *
 * @return void
 */
function fflfw_declare_feature_compatibility() {
	if ( ! class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		return;
	}
	\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', FFLFW_FILE, true );
	\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', FFLFW_FILE, true );
}
add_action( 'before_woocommerce_init', 'fflfw_declare_feature_compatibility' );

/**
 * Boot the plugin, or show a notice when WooCommerce is missing.
 *
 * @return void
 */
function fflfw_bootstrap() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		( new \FFL_Firewall\Admin\Missing_WooCommerce_Notice() )->register();
		return;
	}

	( new \FFL_Firewall\Plugin() )->init();
}
add_action( 'plugins_loaded', 'fflfw_bootstrap' );
