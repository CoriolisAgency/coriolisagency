=== FFL Firewall ===
Contributors: coriolisagency
Tags: woocommerce, checkout, ffl
Requires at least: 6.5
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 0.1.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

At checkout, FFL Firewall checks each product in the cart by UPC against the zip code the shopper entered.

== Description ==

At checkout, FFL Firewall checks each product in the cart by UPC against the zip code the shopper entered. Set how it handles each result here, and run a test before you turn it on for shoppers.

FFL Firewall is a tool that helps you catch restricted items at checkout. You're still responsible for what you ship, and this is not legal advice.

== Changelog ==

= 0.1.2 =
* Test panel on the settings screen for sites with no active license: a UPC and a zip, suggested test pairs, 10 test runs per site.
* Notice in the WordPress admin while there is no active license.

= 0.1.1 =
* Default proxy URL set to production.

= 0.1.0 =
* Sprint 1 skeleton: settings screen, license key check and the proxy client. Not released.
