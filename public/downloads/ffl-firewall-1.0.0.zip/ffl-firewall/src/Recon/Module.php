<?php
/**
 * RECON: report-only store hardening scan. Runs when a dealer starts one and weekly, needs an
 * active license, and never changes anything on the site.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Recon;

use FFL_Firewall\Settings\Repository;

defined( 'ABSPATH' ) || exit;

/**
 * Scheduling, license gate and report storage.
 */
class Module {

	const OPTION = 'fflfw_recon';
	const HOOK   = 'fflfw_recon_weekly';

	/**
	 * Settings.
	 *
	 * @var Repository
	 */
	private $settings;

	/**
	 * Facts source override (tests).
	 *
	 * @var Facts|null
	 */
	private $facts;

	/**
	 * Feed override (tests).
	 *
	 * @var Feed|null
	 */
	private $feed;

	/**
	 * Constructor.
	 *
	 * @param Repository $settings Settings.
	 * @param Facts|null $facts    Facts source.
	 * @param Feed|null  $feed     Feed.
	 */
	public function __construct( Repository $settings, $facts = null, $feed = null ) {
		$this->settings = $settings;
		$this->facts    = $facts instanceof Facts ? $facts : null;
		$this->feed     = $feed instanceof Feed ? $feed : null;
	}

	/**
	 * Hook the weekly run.
	 *
	 * @return void
	 */
	public function register() {
		add_action( self::HOOK, array( $this, 'run_weekly' ) );
		add_action( 'init', array( $this, 'ensure_schedule' ) );
	}

	/**
	 * Keep one weekly event scheduled.
	 *
	 * @return void
	 */
	public function ensure_schedule() {
		if ( false === wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + DAY_IN_SECONDS, 'weekly', self::HOOK );
		}
	}

	/**
	 * Whether a license is active (the only condition to scan).
	 *
	 * @return bool
	 */
	public function licensed() {
		return 'active' === $this->settings->license_status();
	}

	/**
	 * The feed in use. The default returns nothing; the fflfw_recon_feed filter is the seam.
	 *
	 * @return Feed
	 */
	private function feed() {
		if ( $this->feed instanceof Feed ) {
			return $this->feed;
		}
		$feed = apply_filters( 'fflfw_recon_feed', new Null_Feed() );
		return $feed instanceof Feed ? $feed : new Null_Feed();
	}

	/**
	 * Scan and store the report. Returns null (and does nothing) without an active license.
	 *
	 * @param string $trigger 'manual' or 'weekly'.
	 * @return array<string, mixed>|null The stored report.
	 */
	public function scan( $trigger = 'manual' ) {
		if ( ! $this->licensed() ) {
			return null;
		}
		try {
			$facts    = $this->facts instanceof Facts ? $this->facts : new Wp_Facts();
			$feed     = $this->feed();
			$scanner  = new Scanner( $facts, $feed );
			$findings = $scanner->run( true );
		} catch ( \Throwable $e ) {
			return null;
		}
		$report = array(
			'ran_at'   => time(),
			'trigger'  => 'weekly' === $trigger ? 'weekly' : 'manual',
			'findings' => $findings,
		);
		// RECON known issues: a feed with a known() section (Proxy_Feed) adds it to every report, manual or weekly.
		if ( method_exists( $feed, 'known' ) ) {
			try {
				$report['known'] = $feed->known( $facts->collect(), $report['ran_at'] );
			} catch ( \Throwable $e ) {
				unset( $e ); // The built-in findings are kept either way.
			}
		}
		update_option( self::OPTION, $report, false );
		return $report;
	}

	/**
	 * Weekly cron callback.
	 *
	 * @return void
	 */
	public function run_weekly() {
		$this->scan( 'weekly' );
	}

	/**
	 * The last stored report, or null.
	 *
	 * @return array<string, mixed>|null
	 */
	public function last_report() {
		$report = get_option( self::OPTION, null );
		if ( ! is_array( $report ) || empty( $report['ran_at'] ) || ! isset( $report['findings'] ) || ! is_array( $report['findings'] ) ) {
			return null;
		}
		return $report;
	}

	/**
	 * Timestamp of the next weekly run, or 0.
	 *
	 * @return int
	 */
	public function next_run() {
		$next = wp_next_scheduled( self::HOOK );
		return false === $next ? 0 : (int) $next;
	}
}