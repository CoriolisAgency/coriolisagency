<?php
/**
 * Known plugin vulnerabilities for RECON, looked up through the Coriolis proxy.
 *
 * The plugin sends the store's license key, its site key and the slugs and versions of the installed
 * plugins to the proxy's lookup route. The proxy matches them against a vulnerability index it builds on
 * its own schedule; this plugin holds no feed credential and never calls the feed itself. Every copyright
 * notice, license text and record link shown with the results comes from the feed data the proxy passes
 * through, so nothing about the data's owner is written into this plugin.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Recon;

use FFL_Firewall\Defense\Embed;
use FFL_Firewall\Proxy\Client;

defined( 'ABSPATH' ) || exit;

/**
 * The fflfw_recon_feed implementation that adds the "known" block to each RECON report.
 */
class Proxy_Feed implements Feed {

	/**
	 * Results whose index is older than this, at check time, show the stale-feed line.
	 */
	const STALE_AFTER = 172800;

	/**
	 * Most plugins sent in one lookup (the proxy's own limit).
	 */
	const MAX_ITEMS = 500;

	/**
	 * Proxy client.
	 *
	 * @var Client
	 */
	private $client;

	/**
	 * Site key source (tests); null reads the saved site key.
	 *
	 * @var callable|null
	 */
	private $site_key;

	/**
	 * Constructor.
	 *
	 * @param Client        $client   Proxy client.
	 * @param callable|null $site_key Returns the site key (tests).
	 */
	public function __construct( Client $client, $site_key = null ) {
		$this->client   = $client;
		$this->site_key = is_callable( $site_key ) ? $site_key : null;
	}

	/**
	 * Known issues are reported in their own section (see known()), not as findings.
	 *
	 * @param array<string, mixed> $facts Site facts.
	 * @return array<int, array<string, string>>
	 */
	public function findings( array $facts ) {
		return array();
	}

	/**
	 * The saved site key, or ''.
	 *
	 * @return string
	 */
	private function site_key() {
		if ( null !== $this->site_key ) {
			return Embed::clean_key( (string) call_user_func( $this->site_key ) );
		}
		$raw = get_option( Embed::OPTION, '' );
		return is_string( $raw ) ? Embed::clean_key( $raw ) : '';
	}

	/**
	 * Installed plugins as lookup items: slug (the plugin's folder, or its file name) and version.
	 *
	 * @param array<string, mixed> $facts Site facts.
	 * @return array<int, array<string, string>>
	 */
	public static function software( array $facts ) {
		$out  = array();
		$seen = array();
		foreach ( (array) ( isset( $facts['plugins'] ) ? $facts['plugins'] : array() ) as $plugin ) {
			if ( ! is_array( $plugin ) || empty( $plugin['file'] ) ) {
				continue;
			}
			$file    = str_replace( '\\', '/', (string) $plugin['file'] );
			$slug    = false === strpos( $file, '/' ) ? preg_replace( '/\.php$/i', '', $file ) : substr( $file, 0, strpos( $file, '/' ) );
			$slug    = strtolower( (string) $slug );
			$version = trim( (string) ( isset( $plugin['version'] ) ? $plugin['version'] : '' ) );
			if ( ! preg_match( '/^[a-z0-9][a-z0-9._\-]{0,199}$/', $slug ) || ! preg_match( '/^[0-9A-Za-z][0-9A-Za-z.+_\-]{0,63}$/', $version ) ) {
				continue;
			}
			if ( isset( $seen[ $slug . '@' . $version ] ) ) {
				continue;
			}
			$seen[ $slug . '@' . $version ] = true;
			$out[]                          = array(
				'type'    => 'plugin',
				'slug'    => $slug,
				'version' => $version,
				'name'    => isset( $plugin['name'] ) ? (string) $plugin['name'] : $slug,
			);
			if ( count( $out ) >= self::MAX_ITEMS ) {
				break;
			}
		}
		return $out;
	}

	/**
	 * Keep only well-formed copyright entries, exactly as the feed wrote them.
	 *
	 * @param mixed $raw The record's copyrights object.
	 * @return array<int, array<string, string>> One entry per rights holder: holder, notice, license, license_url.
	 */
	public static function clean_copyrights( $raw ) {
		$out = array();
		if ( ! is_array( $raw ) ) {
			return $out;
		}
		foreach ( $raw as $holder => $entry ) {
			if ( 'message' === $holder || ! is_array( $entry ) || empty( $entry['notice'] ) || ! is_string( $entry['notice'] ) ) {
				continue;
			}
			$url   = isset( $entry['license_url'] ) && is_string( $entry['license_url'] ) && 0 === strpos( $entry['license_url'], 'https://' ) ? $entry['license_url'] : '';
			$out[] = array(
				'holder'      => sanitize_key( (string) $holder ),
				'notice'      => substr( trim( strip_tags( $entry['notice'] ) ), 0, 300 ),
				'license'     => isset( $entry['license'] ) && is_string( $entry['license'] ) ? substr( trim( strip_tags( $entry['license'] ) ), 0, 4000 ) : '',
				'license_url' => $url,
			);
		}
		return $out;
	}

	/**
	 * Look the installed plugins up. Never throws; any failure is status 'unavailable' (or 'no_site_key').
	 *
	 * @param array<string, mixed> $facts Site facts.
	 * @param int                  $now   Check time.
	 * @return array<string, mixed>
	 */
	public function known( array $facts, $now ) {
		$software = self::software( $facts );
		$out      = array(
			'status'          => 'unavailable',
			'checked_at'      => (int) $now,
			'feed_updated_at' => 0,
			'plugin_count'    => count( $software ),
			'rows'            => array(),
			'copyrights'      => array(),
		);
		$key = $this->site_key();
		if ( '' === $key ) {
			$out['status'] = 'no_site_key';
			return $out;
		}
		$items = array();
		$names = array();
		foreach ( $software as $s ) {
			$items[]             = array(
				'type'    => $s['type'],
				'slug'    => $s['slug'],
				'version' => $s['version'],
			);
			$names[ $s['slug'] ] = $s['name'];
		}
		$answer = $this->client->recon_lookup( $key, $items );
		$json   = isset( $answer['json'] ) && is_array( $answer['json'] ) ? $answer['json'] : null;
		if ( 200 !== (int) ( isset( $answer['code'] ) ? $answer['code'] : 0 ) || null === $json || true !== ( isset( $json['ok'] ) ? $json['ok'] : null ) || ! isset( $json['matches'] ) || ! is_array( $json['matches'] ) ) {
			return $out;
		}
		$built                  = isset( $json['index_built_at'] ) && is_string( $json['index_built_at'] ) ? strtotime( $json['index_built_at'] ) : false;
		$out['feed_updated_at'] = false === $built ? 0 : (int) $built;

		$index = array();
		foreach ( $json['matches'] as $match ) {
			if ( ! is_array( $match ) || 'plugin' !== ( isset( $match['type'] ) ? $match['type'] : '' ) || empty( $match['vulns'] ) || ! is_array( $match['vulns'] ) ) {
				continue;
			}
			$slug = isset( $match['slug'] ) ? strtolower( (string) $match['slug'] ) : '';
			foreach ( $match['vulns'] as $v ) {
				if ( ! is_array( $v ) || empty( $v['id'] ) ) {
					continue;
				}
				$c  = self::clean_copyrights( isset( $v['copyrights'] ) ? $v['copyrights'] : null );
				$ci = -1;
				if ( $c ) {
					$sig = md5( (string) wp_json_encode( $c ) );
					if ( ! isset( $index[ $sig ] ) ) {
						$index[ $sig ]       = count( $out['copyrights'] );
						$out['copyrights'][] = $c;
					}
					$ci = $index[ $sig ];
				}
				$url           = isset( $v['record_url'] ) && is_string( $v['record_url'] ) && 0 === strpos( $v['record_url'], 'https://' ) ? $v['record_url'] : '';
				$out['rows'][] = array(
					'id'         => substr( preg_replace( '/[^A-Za-z0-9_.:\-]/', '', (string) $v['id'] ), 0, 80 ),
					'slug'       => $slug,
					'plugin'     => isset( $names[ $slug ] ) ? $names[ $slug ] : $slug,
					'version'    => isset( $match['version'] ) ? (string) $match['version'] : '',
					'title'      => isset( $v['title'] ) ? substr( trim( strip_tags( (string) $v['title'] ) ), 0, 300 ) : '',
					'affected'   => implode( ', ', array_map( 'strval', isset( $v['affected_versions'] ) && is_array( $v['affected_versions'] ) ? $v['affected_versions'] : array() ) ),
					'fixed'      => array_values( array_map( 'strval', isset( $v['patched_versions'] ) && is_array( $v['patched_versions'] ) ? $v['patched_versions'] : array() ) ),
					'record_url' => $url,
					'c'          => $ci,
				);
			}
		}
		$out['status'] = 'ok';
		return $out;
	}
}
