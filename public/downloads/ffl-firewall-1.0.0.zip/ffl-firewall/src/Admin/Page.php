<?php
/**
 * WooCommerce > FFL Firewall settings screen (Brandy's mockups A01 to A04, plus the Log and Help tabs).
 *
 * Every action is a plain form post to admin-post.php, so the screen works with JavaScript off.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Admin;

use FFL_Firewall\Overwatch\Cart\Upc_Resolver;
use FFL_Firewall\Overwatch\Checkout\Service;
use FFL_Firewall\Demo\Strings;
use FFL_Firewall\Log\Store;
use FFL_Firewall\Overwatch\Rules\Engine;
use FFL_Firewall\Proxy\Client;
use FFL_Firewall\Settings\Defaults;
use FFL_Firewall\Settings\Repository;

defined( 'ABSPATH' ) || exit;

/**
 * Renders the settings UI and handles saves, the key check and the message reset.
 */
class Page {

	const SLUG  = 'ffl-firewall';
	const TABS  = array( 'overview', 'overwatch', 'active-defense', 'recon', 'license', 'help', 'log' );
	const NONCE = 'fflfw_settings';

	/**
	 * Settings.
	 *
	 * @var Repository
	 */
	private $settings;

	/**
	 * Proxy client.
	 *
	 * @var Client
	 */
	private $client;

	/**
	 * Check log.
	 *
	 * @var Store
	 */
	private $log;

	/**
	 * UPC resolver.
	 *
	 * @var Upc_Resolver
	 */
	private $resolver;

	/**
	 * Demo test panel (unlicensed installs).
	 *
	 * @var Demo_Panel
	 */
	private $demo;

	/**
	 * ACTIVE DEFENSE tab.
	 *
	 * @var Defense_Tab
	 */
	private $defense;

	/**
	 * RECON tab.
	 *
	 * @var Recon_Tab
	 */
	private $recon;

	/**
	 * Overview tab.
	 *
	 * @var Overview_Tab
	 */
	private $overview;

	/**
	 * Constructor.
	 *
	 * @param Repository        $settings Settings.
	 * @param Client            $client   Proxy client.
	 * @param Store|null        $log      Check log.
	 * @param Upc_Resolver|null $resolver UPC resolver.
	 * @param Defense_Tab|null  $defense_tab ACTIVE DEFENSE tab.
	 * @param Recon_Tab|null    $recon_tab RECON tab.
	 */
	public function __construct( Repository $settings, Client $client, $log = null, $resolver = null, $defense_tab = null, $recon_tab = null ) {
		$this->settings = $settings;
		$this->client   = $client;
		$this->log      = $log instanceof Store ? $log : new Store();
		$this->resolver = $resolver instanceof Upc_Resolver ? $resolver : new Upc_Resolver( $settings );
		$this->demo     = new Demo_Panel( $settings, $client );
		$this->defense  = $defense_tab instanceof Defense_Tab ? $defense_tab : Defense_Tab::make( $client );
		$this->recon    = $recon_tab instanceof Recon_Tab ? $recon_tab : Recon_Tab::make( $settings );
		$this->overview = new Overview_Tab( $settings, $this->defense, $this->recon, $this->log, $this->demo );
	}

	/**
	 * Hook menu, assets and admin-post handlers.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_menu', array( $this, 'register_menu' ), 60 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
		add_action( 'admin_post_fflfw_save_settings', array( $this, 'handle_save' ) );
		add_action( 'admin_post_fflfw_reset_messages', array( $this, 'handle_reset_messages' ) );
		add_action( 'admin_post_fflfw_run_test', array( $this, 'handle_run_test' ) );
		$this->demo->register();
		$this->defense->register();
		$this->recon->register();
	}

	/**
	 * Add the WooCommerce submenu.
	 *
	 * @return void
	 */
	public function register_menu() {
		add_submenu_page(
			'woocommerce',
			__( 'FFL Firewall', 'ffl-firewall' ),
			__( 'FFL Firewall', 'ffl-firewall' ),
			'manage_woocommerce',
			self::SLUG,
			array( $this, 'render' )
		);
	}

	/**
	 * Enqueue admin assets on this screen only.
	 *
	 * @param string $hook Current hook suffix.
	 * @return void
	 */
	public function enqueue( $hook ) {
		if ( false === strpos( (string) $hook, self::SLUG ) ) {
			return;
		}
		$ver = defined( 'FFLFW_VERSION' ) ? FFLFW_VERSION : '0.0.0';
		$url = defined( 'FFLFW_URL' ) ? FFLFW_URL : '';
		wp_enqueue_style( 'fflfw-admin', $url . 'assets/css/admin.css', array(), $ver );
		wp_enqueue_script( 'fflfw-admin', $url . 'assets/js/admin-settings.js', array(), $ver, true );
	}

	/**
	 * Current tab from the request.
	 *
	 * @return string
	 */
	private function current_tab() {
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'overview'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$tab = 'settings' === $tab ? 'overview' : $tab; // Address from before the rebrand.
		return in_array( $tab, self::TABS, true ) ? $tab : 'overview';
	}

	/**
	 * Screen URL.
	 *
	 * @param string $tab Tab.
	 * @return string
	 */
	public static function url( $tab = 'overview' ) {
		$tab = 'settings' === $tab ? 'overview' : $tab; // Address from before the rebrand.
		return admin_url( 'admin.php?page=' . self::SLUG . '&tab=' . $tab );
	}

	/**
	 * Render the screen.
	 *
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		$tab = $this->current_tab();

		echo '<div class="wrap fflfw-settings">';
		echo '<h1 class="screen-reader-text">' . esc_html__( 'FFL Firewall', 'ffl-firewall' ) . '</h1>';
		$this->render_header();
		$this->render_tabs( $tab );

		if ( 'active-defense' === $tab ) {
			$this->defense->render( self::url( 'active-defense' ) );
		} elseif ( 'recon' === $tab ) {
			$this->recon->render();
		} elseif ( 'log' === $tab ) {
			$this->render_log_tab();
		} elseif ( 'help' === $tab ) {
			$this->render_help_tab();
		} elseif ( 'license' === $tab ) {
			$this->render_license_tab();
		} elseif ( 'overwatch' === $tab ) {
			$this->render_overwatch_tab();
		} else {
			if ( $this->demo->no_key() ) {
				$this->demo->render_top_notice();
			}
			$this->overview->render();
		}

		if ( in_array( $tab, array( 'overwatch', 'log' ), true ) ) {
			echo '<p class="fflfw-settings__disclaimer">' . esc_html__( "You're still responsible for what you ship, and this is not legal advice.", 'ffl-firewall' ) . '</p>';
		}
		echo '<p class="fflfw-settings__disclaimer">' . esc_html__( 'FFL Firewall is a tool that helps you protect your store and catch restricted items at checkout.', 'ffl-firewall' ) . '</p>';
		echo '</div>';
	}

	/**
	 * Dark header card: icon, name, version, and the plan and license pills (Brandy's A01 and A08).
	 *
	 * @return void
	 */
	private function render_header() {
		$url      = defined( 'FFLFW_URL' ) ? FFLFW_URL : '';
		$version  = defined( 'FFLFW_VERSION' ) ? FFLFW_VERSION : '';
		$licensed = 'active' === $this->settings->license_status();
		echo '<header class="fflfw-settings__header">';
		echo '<img class="fflfw-settings__icon" src="' . esc_url( $url . 'assets/img/ffl-firewall-icon.svg' ) . '" alt="" width="44" height="44" />';
		echo '<span class="fflfw-settings__name">' . esc_html__( 'FFL Firewall', 'ffl-firewall' ) . '</span>';
		if ( '' !== $version ) {
			/* translators: %s: plugin version */
			echo '<span class="fflfw-settings__version">' . esc_html( sprintf( __( 'Version %s', 'ffl-firewall' ), $version ) ) . '</span>';
		}
		echo '<span class="fflfw-settings__pills">';
		if ( $licensed ) {
			echo '<span class="fflfw-hpill">' . esc_html__( '$79/month plan', 'ffl-firewall' ) . '</span>';
			echo '<span class="fflfw-hpill fflfw-hpill--ok"><span aria-hidden="true">&#10003;</span> ' . esc_html__( 'License active', 'ffl-firewall' ) . '</span>';
		} else {
			echo '<span class="fflfw-hpill">' . esc_html__( 'Demo mode', 'ffl-firewall' ) . '</span>';
			echo '<span class="fflfw-hpill">' . esc_html( $this->demo->no_key() ? __( 'No license', 'ffl-firewall' ) : __( 'License not active', 'ffl-firewall' ) ) . '</span>';
			echo '<a class="fflfw-btn fflfw-btn--primary" href="' . esc_url( self::url( 'license' ) ) . '">' . esc_html__( 'Add license', 'ffl-firewall' ) . '</a>';
		}
		echo '</span>';
		echo '</header>';
	}

	/**
	 * Nav tabs.
	 *
	 * @param string $tab Current tab.
	 * @return void
	 */
	private function render_tabs( $tab ) {
		$labels = array(
			'overview'       => __( 'Overview', 'ffl-firewall' ),
			'overwatch'      => __( 'OVERWATCH', 'ffl-firewall' ),
			'active-defense' => __( 'ACTIVE DEFENSE', 'ffl-firewall' ),
			'recon'          => __( 'RECON', 'ffl-firewall' ),
			'license'        => __( 'License', 'ffl-firewall' ),
			'help'           => __( 'Help', 'ffl-firewall' ),
		);
		$tab    = 'log' === $tab ? 'overwatch' : $tab; // The log belongs to OVERWATCH.
		echo '<nav class="nav-tab-wrapper fflfw-settings__tabs">';
		foreach ( $labels as $id => $label ) {
			$class = 'nav-tab' . ( $tab === $id ? ' nav-tab-active' : '' );
			echo '<a class="' . esc_attr( $class ) . '" href="' . esc_url( self::url( $id ) ) . '">' . esc_html( $label ) . '</a>';
		}
		echo '</nav>';
	}

	/**
	 * One label-plus-field row.
	 *
	 * @param string $label Row label (already translated).
	 * @param string $html  Field HTML (already escaped).
	 * @param string $for   Optional field id for the label.
	 * @return void
	 */
	private function row( $label, $html, $for = '' ) {
		echo '<div class="fflfw-row">';
		if ( '' !== $for ) {
			echo '<label class="fflfw-row__label" for="' . esc_attr( $for ) . '">' . esc_html( $label ) . '</label>';
		} else {
			echo '<div class="fflfw-row__label">' . esc_html( $label ) . '</div>';
		}
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts below.
		echo '<div class="fflfw-row__field">' . $html . '</div>';
		echo '</div>';
	}

	/**
	 * Hidden fields that carry settings this tab doesn't show through its save (the save replaces the whole option).
	 *
	 * @param string $tab 'overwatch' (carries the license key) or 'license' (carries everything else).
	 * @return string Escaped HTML.
	 */
	private function carry( $tab ) {
		$s    = $this->settings->all();
		$html = '<input type="hidden" name="fflfw_tab" value="' . esc_attr( $tab ) . '" />';
		if ( 'overwatch' === $tab ) {
			return $html . '<input type="hidden" name="fflfw[license_key]" value="' . esc_attr( (string) $s['license_key'] ) . '" />';
		}
		$html .= '<input type="hidden" name="fflfw[enabled]" value="' . ( ! empty( $s['enabled'] ) ? '1' : '' ) . '" />';
		$html .= '<input type="hidden" name="fflfw[roster_rule]" value="' . esc_attr( (string) $s['roster_rule'] ) . '" />';
		$html .= '<input type="hidden" name="fflfw[upc_meta_key]" value="' . esc_attr( (string) $s['upc_meta_key'] ) . '" />';
		foreach ( (array) $s['messages'] as $slot => $message ) {
			$html .= '<input type="hidden" name="fflfw[messages][' . esc_attr( (string) $slot ) . ']" value="' . esc_attr( (string) $message ) . '" />';
		}
		return $html;
	}

	/**
	 * OVERWATCH tab (Brandy's A05): the cart check settings, the test and the fail-open note.
	 *
	 * @return void
	 */
	private function render_overwatch_tab() {
		$s      = $this->settings->all();
		$demo   = $this->demo->active();
		$no_key = $this->demo->no_key();

		echo Ui::head( 'OVERWATCH', __( 'State shipping checks', 'ffl-firewall' ), Ui::pill( $this->settings->checks_active() ? __( 'On', 'ffl-firewall' ) : ( $demo ? __( 'Demo', 'ffl-firewall' ) : __( 'Off', 'ffl-firewall' ) ), $this->settings->checks_active() ? 'on' : 'off' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in Ui.
		echo '<p class="fflfw-settings__intro">' . esc_html__( "At checkout, OVERWATCH matches each item's UPC to the shipping ZIP. To help you catch restricted items, it removes items that can't ship there, asks for a permit or age acknowledgement where one applies, and flags orders for you to review. Set how it handles each result here.", 'ffl-firewall' ) . '</p>';
		echo '<p class="fflfw-settings__actions"><a class="fflfw-btn fflfw-btn--ghost" href="' . esc_url( self::url( 'log' ) ) . '">' . esc_html__( 'Log', 'ffl-firewall' ) . '</a></p>';

		if ( $no_key ) {
			echo '<a class="fflfw-btn fflfw-btn--ghost" href="' . esc_url( self::url( 'overview' ) . '#fflfw-test-panel' ) . '">' . esc_html__( 'Go to Test a check', 'ffl-firewall' ) . '</a>';
			return;
		}

		echo '<form class="fflfw-settings__form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="fflfw_save_settings" />';
		wp_nonce_field( self::NONCE );
		echo $this->carry( 'overwatch' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in carry().
		echo '<div class="fflfw-panel">';

		// Master switch.
		$html  = '<label class="fflfw-check"><input type="checkbox" name="fflfw[enabled]" value="1"' . checked( ! empty( $s['enabled'] ), true, false ) . ' /> ' . esc_html__( 'Run OVERWATCH at checkout', 'ffl-firewall' ) . '</label>';
		$html .= '<p class="fflfw-help">' . esc_html__( "This is off when you first install the plugin. While it's off, shoppers check out the way they do today and nothing is removed from a cart.", 'ffl-firewall' ) . '</p>';
		$this->row( __( 'Master switch', 'ffl-firewall' ), $html );

		// Where it runs.
		$this->row( __( 'Where it runs', 'ffl-firewall' ), '<p class="fflfw-help fflfw-help--flush">' . esc_html__( 'It runs on both the classic and Blocks checkout, and it runs again when the address or cart changes and when the shopper places the order. It uses the shipping ZIP, or the billing ZIP when there\'s no shipping ZIP, and it skips local pickup orders.', 'ffl-firewall' ) . '</p>' );

		// Roster states.
		$options = array(
			Defaults::ROSTER_REMOVE => array( __( 'Remove the item from the cart', 'ffl-firewall' ), __( 'The shopper sees your item removed message and can check out with the rest of the cart.', 'ffl-firewall' ) ),
			Defaults::ROSTER_FLAG   => array( __( 'Allow it and flag the order (default)', 'ffl-firewall' ), __( 'The shopper can check out and sees nothing about the flag. The order gets an order note and a Flagged label in Orders.', 'ffl-firewall' ) ),
			Defaults::ROSTER_ALLOW  => array( __( 'Allow it with no flag', 'ffl-firewall' ), __( 'The roster result is left out of the check, and the order goes through the way it does today.', 'ffl-firewall' ) ),
		);
		$html  = '<fieldset><legend class="screen-reader-text">' . esc_html__( 'Roster states', 'ffl-firewall' ) . '</legend>';
		$html .= '<p class="fflfw-help fflfw-help--lead">' . esc_html__( "Some states keep a roster of handguns that dealers there can sell. Choose what happens when a handgun in the cart isn't on the roster for the shopper's state.", 'ffl-firewall' ) . '</p>';
		foreach ( $options as $value => $text ) {
			$html .= '<label class="fflfw-radio"><input type="radio" name="fflfw[roster_rule]" value="' . esc_attr( $value ) . '"' . checked( $s['roster_rule'], $value, false ) . ' />';
			$html .= '<span><span class="fflfw-radio__title">' . esc_html( $text[0] ) . '</span><span class="fflfw-radio__help">' . esc_html( $text[1] ) . '</span></span></label>';
		}
		$html .= '</fieldset>';
		$this->row( __( 'Roster states', 'ffl-firewall' ), $html );

		// Shopper messages.
		$labels   = array(
			'removed' => __( 'Item removed', 'ffl-firewall' ),
			'ffl'     => __( 'Ships to an FFL dealer only', 'ffl-firewall' ),
			'permit'  => __( 'Permit or age check', 'ffl-firewall' ),
		);
		$defaults = Defaults::messages();
		$html     = '<p class="fflfw-help fflfw-help--lead">' . esc_html__( 'Shoppers see these at checkout. Type {product}, {zip} or {state} where you want the item name, ZIP code or state filled in.', 'ffl-firewall' ) . '</p>';
		foreach ( $labels as $slot => $label ) {
			$id    = 'fflfw-msg-' . $slot;
			$html .= '<div class="fflfw-msg"><label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label>';
			$html .= '<textarea id="' . esc_attr( $id ) . '" name="fflfw[messages][' . esc_attr( $slot ) . ']" rows="3" data-fflfw-default="' . esc_attr( $defaults[ $slot ] ) . '">' . esc_textarea( (string) $s['messages'][ $slot ] ) . '</textarea></div>';
		}
		$html .= '<p class="fflfw-help">' . esc_html__( 'With a permit or age check, the shopper also has to tick "I understand this item won\'t ship until the permit or age check is done." before Place Order works.', 'ffl-firewall' ) . '</p>';
		$reset = wp_nonce_url( admin_url( 'admin-post.php?action=fflfw_reset_messages' ), self::NONCE );
		$html .= '<a class="fflfw-reset" href="' . esc_url( $reset ) . '" data-fflfw-reset>' . esc_html__( 'Restore the default text', 'ffl-firewall' ) . '</a>';
		$this->row( __( 'Shopper messages', 'ffl-firewall' ), $html );

		// UPC source: the dealer's own meta key, checked after the built-in sources.
		$html  = '<label for="fflfw-upc-meta" class="fflfw-field-label">' . esc_html__( 'Custom field', 'ffl-firewall' ) . '</label>';
		$html .= '<input type="text" id="fflfw-upc-meta" class="regular-text fflfw-input" name="fflfw[upc_meta_key]" value="' . esc_attr( (string) $s['upc_meta_key'] ) . '" autocomplete="off" spellcheck="false" aria-describedby="fflfw-upc-meta-help" />';
		$html .= '<p class="fflfw-help" id="fflfw-upc-meta-help">' . esc_html__( 'Tell OVERWATCH where your products keep their UPC. Items with no UPC pass through the check, and the order is flagged.', 'ffl-firewall' ) . ' ' . esc_html__( "If you leave this blank, FFL Firewall uses WooCommerce's own GTIN/UPC field and common UPC plugin fields. A UPC counts only when it is 8 to 14 digits.", 'ffl-firewall' ) . '</p>';
		$this->row( __( 'UPC field', 'ffl-firewall' ), $html );

		// Test a check. Its own form (inputs use form="fflfw-test-form"), so it works without JavaScript.
		if ( $demo ) {
			$this->row( __( 'Test a check', 'ffl-firewall' ), '<p class="fflfw-help fflfw-help--flush">' . esc_html__( 'You can still try one product and one ZIP with Test a check.', 'ffl-firewall' ) . '</p><a class="fflfw-btn fflfw-btn--ghost" href="' . esc_url( self::url( 'overview' ) . '#fflfw-test-panel' ) . '">' . esc_html__( 'Go to Test a check', 'ffl-firewall' ) . '</a>' );
		} else {
			$products = $this->test_products();
			$html     = '<p class="fflfw-help fflfw-help--flush">' . esc_html__( 'Pick one product and type one ZIP to see what a shopper would get. Nothing is added to a real cart, and no order is made.', 'ffl-firewall' ) . '</p>';
			$html    .= '<div class="fflfw-test">';
			$html    .= '<div><label for="fflfw-test-zip">' . esc_html__( 'ZIP code', 'ffl-firewall' ) . '</label><input type="text" id="fflfw-test-zip" form="fflfw-test-form" name="zip" class="fflfw-input" inputmode="numeric" maxlength="10" required /></div>';
			$html    .= '<div><label for="fflfw-test-product">' . esc_html__( 'Product', 'ffl-firewall' ) . '</label><select id="fflfw-test-product" form="fflfw-test-form" name="product_id" required>';
			foreach ( $products as $id => $label ) {
				$html .= '<option value="' . esc_attr( (string) $id ) . '">' . esc_html( $label ) . '</option>';
			}
			$html .= '</select></div>';
			$html .= '<div><button type="submit" form="fflfw-test-form" class="button button-primary"' . ( empty( $products ) ? ' disabled' : '' ) . '>' . esc_html__( 'Run test', 'ffl-firewall' ) . '</button></div>';
			$html .= '</div>';
			$html .= $this->test_result_html();
			$this->row( __( 'Test a check', 'ffl-firewall' ), $html );
		}

		// Fails open.
		$this->row( __( "If the check can't run", 'ffl-firewall' ), '<p class="fflfw-help fflfw-help--flush">' . esc_html__( "OVERWATCH fails open. If the check service is down, times out or answers for only part of the cart, or the license can't be verified, checkout carries on and the order is flagged so you can review it.", 'ffl-firewall' ) . '</p>' );

		echo '</div>';
		echo '<p class="fflfw-settings__save"><button type="submit" class="button button-primary">' . esc_html__( 'Save changes', 'ffl-firewall' ) . '</button></p>';
		echo '</form>';
		if ( ! $demo ) {
			echo '<form id="fflfw-test-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="fflfw_run_test" />';
			wp_nonce_field( 'fflfw_run_test', '_fflfw_test_nonce' );
			echo '</form>';
		}
	}

	/**
	 * License tab: the key, Check key and the key status. The key row came from the old Settings tab unchanged.
	 *
	 * @return void
	 */
	private function render_license_tab() {
		$s      = $this->settings->all();
		$status = $this->settings->license_status();
		$invalid = in_array( $status, array( 'invalid', 'inactive' ), true );
		$no_key  = $this->demo->no_key();

		echo '<p class="fflfw-settings__intro">' . esc_html__( "One license at $79 a month covers every service in FFL Firewall: ACTIVE DEFENSE, OVERWATCH, RECON and every feature we add later.", 'ffl-firewall' ) . '</p>';
		echo '<form class="fflfw-settings__form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="fflfw_save_settings" />';
		wp_nonce_field( self::NONCE );
		echo $this->carry( 'license' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in carry().
		echo '<div class="fflfw-panel">';

		$html  = '<div class="fflfw-inline">';
		$html .= '<input type="text" id="fflfw-license" class="regular-text fflfw-input' . ( $invalid ? ' fflfw-input--error' : '' ) . '" name="fflfw[license_key]" value="' . esc_attr( (string) $s['license_key'] ) . '"' . ( $no_key ? ' placeholder="' . esc_attr( Strings::get( 'lic.ph' ) ) . '"' : '' ) . ' autocomplete="off" spellcheck="false"' . ( $invalid ? ' aria-invalid="true" aria-describedby="fflfw-license-status"' : '' ) . ' />';
		$html .= '<button type="submit" class="button" name="fflfw_check_key" value="1">' . esc_html__( 'Check key', 'ffl-firewall' ) . '</button>';
		$html .= ' <a class="fflfw-license-link" href="https://coriolisagency.com/ffl-firewall/" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Get a license', 'ffl-firewall' ) . '</a>';
		$html .= '</div>';
		if ( 'active' === $status ) {
			$html .= '<div class="fflfw-pill fflfw-pill--ok" id="fflfw-license-status"><span aria-hidden="true">&#10003;</span>' . esc_html__( 'This key is valid, and this site is connected.', 'ffl-firewall' ) . '</div>';
		} elseif ( $invalid ) {
			$html .= '<div class="fflfw-pill fflfw-pill--bad" id="fflfw-license-status" role="alert"><span aria-hidden="true">!</span>' . esc_html__( "We couldn't verify this key. Check it for typos, or write to support@coriolisagency.com and we'll look it up.", 'ffl-firewall' ) . '</div>';
			$html .= '<div class="fflfw-inline-notice">' . esc_html__( 'Until the key is verified, items pass through checkout and each order is flagged so you can review it.', 'ffl-firewall' ) . '</div>';
		}
		if ( 'unknown' === $status && ! $no_key ) {
			$html .= '<div class="fflfw-pill fflfw-pill--warn" id="fflfw-license-status" role="status"><span aria-hidden="true">!</span>' . esc_html__( "The plugin couldn't reach the license server just now, so it's running in demo mode until it can check your FFL Firewall license again. It retries on its own; if this notice stays up, re-enter your license key above and press Check key, or write to support@coriolisagency.com.", 'ffl-firewall' ) . '</div>';
		}
		if ( $no_key ) {
			$html .= '<div class="fflfw-pill fflfw-pill--warn" id="fflfw-license-status"><span aria-hidden="true">!</span>' . esc_html( Strings::get( 'lic.status' ) ) . '</div>';
		}
		$html .= '<p class="fflfw-help">' . esc_html__( 'Paste the license key we emailed you after checkout, then click Check key. If you don\'t have a key yet, get a license on ', 'ffl-firewall' ) . '<a href="https://coriolisagency.com/ffl-firewall/" target="_blank" rel="noopener noreferrer">' . esc_html__( 'the FFL Firewall page', 'ffl-firewall' ) . '</a>' . esc_html__( '; it\'s $79 a month for unlimited OVERWATCH transactions.', 'ffl-firewall' ) . '</p>';
		$this->row( __( 'License key', 'ffl-firewall' ), $html, 'fflfw-license' );

		echo '</div></form>';
	}

	/**
	 * Products for the test picker: published products and variations with a UPC (first 200).
	 *
	 * @return array<int, string> Product ID => "Name (UPC)".
	 */
	private function test_products() {
		if ( ! function_exists( 'wc_get_products' ) ) {
			return array();
		}
		$out = array();
		foreach ( wc_get_products( array( 'limit' => 200, 'status' => 'publish', 'type' => array( 'simple', 'variation' ), 'orderby' => 'title', 'order' => 'ASC' ) ) as $product ) {
			$upc = $this->resolver->resolve( $product );
			if ( '' !== $upc ) {
				$out[ $product->get_id() ] = $product->get_name() . ' (' . $upc . ')';
			}
		}
		return $out;
	}

	/**
	 * Result box for the last test run by this user.
	 *
	 * @return string
	 */
	private function test_result_html() {
		$r = get_transient( 'fflfw_test_' . get_current_user_id() );
		if ( ! is_array( $r ) ) {
			return '';
		}
		$base = Service::fill( '{product}, UPC {upc}, to zip {zip}.', $r['product'], $r['zip'] );
		$base = str_replace( '{upc}', $r['upc'], $base );
		$quote = '';
		switch ( $r['action'] ) {
			case Engine::REMOVE:
				$title = __( 'Item would be removed', 'ffl-firewall' );
				$desc  = $base . ' ' . __( 'The item comes out of the cart, and the shopper sees this message:', 'ffl-firewall' );
				$quote = Service::fill( $this->settings->get( 'messages' )['removed'], $r['product'], $r['zip'] );
				break;
			case Engine::FFL:
				$title = __( 'CC: ship to an FFL or dealer only', 'ffl-firewall' );
				$desc  = $base . ' ' . __( 'The item stays in the cart, and the shopper sees this message:', 'ffl-firewall' );
				$quote = Service::fill( $this->settings->get( 'messages' )['ffl'], $r['product'], $r['zip'] );
				break;
			case Engine::PERMIT:
				$title = __( 'This item needs a permit or age check', 'ffl-firewall' );
				$desc  = $base . ' ' . __( 'The item stays in the cart, and the shopper sees this message:', 'ffl-firewall' );
				$quote = Service::fill( $this->settings->get( 'messages' )['permit'], $r['product'], $r['zip'] );
				break;
			case Engine::FLAG:
				if ( in_array( $r['reason'], array( 'license_invalid', 'license_inactive' ), true ) ) {
					$title = __( "Check couldn't run: key not verified", 'ffl-firewall' );
					$desc  = $base . ' ' . __( "Because the license key isn't verified, the item passes and stays in the cart, the shopper sees no message, and the order gets an order note and a Flagged label.", 'ffl-firewall' );
					break;
				}
				$title = __( 'Allowed and flagged', 'ffl-firewall' );
				$desc  = $base . ' ' . str_replace( '{code}', $r['reason'], __( 'The shopper can check out with the item and sees no message, while the order is marked Flagged in Orders with a note giving the reason code: {code}.', 'ffl-firewall' ) );
				break;
			default:
				$title = __( 'Item can ship', 'ffl-firewall' );
				$desc  = $base . ' ' . __( 'The check found nothing for this zip, so the item stays in the cart and the shopper sees no message.', 'ffl-firewall' );
		}
		$html = '<div class="fflfw-result" role="status">';
		if ( '' !== $title ) {
			$html .= '<b>' . esc_html( $title ) . '</b>';
		}
		$html .= '<div>' . esc_html( $desc ) . '</div>';
		if ( '' !== $quote ) {
			$html .= '<q>' . esc_html( $quote ) . '</q>';
		}
		if ( '' !== $r['age'] ) {
			$html .= '<div class="fflfw-help">' . esc_html( strtr( __( 'Age code {age_code}: {age_rule}', 'ffl-firewall' ), array( '{age_code}' => $r['age'], '{age_rule}' => Service::age_rule( $r['age'] ) ) ) ) . '</div>';
		}
		return $html . '</div>';
	}

	/**
	 * Run one test check through the proxy (no cart, no order) and show the result.
	 *
	 * @return void
	 */
	public function handle_run_test() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'ffl-firewall' ), 403 );
		}
		check_admin_referer( 'fflfw_run_test', '_fflfw_test_nonce' );
		$zip     = Service::zip5( isset( $_POST['zip'] ) ? sanitize_text_field( wp_unslash( $_POST['zip'] ) ) : '' );
		$product = isset( $_POST['product_id'] ) && function_exists( 'wc_get_product' ) ? wc_get_product( absint( $_POST['product_id'] ) ) : null;
		if ( '' !== $zip && is_object( $product ) ) {
			$upc    = $this->resolver->resolve( $product );
			$answer = '' === $upc ? array( 'results' => array() ) : $this->client->check( $zip, array( $upc ) );
			$result = Engine::evaluate( array( 'test' => array( 'upc' => $upc, 'name' => $product->get_name() ) ), $answer, (string) $this->settings->get( 'roster_rule' ) );
			$line   = $result['lines']['test'];
			set_transient(
				'fflfw_test_' . get_current_user_id(),
				array(
					'product' => $product->get_name(),
					'upc'     => '' !== $upc ? $upc : '-',
					'zip'     => $zip,
					'action'  => $line['action'],
					'reason'  => $line['reason'],
					'age'     => $line['age'],
				),
				HOUR_IN_SECONDS
			);
		}
		wp_safe_redirect( self::url( 'overwatch' ) );
		exit;
	}

	/**
	 * Log tab (A05/A06): removed items, flagged orders, permit notices and FFL-only items.
	 *
	 * @return void
	 */
	private function render_log_tab() {
		$on     = $this->settings->checks_active();
		$valid  = 'active' === $this->settings->license_status();
		$rows   = $this->log->rows();
		$labels = Store::action_labels();
		$filter = isset( $_GET['fflfw_action'] ) ? sanitize_key( wp_unslash( $_GET['fflfw_action'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$actions = array();
		foreach ( $rows as $row ) {
			if ( '' !== $row['action'] ) {
				$actions[ $row['action'] ] = isset( $labels[ $row['action'] ] ) ? $labels[ $row['action'] ] : $row['action'];
			}
		}
		if ( '' !== $filter ) {
			$rows = array_values(
				array_filter(
					$rows,
					function ( $row ) use ( $filter ) {
						return $row['action'] === $filter;
					}
				)
			);
		}

		echo Ui::head( 'OVERWATCH', __( 'Log', 'ffl-firewall' ), Ui::pill( $on ? __( 'On', 'ffl-firewall' ) : __( 'Off', 'ffl-firewall' ), $on ? 'on' : 'off' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in Ui.
		echo '<p class="fflfw-settings__intro">' . esc_html__( "Each time OVERWATCH removes an item, flags an order or shows a shopper notice, it's listed here. Flagged orders also get an order note and a Flagged label in WooCommerce Orders.", 'ffl-firewall' ) . '</p>';
		echo '<div class="fflfw-stats">';
		echo '<div class="fflfw-stat"><div class="fflfw-stat__k">' . esc_html__( 'OVERWATCH at checkout', 'ffl-firewall' ) . '</div><div class="fflfw-stat__v' . ( $on ? ' fflfw-ok' : '' ) . '">' . ( $on ? esc_html__( 'On', 'ffl-firewall' ) : '&mdash;' ) . '</div></div>';
		echo '<div class="fflfw-stat"><div class="fflfw-stat__k">' . esc_html__( 'License key', 'ffl-firewall' ) . '</div><div class="fflfw-stat__v' . ( $valid ? ' fflfw-ok' : '' ) . '">' . ( $valid ? esc_html__( 'Verified', 'ffl-firewall' ) : '&mdash;' ) . '</div></div>';
		echo '<div class="fflfw-stat"><div class="fflfw-stat__k">' . esc_html__( 'Items removed, last 7 days', 'ffl-firewall' ) . '</div><div class="fflfw-stat__v">' . esc_html( (string) $this->log->removed_last_week() ) . '</div></div>';
		echo '<div class="fflfw-stat"><div class="fflfw-stat__k">' . esc_html__( 'Orders flagged, last 7 days', 'ffl-firewall' ) . '</div><div class="fflfw-stat__v">' . esc_html( (string) $this->log->flagged_last_week() ) . '</div></div>';
		echo '</div>';

		// Action filter: a plain GET form, so it works with JavaScript off.
		echo '<form class="fflfw-tnav" method="get" action="' . esc_url( admin_url( 'admin.php' ) ) . '">';
		echo '<input type="hidden" name="page" value="' . esc_attr( self::SLUG ) . '" /><input type="hidden" name="tab" value="log" />';
		echo '<label class="screen-reader-text" for="fflfw-action-filter">' . esc_html__( 'All actions', 'ffl-firewall' ) . '</label>';
		echo '<select id="fflfw-action-filter" name="fflfw_action"><option value="">' . esc_html__( 'All actions', 'ffl-firewall' ) . '</option>';
		foreach ( $actions as $value => $label ) {
			echo '<option value="' . esc_attr( $value ) . '"' . selected( $filter, $value, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select> <button type="submit" class="button">' . esc_html__( 'Filter', 'ffl-firewall' ) . '</button>';
		/* translators: %d: number of log rows */
		echo '<span class="fflfw-tnav__count">' . esc_html( sprintf( _n( '%d item', '%d items', count( $rows ), 'ffl-firewall' ), count( $rows ) ) ) . '</span>';
		echo '</form>';

		$cols = array(
			'date'  => __( 'Date', 'ffl-firewall' ),
			'ref'   => __( 'Order or cart', 'ffl-firewall' ),
			'prod'  => __( 'Product', 'ffl-firewall' ),
			'zip'   => __( 'Zip', 'ffl-firewall' ),
			'state' => __( 'State', 'ffl-firewall' ),
			'act'   => __( 'Action', 'ffl-firewall' ),
		);
		echo '<table class="widefat striped fflfw-log"><thead><tr>';
		foreach ( $cols as $col ) {
			echo '<th scope="col">' . esc_html( $col ) . '</th>';
		}
		echo '</tr></thead><tbody>';
		if ( empty( $rows ) ) {
			echo '<tr class="no-items"><td colspan="6">' . esc_html( __( 'No items found.' ) ) . '</td></tr>'; // phpcs:ignore WordPress.WP.I18n.MissingArgDomain -- WordPress core string.
		}
		$date_format = get_option( 'date_format', 'M j, Y' ) . ', ' . get_option( 'time_format', 'g:i A' );
		foreach ( $rows as $row ) {
			$action = isset( $labels[ $row['action'] ] ) ? $labels[ $row['action'] ] : $row['action'];
			$cells  = array(
				'date'  => wp_date( $date_format, (int) $row['time'] ),
				'ref'   => $row['ref'],
				'prod'  => $row['products'],
				'zip'   => $row['zip'],
				'state' => $row['state'],
				'act'   => $action,
			);
			echo '<tr>';
			foreach ( $cells as $key => $value ) {
				$value = '' === (string) $value ? '&mdash;' : esc_html( (string) $value );
				if ( 'act' === $key && '&mdash;' !== $value ) {
					$value = '<span class="fflfw-log__act">' . $value . '</span>';
				}
				// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above.
				echo '<td data-colname="' . esc_attr( $cols[ $key ] ) . '">' . $value . '</td>';
			}
			echo '</tr>';
		}
		echo '</tbody></table>';
	}

	/**
	 * Help tab.
	 *
	 * @return void
	 */
	private function render_help_tab() {
		echo '<p class="fflfw-settings__intro">' . esc_html__( 'FFL Firewall runs three services on your store: ACTIVE DEFENSE, OVERWATCH and RECON. The Overview tab shows where each one stands, and each has its own tab for its settings.', 'ffl-firewall' ) . '</p>';
		echo '<p class="fflfw-help">' . esc_html__( 'Your license key comes by email after you buy FFL Firewall at coriolisagency.com/ffl-firewall. Paste it on the License tab and click Check key, and write to support@coriolisagency.com if the key won\'t verify.', 'ffl-firewall' ) . '</p>';
	}

	/**
	 * Save settings, and check the key when "Check key" was pressed or the key changed.
	 *
	 * @return void
	 */
	public function handle_save() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'ffl-firewall' ), 403 );
		}
		check_admin_referer( self::NONCE );

		$raw      = isset( $_POST['fflfw'] ) && is_array( $_POST['fflfw'] ) ? wp_unslash( $_POST['fflfw'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized by Repository::sanitize().
		$previous = (string) $this->settings->get( 'license_key', '' );
		$clean    = $this->settings->sanitize( $raw );
		$this->settings->save( $clean );

		if ( ! empty( $_POST['fflfw_check_key'] ) || $previous !== $clean['license_key'] ) {
			$status = '' === $clean['license_key'] ? 'invalid' : $this->client->license_status( $clean['license_key'] );
			$this->settings->set_license_status( $status );
			( new \FFL_Firewall\Settings\License_Recheck( $this->settings, $this->client ) )->restart();
			// FFLFW-ONBOARD-SITEKEY: ACTIVE DEFENSE already on with no key: the now-active license gets one.
			if ( 'active' === $status ) {
				$defense = new \FFL_Firewall\Defense\Config();
				( new \FFL_Firewall\Defense\Provision( $this->client, $this->settings ) )->maybe_fill( $defense, new \FFL_Firewall\Defense\Embed( $defense ) );
			}
		}

		$back = isset( $_POST['fflfw_tab'] ) ? sanitize_key( wp_unslash( $_POST['fflfw_tab'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Checked above.
		wp_safe_redirect( add_query_arg( 'updated', '1', self::url( in_array( $back, array( 'overwatch', 'license' ), true ) ? $back : 'overwatch' ) ) );
		exit;
	}

	/**
	 * Restore the default shopper messages (no-JS path for "Restore the default text").
	 *
	 * @return void
	 */
	public function handle_reset_messages() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'ffl-firewall' ), 403 );
		}
		check_admin_referer( self::NONCE );

		$settings             = $this->settings->all();
		$settings['messages'] = Defaults::messages();
		$this->settings->save( $settings );

		wp_safe_redirect( self::url( 'overwatch' ) );
		exit;
	}
}
