<?php
/**
 * Admin notice that FFL Firewall · ACTIVE DEFENSE is on by default, with a one-click off switch.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Admin;

use FFL_Firewall\Defense\Config;

defined( 'ABSPATH' ) || exit;

/**
 * Shows N1 while ACTIVE DEFENSE is on, and N3 once after the dealer switches it off from the notice.
 */
class Ad_Default_Notice {

	const ACTION = 'fflfw_ad_switch_off';
	const NONCE  = 'fflfw_ad_switch_off';

	/**
	 * Hook the notice and the off-switch action.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_notices', array( $this, 'render' ) );
		add_action( 'admin_post_' . self::ACTION, array( $this, 'handle_switch_off' ) );
	}

	/**
	 * Whether the current user can switch ACTIVE DEFENSE.
	 *
	 * @return bool
	 */
	private function can_manage() {
		return current_user_can( 'manage_woocommerce' ) || current_user_can( 'manage_options' );
	}

	/**
	 * Print N1 plus the N2 off switch, or N3 after a successful off-switch.
	 *
	 * @return void
	 */
	public function render() {
		if ( ! $this->can_manage() ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only notice flag.
		$flag = isset( $_GET['fflfw_notice'] ) ? sanitize_key( wp_unslash( $_GET['fflfw_notice'] ) ) : '';
		if ( 'ad_off' === $flag ) {
			echo '<div class="notice notice-info is-dismissible"><p>';
			echo esc_html( Ad_Default_Copy::off_notice() );
			echo '</p></div>';
			return;
		}

		if ( true !== ( new Config() )->get( 'enabled' ) ) {
			return;
		}

		echo '<div class="notice notice-info"><p>';
		echo esc_html( Ad_Default_Copy::notice() );
		echo '</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="' . esc_attr( self::ACTION ) . '" />';
		wp_nonce_field( self::NONCE );
		echo '<p><button type="submit" class="button">' . esc_html( Ad_Default_Copy::switch_off() ) . '</button></p>';
		echo '</form></div>';
	}

	/**
	 * Turn ACTIVE DEFENSE off and show N3.
	 *
	 * @return void
	 */
	public function handle_switch_off() {
		if ( ! $this->can_manage() ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'ffl-firewall' ), 403 );
		}
		check_admin_referer( self::NONCE );

		$config = new Config();
		$config->save( $config->sanitize( array_merge( $config->all(), array( 'enabled' => false ) ) ) );

		$back = admin_url( 'admin.php?page=ffl-firewall' );
		wp_safe_redirect( add_query_arg( 'fflfw_notice', 'ad_off', $back ) );
		exit;
	}
}
