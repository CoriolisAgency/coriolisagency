<?php
/**
 * WooCommerce > FFL Firewall > Overview: three service cards (Brandy's mockups A01, A02 and A08).
 *
 * Every button is a link or a plain form post, so the screen works with JavaScript off.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Admin;

use FFL_Firewall\Log\Store;
use FFL_Firewall\Settings\Repository;

defined( 'ABSPATH' ) || exit;

/**
 * Renders the Overview tab.
 */
class Overview_Tab {

	/**
	 * Settings.
	 *
	 * @var Repository
	 */
	private $settings;

	/**
	 * ACTIVE DEFENSE tab (for its state).
	 *
	 * @var Defense_Tab
	 */
	private $defense;

	/**
	 * RECON tab (for its state and Run scan form).
	 *
	 * @var Recon_Tab
	 */
	private $recon;

	/**
	 * Check log.
	 *
	 * @var Store
	 */
	private $log;

	/**
	 * Demo test panel.
	 *
	 * @var Demo_Panel
	 */
	private $demo;

	/**
	 * Constructor.
	 *
	 * @param Repository  $settings Settings.
	 * @param Defense_Tab $defense  ACTIVE DEFENSE tab.
	 * @param Recon_Tab   $recon    RECON tab.
	 * @param Store       $log      Check log.
	 * @param Demo_Panel  $demo     Demo panel.
	 */
	public function __construct( Repository $settings, Defense_Tab $defense, Recon_Tab $recon, Store $log, Demo_Panel $demo ) {
		$this->settings = $settings;
		$this->defense  = $defense;
		$this->recon    = $recon;
		$this->log      = $log;
		$this->demo     = $demo;
	}

	/**
	 * One card.
	 *
	 * @param string $name    Service name.
	 * @param string $sub     Description line.
	 * @param string $pill    Pill HTML.
	 * @param string $body    Escaped body HTML.
	 * @param string $meta    Escaped meta HTML ('' for none).
	 * @param string $buttons Escaped buttons HTML.
	 * @return void
	 */
	private function card( $name, $sub, $pill, $body, $meta, $buttons, $dim = false ) {
		echo '<section class="fflfw-card' . ( $dim ? ' fflfw-card--dim' : '' ) . '">';
		if ( 'RECON' === $name ) {
			echo Ui::bonus_tag(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in Ui.
		}
		echo '<div class="fflfw-card__top">' . self::glyph( $name ) . '<div><h3 class="fflfw-card__name">' . esc_html( $name ) . '</h3><p class="fflfw-card__sub">' . esc_html( $sub ) . '</p></div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- glyph() is a fixed SVG.
		echo '<div class="fflfw-card__state">' . $pill . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped by the caller.
		echo '<div class="fflfw-card__body">' . $body . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped by the caller.
		if ( '' !== $meta ) {
			echo '<div class="fflfw-card__meta">' . $meta . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped by the caller.
		}
		echo '<div class="fflfw-card__actions">' . $buttons . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped by the caller.
		echo '</section>';
	}

	/**
	 * Service glyph (Brandy's v3 mocks). Decorative, so it is hidden from screen readers.
	 *
	 * @param string $name Service name.
	 * @return string
	 */
	private static function glyph( $name ) {
		$ink = '#E4E4E7';
		$red = '#E53E3E';
		if ( 'ACTIVE DEFENSE' === $name ) {
			$g = '<path d="M48 8 L84 21 V46 C84 68 68 82 48 90 C28 82 12 68 12 46 V21 Z" fill="none" stroke="' . $ink . '" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/><path d="M26 50 H70" stroke="' . $red . '" stroke-width="5" stroke-linecap="round"/><path d="M26 38 H70 M26 62 H70" stroke="' . $ink . '" stroke-width="2" opacity=".35"/>';
		} elseif ( 'OVERWATCH' === $name ) {
			$g = '<circle cx="48" cy="48" r="38" fill="none" stroke="' . $ink . '" stroke-width="5"/><circle cx="48" cy="48" r="20" fill="none" stroke="' . $ink . '" stroke-width="3" opacity=".6"/><path d="M48 48 L48 10 A38 38 0 0 1 75 21 Z" fill="' . $red . '" opacity=".85"/><path d="M48 48 L48 10" stroke="' . $red . '" stroke-width="4" stroke-linecap="round"/><circle cx="48" cy="48" r="4" fill="' . $ink . '"/><circle cx="30" cy="66" r="4" fill="' . $ink . '" opacity=".8"/>';
		} else {
			$g = '<circle cx="48" cy="48" r="36" fill="none" stroke="' . $ink . '" stroke-width="5"/><circle cx="48" cy="48" r="22" fill="none" stroke="' . $ink . '" stroke-width="3" opacity=".6"/><circle cx="48" cy="48" r="6" fill="' . $red . '"/><path d="M33 30 A24 24 0 0 1 44 25" stroke="' . $ink . '" stroke-width="3" fill="none" stroke-linecap="round" opacity=".8"/>';
		}
		return '<svg class="fflfw-card__glyph" width="44" height="44" viewBox="0 0 96 96" aria-hidden="true" focusable="false">' . $g . '</svg>';
	}

	/**
	 * Link styled as a button.
	 *
	 * @param string $label   Label.
	 * @param string $url     Address.
	 * @param string $variant 'primary' (red) or 'ghost'.
	 * @return string
	 */
	private function button( $label, $url, $variant = 'ghost' ) {
		return '<a class="fflfw-btn fflfw-btn--' . esc_attr( $variant ) . '" href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>';
	}

	/**
	 * "Needs a license" box for a locked card.
	 *
	 * @return string
	 */
	private function needs_license() {
		return '<div class="fflfw-needs"><strong>' . esc_html__( 'Needs a license.', 'ffl-firewall' ) . '</strong> ' . esc_html__( 'Add your FFL Firewall license ($79/month) to use this service.', 'ffl-firewall' ) . '</div>';
	}

	/**
	 * Render the tab.
	 *
	 * @return void
	 */
	public function render() {
		$licensed = 'active' === $this->settings->license_status();
		$no_key   = $this->demo->no_key();
		$license  = Page::url( 'license' );

		echo '<div class="fflfw-overview">';
		echo '<h2 class="fflfw-overview__title">' . esc_html__( "Your store's services", 'ffl-firewall' ) . '</h2>';
		if ( $licensed ) {
			echo '<p class="fflfw-settings__intro">' . esc_html__( "OVERWATCH checks every cart against the shipping ZIP at checkout, ACTIVE DEFENSE is on by default and watches for bots and scrapers once your license is active and the dealer embed script has been seen on your store in the last 24 hours, and RECON reports come included as a bonus. Each card shows where a service stands right now, and its button takes you to that service's settings.", 'ffl-firewall' ) . '</p>';
		} elseif ( $no_key ) {
			echo '<p class="fflfw-settings__intro">' . esc_html__( "This site doesn't have an FFL Firewall license yet, so the plugin is in demo mode. One license at $79 a month unlocks OVERWATCH checks on real carts, ACTIVE DEFENSE and the bonus RECON reports, and the only tool open in demo mode is the OVERWATCH Test a check below.", 'ffl-firewall' ) . '</p>';
		} elseif ( 'unknown' === $this->settings->license_status() ) {
			echo '<p class="fflfw-settings__intro">' . esc_html__( "The plugin couldn't reach the license server just now, so it's running in demo mode until it can check your FFL Firewall license again. It retries on its own; if this notice stays up, re-enter your license on the License tab or write to support@coriolisagency.com.", 'ffl-firewall' ) . '</p>';
		} else {
			echo '<p class="fflfw-settings__intro">' . esc_html__( "Your FFL Firewall license isn't active right now, so the plugin has gone back to demo mode. Renew or re-enter your license ($79 a month) to turn FFL\u{00A0}Firewall\u{00A0}·\u{00A0}OVERWATCH checks on real carts, FFL\u{00A0}Firewall\u{00A0}·\u{00A0}ACTIVE\u{00A0}DEFENSE and the bonus FFL\u{00A0}Firewall\u{00A0}·\u{00A0}RECON reports back on; until then, the only tool open is the OVERWATCH Test a check below.", 'ffl-firewall' ) . '</p>';
		}

		echo '<div class="fflfw-cards">';
		$this->card_overwatch( $licensed );
		$this->card_defense( $licensed, $license );
		$this->card_recon( $licensed, $license );
		echo '</div>';

		if ( $licensed ) {
			echo '<p class="fflfw-callout"><strong>' . esc_html__( 'Your plan is $79 a month.', 'ffl-firewall' ) . '</strong> ' . esc_html__( 'It covers unlimited OVERWATCH transactions, every service on this page and every feature we add later, and the price stays the same whether or not ACTIVE DEFENSE is on.', 'ffl-firewall' ) . '</p>';
		} else {
			echo '<div class="fflfw-panel fflfw-demo-card">';
			echo '<div class="fflfw-row"><div class="fflfw-row__label">' . esc_html( \FFL_Firewall\Demo\Strings::get( 't.label' ) ) . '</div><div class="fflfw-row__field">' . $this->demo->panel_html() . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts.
			echo '</div>';
			echo $this->demo->form_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts.
			echo '<p class="fflfw-callout"><strong>' . esc_html__( 'Add a license to unlock FFL Firewall.', 'ffl-firewall' ) . '</strong> ' . esc_html__( 'The plan is $79 a month and covers unlimited OVERWATCH transactions, ACTIVE DEFENSE, RECON reports and every feature we add later.', 'ffl-firewall' ) . ' ' . $this->button( __( 'Add license', 'ffl-firewall' ), $license, 'primary' ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped parts.
		}
		echo '</div>';
	}

	/**
	 * ACTIVE DEFENSE card.
	 *
	 * @param bool   $licensed Whether the license is active.
	 * @param string $license  License tab address.
	 * @return void
	 */
	private function card_defense( $licensed, $license ) {
		$name = 'ACTIVE DEFENSE';
		$sub  = __( 'Always-on bot and scraper control', 'ffl-firewall' );
		$tab  = Page::url( 'active-defense' );
		if ( ! $licensed ) {
			$this->card(
				$name,
				$sub,
				Ui::pill( __( 'Locked', 'ffl-firewall' ) ),
				'<p>' . esc_html__( 'Blocks and throttles bots and scrapers, and needs an active license before it starts keeping them off your store.', 'ffl-firewall' ) . '</p>' . $this->needs_license(),
				'',
				$this->button( __( 'Add license', 'ffl-firewall' ), $license, 'primary' ),
				true
			);
			return;
		}
		if ( $this->defense->is_active() ) {
			$this->card(
				$name,
				$sub,
				Ui::pill( __( 'Active', 'ffl-firewall' ), 'on' ),
				'<p>' . esc_html__( 'The dealer embed script was spotted within the past day, so rate limits, user agent and header checks, honeypots, checkout velocity and card-testing checks and the datacenter IP block list are running on your store.', 'ffl-firewall' ) . '</p>',
				'<p>' . esc_html__( 'Script last seen:', 'ffl-firewall' ) . ' <strong>' . esc_html( $this->defense->last_seen_value() ) . '</strong></p>',
				$this->button( __( 'Manage', 'ffl-firewall' ), $tab, 'ghost' )
			);
			return;
		}
		$this->card(
			$name,
			$sub,
			Ui::pill( __( 'Off', 'ffl-firewall' ) ),
			'<p>' . esc_html__( 'FFL Firewall · ACTIVE DEFENSE switches on when you install the plugin, and with an active license the plugin connects the site key and adds the dealer embed script for you. It starts keeping bots and scrapers off your store once the script has been seen on your store in the last 24 hours. You can switch it off from the ACTIVE DEFENSE tab.', 'ffl-firewall' ) . '</p>',
			'<p><strong>' . esc_html__( 'Not detected in the last 24 hours', 'ffl-firewall' ) . '</strong><br />' . esc_html__( 'Script last seen:', 'ffl-firewall' ) . ' <strong>' . esc_html( $this->defense->last_seen_value() ) . '</strong></p>',
			$this->button( __( 'Manage', 'ffl-firewall' ), $tab, 'primary' )
		);
	}

	/**
	 * OVERWATCH card.
	 *
	 * @param bool $licensed Whether the license is active.
	 * @return void
	 */
	private function card_overwatch( $licensed ) {
		$name = 'OVERWATCH';
		$sub  = __( 'State shipping checks', 'ffl-firewall' );
		if ( ! $licensed ) {
			$this->card(
				$name,
				$sub,
				Ui::pill( __( 'Demo', 'ffl-firewall' ) ),
				'<p>' . esc_html__( "Without a license, nothing is removed from a cart. If the switch is on, orders go through with a Flagged label and a note that the items weren't checked.", 'ffl-firewall' ) . '</p><p>' . esc_html__( 'You can still try one product and one ZIP with Test a check below.', 'ffl-firewall' ) . '</p>',
				'<p>' . esc_html__( 'Checks on real carts start once you add a license.', 'ffl-firewall' ) . '</p>',
				$this->button( __( 'Go to Test a check', 'ffl-firewall' ), '#fflfw-test-panel', 'ghost' )
			);
			return;
		}
		$on = $this->settings->checks_active();
		$this->card(
			$name,
			$sub,
			Ui::pill( $on ? __( 'On', 'ffl-firewall' ) : __( 'Off', 'ffl-firewall' ), $on ? 'on' : 'off' ),
			'<p>' . esc_html__( "Your checkout compares every item's UPC with the buyer's shipping ZIP, which helps you catch products that can't go to that address.", 'ffl-firewall' ) . '</p>',
			'<p>' . esc_html__( 'Flagged orders to review:', 'ffl-firewall' ) . ' <strong>' . esc_html( (string) $this->log->flagged_last_week() ) . '</strong> &middot; ' . esc_html__( 'Unlimited transactions on your plan', 'ffl-firewall' ) . '</p>',
			$this->button( __( 'Settings', 'ffl-firewall' ), Page::url( 'overwatch' ), 'ghost' ) . ' ' . $this->button( __( 'View log', 'ffl-firewall' ), Page::url( 'log' ), 'ghost' )
		);
	}

	/**
	 * RECON card.
	 *
	 * @param bool   $licensed Whether the license is active.
	 * @param string $license  License tab address.
	 * @return void
	 */
	private function card_recon( $licensed, $license ) {
		$name = 'RECON';
		$sub  = __( 'Store hardening report', 'ffl-firewall' );
		if ( ! $licensed ) {
			$this->card(
				$name,
				$sub,
				Ui::pill( __( 'Locked', 'ffl-firewall' ) ),
				'<p>' . esc_html__( 'Weekly and on-demand reports that compare your plugins, themes and core with WordPress.org and look for configuration gaps, with no automatic fixes.', 'ffl-firewall' ) . '</p>' . $this->needs_license(),
				'',
				$this->button( __( 'Add license', 'ffl-firewall' ), $license, 'primary' ),
				true
			);
			return;
		}
		$buttons = $this->recon->run_form_html();
		if ( $this->recon->has_report() ) {
			$buttons .= ' ' . $this->button( __( 'View report', 'ffl-firewall' ), Page::url( 'recon' ), 'ghost' );
		}
		$this->card(
			$name,
			$sub,
			Ui::pill( __( 'Ready', 'ffl-firewall' ) ),
			'<p>' . esc_html__( 'Weekly and on-demand reports on WordPress.org versions for your plugins, themes and core, plus configuration gaps. It reports only and makes no automatic fixes.', 'ffl-firewall' ) . '</p>',
			'<p>' . esc_html__( 'Last scan:', 'ffl-firewall' ) . ' <strong>' . esc_html( $this->recon->last_scan_text() ) . '</strong><br />' . esc_html__( 'Next weekly scan:', 'ffl-firewall' ) . ' <strong>' . esc_html( $this->recon->next_scan_text() ) . '</strong></p>',
			$buttons
		);
	}
}
