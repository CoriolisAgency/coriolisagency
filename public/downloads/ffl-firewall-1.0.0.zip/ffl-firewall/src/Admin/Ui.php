<?php
/**
 * Small shared pieces of the admin screen: the state pill and the service heading card.
 *
 * Only an "on" state is green. Every other state (off, locked, demo) is plain grey.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Markup helpers. Every method returns escaped HTML.
 */
class Ui {

	/**
	 * State pill.
	 *
	 * @param string $text Label.
	 * @param string $kind 'on' (green) or 'off' (grey).
	 * @return string
	 */
	public static function pill( $text, $kind = 'off' ) {
		$kind = 'on' === $kind ? 'on' : 'off';
		$mark = 'on' === $kind ? '<span aria-hidden="true">&#10003;</span>' : '';
		return '<span class="fflfw-state fflfw-state--' . esc_attr( $kind ) . '">' . $mark . esc_html( $text ) . '</span>';
	}

	/**
	 * The green "Included bonus" tag (RECON). Positioned by its container.
	 *
	 * @return string
	 */
	public static function bonus_tag() {
		return '<span class="fflfw-card__tag">' . esc_html__( 'Included bonus', 'ffl-firewall' ) . '</span>';
	}

	/**
	 * Service heading card (name, one-line description, state pill).
	 *
	 * @param string $name Service name.
	 * @param string $sub  Description.
	 * @param string $pill Pill HTML from pill().
	 * @return string
	 */
	public static function head( $name, $sub, $pill = '' ) {
		$html  = '<div class="fflfw-service-head"><div>';
		$html .= '<h2 class="fflfw-service-head__name">' . esc_html( $name ) . '</h2>';
		$html .= '<p class="fflfw-service-head__sub">' . esc_html( $sub ) . '</p></div>';
		$html .= $pill . '</div>'; // Pill markup is already escaped.
		return $html;
	}
}
