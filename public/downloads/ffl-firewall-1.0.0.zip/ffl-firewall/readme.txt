=== FFL Firewall ===
Contributors: coriolisagency
Tags: woocommerce, checkout, ffl
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Checks cart UPCs against the buyer's zip at checkout, stops bots and scrapers, and scans your store for waiting updates. Built for FFLs.

== Description ==

FFL Firewall is a WooCommerce plugin for independent FFL dealers. It runs three services from one admin screen: FFL Firewall · OVERWATCH checks the products in each cart against the buyer's zip at checkout, FFL Firewall · ACTIVE DEFENSE keeps bots and scrapers off your store, and FFL Firewall · RECON scans the site for waiting updates and setup gaps.

= FFL Firewall · OVERWATCH =

At checkout (classic and block checkout both), OVERWATCH sends the UPCs in the cart and the shipping zip, or the billing zip when there's no shipping zip, to the Coriolis proxy in one call. Local pickup orders are skipped. Depending on what comes back for each product, the plugin removes the item from the cart with a message to the shopper, shows a notice with a checkbox the shopper has to tick, or adds a note to the order; age notes go in the order note. Items the check marks as roster items follow the roster setting you choose, which starts as allow and flag.

If the check can't finish (a timeout, a product with no UPC, or a license that isn't active), the order goes through and the plugin flags it with an order note and a Flagged label in Orders, so nothing gets stuck at checkout. The plugin doesn't email anyone when it flags an order. OVERWATCH is off when you install it, real carts are checked only with an active license, and licensed stores have no limit on checks. Before you add a license, the test panel lets you run 10 sample checks on a single UPC and zip.

FFL Firewall is a tool to help you catch restricted items at checkout; you're still responsible for what you sell and ship, and you should review every order before it goes out.

= FFL Firewall · ACTIVE DEFENSE =

ACTIVE DEFENSE starts working once three things are true: the master switch is on (it switches on when you install the plugin), your license is active, and the dealer embed script has been seen on your store in the last 24 hours. It then runs these checks on the store:

* A rate limit (120 page requests per 60 seconds by default), after which a visitor gets a 429 response.
* User agent and header checks. Search engines (Google, Bing, Apple, DuckDuckGo, Yandex, Baidu, Yahoo and Petal) and the Ahrefs and Semrush SEO crawlers skip every FFL Firewall · ACTIVE DEFENSE check once FFL Firewall verifies them against their published IP ranges or by DNS; a request that only borrows a crawler's name gets no pass. Link previewers skip the header check only.
* A hidden honeypot field on classic checkout, registration and comment forms.
* Checkout and card-testing limits: 8 checkout attempts in 10 minutes, 3 failed payments in an hour, or 3 small orders in 15 minutes. Verified search and SEO crawlers are exempt from these limits and from the checkout honeypot.
* A datacenter address check, on by default. Once a day, your store downloads the IPv4 lists that DigitalOcean, Linode and Vultr publish for their own networks and keeps the last good copy of each, so it makes outbound requests to those providers' public feeds. Requests from those IPv4 ranges are blocked on store pages and when checkout is submitted, including through the Store API; page requests on cart, checkout, My Account, wp-admin (including admin-ajax), wp-login.php and the WooCommerce AJAX and API endpoints (wc-ajax, wc-api and /wp-json/wc/, which includes the Store API) are exempt, and checkout submit also keeps the card-testing, checkout velocity and honeypot checks above. If a download fails, the last good list keeps blocking for up to 3 days; nobody is blocked if a provider's list has never downloaded or is more than 3 days old.

Auto-block uses the behavior signals from the dealer embed script and steps up from a 429, to a browser check, to timed 403 responses.

The shared reputation feed lets FFL Firewall stores warn each other about bots. Your store reports the bots it catches (as hashes of their IP addresses, IPv6 networks and user agents, made with one salt shared by every FFL Firewall store, never raw IP addresses) and receives a signed list of bots other stores have reported; there's no receive-only mode, so sharing and receiving go together. On a new install with an active license, the feed is on by default, and a store that already had FFL Firewall keeps the feed setting it had; if it never made a choice, the feed stays off until someone switches it on. You can switch it on or off in the Shared reputation feed section of the FFL Firewall · ACTIVE DEFENSE tab. The feed never touches checkout, login, the cart, My Account or wp-admin; on your other pages, a visitor on the list is slowed after 10 requests a minute. If the feed stops someone it shouldn't have, a store manager can click "Not a bot" to unblock them and send Coriolis a review request with a short note.

Signed-in store managers and private network addresses are never limited, and any error in ACTIVE DEFENSE lets the request through instead of blocking it.

= FFL Firewall · RECON =

RECON is a read-only scan that ranks what it finds: WordPress, plugin and theme updates that are waiting (read from WordPress's own update data) and setup gaps such as missing https, debug output left on, or file editing still enabled in wp-admin. It changes nothing on your site, and it needs an active license. It also matches your installed plugins against known plugin vulnerabilities, and can only match issues that the feed has published.

= Price and license =

FFL Firewall costs $79 a month, billed monthly in advance by card through Stripe Checkout, with no trial period. You can cancel at any time, and the checks keep running until the end of the month you've paid for. The FFL Firewall terms page at coriolisagency.com has the full billing and cancelling terms.

= Downloads and updates =

FFL Firewall is a direct download from coriolisagency.com, and updates arrive through WordPress's normal plugin update screen from Coriolis's GitHub releases.

== External services ==

FFL Firewall connects to the outside services below. Each one is listed with what it's for, what is sent, and when.

= Coriolis proxy (Coriolis, LLC) =

The plugin's checks run through a proxy that Coriolis, LLC operates at ffl-firewall-proxy.vercel.app. A site owner can point the plugin at a different address with the FFLFW_PROXY_URL constant or the fflfw_proxy_url filter. The plugin calls it in these cases:

* License check (/api/license): when you click Check key, and on automatic rechecks while the license status is unknown (after 5 minutes, 15 minutes and 1 hour, then every 6 hours). Sends the license key; gets back the license status.
* Cart check (/api/check): at each checkout once the zip is known, while FFL Firewall · OVERWATCH is on and the license is active. Sends the license key, the zip and the UPCs in the cart; gets back a result for each UPC.
* Test panel (/api/demo): each time you run a test check before adding a license. Sends one UPC, one zip and the site address; gets back the result and the number of test runs left.
* Embed check (/api/embed-seen): every hour while the dealer embed script is added, when you save the setting, and when you click Check for script. Sends the license key, the dealer site key and the site origin; gets back whether the script was seen, the script address, and the behavior signals that auto-block uses: hashes of visitors' IP addresses, networks and browser fingerprints made with a salt specific to your store, an unsalted hash of their user agent, and that salt.
* Reputation feed (/api/reputation/feed): every 30 minutes while FFL Firewall · ACTIVE DEFENSE and the shared reputation feed are on and the license is active. Sends the license key and the sharing setting; gets back a signed list of hashed entries and the salt used to make them.
* Reputation reports (/api/reputation/report): every 15 minutes, from a buffer. Sends the license key, hashed subjects (a sha256 of the salt, the kind of subject and its value; never raw IP addresses), and any "Not a bot" review requests with the store manager's note. Gets back an accept or a retry.

Terms: https://www.coriolisagency.com/ffl-firewall/terms
Privacy: https://www.coriolisagency.com/privacy

= Dealer embed script (Coriolis, LLC) =

While FFL Firewall · ACTIVE DEFENSE is on and a site key is saved, the plugin adds the dealer embed script to every page of the store. The script loads from gunsearchengine.com (/embed.js, at an address the Coriolis proxy supplies), which is operated by Coriolis, LLC, and runs in shoppers' browsers. Each browser connects to gunsearchengine.com directly, so it receives the shopper's IP address, and the script sends the address, title and first referrer of each page viewed, campaign tags and the products viewed; gunsearchengine.com keeps a visitor record with those pages and products, an order number when one appears in a page address, any email address the shopper enters in the dealer search, such as to get results by email, set a watch or sign in, the browser, operating system, language, time zone, device type and touch screen, whether the visitor interacted with the page and how long they stayed, the approximate city and other technical signals about the visit, plus hashes of the IP address, network, browser fingerprint and user agent, but not the raw IP address or full user agent. Visitor records, including that email address, are kept with no set deletion period. A shopper's details go only to the store they contacted and are never sold or shared with third parties.

Terms: https://www.coriolisagency.com/ffl-firewall/terms
Privacy: https://gunsearchengine.com/privacy

= Your store's home page =

When you click Check for script, the plugin requests your own store's home page to see whether the script tag is there. Nothing is sent to anyone else.

= GitHub (GitHub, Inc.) =

Updates come from Coriolis's public release repository, CoriolisAgency/ffl-firewall-releases, on api.github.com and github.com. During WordPress's normal plugin update checks, the plugin asks GitHub for the latest release; the answer is cached for 12 hours (1 hour if the check fails). It sends only a User-Agent of ffl-firewall/ and the plugin version, with no token and no site data, and gets back the latest version number and the zip address.

Terms: https://docs.github.com/en/site-policy/github-terms/github-terms-of-service
Privacy: https://docs.github.com/en/site-policy/privacy-policies/github-general-privacy-statement

Never sent anywhere: the product-check vendor key (it stays on the proxy), raw shopper IP addresses, and card or order contents beyond the cart UPCs and zip.

== Changelog ==

= 1.0.0 =
* New: FFL Firewall · ACTIVE DEFENSE is on by default, with a notice after install that explains what it sends and a Switch off ACTIVE DEFENSE link. The consent checkbox is gone.
* New: FFL Firewall · RECON, powered by Wordfence, lists known plugin vulnerabilities with affected versions, the fixed version and a View record link. It sends the names and versions of your installed plugins to the Coriolis server and needs an ACTIVE DEFENSE site key.
* New: the datacenter address check downloads the IPv4 lists that DigitalOcean, Linode and Vultr publish once a day and keeps the last good copy of each. These are outbound requests from your store to those providers' public feeds. The check runs on store pages and at checkout submit, but not on page requests to cart, checkout, My Account, wp-admin (including admin-ajax), wp-login.php and the WooCommerce AJAX and API endpoints (wc-ajax, wc-api and /wp-json/wc/, which includes the Store API). If a download fails, the last good list keeps blocking for up to 3 days; nobody is blocked if a provider's list has never downloaded or is more than 3 days old.
* Changed: the user agent and header check, the rate limit and the datacenter list skip page requests to cart, checkout, My Account, wp-admin (including admin-ajax), wp-login.php and the WooCommerce AJAX and API endpoints (wc-ajax, wc-api and /wp-json/wc/, which includes the Store API). When checkout is submitted, including through the Store API, the datacenter check and the card-testing, checkout velocity and honeypot checks still run.
* Changed: the ACTIVE DEFENSE site key is requested automatically, once after activation and again when an automatic license recheck finds the license active, with retries after 5 minutes, 15 minutes, 1 hour and then every 6 hours.
* Fixed: the consent, shared reputation feed and readme text now describe what the dealer embed script and the shared reputation feed send and keep, and how long feed records are kept.
* Changed: the FFL Firewall · RECON section of this readme now says RECON matches your installed plugins against known plugin vulnerabilities, and can only match issues that the feed has published. The earlier line that said the known-issue list was not part of 1.0.0 is gone.
* Changed: the ACTIVE DEFENSE tab and Overview now describe FFL Firewall · ACTIVE DEFENSE as on by default, with a switch you can turn off.

= 1.0.0 =
* New: three services in one plugin, FFL Firewall · OVERWATCH, FFL Firewall · ACTIVE DEFENSE and FFL Firewall · RECON, with a new admin layout and an Overview tab.
* New: FFL Firewall · ACTIVE DEFENSE bot and scraper control, with rate limits, user agent and header checks, a checkout honeypot, and checkout and card-testing limits. Verified search engines and the Ahrefs and Semrush SEO crawlers now skip every FFL Firewall · ACTIVE DEFENSE check, and a license whose monthly payment fails keeps working for 7 days.
* New: the dealer embed script and its seen-in-the-last-24-hours check, with guards against adding the script twice.
* New: auto-block from the dealer embed script's behavior signals, stepping up from a 429 to a browser check to timed 403s.
* New: the shared reputation feed, on by default for new installs, with a "Not a bot" button to unblock a visitor and send Coriolis a review request. The feed never touches checkout, login, the cart, My Account or wp-admin.
* New: FFL Firewall · RECON, a read-only scan for waiting updates and setup gaps.
* New: updates through WordPress's plugin update screen from GitHub releases, on by default.
* Changed: FFL Firewall · OVERWATCH is its own module, with no limit on checks for licensed stores.
* Fixed: the license is rechecked automatically when the proxy couldn't be reached.
* Fixed: a fingerprint value that was saved with extra slashes.
* Tested up to WordPress 7.1 and WooCommerce 11.3. Requires WordPress 6.5, PHP 7.4 and WooCommerce 9.2.

= 0.1.3 =
* Test panel wording updated: a result card for items that need a permit or age check, a card when this network has reached its daily test limit (with the runs your site has left), and a clearer card when a test can't reach the check service.
* A test that can't reach the check service doesn't count against your 10 test runs.
* The notice in the WordPress admin now says "Hide this notice".

= 0.1.2 =
* Test panel on the settings screen for sites with no active license: a UPC and a zip, suggested test pairs, 10 test runs per site.
* Notice in the WordPress admin while there is no active license.

= 0.1.1 =
* Default proxy URL set to production.

= 0.1.0 =
* Sprint 1 skeleton: settings screen, license key check and the proxy client. Not released.

== Upgrade Notice ==

= 1.0.0 =
FFL Firewall · ACTIVE DEFENSE is now on by default. A notice explains what it sends and has a one-click link to switch it off.
