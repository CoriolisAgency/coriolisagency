/* FFL Firewall settings screen. Progressive enhancement only: every control also works as a plain form post. */
( function () {
	'use strict';
	var reset = document.querySelector( '[data-fflfw-reset]' );
	if ( ! reset ) {
		return;
	}
	reset.addEventListener( 'click', function ( event ) {
		var fields = document.querySelectorAll( 'textarea[data-fflfw-default]' );
		if ( ! fields.length ) {
			return;
		}
		event.preventDefault();
		Array.prototype.forEach.call( fields, function ( field ) {
			field.value = field.getAttribute( 'data-fflfw-default' );
		} );
	} );
}() );

/* FFLFW-101-01: focus the title and trap Tab inside the first-open screen. No close or Esc. */
( function () {
	'use strict';
	var root = document.getElementById( 'fflfw-ad-ack' );
	if ( ! root ) {
		return;
	}
	var dialog = root.querySelector( '.fflfw-ad-ack__dialog' );
	if ( ! dialog ) {
		return;
	}
	var title = document.getElementById( 'fflfw-ad-ack-title' );
	if ( title && title.focus ) {
		title.focus();
	}
	function focusables() {
		return dialog.querySelectorAll( 'a[href], button, input, textarea, select, [tabindex]:not([tabindex="-1"])' );
	}
	dialog.addEventListener( 'keydown', function ( event ) {
		var key = event.key || event.code;
		if ( 'Tab' !== key && 9 !== event.keyCode ) {
			return;
		}
		var list = focusables();
		if ( ! list.length ) {
			return;
		}
		var first = list[0];
		var last = list[list.length - 1];
		if ( event.shiftKey ) {
			if ( document.activeElement === first || ! dialog.contains( document.activeElement ) ) {
				event.preventDefault();
				last.focus();
			}
		} else if ( document.activeElement === last ) {
			event.preventDefault();
			first.focus();
		}
	} );
}() );
