/* FFL Firewall, classic checkout. Shows "Checking your cart" while WooCommerce refreshes the order review
 * (the server runs the check then), and keeps Place Order disabled until the permit box is ticked.
 * WooCommerce skips a fragment when it matches the last response, so when the check result is unchanged
 * the notices slot is not replaced; the notices from before the refresh are put back instead.
 * Without JavaScript the server still enforces every rule on Place Order. */
jQuery( function ( $ ) {
	'use strict';
	var S = window.fflfwClassic || {};

	function esc( s ) {
		return $( '<div/>' ).text( s || '' ).html();
	}

	function zip() {
		var shipping = $( '#ship-to-different-address-checkbox' ).is( ':checked' );
		var v = String( ( shipping ? $( '#shipping_postcode' ).val() : '' ) || $( '#billing_postcode' ).val() || '' ).trim();
		return /^[0-9]{5}/.test( v );
	}

	function syncAck() {
		var box = $( '#fflfw_permit_ack' );
		$( '#place_order' ).prop( 'disabled', box.length ? ! box.is( ':checked' ) : false );
	}

	// Notices shown before the current refresh, put back if WooCommerce leaves the slot as it was.
	var before = '';

	$( document.body ).on( 'update_checkout', function () {
		if ( ! zip() ) {
			return;
		}
		var slot = $( '.fflfw-notices' );
		if ( ! slot.find( '.fflfw-notice--load' ).length ) {
			before = slot.html() || '';
		}
		slot.html(
			'<ul class="woocommerce-info fflfw-notice fflfw-notice--load" role="status"><li><strong>' + esc( S.ckTitle ) + '</strong><p>' + esc( S.ckBody ) + '</p></li></ul>'
		);
		$( '#place_order' ).prop( 'disabled', true );
	} );

	$( document.body ).on( 'updated_checkout', function () {
		var slot = $( '.fflfw-notices' );
		if ( slot.find( '.fflfw-notice--load' ).length ) {
			slot.html( before );
		}
		syncAck();
	} );
	$( document.body ).on( 'change', '#fflfw_permit_ack', syncAck );
} );
