<?php
/**
 * Turns one proxy answer into an action per cart line (pure PHP, no WordPress calls).
 *
 * Actions:
 *   remove - take the item out of the cart and show the item removed message.
 *   ffl    - CC: ship to an FFL or dealer only; show the info notice (never blocks the order).
 *   permit - BB, SHI, SCO, SNJ: show the notice and require the checkbox before Place Order.
 *   flag   - allow it and flag the order (order note plus Flagged label; the shopper sees nothing).
 *   ok     - nothing to do.
 * Age codes are collected for the order note whatever the action.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Overwatch\Rules;

use FFL_Firewall\Settings\Defaults;

defined( 'ABSPATH' ) || exit;

/**
 * Rules engine.
 */
class Engine {

	const REMOVE = 'remove';
	const FFL    = 'ffl';
	const PERMIT = 'permit';
	const FLAG   = 'flag';
	const OK     = 'ok';

	/**
	 * Ammo shipping codes that ship to the consumer only after a permit, license or age check.
	 *
	 * @var array<int, string>
	 */
	const PERMIT_CODES = array( 'BB', 'SHI', 'SCO', 'SNJ' );

	/**
	 * Evaluate cart lines against a proxy answer.
	 *
	 * @param array<string, array<string, mixed>> $lines       Line key => [ upc, name ].
	 * @param array<string, mixed>                $answer      Proxy /api/check answer (or a pass-with-flag answer).
	 * @param string                              $roster_rule Roster rule (remove | flag | allow).
	 * @return array<string, mixed> [ lines => key => [ action, reason, upc, name, age ], remove, ffl, permit, flag ]
	 */
	public static function evaluate( $lines, $answer, $roster_rule = Defaults::ROSTER_FLAG ) {
		$results  = isset( $answer['results'] ) && is_array( $answer['results'] ) ? $answer['results'] : array();
		$top_flag = isset( $answer['flag'] ) && is_string( $answer['flag'] ) ? $answer['flag'] : '';
		$license  = in_array( $top_flag, array( 'license_invalid', 'license_inactive' ), true );
		$out      = array(
			'lines'  => array(),
			'remove' => array(),
			'ffl'    => array(),
			'permit' => array(),
			'flag'   => array(),
		);

		foreach ( $lines as $key => $line ) {
			$upc  = isset( $line['upc'] ) ? (string) $line['upc'] : '';
			$name = isset( $line['name'] ) ? (string) $line['name'] : '';

			if ( '' === $upc ) {
				$decision = array( self::FLAG, 'no_upc', '' );
			} elseif ( $license ) {
				$decision = array( self::FLAG, $top_flag, '' );
			} elseif ( ! isset( $results[ $upc ] ) || ! is_array( $results[ $upc ] ) ) {
				$decision = array( self::FLAG, '' !== $top_flag ? $top_flag : 'unchecked', '' );
			} else {
				$decision = self::decide( $results[ $upc ], $roster_rule, $top_flag );
			}

			list( $action, $reason, $age ) = $decision;
			$out['lines'][ $key ]          = array(
				'action' => $action,
				'reason' => $reason,
				'upc'    => $upc,
				'name'   => $name,
				'age'    => $age,
			);
			if ( self::OK !== $action ) {
				$out[ $action ][] = $key;
			}
		}

		return $out;
	}

	/**
	 * Decide one normalized proxy result.
	 *
	 * @param array<string, mixed> $r           Result.
	 * @param string               $roster_rule Roster rule.
	 * @param string               $top_flag    Answer-level flag.
	 * @return array{0: string, 1: string, 2: string} [ action, reason, age code ]
	 */
	private static function decide( $r, $roster_rule, $top_flag ) {
		$status = isset( $r['status'] ) ? (string) $r['status'] : '';
		if ( 'not_found' === $status ) {
			return array( self::FLAG, 'code_5', '' );
		}
		if ( 'ok' !== $status ) {
			$reason = isset( $r['reason'] ) && '' !== (string) $r['reason'] ? (string) $r['reason'] : ( '' !== $top_flag ? $top_flag : 'unchecked' );
			return array( self::FLAG, $reason, '' );
		}

		$type        = isset( $r['type'] ) ? (string) $r['type'] : '';
		$restriction = isset( $r['restriction'] ) ? strtoupper( (string) $r['restriction'] ) : '';

		if ( 'firearm' === $type ) {
			switch ( $restriction ) {
				case '1':
					return array( self::OK, 'code_1', '' );
				case '2':
					return array( self::REMOVE, 'code_2', '' );
				case '3':
					if ( Defaults::ROSTER_REMOVE === $roster_rule ) {
						return array( self::REMOVE, 'code_3', '' );
					}
					if ( Defaults::ROSTER_ALLOW === $roster_rule ) {
						return array( self::OK, 'code_3', '' );
					}
					return array( self::FLAG, 'code_3', '' );
				default:
					return array( self::FLAG, 'unknown_code', '' );
			}
		}

		if ( 'ammo' === $type ) {
			$shipping = isset( $r['shipping'] ) ? strtoupper( (string) $r['shipping'] ) : '';
			$age      = isset( $r['age'] ) ? strtoupper( (string) $r['age'] ) : '';
			$age_note = 'FFF' === $age ? '' : $age;

			if ( 'A' === $restriction || 'FF' === $shipping || 'FFF' === $age ) {
				return array( self::REMOVE, 'ammo_' . ( 'A' === $restriction ? 'A' : ( 'FF' === $shipping ? 'FF' : 'FFF' ) ), '' );
			}
			if ( 'B' !== $restriction ) {
				return array( self::FLAG, 'unknown_code', $age_note );
			}
			if ( 'CC' === $shipping ) {
				return array( self::FFL, 'ammo_CC', $age_note );
			}
			if ( in_array( $shipping, self::PERMIT_CODES, true ) ) {
				return array( self::PERMIT, 'ammo_' . $shipping, $age_note );
			}
			if ( 'AA' === $shipping ) {
				return array( self::OK, 'ammo_AA', $age_note );
			}
			return array( self::FLAG, 'unknown_code', $age_note );
		}

		return array( self::FLAG, 'unknown_code', '' );
	}
}
