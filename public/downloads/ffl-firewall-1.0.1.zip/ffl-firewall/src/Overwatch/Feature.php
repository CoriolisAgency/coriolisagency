<?php
/**
 * FFL Firewall · OVERWATCH: the feature's name and its on / licensed state.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Overwatch;

use FFL_Firewall\Settings\Repository;

defined( 'ABSPATH' ) || exit;

/**
 * OVERWATCH is the UPC and ZIP check at checkout. It has its own master switch (the "enabled"
 * setting) and runs on real carts only with an active license. A licensed site has no
 * transaction limit: nothing here counts or caps checks. The only count in the plugin is the
 * unlicensed test panel's 10 runs per site, and the proxy keeps that.
 */
class Feature {

	const NAME  = "FFL\u{00A0}Firewall\u{00A0}·\u{00A0}OVERWATCH";
	const SHORT = 'OVERWATCH';

	/**
	 * Settings.
	 *
	 * @var Repository
	 */
	private $settings;

	/**
	 * Constructor.
	 *
	 * @param Repository $settings Settings.
	 */
	public function __construct( Repository $settings ) {
		$this->settings = $settings;
	}

	/**
	 * Whether the dealer switched OVERWATCH on.
	 *
	 * @return bool
	 */
	public function switched_on() {
		return (bool) $this->settings->get( 'enabled', false );
	}

	/**
	 * Whether the site's license is active.
	 *
	 * @return bool
	 */
	public function licensed() {
		return 'active' === $this->settings->license_status();
	}

	/**
	 * Whether OVERWATCH checks real carts: switched on with an active license.
	 *
	 * @return bool
	 */
	public function running() {
		return $this->settings->checks_active();
	}
}