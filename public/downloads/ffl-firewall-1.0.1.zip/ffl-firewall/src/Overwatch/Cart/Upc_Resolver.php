<?php
/**
 * Finds a product's UPC. Order (Paul, 1:04 PM ET 11/17): WooCommerce's native
 * GTIN/UPC field, then common UPC plugin meta keys, then product attributes
 * named UPC (read only), then the dealer's custom meta key from settings.
 * Each source is checked on a variation first, then on its parent.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Overwatch\Cart;

use FFL_Firewall\Settings\Repository;

defined( 'ABSPATH' ) || exit;

/**
 * UPC lookup.
 */
class Upc_Resolver {

	/**
	 * Meta keys used by common GTIN/UPC plugins, in lookup order.
	 *
	 * @var array<int, string>
	 */
	const META_KEYS = array( '_upc', 'upc', '_wpm_gtin_code', 'hwp_product_gtin', '_ts_gtin', '_alg_ean', '_gtin', 'gtin', '_barcode', 'barcode' );

	/**
	 * Attribute names read as a UPC (after dropping a pa_ prefix and lowercasing).
	 *
	 * @var array<int, string>
	 */
	const ATTRIBUTE_NAMES = array( 'upc', 'upc-code', 'upc_code', 'upccode', 'gtin', 'upc-gtin' );

	/**
	 * Settings.
	 *
	 * @var Repository|null
	 */
	private $settings;

	/**
	 * Constructor.
	 *
	 * @param Repository|null $settings Settings (for the custom meta key).
	 */
	public function __construct( $settings = null ) {
		$this->settings = $settings instanceof Repository ? $settings : null;
	}

	/**
	 * Normalize a raw value to 8 to 14 digits, or ''.
	 *
	 * @param mixed $raw Raw value.
	 * @return string
	 */
	public static function normalize( $raw ) {
		if ( is_array( $raw ) ) {
			$raw = reset( $raw );
		}
		if ( ! is_scalar( $raw ) ) {
			return '';
		}
		$digits = preg_replace( '/[\s\-]/', '', trim( (string) $raw ) );
		return preg_match( '/^[0-9]{8,14}$/', (string) $digits ) ? (string) $digits : '';
	}

	/**
	 * Resolve a product's UPC.
	 *
	 * @param \WC_Product|object $product Product (or variation).
	 * @return string UPC digits, or '' when none is found.
	 */
	public function resolve( $product ) {
		$chain  = array( $product );
		$parent = $this->parent_of( $product );
		if ( $parent ) {
			$chain[] = $parent;
		}

		$upc = '';
		foreach ( array( 'native', 'meta', 'attribute', 'custom' ) as $source ) {
			foreach ( $chain as $item ) {
				$upc = $this->from_source( $source, $item );
				if ( '' !== $upc ) {
					break 2;
				}
			}
		}

		$filtered = function_exists( 'apply_filters' ) ? apply_filters( 'fflfw_product_upc', $upc, $product ) : $upc;
		return self::normalize( $filtered );
	}

	/**
	 * Parent product of a variation, if any.
	 *
	 * @param object $product Product.
	 * @return object|null
	 */
	private function parent_of( $product ) {
		if ( ! is_object( $product ) || ! method_exists( $product, 'get_parent_id' ) ) {
			return null;
		}
		$parent_id = (int) $product->get_parent_id();
		if ( $parent_id <= 0 || ! function_exists( 'wc_get_product' ) ) {
			return null;
		}
		$parent = wc_get_product( $parent_id );
		return is_object( $parent ) ? $parent : null;
	}

	/**
	 * One lookup source.
	 *
	 * @param string $source  Source name.
	 * @param object $product Product.
	 * @return string
	 */
	private function from_source( $source, $product ) {
		if ( ! is_object( $product ) ) {
			return '';
		}
		switch ( $source ) {
			case 'native':
				return method_exists( $product, 'get_global_unique_id' ) ? self::normalize( $product->get_global_unique_id() ) : '';
			case 'meta':
				foreach ( self::META_KEYS as $key ) {
					$upc = self::normalize( $this->meta( $product, $key ) );
					if ( '' !== $upc ) {
						return $upc;
					}
				}
				return '';
			case 'attribute':
				return $this->from_attributes( $product );
			case 'custom':
				$key = $this->settings ? (string) $this->settings->get( 'upc_meta_key', '' ) : '';
				return '' === $key ? '' : self::normalize( $this->meta( $product, $key ) );
		}
		return '';
	}

	/**
	 * Read product meta.
	 *
	 * @param object $product Product.
	 * @param string $key     Meta key.
	 * @return mixed
	 */
	private function meta( $product, $key ) {
		return method_exists( $product, 'get_meta' ) ? $product->get_meta( $key, true ) : '';
	}

	/**
	 * UPC from product attributes named UPC (read only).
	 *
	 * @param object $product Product.
	 * @return string
	 */
	private function from_attributes( $product ) {
		if ( ! method_exists( $product, 'get_attributes' ) ) {
			return '';
		}
		foreach ( (array) $product->get_attributes() as $name => $attribute ) {
			$label = strtolower( (string) $name );
			$label = 0 === strpos( $label, 'pa_' ) ? substr( $label, 3 ) : $label;
			if ( ! in_array( $label, self::ATTRIBUTE_NAMES, true ) ) {
				continue;
			}
			$values = array();
			if ( is_object( $attribute ) && method_exists( $attribute, 'is_taxonomy' ) ) {
				if ( $attribute->is_taxonomy() && function_exists( 'wc_get_product_terms' ) && method_exists( $product, 'get_id' ) ) {
					$values = wc_get_product_terms( $product->get_id(), $attribute->get_name(), array( 'fields' => 'names' ) );
				} elseif ( method_exists( $attribute, 'get_options' ) ) {
					$values = $attribute->get_options();
				}
			} else {
				$values = array( $attribute );
			}
			foreach ( (array) $values as $value ) {
				$upc = self::normalize( $value );
				if ( '' !== $upc ) {
					return $upc;
				}
			}
		}
		return '';
	}
}
