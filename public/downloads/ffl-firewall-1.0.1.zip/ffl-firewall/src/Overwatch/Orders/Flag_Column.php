<?php
/**
 * Flagged label in WooCommerce > Orders (HPOS and legacy list). No email is sent for a flag.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Overwatch\Orders;

use FFL_Firewall\Overwatch\Checkout\Service;

defined( 'ABSPATH' ) || exit;

/**
 * Orders list column.
 */
class Flag_Column {

	const COLUMN = 'fflfw_flag';

	/**
	 * Hook both orders list screens.
	 *
	 * @return void
	 */
	public function register() {
		add_filter( 'manage_woocommerce_page_wc-orders_columns', array( $this, 'columns' ) );
		add_action( 'manage_woocommerce_page_wc-orders_custom_column', array( $this, 'render_hpos' ), 10, 2 );
		add_filter( 'manage_edit-shop_order_columns', array( $this, 'columns' ) );
		add_action( 'manage_shop_order_posts_custom_column', array( $this, 'render_legacy' ), 10, 2 );
		add_action( 'admin_head', array( $this, 'style' ) );
	}

	/**
	 * Add the column after the status column.
	 *
	 * @param array<string, string> $columns Columns.
	 * @return array<string, string>
	 */
	public function columns( $columns ) {
		$out = array();
		foreach ( $columns as $key => $label ) {
			$out[ $key ] = $label;
			if ( 'order_status' === $key ) {
				$out[ self::COLUMN ] = __( "FFL\u{00A0}Firewall\u{00A0}·\u{00A0}OVERWATCH", 'ffl-firewall' );
			}
		}
		if ( ! isset( $out[ self::COLUMN ] ) ) {
			$out[ self::COLUMN ] = __( "FFL\u{00A0}Firewall\u{00A0}·\u{00A0}OVERWATCH", 'ffl-firewall' );
		}
		return $out;
	}

	/**
	 * Label HTML for an order.
	 *
	 * @param \WC_Order|null $order Order.
	 * @return string
	 */
	public static function label( $order ) {
		if ( ! is_object( $order ) || 'yes' !== $order->get_meta( Service::ORDER_FLAG_META, true ) ) {
			return '';
		}
		return '<mark class="order-status fflfw-flagged"><span>' . esc_html__( 'Flagged', 'ffl-firewall' ) . '</span></mark>';
	}

	/**
	 * HPOS list cell.
	 *
	 * @param string    $column Column.
	 * @param \WC_Order $order  Order.
	 * @return void
	 */
	public function render_hpos( $column, $order ) {
		if ( self::COLUMN === $column ) {
			echo wp_kses_post( self::label( $order ) );
		}
	}

	/**
	 * Legacy list cell.
	 *
	 * @param string $column  Column.
	 * @param int    $post_id Order ID.
	 * @return void
	 */
	public function render_legacy( $column, $post_id ) {
		if ( self::COLUMN === $column && function_exists( 'wc_get_order' ) ) {
			echo wp_kses_post( self::label( wc_get_order( $post_id ) ) );
		}
	}

	/**
	 * Label style.
	 *
	 * @return void
	 */
	public function style() {
		echo '<style>.fflfw-flagged{background:#fcf9e8;color:#4d3b00;border:1px solid #dba617}</style>';
	}
}
