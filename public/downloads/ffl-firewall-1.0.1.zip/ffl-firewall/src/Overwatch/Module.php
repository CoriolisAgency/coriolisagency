<?php
/**
 * FFL Firewall · OVERWATCH wiring: the cart check on classic and Blocks checkout, the order flag
 * and the UPC resolver, kept apart from ACTIVE DEFENSE.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Overwatch;

use FFL_Firewall\Log\Store;
use FFL_Firewall\Overwatch\Cart\Upc_Resolver;
use FFL_Firewall\Overwatch\Checkout\Block;
use FFL_Firewall\Overwatch\Checkout\Classic;
use FFL_Firewall\Overwatch\Checkout\Service;
use FFL_Firewall\Overwatch\Orders\Flag_Column;
use FFL_Firewall\Proxy\Client;
use FFL_Firewall\Settings\Repository;

defined( 'ABSPATH' ) || exit;

/**
 * Builds and registers OVERWATCH.
 */
class Module {

	/**
	 * Feature.
	 *
	 * @var Feature
	 */
	private $feature;

	/**
	 * Cart check service.
	 *
	 * @var Service
	 */
	private $service;

	/**
	 * UPC resolver.
	 *
	 * @var Upc_Resolver
	 */
	private $resolver;

	/**
	 * Constructor.
	 *
	 * @param Repository $settings Settings.
	 * @param Client     $client   Proxy client.
	 * @param Store      $log      Check log.
	 */
	public function __construct( Repository $settings, Client $client, Store $log ) {
		$this->feature  = new Feature( $settings );
		$this->resolver = new Upc_Resolver( $settings );
		$this->service  = new Service( $settings, $client, $log, $this->resolver );
	}

	/**
	 * Feature.
	 *
	 * @return Feature
	 */
	public function feature() {
		return $this->feature;
	}

	/**
	 * Cart check service.
	 *
	 * @return Service
	 */
	public function service() {
		return $this->service;
	}

	/**
	 * UPC resolver.
	 *
	 * @return Upc_Resolver
	 */
	public function resolver() {
		return $this->resolver;
	}

	/**
	 * Hook the checkout checks and the order flag column.
	 *
	 * @return void
	 */
	public function register() {
		( new Classic( $this->service ) )->register();
		( new Block( $this->service ) )->register();
		( new Flag_Column() )->register();
	}
}