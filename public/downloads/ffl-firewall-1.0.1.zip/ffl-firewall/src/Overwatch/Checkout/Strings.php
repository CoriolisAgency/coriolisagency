<?php
/**
 * Shopper strings shared with the checkout scripts (Brandy's copy).
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Overwatch\Checkout;

defined( 'ABSPATH' ) || exit;

/**
 * Strings.
 */
class Strings {

	/**
	 * Checking-your-cart strings.
	 *
	 * @return array<string, string>
	 */
	public static function checking() {
		return array(
			'ckTitle' => __( 'Checking your cart', 'ffl-firewall' ),
			'ckBody'  => __( "We're checking each item against the zip code you entered. Your order stays as it is unless an item can't ship there.", 'ffl-firewall' ),
			'ckItem'  => __( 'Checking', 'ffl-firewall' ),
		);
	}

	/**
	 * Every shopper string the block checkout script renders.
	 *
	 * @return array<string, string>
	 */
	public static function block() {
		return array_merge(
			self::checking(),
			array(
				'rmTitle'   => __( "An item in your cart can't ship to your zip", 'ffl-firewall' ),
				'rmMore'    => __( 'If you think this is a mistake, contact us before you place your order.', 'ffl-firewall' ),
				'fflTitle'  => __( 'This item ships to an FFL or dealer only', 'ffl-firewall' ),
				'fflBadge'  => __( 'Ships to an FFL or dealer only', 'ffl-firewall' ),
				'pmTitle'   => __( 'This item needs a permit or age check', 'ffl-firewall' ),
				'pmBadge'   => __( 'Needs a permit or age check', 'ffl-firewall' ),
				'pmAck'     => __( "I understand this item won't ship until the permit or age check is done.", 'ffl-firewall' ),
				'pmReq'     => __( 'Tick the box above to place your order.', 'ffl-firewall' ),
				'required'  => __( 'required', 'ffl-firewall' ),
			)
		);
	}
}
