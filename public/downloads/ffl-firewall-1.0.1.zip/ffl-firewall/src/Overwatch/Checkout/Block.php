<?php
/**
 * Block checkout (Store API): the checkout script asks for a check through
 * the cart extensions endpoint once the zip is known and whenever it changes, the cart response
 * carries the result for the script to render, and Place Order enforces the
 * rules again on the server.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Overwatch\Checkout;

use FFL_Firewall\Overwatch\Rules\Engine;

defined( 'ABSPATH' ) || exit;

/**
 * Block checkout integration.
 */
class Block {

	const NS = 'fflfw';

	/**
	 * Service.
	 *
	 * @var Service
	 */
	private $service;

	/**
	 * Optional environment factory (tests).
	 *
	 * @var callable|null
	 */
	private $env_factory;

	/**
	 * Constructor.
	 *
	 * @param Service       $service     Service.
	 * @param callable|null $env_factory Optional environment factory (tests).
	 */
	public function __construct( Service $service, $env_factory = null ) {
		$this->service     = $service;
		$this->env_factory = is_callable( $env_factory ) ? $env_factory : null;
	}

	/**
	 * Checkout environment (WooCommerce, or a test double from the factory).
	 *
	 * @param array<string, mixed> $overrides Request overrides.
	 * @return Environment
	 */
	private function env( $overrides = array() ) {
		return $this->env_factory ? call_user_func( $this->env_factory, $overrides ) : new Woo_Environment( $overrides );
	}

	/**
	 * Hook the Store API and the checkout script.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'woocommerce_blocks_loaded', array( $this, 'register_store_api' ) );
		add_action( 'woocommerce_store_api_cart_update_customer_from_request', array( $this, 'on_customer_update' ), 20 );
		add_action( 'woocommerce_store_api_checkout_update_order_from_request', array( $this, 'validate' ), 20, 2 );
		add_action( 'woocommerce_store_api_checkout_order_processed', array( $this, 'order_processed' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ) );
	}

	/**
	 * Cart extension data plus the update callback the script calls.
	 *
	 * @return void
	 */
	public function register_store_api() {
		if ( function_exists( 'woocommerce_store_api_register_endpoint_data' ) ) {
			woocommerce_store_api_register_endpoint_data(
				array(
					'endpoint'        => 'cart',
					'namespace'       => self::NS,
					'data_callback'   => array( $this, 'cart_data' ),
					'schema_callback' => array( $this, 'cart_schema' ),
					'schema_type'     => ARRAY_A,
				)
			);
		}
		if ( function_exists( 'woocommerce_store_api_register_update_callback' ) ) {
			woocommerce_store_api_register_update_callback(
				array(
					'namespace' => self::NS,
					'callback'  => array( $this, 'on_extension_update' ),
				)
			);
		}
	}

	/**
	 * Cart extension schema.
	 *
	 * @return array<string, mixed>
	 */
	public function cart_schema() {
		return array(
			'status'  => array( 'type' => 'string', 'readonly' => true ),
			'zip'     => array( 'type' => 'string', 'readonly' => true ),
			'notices' => array( 'type' => 'array', 'readonly' => true ),
			'badges'  => array( 'type' => 'object', 'readonly' => true ),
			'permit'  => array( 'type' => 'boolean', 'readonly' => true ),
			'acked'   => array( 'type' => 'boolean', 'readonly' => true ),
		);
	}

	/**
	 * Cart extension data: the notices and badges to show, and whether the permit checkbox is needed.
	 *
	 * @return array<string, mixed>
	 */
	public function cart_data() {
		$env     = $this->env();
		$state   = $this->service->state( $env );
		$notices = array();
		$badges  = array();

		foreach ( $this->service->take_removed( $env, false ) as $removed ) {
			$notices[] = array(
				'type' => 'removed',
				'body' => $this->service->message( 'removed', $removed['product'], $removed['zip'] ),
			);
		}
		$permit = false;
		if ( ! empty( $state['status'] ) && 'checked' === $state['status'] ) {
			foreach ( Service::lines_with( $state, Engine::FFL ) as $key => $line ) {
				$notices[]      = array(
					'type' => 'ffl',
					'body' => $this->service->message( 'ffl', $line['name'], $state['zip'], $state['state'] ),
				);
				$badges[ $key ] = 'ffl';
			}
			foreach ( Service::lines_with( $state, Engine::PERMIT ) as $key => $line ) {
				$notices[]      = array(
					'type' => 'permit',
					'body' => $this->service->message( 'permit', $line['name'], $state['zip'], $state['state'] ),
				);
				$badges[ $key ] = 'permit';
				$permit         = true;
			}
		}

		return array(
			'status'  => isset( $state['status'] ) ? (string) $state['status'] : '',
			'zip'     => isset( $state['zip'] ) ? (string) $state['zip'] : '',
			'notices' => $notices,
			'badges'  => (object) $badges,
			'permit'  => $permit,
			'acked'   => $this->service->permit_acked( $env ),
		);
	}

	/**
	 * Script-triggered update: run the check, record the checkbox, or clear shown removal notices.
	 *
	 * @param array<string, mixed> $data Data from the script.
	 * @return void
	 */
	public function on_extension_update( $data ) {
		$data      = is_array( $data ) ? $data : array();
		$overrides = array();
		// The script sends the zip it sees, since the address it just typed may not be saved yet.
		// Place Order re-runs the check against the saved address either way.
		$zip = isset( $data['zip'] ) ? Service::zip5( sanitize_text_field( (string) $data['zip'] ) ) : '';
		if ( '' !== $zip ) {
			$overrides['shipping_postcode'] = $zip;
			$overrides['shipping_state']    = isset( $data['state'] ) ? strtoupper( substr( preg_replace( '/[^A-Za-z]/', '', (string) $data['state'] ), 0, 3 ) ) : '';
		}
		$env = $this->env( $overrides );
		if ( isset( $data['permit_ack'] ) ) {
			$this->service->set_permit_ack( $env, (bool) $data['permit_ack'] );
		}
		if ( ! empty( $data['seen_removed'] ) ) {
			$this->service->take_removed( $env, true );
		}
		if ( ! empty( $data['check'] ) ) {
			$this->service->evaluate( $env );
		}
	}

	/**
	 * Address saved through the Store API (the checkout pushes it as the shopper types):
	 * run the check, so the cart in the same response already has the result.
	 *
	 * @return void
	 */
	public function on_customer_update() {
		$this->service->evaluate( $this->env() );
	}

	/**
	 * Place Order: re-run the check and enforce the rules; a removed item or an unticked permit box stops the order.
	 *
	 * @param \WC_Order        $order   Order.
	 * @param \WP_REST_Request $request Request.
	 * @return void
	 * @throws \Automattic\WooCommerce\StoreApi\Exceptions\RouteException When a rule blocks the order.
	 */
	public function validate( $order, $request = null ) {
		unset( $order, $request );
		$env   = $this->env();
		$state = $this->service->evaluate( $env );
		if ( empty( $state['status'] ) || 'checked' !== $state['status'] ) {
			return;
		}
		// FFL-only (CC) items show the info notice only and never block the order (Paul, 1:51 PM ET).
		$errors = $this->service->place_order_errors( $state, $this->service->permit_acked( $env ) );
		$fail   = empty( $errors ) ? '' : $errors[0];
		if ( '' !== $fail && class_exists( '\Automattic\WooCommerce\StoreApi\Exceptions\RouteException' ) ) {
			throw new \Automattic\WooCommerce\StoreApi\Exceptions\RouteException( 'fflfw_blocked', esc_html( $fail ), 400 );
		}
	}

	/**
	 * Order placed: flag it and add the notes.
	 *
	 * @param \WC_Order $order Order.
	 * @return void
	 */
	public function order_processed( $order ) {
		$env = $this->env();
		$this->service->apply_to_order( $order, $this->service->state( $env ) );
		$this->service->set_permit_ack( $env, false );
		$this->service->take_removed( $env, true );
	}

	/**
	 * Block checkout script and styles.
	 *
	 * @return void
	 */
	public function enqueue() {
		if ( ! function_exists( 'is_checkout' ) || ! is_checkout() ) {
			return;
		}
		$url = defined( 'FFLFW_URL' ) ? FFLFW_URL : '';
		$ver = defined( 'FFLFW_VERSION' ) ? FFLFW_VERSION : '0.0.0';
		wp_enqueue_style( 'fflfw-checkout', $url . 'assets/css/checkout.css', array(), $ver );
		wp_enqueue_script( 'fflfw-checkout-block', $url . 'assets/js/checkout-block.js', array( 'wp-data', 'wc-blocks-checkout' ), $ver, true );
		wp_localize_script( 'fflfw-checkout-block', 'fflfwBlock', Strings::block() );
	}
}
