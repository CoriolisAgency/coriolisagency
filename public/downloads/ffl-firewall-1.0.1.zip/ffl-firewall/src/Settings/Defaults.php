<?php
/**
 * Default settings and the default shopper messages (copy from Brandy's mockups v1).
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Default values.
 */
class Defaults {

	const ROSTER_REMOVE = 'remove';
	const ROSTER_FLAG   = 'flag';
	const ROSTER_ALLOW  = 'allow';

	/**
	 * Default shopper messages, keyed by message slot.
	 *
	 * @return array<string, string>
	 */
	public static function messages() {
		return array(
			'removed' => __( "We took {product} out of your cart because it can't ship to zip {zip}. The rest of your order is still here, and you can keep checking out.", 'ffl-firewall' ),
			'ffl'     => __( "For zip {zip}, we can ship {product} to a licensed firearms dealer (FFL) but not to your home address. Choose your dealer in the FFL dealer selection on this page, and you'll pick it up there.", 'ffl-firewall' ),
			'permit'  => __( "For zip {zip}, we need a permit or age check before {product} can ship. After you place your order, we'll contact you to confirm it, and the item ships once that's done. You don't need to upload anything at checkout.", 'ffl-firewall' ),
		);
	}

	/**
	 * Full default settings.
	 *
	 * Checks start off; the roster default is "Allow it and flag the order" (Paul's call).
	 *
	 * @return array<string, mixed>
	 */
	public static function settings() {
		return array(
			'enabled'      => false,
			'license_key'  => '',
			'roster_rule'  => self::ROSTER_FLAG,
			'upc_meta_key' => '',
			'messages'     => self::messages(),
		);
	}

	/**
	 * Allowed roster rules.
	 *
	 * @return array<int, string>
	 */
	public static function roster_rules() {
		return array( self::ROSTER_REMOVE, self::ROSTER_FLAG, self::ROSTER_ALLOW );
	}
}
