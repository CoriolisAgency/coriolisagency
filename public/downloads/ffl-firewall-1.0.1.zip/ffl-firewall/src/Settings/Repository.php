<?php
/**
 * Settings storage (one option) and the cached license status.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Reads, sanitizes and saves the fflfw_settings option.
 */
class Repository {

	const OPTION         = 'fflfw_settings';
	const LICENSE_STATUS = 'fflfw_license_status';

	/**
	 * Current settings merged over defaults.
	 *
	 * @return array<string, mixed>
	 */
	public function all() {
		$stored   = get_option( self::OPTION, array() );
		$stored   = is_array( $stored ) ? $stored : array();
		$defaults = Defaults::settings();
		$merged   = array_merge( $defaults, $stored );

		$messages           = isset( $stored['messages'] ) && is_array( $stored['messages'] ) ? $stored['messages'] : array();
		$merged['messages'] = array_merge( $defaults['messages'], $messages );

		return $merged;
	}

	/**
	 * One setting.
	 *
	 * @param string $key     Setting key.
	 * @param mixed  $fallback Fallback value.
	 * @return mixed
	 */
	public function get( $key, $fallback = null ) {
		$all = $this->all();
		return array_key_exists( $key, $all ) ? $all[ $key ] : $fallback;
	}

	/**
	 * Sanitize raw form input into a settings array.
	 *
	 * @param array<string, mixed> $raw Unslashed request input.
	 * @return array<string, mixed>
	 */
	public function sanitize( $raw ) {
		$raw      = is_array( $raw ) ? $raw : array();
		$defaults = Defaults::settings();
		$out      = array();

		$out['enabled'] = ! empty( $raw['enabled'] );

		$key                = isset( $raw['license_key'] ) ? (string) $raw['license_key'] : '';
		$key                = strtoupper( preg_replace( '/[^A-Za-z0-9-]/', '', $key ) );
		$out['license_key'] = substr( $key, 0, 64 );

		$rule               = isset( $raw['roster_rule'] ) ? (string) $raw['roster_rule'] : '';
		$out['roster_rule'] = in_array( $rule, Defaults::roster_rules(), true ) ? $rule : $defaults['roster_rule'];

		$meta                = isset( $raw['upc_meta_key'] ) ? (string) $raw['upc_meta_key'] : '';
		$out['upc_meta_key'] = substr( preg_replace( '/[^A-Za-z0-9_\-]/', '', $meta ), 0, 100 );

		$out['messages'] = array();
		$messages        = isset( $raw['messages'] ) && is_array( $raw['messages'] ) ? $raw['messages'] : array();
		foreach ( $defaults['messages'] as $slot => $default ) {
			$text                     = isset( $messages[ $slot ] ) ? sanitize_textarea_field( (string) $messages[ $slot ] ) : '';
			$out['messages'][ $slot ] = '' === trim( $text ) ? $default : $text;
		}

		return $out;
	}

	/**
	 * Save sanitized settings.
	 *
	 * @param array<string, mixed> $settings Sanitized settings.
	 * @return void
	 */
	public function save( $settings ) {
		update_option( self::OPTION, $settings, false );
	}

	/**
	 * Last known license status: 'active', 'inactive', 'invalid' or '' (never checked).
	 *
	 * @return string
	 */
	public function license_status() {
		$status = get_option( self::LICENSE_STATUS, '' );
		return is_string( $status ) ? $status : '';
	}

	/**
	 * Store the license status from the proxy.
	 *
	 * @param string $status Status.
	 * @return void
	 */
	public function set_license_status( $status ) {
		$status = in_array( $status, array( 'active', 'inactive', 'invalid', 'unknown' ), true ) ? $status : 'unknown';
		update_option( self::LICENSE_STATUS, $status, false );
	}

	/**
	 * Whether shopper checks should run. Off, or a key that isn't active, means checkout passes.
	 *
	 * @return bool
	 */
	public function checks_active() {
		return (bool) $this->get( 'enabled', false ) && 'active' === $this->license_status();
	}
}
