<?php
/**
 * Automatic license recheck while the stored status is 'unknown' (proxy was unreachable).
 *
 * Backoff 5 min, 15 min, 1 h, then every 6 h. It only ever runs for 'unknown': a successful
 * answer writes the real status, an unreachable proxy keeps 'unknown'. It is started and kept
 * alive from admin pages and WP-Cron, never from a front-end request, and every attempt runs
 * inside a WP-Cron event so no admin page waits on the proxy.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Settings;

use FFL_Firewall\Proxy\Client;

defined( 'ABSPATH' ) || exit;

/**
 * Schedules and runs the recheck.
 */
class License_Recheck {

	const CRON   = 'fflfw_license_recheck';
	const OPTION = 'fflfw_license_recheck';

	/**
	 * Seconds to wait after attempt 0, 1, 2; the last value repeats.
	 *
	 * @var int[]
	 */
	const STEPS = array( 300, 900, 3600, 21600 );

	/**
	 * Clock override for tests.
	 *
	 * @var int|null
	 */
	public static $now = null;

	/**
	 * Settings.
	 *
	 * @var Repository
	 */
	private $settings;

	/**
	 * Proxy client.
	 *
	 * @var Client
	 */
	private $client;

	/**
	 * Constructor.
	 *
	 * @param Repository $settings Settings.
	 * @param Client     $client   Proxy client.
	 */
	public function __construct( Repository $settings, Client $client ) {
		$this->settings = $settings;
		$this->client   = $client;
	}

	/**
	 * Hooks: the cron callback (any request type, WP-Cron fires it) and admin pages only for scheduling.
	 *
	 * @return void
	 */
	public function register() {
		add_action( self::CRON, array( $this, 'run' ) );
		add_action( 'admin_init', array( $this, 'ensure' ) );
	}

	/**
	 * Current time.
	 *
	 * @return int
	 */
	private static function now() {
		return null !== self::$now ? (int) self::$now : time();
	}

	/**
	 * Seconds to wait after the given number of finished attempts.
	 *
	 * @param int $attempts Attempts so far.
	 * @return int
	 */
	public static function delay( $attempts ) {
		$i = max( 0, min( (int) $attempts, count( self::STEPS ) - 1 ) );
		return self::STEPS[ $i ];
	}

	/**
	 * Stored state: attempts so far and the earliest time of the next attempt.
	 *
	 * @return array<string, int>
	 */
	public static function state() {
		$s = get_option( self::OPTION, array() );
		$s = is_array( $s ) ? $s : array();
		return array(
			'attempts' => isset( $s['attempts'] ) ? max( 0, (int) $s['attempts'] ) : 0,
			'next_at'  => isset( $s['next_at'] ) ? (int) $s['next_at'] : 0,
		);
	}

	/**
	 * Whether a recheck applies: a key is saved and the status is 'unknown'.
	 *
	 * @return bool
	 */
	private function applies() {
		return 'unknown' === $this->settings->license_status() && '' !== (string) $this->settings->get( 'license_key', '' );
	}

	/**
	 * Forget the schedule and the state.
	 *
	 * @return void
	 */
	public static function clear() {
		wp_clear_scheduled_hook( self::CRON );
		delete_option( self::OPTION );
	}

	/**
	 * Deactivation: no event left behind.
	 *
	 * @return void
	 */
	public static function deactivate() {
		self::clear();
	}

	/**
	 * Start over (the key was just saved or checked and came back 'unknown').
	 *
	 * @return void
	 */
	public function restart() {
		self::clear();
		$this->ensure();
	}

	/**
	 * Keep one event scheduled while the status is 'unknown', and none otherwise.
	 *
	 * @return void
	 */
	public function ensure() {
		try {
			if ( ! $this->applies() ) {
				if ( false !== wp_next_scheduled( self::CRON ) || array() !== get_option( self::OPTION, array() ) ) {
					self::clear();
				}
				return;
			}
			$state = get_option( self::OPTION, null );
			if ( ! is_array( $state ) ) {
				$state = array(
					'attempts' => 0,
					'next_at'  => self::now() + self::delay( 0 ),
				);
				update_option( self::OPTION, $state, false );
			}
			if ( ! wp_next_scheduled( self::CRON ) ) {
				wp_schedule_single_event( max( self::now(), self::state()['next_at'] ), self::CRON );
			}
		} catch ( \Throwable $e ) {
			return;
		}
	}

	/**
	 * FFLFW-SITEKEY-PROVISION-FIX: the license just turned active here, so bind the ACTIVE DEFENSE site key
	 * when the service is on and there is no key (the same helper the dealer's save uses). Fails open.
	 *
	 * @return void
	 */
	private function provision_key() {
		try {
			$config = new \FFL_Firewall\Defense\Config();
			( new \FFL_Firewall\Defense\Provision( $this->client, $this->settings ) )->ensure_key( $config, new \FFL_Firewall\Defense\Embed( $config ), true );
		} catch ( \Throwable $e ) {
			return;
		}
	}

	/**
	 * One recheck (cron). Returns what happened: 'skipped', 'early', 'active', 'inactive', 'invalid' or 'unknown'.
	 *
	 * @return string
	 */
	public function run() {
		try {
			if ( ! $this->applies() ) {
				self::clear();
				return 'skipped';
			}
			$state = self::state();
			$now   = self::now();
			if ( $now < $state['next_at'] ) {
				wp_clear_scheduled_hook( self::CRON );
				wp_schedule_single_event( $state['next_at'], self::CRON );
				return 'early';
			}
			// Claim this attempt first, so an error or a slow answer never causes a quick repeat.
			$next = $now + self::delay( $state['attempts'] + 1 );
			update_option(
				self::OPTION,
				array(
					'attempts' => $state['attempts'] + 1,
					'next_at'  => $next,
				),
				false
			);
			$key    = (string) $this->settings->get( 'license_key', '' );
			$status = $this->client->license_status( $key );
			// Only write when nothing changed while the proxy was answering.
			if ( in_array( $status, array( 'active', 'inactive', 'invalid' ), true ) && $this->applies() && (string) $this->settings->get( 'license_key', '' ) === $key ) {
				$this->settings->set_license_status( $status );
				self::clear();
				if ( 'active' === $status ) {
					$this->provision_key();
				}
				return $status;
			}
		} catch ( \Throwable $e ) {
			$next = self::now() + self::delay( self::state()['attempts'] );
		}
		if ( $this->applies() ) {
			$next = isset( $next ) ? $next : self::now() + self::delay( 0 );
			wp_clear_scheduled_hook( self::CRON );
			wp_schedule_single_event( $next, self::CRON );
		}
		return 'unknown';
	}
}