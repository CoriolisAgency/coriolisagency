<?php
/**
 * FFLFW-AD-AUTOBLOCK strings. AD-AB-01 to 04 and 06 to 27 ship verbatim from
 * FINAL-autoblock-copy-2026-11-25.md, CLEARED by Karp 9:06 AM ET 2026-11-25.
 * AD-AB-05 is unchanged (cleared by Karp 12:18 PM ET 23 Nov 2026, FFLFW-CRAWLER-GRACE).
 * The {visitor} token in unblocked_notice() is filled by Defense_Tab.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Auto-block strings.
 */
class Autoblock_Copy {

	/**
	 * AD-AB-01 Panel heading.
	 *
	 * @return string
	 */
	public static function heading() {
		return __( 'Auto-block', 'ffl-firewall' );
	}

	/**
	 * AD-AB-02 Pill while auto-block is running.
	 *
	 * @return string
	 */
	public static function pill_on() {
		return __( 'On', 'ffl-firewall' );
	}

	/**
	 * AD-AB-03 Pill when the dealer turned auto-block off.
	 *
	 * @return string
	 */
	public static function pill_off() {
		return __( 'Off', 'ffl-firewall' );
	}

	/**
	 * AD-AB-04 Pill when ACTIVE DEFENSE is not active (switch on, but nothing runs).
	 *
	 * @return string
	 */
	public static function pill_waiting() {
		return __( 'Waiting for ACTIVE DEFENSE', 'ffl-firewall' );
	}

	/**
	 * AD-AB-05 Intro: what auto-block does. Brandy's copy, cleared by Karp 2026-11-23 12:18 PM ET (FFLFW-CRAWLER-GRACE).
	 *
	 * @return string
	 */
	public static function intro() {
		return __( 'Auto-block skips search and SEO crawlers it has verified, along with your cart, checkout, account and admin pages.', 'ffl-firewall' );
	}

	/**
	 * AD-AB-06 Counts row label: throttled this month.
	 *
	 * @return string
	 */
	public static function count_throttle() {
		return __( 'Slowed down this month', 'ffl-firewall' );
	}

	/**
	 * AD-AB-07 Counts row label: challenged this month.
	 *
	 * @return string
	 */
	public static function count_challenge() {
		return __( 'Browser checks this month', 'ffl-firewall' );
	}

	/**
	 * AD-AB-08 Counts row label: blocked this month.
	 *
	 * @return string
	 */
	public static function count_block() {
		return __( 'Blocked this month', 'ffl-firewall' );
	}

	/**
	 * AD-AB-09 Off switch label.
	 *
	 * @return string
	 */
	public static function toggle() {
		return __( 'Keep auto-block on', 'ffl-firewall' );
	}

	/**
	 * AD-AB-10 Help under the switch: what turning it off does.
	 *
	 * @return string
	 */
	public static function toggle_help() {
		return __( 'Turning this off stops all automatic slowing, browser checks and blocks right away. Your other ACTIVE DEFENSE checks keep running.', 'ffl-firewall' );
	}

	/**
	 * AD-AB-11 Save button.
	 *
	 * @return string
	 */
	public static function save() {
		return __( 'Save auto-block setting', 'ffl-firewall' );
	}

	/**
	 * AD-AB-12 Heading over the list of blocks in force.
	 *
	 * @return string
	 */
	public static function list_heading() {
		return __( 'Blocked right now', 'ffl-firewall' );
	}

	/**
	 * AD-AB-13 Empty list.
	 *
	 * @return string
	 */
	public static function list_empty() {
		return __( 'Nothing is blocked right now.', 'ffl-firewall' );
	}

	/**
	 * AD-AB-14 Column: last source address.
	 *
	 * @return string
	 */
	public static function col_visitor() {
		return __( 'Source address', 'ffl-firewall' );
	}

	/**
	 * AD-AB-15 Column: matched signal type.
	 *
	 * @return string
	 */
	public static function col_signal() {
		return __( 'Matched by', 'ffl-firewall' );
	}

	/**
	 * AD-AB-16 Column: when the block ends.
	 *
	 * @return string
	 */
	public static function col_until() {
		return __( 'Block ends', 'ffl-firewall' );
	}

	/**
	 * AD-AB-17 Unblock button on one row.
	 *
	 * @return string
	 */
	public static function unblock() {
		return __( 'Unblock', 'ffl-firewall' );
	}

	/**
	 * AD-AB-18 Notice after an unblock. {visitor} is the row's source address.
	 *
	 * @return string
	 */
	public static function unblocked_notice() {
		return __( '{visitor} is unblocked on your store now, and auto-block won\'t act on that match again for 30 days.', 'ffl-firewall' );
	}

	/**
	 * AD-AB-19 to AD-AB-22 Signal type names for the "Matched by" column.
	 *
	 * @return array<string, string>
	 */
	public static function kinds() {
		return array(
			'ip'  => __( 'IP address', 'ffl-firewall' ),
			'net' => __( 'Network', 'ffl-firewall' ),
			'fp'  => __( 'Browser fingerprint', 'ffl-firewall' ),
			'ua'  => __( 'User agent', 'ffl-firewall' ),
		);
	}

	/**
	 * AD-AB-23 Countermeasure name in Recent activity and the monthly panel row.
	 *
	 * @return string
	 */
	public static function countermeasure() {
		return __( 'Auto-block', 'ffl-firewall' );
	}

	/**
	 * AD-AB-24 Recent activity action word for a browser check.
	 *
	 * @return string
	 */
	public static function action_challenge() {
		return __( 'Sent to a browser check', 'ffl-firewall' );
	}

	/**
	 * AD-AB-25 Shopper-facing browser check page: title.
	 *
	 * @return string
	 */
	public static function challenge_title() {
		return __( 'One moment', 'ffl-firewall' );
	}

	/**
	 * AD-AB-26 Shopper-facing browser check page: body.
	 *
	 * @return string
	 */
	public static function challenge_body() {
		return __( 'Please wait. This page reloads by itself, and then you can continue.', 'ffl-firewall' );
	}

	/**
	 * AD-AB-27 Shopper-facing browser check page: shown without JavaScript.
	 *
	 * @return string
	 */
	public static function challenge_noscript() {
		return __( 'Turn on JavaScript in your browser, then reload this page to continue.', 'ffl-firewall' );
	}

	/**
	 * Every string, for the word guard test.
	 *
	 * @return array<int, string>
	 */
	public static function all() {
		return array_merge(
			array(
				self::heading(),
				self::pill_on(),
				self::pill_off(),
				self::pill_waiting(),
				self::intro(),
				self::count_throttle(),
				self::count_challenge(),
				self::count_block(),
				self::toggle(),
				self::toggle_help(),
				self::save(),
				self::list_heading(),
				self::list_empty(),
				self::col_visitor(),
				self::col_signal(),
				self::col_until(),
				self::unblock(),
				self::unblocked_notice(),
				self::countermeasure(),
				self::action_challenge(),
				self::challenge_title(),
				self::challenge_body(),
				self::challenge_noscript(),
			),
			array_values( self::kinds() )
		);
	}
}
