<?php
/**
 * WooCommerce > FFL Firewall > ACTIVE DEFENSE tab (Brandy's mockups A03 and A04, strings word for
 * word). Steps: switch the service on, paste the site key (with the data disclosure and its consent
 * box beside it), and the plugin adds the dealer embed script. Also carries the countermeasure list,
 * recent activity and the editable checkout block message.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Admin;

use FFL_Firewall\Defense\Activity_Log;
use FFL_Firewall\Defense\Auto_Block;
use FFL_Firewall\Defense\Config;
use FFL_Firewall\Defense\Consent;
use FFL_Firewall\Defense\Embed;
use FFL_Firewall\Defense\Feed_Optin;
use FFL_Firewall\Defense\Monthly;
use FFL_Firewall\Defense\Provision;
use FFL_Firewall\Defense\Proxy_Seen_Source;
use FFL_Firewall\Defense\Reputation_Buffer;
use FFL_Firewall\Defense\Reputation_Feed;
use FFL_Firewall\Defense\Reputation_Reporter;
use FFL_Firewall\Defense\Reputation_Unblocks;
use FFL_Firewall\Defense\Signal;
use FFL_Firewall\Proxy\Client;
use FFL_Firewall\Settings\Repository;

defined( 'ABSPATH' ) || exit;

/**
 * Renders the tab and handles its form posts.
 */
class Defense_Tab {

	const NONCE     = 'fflfw_defense';
	const MSG_NONCE = 'fflfw_defense_message';
	const FEED_NONCE = 'fflfw_reputation';
	const NAB_NONCE  = 'fflfw_not_a_bot';
	const AB_NONCE   = 'fflfw_ad_autoblock';
	const AB_UNBLOCK = 'fflfw_ad_unblock';
	/** Per-user flash for the auto-block unblock notice. */
	const AB_FLASH = 'fflfw_ab_';
	/** Per-user flash for the Not a bot result (S6F.9, S6F.10, S6F.11). */
	const NAB_FLASH = 'fflfw_nab_';

	/**
	 * Config.
	 *
	 * @var Config
	 */
	private $config;

	/**
	 * Embed.
	 *
	 * @var Embed
	 */
	private $embed;

	/**
	 * Signal.
	 *
	 * @var Signal
	 */
	private $signal;

	/**
	 * Consent record.
	 *
	 * @var Consent
	 */
	private $consent;

	/**
	 * Self-serve site key (FFLFW-ONBOARD-SITEKEY). Built on first use when not passed in.
	 *
	 * @var Provision|null
	 */
	private $provision;

	/**
	 * Constructor.
	 *
	 * @param Config         $config    Defense config.
	 * @param Embed          $embed     Embed.
	 * @param Signal         $signal    Signal.
	 * @param Provision|null $provision Self-serve site key.
	 */
	public function __construct( Config $config, Embed $embed, Signal $signal, $provision = null ) {
		$this->config    = $config;
		$this->embed     = $embed;
		$this->signal    = $signal;
		$this->consent   = new Consent();
		$this->provision = $provision instanceof Provision ? $provision : null;
	}

	/**
	 * Self-serve site key helper.
	 *
	 * @return Provision
	 */
	private function provision() {
		if ( null === $this->provision ) {
			$settings        = new Repository();
			$this->provision = new Provision( new Client( $settings ), $settings );
		}
		return $this->provision;
	}

	/**
	 * Default wiring for a Page built without one.
	 *
	 * @param Client $client Proxy client.
	 * @return Defense_Tab
	 */
	public static function make( Client $client ) {
		$config = new Config();
		$embed  = new Embed( $config );
		return new self( $config, $embed, new Signal( $embed, new Proxy_Seen_Source( $client ) ) );
	}

	/**
	 * Hook the form post.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_post_fflfw_save_defense', array( $this, 'handle_save' ) );
		add_action( 'admin_post_fflfw_save_defense_message', array( $this, 'handle_save_message' ) );
		add_action( 'admin_post_fflfw_save_reputation', array( $this, 'handle_save_feed' ) );
		add_action( 'admin_post_fflfw_not_a_bot', array( $this, 'handle_not_a_bot' ) );
		add_action( 'admin_post_fflfw_save_autoblock', array( $this, 'handle_save_autoblock' ) );
		add_action( 'admin_post_fflfw_ad_unblock', array( $this, 'handle_ad_unblock' ) );
	}

	/**
	 * Whether ACTIVE DEFENSE is running: switch on, license active, script seen in the last 24 hours.
	 *
	 * @return bool
	 */
	public function is_active() {
		return true === $this->config->get( 'enabled' )
			&& 'active' === ( new Repository() )->license_status()
			&& $this->signal->seen();
	}

	/**
	 * "Script last seen" value: the date and time, or Never.
	 *
	 * @return string
	 */
	public function last_seen_value() {
		$ts = $this->signal->last_seen();
		return $ts > 0 ? wp_date( 'M j, Y, g:i A T', $ts ) : __( 'Never', 'ffl-firewall' );
	}

	/**
	 * "Script last seen" line.
	 *
	 * @return string
	 */
	private function last_seen_line() {
		$ts = $this->signal->last_seen();
		/* translators: %s: date and time, or Never */
		return sprintf( __( 'Script last seen: %s', 'ffl-firewall' ), $ts > 0 ? wp_date( 'M j, Y, g:i A T', $ts ) : __( 'Never', 'ffl-firewall' ) );
	}

	/**
	 * Render the tab.
	 *
	 * @param string $url This tab's address (unused, kept for the form redirect).
	 * @return void
	 */
	public function render( $url = '' ) {
		$active = $this->is_active();
		echo '<div class="fflfw-defense">';
		if ( $this->embed->foreign_present() ) {
			echo '<div class="notice notice-info inline"><p>' . esc_html__( 'A dealer embed is already on this site; FFL Firewall will use it.', 'ffl-firewall' ) . '</p></div>';
			if ( $this->embed->key_mismatch() ) {
				echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'The dealer embed on this site uses a different site key than the one saved here. Update one so they match.', 'ffl-firewall' ) . '</p></div>';
			}
		}
		$licensed = 'active' === ( new Repository() )->license_status();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only notice flag.
		$flag = isset( $_GET['fflfw_notice'] ) ? sanitize_key( wp_unslash( $_GET['fflfw_notice'] ) ) : '';

		if ( $active ) {
			echo Ui::head( 'ACTIVE DEFENSE', __( 'Bot and scraper control', 'ffl-firewall' ), Ui::pill( __( 'Active · script seen in the last 24 hours', 'ffl-firewall' ), 'on' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in Ui.
			echo '<p class="fflfw-settings__intro">' . esc_html__( 'The plugin has seen the dealer embed script on your store in the last 24 hours, so ACTIVE DEFENSE is blocking and throttling bots and scrapers before they reach checkout. Your plan stays at $79 a month whether this service is on or off.', 'ffl-firewall' ) . '</p>';
		} else {
			echo Ui::head( 'ACTIVE DEFENSE', __( 'Bot and scraper control', 'ffl-firewall' ), Ui::pill( $licensed ? __( 'Off · not detected in the last 24 hours', 'ffl-firewall' ) : __( 'Locked', 'ffl-firewall' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in Ui.
			if ( $licensed ) {
				echo '<p class="fflfw-settings__intro">' . esc_html__( 'ACTIVE DEFENSE watches the traffic coming into your store, spots bots and scrapers, and blocks or throttles them before they reach checkout once your license is active and the dealer embed script has been seen on your store in the last 24 hours. Your plan costs $79 a month either way.', 'ffl-firewall' ) . '</p>';
			} else {
				echo '<p class="fflfw-settings__intro">' . esc_html__( 'Blocks and throttles bots and scrapers, and needs an active license before it starts keeping them off your store.', 'ffl-firewall' ) . '</p>';
				echo '<div class="fflfw-needs"><strong>' . esc_html__( 'Needs a license.', 'ffl-firewall' ) . '</strong> ' . esc_html__( 'Add your FFL Firewall license ($79/month) to use this service.', 'ffl-firewall' ) . ' <a class="fflfw-btn fflfw-btn--primary" href="' . esc_url( Page::url( 'license' ) ) . '">' . esc_html__( 'Add license', 'ffl-firewall' ) . '</a></div>';
			}
		}
		if ( ! $licensed ) {
			echo '</div>';
			return;
		}

		echo '<div class="fflfw-cols"><div class="fflfw-col">';
		$this->render_monthly( $active );
		$this->render_autoblock( $active );
		if ( $active ) {
			$this->render_activity();
		}
		$this->render_activate();
		$this->render_feed( $flag );
		$this->render_message_form();
		echo '</div><div class="fflfw-col">';
		$this->render_countermeasures( $active );
		echo '</div></div>';
		echo '</div>';
	}

	/**
	 * "Blocked or slowed down this month" panel (S6A). Local counts only; copy lives in Monthly_Copy.
	 *
	 * @param bool $active Whether ACTIVE DEFENSE is running.
	 * @return void
	 */
	private function render_monthly( $active ) {
		$now     = \FFL_Firewall\Defense\Counter::now();
		$sum     = ( new Monthly() )->summary( Monthly::month_key( $now ) );
		$feed_on = (bool) apply_filters( 'fflfw_reputation_feed_on', false );
		echo '<div class="fflfw-panel fflfw-panel--pad fflfw-monthly"><h2>' . esc_html( Monthly_Copy::title() ) . '</h2>';
		$sub = strtr(
			Monthly_Copy::subtitle(),
			array(
				'{month}' => wp_date( 'F', $now ),
				'{today}' => wp_date( 'j', $now ),
				'{year}'  => wp_date( 'Y', $now ),
			)
		);
		echo '<p class="fflfw-help fflfw-help--flush">' . esc_html( $sub ) . '</p>';
		if ( $sum['total'] < 1 ) {
			echo '<p class="fflfw-help">' . esc_html( $active ? Monthly_Copy::empty_on() : Monthly_Copy::empty_off() ) . '</p>';
		} else {
			echo '<p class="fflfw-monthly__total"><strong>' . esc_html( strtr( Monthly_Copy::total(), array( '{count}' => self::number( $sum['total'] ) ) ) ) . '</strong></p>';
			echo '<table class="widefat striped fflfw-monthly__table"><tbody>';
			foreach ( Monthly_Copy::rows() as $group => $label ) {
				if ( 'feed' === $group ) {
					$value = $feed_on ? self::number( $sum['feed'] ) : Monthly_Copy::feed_off();
					$hint  = $feed_on ? '' : '<span class="fflfw-monthly__hint">' . esc_html( Monthly_Copy::feed_off_hint() ) . '</span>';
					echo '<tr class="fflfw-monthly__feed"><th scope="row">' . esc_html( $label ) . $hint . '</th><td class="fflfw-monthly__n">' . esc_html( $value ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $hint is escaped above.
					continue;
				}
				echo '<tr><th scope="row">' . esc_html( $label ) . '</th><td class="fflfw-monthly__n">' . esc_html( self::number( $sum['groups'][ $group ] ) ) . '</td></tr>';
			}
			echo '</tbody></table>';
			echo '<p class="fflfw-help fflfw-monthly__foot">' . esc_html( Monthly_Copy::footnote() ) . '</p>';
		}
		echo '<details class="fflfw-monthly__help"><summary>' . esc_html( Monthly_Copy::help_link() ) . '</summary><p class="fflfw-help">' . esc_html( Monthly_Copy::help() ) . '</p></details>';
		echo '</div>';
	}

	/**
	 * Formatted count.
	 *
	 * @param int $n Count.
	 * @return string
	 */
	private static function number( $n ) {
		return function_exists( 'number_format_i18n' ) ? (string) number_format_i18n( (int) $n ) : number_format( (int) $n );
	}

	/**
	 * Recent activity table (Brandy's A04).
	 *
	 * @return void
	 */
	private function render_activity() {
		$rows = array_slice( ( new Activity_Log() )->rows(), 0, 5 );
		echo '<div class="fflfw-panel fflfw-panel--pad"><h2>' . esc_html__( 'Recent activity', 'ffl-firewall' ) . '</h2>';
		echo '<p class="fflfw-help fflfw-help--flush">' . esc_html__( 'Seen in the last 24 hours', 'ffl-firewall' ) . '</p>';
		echo '<p class="fflfw-help">' . esc_html( $this->last_seen_line() ) . '</p>';
		$this->render_nab_flash();
		if ( ! $rows ) {
			echo '<p class="fflfw-help">' . esc_html__( 'Nothing has been blocked or throttled yet.', 'ffl-firewall' ) . '</p></div>';
			return;
		}
		echo '<table class="widefat striped fflfw-log"><thead><tr>';
		foreach ( array( __( 'Time', 'ffl-firewall' ), __( 'Countermeasure', 'ffl-firewall' ), __( 'Source address', 'ffl-firewall' ), __( 'Action', 'ffl-firewall' ) ) as $col ) {
			echo '<th scope="col">' . esc_html( $col ) . '</th>';
		}
		echo '</tr></thead><tbody>';
		foreach ( $rows as $i => $row ) {
			$action = isset( $row['action'] ) && 'throttle' === $row['action'] ? __( 'Throttled', 'ffl-firewall' ) : __( 'Blocked', 'ffl-firewall' );
			if ( isset( $row['action'] ) && 'challenge' === $row['action'] ) {
				$action = Autoblock_Copy::action_challenge();
			}
			echo '<tr>';
			echo '<td data-colname="' . esc_attr__( 'Time', 'ffl-firewall' ) . '">' . esc_html( wp_date( 'M j, Y, g:i A', (int) $row['time'] ) ) . '</td>';
			echo '<td data-colname="' . esc_attr__( 'Countermeasure', 'ffl-firewall' ) . '">' . esc_html( $this->countermeasure_name( isset( $row['reason'] ) ? $row['reason'] : '' ) ) . '</td>';
			echo '<td data-colname="' . esc_attr__( 'Source address', 'ffl-firewall' ) . '">' . esc_html( (string) $row['ip'] ) . '</td>';
			echo '<td data-colname="' . esc_attr__( 'Action', 'ffl-firewall' ) . '"><span class="fflfw-log__act">' . esc_html( $action ) . '</span>';
			$this->render_nab( $row, (int) $i );
			echo '</td>';
			echo '</tr>';
		}
		echo '</tbody></table></div>';
	}

	/**
	 * Not a bot (S6F) for one activity row: only on rows the shared feed stopped. Shows the badge
	 * once the visitor is unblocked here, otherwise the button and its dialog (no script needed).
	 *
	 * @param array<string, mixed> $row Activity row.
	 * @param int                  $i   Row number (for unique ids).
	 * @return void
	 */
	private function render_nab( $row, $i ) {
		if ( Monthly::FEED_REASON !== ( isset( $row['reason'] ) ? $row['reason'] : '' ) || empty( $row['feed']['k'] ) || empty( $row['feed']['h'] ) ) {
			return;
		}
		$k = (string) $row['feed']['k'];
		$h = (string) $row['feed']['h'];
		if ( ! Reputation_Unblocks::valid( $k, $h ) ) {
			return;
		}
		$u = Reputation_Unblocks::get( $k, $h );
		if ( null !== $u ) {
			$badge = empty( $u['sent'] ) ? Feed_Copy::nab_badge_retry() : Feed_Copy::nab_badge_sent();
			echo ' <span class="fflfw-nab__badge">' . esc_html( $badge ) . '</span>';
			return;
		}
		$id = 'fflfw-nab-' . $i;
		echo '<details class="fflfw-nab"><summary class="fflfw-btn fflfw-btn--ghost fflfw-nab__open">' . esc_html( Feed_Copy::nab_button() ) . '</summary>';
		echo '<div class="fflfw-nab__dialog" role="dialog" aria-labelledby="' . esc_attr( $id ) . '-t">';
		echo '<p class="fflfw-nab__title" id="' . esc_attr( $id ) . '-t"><strong>' . esc_html( Feed_Copy::nab_button() ) . '</strong></p>';
		echo '<p class="fflfw-help fflfw-help--flush">' . esc_html( Feed_Copy::nab_explainer() ) . '</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="fflfw_not_a_bot" />';
		wp_nonce_field( self::NAB_NONCE );
		echo '<input type="hidden" name="fflfw_nab[k]" value="' . esc_attr( $k ) . '" />';
		echo '<input type="hidden" name="fflfw_nab[h]" value="' . esc_attr( $h ) . '" />';
		echo '<label class="fflfw-nab__label" for="' . esc_attr( $id ) . '-note">' . esc_html( Feed_Copy::nab_note_label() ) . '</label>';
		echo '<textarea id="' . esc_attr( $id ) . '-note" name="fflfw_nab[note]" rows="2" maxlength="' . (int) Reputation_Unblocks::NOTE_MAX . '" placeholder="' . esc_attr( Feed_Copy::nab_note_placeholder() ) . '" aria-describedby="' . esc_attr( $id ) . '-hint"></textarea>';
		echo '<p class="fflfw-help fflfw-help--flush" id="' . esc_attr( $id ) . '-hint">' . esc_html( Feed_Copy::nab_note_hint() ) . '</p>';
		echo '<p class="fflfw-nab__actions"><button type="submit" class="fflfw-btn fflfw-btn--primary">' . esc_html( Feed_Copy::nab_confirm() ) . '</button> ';
		echo '<a class="fflfw-btn fflfw-btn--ghost" href="' . esc_url( Page::url( 'active-defense' ) ) . '">' . esc_html( Feed_Copy::nab_cancel() ) . '</a></p>';
		echo '</form></div></details>';
	}

	/**
	 * The last Not a bot result for this user, shown once.
	 *
	 * @return void
	 */
	private function render_nab_flash() {
		$key   = self::NAB_FLASH . (int) get_current_user_id();
		$flash = get_transient( $key );
		if ( ! is_array( $flash ) || empty( $flash['r'] ) ) {
			return;
		}
		delete_transient( $key );
		$visitor = isset( $flash['v'] ) && '' !== (string) $flash['v'] ? (string) $flash['v'] : Feed_Copy::nab_visitor_fallback();
		$lines   = array(
			'sent'    => Feed_Copy::nab_sent(),
			'already' => Feed_Copy::nab_already(),
			'retry'   => Feed_Copy::nab_retry(),
		);
		if ( ! isset( $lines[ $flash['r'] ] ) ) {
			return;
		}
		$class = 'sent' === $flash['r'] ? 'notice-success' : 'notice-info';
		echo '<div class="notice ' . esc_attr( $class ) . ' inline fflfw-nab__result" role="status"><p>' . esc_html( strtr( $lines[ $flash['r'] ], array( '{visitor}' => $visitor ) ) ) . '</p></div>';
	}

	/**
	 * Not a bot (S6F): unblock the row's hashed subject on this store right away, then try to send
	 * the review request to Coriolis now (it is retried on the next sync if it doesn't go through).
	 * The network list is not changed here; only an Ops admin can delist.
	 *
	 * @return void
	 */
	public function handle_not_a_bot() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'ffl-firewall' ), 403 );
		}
		check_admin_referer( self::NAB_NONCE );
		$back = Page::url( 'active-defense' );
		$raw  = isset( $_POST['fflfw_nab'] ) && is_array( $_POST['fflfw_nab'] ) ? wp_unslash( $_POST['fflfw_nab'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Each field is checked or cleaned below.
		$k    = isset( $raw['k'] ) ? sanitize_key( $raw['k'] ) : '';
		$h    = isset( $raw['h'] ) ? sanitize_key( $raw['h'] ) : '';
		$note = isset( $raw['note'] ) ? Reputation_Unblocks::clean_note( $raw['note'] ) : '';

		// Only a subject the feed actually stopped on this store (it is in Recent activity).
		$visitor = null;
		foreach ( ( new Activity_Log() )->rows() as $row ) {
			if ( isset( $row['feed']['k'], $row['feed']['h'] ) && $row['feed']['k'] === $k && $row['feed']['h'] === $h ) {
				$visitor = isset( $row['ip'] ) ? (string) $row['ip'] : '';
				break;
			}
		}
		$optin = new Feed_Optin();
		if ( null === $visitor || ! Reputation_Unblocks::valid( $k, $h ) || ! $optin->effective() ) {
			wp_safe_redirect( $back );
			exit;
		}

		if ( Reputation_Unblocks::has( $k, $h ) ) {
			$result = 'already';
		} else {
			$feed = Reputation_Feed::state();
			Reputation_Unblocks::add( $k, $h, (string) $feed['salt_id'], $note, \FFL_Firewall\Defense\Counter::now() );
			( new Reputation_Reporter( new Client( new Repository() ), $optin ) )->send_unblocks();
			$u      = Reputation_Unblocks::get( $k, $h );
			$result = ( null !== $u && ! empty( $u['sent'] ) ) ? 'sent' : 'retry';
		}
		set_transient(
			self::NAB_FLASH . (int) get_current_user_id(),
			array(
				'r' => $result,
				'v' => $visitor,
			),
			300
		);
		wp_safe_redirect( add_query_arg( 'updated', '1', $back ) );
		exit;
	}

	/**
	 * Countermeasure name for a logged reason code.
	 *
	 * @param string $reason Reason code.
	 * @return string
	 */
	private function countermeasure_name( $reason ) {
		$reason = (string) $reason;
		if ( 0 === strpos( $reason, 'agent_' ) || 0 === strpos( $reason, 'headers_' ) ) {
			return __( 'User agent and headers', 'ffl-firewall' );
		}
		if ( 0 === strpos( $reason, 'rate' ) ) {
			return __( 'Rate limits', 'ffl-firewall' );
		}
		if ( 0 === strpos( $reason, 'honeypot' ) ) {
			return __( 'Honeypots', 'ffl-firewall' );
		}
		if ( 0 === strpos( $reason, 'datacenter' ) ) {
			return __( 'Datacenter IP block list', 'ffl-firewall' );
		}
		if ( Monthly::FEED_REASON === $reason ) {
			return Feed_Copy::cm_name();
		}
		if ( 0 === strpos( $reason, 'ad_auto_' ) ) {
			return Autoblock_Copy::countermeasure();
		}
		return __( 'Checkout velocity and card-testing', 'ffl-firewall' );
	}

	/**
	 * Auto-block panel (FFLFW-AD-AUTOBLOCK): this month's counts, the dealer off switch and the
	 * timed blocks in force with an instant Unblock on each. Copy lives in Autoblock_Copy.
	 *
	 * @param bool $active Whether ACTIVE DEFENSE is running.
	 * @return void
	 */
	private function render_autoblock( $active ) {
		$on = Auto_Block::is_on();
		if ( ! $on ) {
			$pill = Ui::pill( Autoblock_Copy::pill_off() );
		} elseif ( $active ) {
			$pill = Ui::pill( Autoblock_Copy::pill_on(), 'on' );
		} else {
			$pill = Ui::pill( Autoblock_Copy::pill_waiting() );
		}
		$counts = Auto_Block::month_counts();
		echo '<div class="fflfw-panel fflfw-panel--pad fflfw-autoblock">';
		echo '<h2>' . esc_html( Autoblock_Copy::heading() ) . ' ' . $pill . '</h2>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in Ui.
		echo '<p class="fflfw-help fflfw-help--flush">' . esc_html( Autoblock_Copy::intro() ) . '</p>';
		$flash = get_transient( self::AB_FLASH . (int) get_current_user_id() );
		if ( is_array( $flash ) && isset( $flash['v'] ) ) {
			delete_transient( self::AB_FLASH . (int) get_current_user_id() );
			echo '<div class="notice notice-success inline" role="status"><p>' . esc_html( strtr( Autoblock_Copy::unblocked_notice(), array( '{visitor}' => (string) $flash['v'] ) ) ) . '</p></div>';
		}
		echo '<table class="widefat striped fflfw-autoblock__counts"><tbody>';
		foreach ( array(
			'throttle'  => Autoblock_Copy::count_throttle(),
			'challenge' => Autoblock_Copy::count_challenge(),
			'block'     => Autoblock_Copy::count_block(),
		) as $k => $label ) {
			echo '<tr><th scope="row">' . esc_html( $label ) . '</th><td class="fflfw-autoblock__n" data-ab="' . esc_attr( $k ) . '">' . esc_html( self::number( $counts[ $k ] ) ) . '</td></tr>';
		}
		echo '</tbody></table>';

		echo '<form class="fflfw-autoblock__switch" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="fflfw_save_autoblock" />';
		wp_nonce_field( self::AB_NONCE );
		echo '<input type="hidden" name="fflfw_ab[sent]" value="1" />';
		echo '<label class="fflfw-check"><input type="checkbox" id="fflfw-ab-on" name="fflfw_ab[on]" value="1"' . checked( $on, true, false ) . ' /> <strong>' . esc_html( Autoblock_Copy::toggle() ) . '</strong></label>';
		echo '<p class="fflfw-help">' . esc_html( Autoblock_Copy::toggle_help() ) . '</p>';
		echo '<button type="submit" class="button">' . esc_html( Autoblock_Copy::save() ) . '</button>';
		echo '</form>';

		echo '<h3>' . esc_html( Autoblock_Copy::list_heading() ) . '</h3>';
		$blocks = Auto_Block::active_blocks();
		if ( empty( $blocks ) ) {
			echo '<p class="fflfw-help">' . esc_html( Autoblock_Copy::list_empty() ) . '</p></div>';
			return;
		}
		$kinds = Autoblock_Copy::kinds();
		echo '<table class="widefat striped fflfw-autoblock__list"><thead><tr>';
		foreach ( array( Autoblock_Copy::col_visitor(), Autoblock_Copy::col_signal(), Autoblock_Copy::col_until(), '' ) as $col ) {
			echo '<th scope="col">' . esc_html( $col ) . '</th>';
		}
		echo '</tr></thead><tbody>';
		foreach ( array_slice( $blocks, 0, 50 ) as $b ) {
			echo '<tr>';
			echo '<td>' . esc_html( (string) $b['ip'] ) . '</td>';
			echo '<td>' . esc_html( isset( $kinds[ $b['k'] ] ) ? $kinds[ $b['k'] ] : (string) $b['k'] ) . '</td>';
			echo '<td>' . esc_html( wp_date( 'M j, Y, g:i A', (int) $b['until'] ) ) . '</td>';
			echo '<td><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			echo '<input type="hidden" name="action" value="fflfw_ad_unblock" />';
			wp_nonce_field( self::AB_UNBLOCK );
			echo '<input type="hidden" name="fflfw_ab[k]" value="' . esc_attr( (string) $b['k'] ) . '" />';
			echo '<input type="hidden" name="fflfw_ab[h]" value="' . esc_attr( (string) $b['h'] ) . '" />';
			echo '<button type="submit" class="button button-small">' . esc_html( Autoblock_Copy::unblock() ) . '</button>';
			echo '</form></td>';
			echo '</tr>';
		}
		echo '</tbody></table></div>';
	}

	/**
	 * Save the dealer's auto-block switch. Off stops all auto-blocking right away.
	 *
	 * @return void
	 */
	public function handle_save_autoblock() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'ffl-firewall' ), 403 );
		}
		check_admin_referer( self::AB_NONCE );
		$raw = isset( $_POST['fflfw_ab'] ) && is_array( $_POST['fflfw_ab'] ) ? wp_unslash( $_POST['fflfw_ab'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Only checked for presence.
		Auto_Block::set_on( ! empty( $raw['on'] ), get_current_user_id() );
		wp_safe_redirect( add_query_arg( 'updated', '1', Page::url( 'active-defense' ) ) );
		exit;
	}

	/**
	 * Instant dealer unblock of one auto-blocked entry: lifted on this store right away and kept off
	 * auto-block for 30 days.
	 *
	 * @return void
	 */
	public function handle_ad_unblock() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'ffl-firewall' ), 403 );
		}
		check_admin_referer( self::AB_UNBLOCK );
		$back = Page::url( 'active-defense' );
		$raw  = isset( $_POST['fflfw_ab'] ) && is_array( $_POST['fflfw_ab'] ) ? wp_unslash( $_POST['fflfw_ab'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Checked below.
		$k    = isset( $raw['k'] ) ? sanitize_key( $raw['k'] ) : '';
		$h    = isset( $raw['h'] ) ? sanitize_key( $raw['h'] ) : '';
		$all  = Auto_Block::all();
		$ip   = isset( $all[ $k . '|' . $h ]['ip'] ) ? (string) $all[ $k . '|' . $h ]['ip'] : '';
		if ( ! Auto_Block::unblock( $k, $h ) ) {
			wp_safe_redirect( $back );
			exit;
		}
		set_transient( self::AB_FLASH . (int) get_current_user_id(), array( 'v' => $ip ), 300 );
		wp_safe_redirect( add_query_arg( 'updated', '1', $back ) );
		exit;
	}

	/**
	 * Activate panel: the three steps and the data disclosure.
	 *
	 * @return void
	 */
	private function render_activate() {
		echo '<form class="fflfw-settings__form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="fflfw_save_defense" />';
		wp_nonce_field( self::NONCE );
		echo '<div class="fflfw-panel fflfw-panel--pad">';
		echo '<h2>' . esc_html__( 'FFL Firewall · ACTIVE DEFENSE', 'ffl-firewall' ) . '</h2>';
		echo '<p class="fflfw-help">' . esc_html__( 'FFL Firewall · ACTIVE DEFENSE switches on when you install the plugin. It shows as active once your license is active and the dealer embed script has been seen on your store in the last 24 hours. You can switch it off here.', 'ffl-firewall' ) . '</p>';

		$html  = '<label class="fflfw-check"><input type="checkbox" id="fflfw-defense-on" name="fflfw_defense[enabled]" value="1"' . checked( true === $this->config->get( 'enabled' ), true, false ) . ' /> <strong>' . esc_html__( 'Keep ACTIVE DEFENSE on', 'ffl-firewall' ) . '</strong></label>';
		$html .= '<p class="fflfw-help">' . esc_html__( 'ACTIVE DEFENSE stays on unless you turn it off. It starts keeping bots and scrapers off your store once your license is active and the dealer embed script has been seen on your store in the last 24 hours.', 'ffl-firewall' ) . '</p>';
		$this->row( '1', $html );

		$html  = '<p class="fflfw-help fflfw-help--flush"><label for="fflfw-defense-key"><strong>' . esc_html__( 'Paste your site key', 'ffl-firewall' ) . '</strong></label></p>';
		$html .= '<p class="fflfw-help">' . esc_html__( 'Paste your site key into the field below and save it.', 'ffl-firewall' ) . '</p>';
		$html .= '<div class="fflfw-inline fflfw-keyfield"><input type="text" id="fflfw-defense-key" class="regular-text fflfw-input" name="fflfw_defense[site_key]" value="' . esc_attr( $this->embed->site_key() ) . '" placeholder="' . esc_attr__( 'Paste your site key', 'ffl-firewall' ) . '" autocomplete="off" spellcheck="false" /></div>';
		// FFLFW-AD-DEFAULT-ON C2: disclosure only; the consent checkbox is gone.
		$html .= '<div class="fflfw-consent">';
		$html .= '<p class="fflfw-help">' . esc_html( Consent::paragraph() ) . '</p>';
		$html .= '</div>';
		$html .= '<div class="fflfw-inline fflfw-keysave"><button type="submit" class="button button-primary">' . esc_html__( 'Save site key', 'ffl-firewall' ) . '</button></div>';
		$this->row( '2', $html );

		$html  = '<p class="fflfw-help fflfw-help--flush"><strong>' . esc_html__( 'The plugin adds the dealer embed script', 'ffl-firewall' ) . '</strong></p>';
		$html .= '<p class="fflfw-help">' . esc_html__( "Once your site key is saved, the plugin adds the dealer embed script to your store's pages for you, so there's nothing to paste into your theme. If the plugin has seen the script in the last 24 hours, this screen and your overview light up as Active.", 'ffl-firewall' ) . '</p>';
		$html .= '<div class="fflfw-inline"><button type="submit" class="button" name="fflfw_check_script" value="1">' . esc_html__( 'Check for script', 'ffl-firewall' ) . '</button>';
		$html .= ' <span class="fflfw-help">' . esc_html( $this->last_seen_line() ) . '</span></div>';
		$this->row( '3', $html );

		echo '</div></form>';
	}

	/**
	 * Shared reputation feed group (S6D): its own switch and consent box, off by default, below the
	 * site key step. Copy lives in Feed_Copy.
	 *
	 * @param string $flag Notice flag from the last save.
	 * @return void
	 */
	private function render_feed( $flag ) {
		$optin                    = new Feed_Optin();
		list( $ad_on, $licensed ) = Feed_Optin::preconditions( $this->config );
		$joined                   = $optin->opted_in();
		$works                    = $joined && $ad_on && $licensed;
		// S6E: the feed step also pauses (fails open) when there is no current, verified list.
		$paused                   = $works && ( Reputation_Reporter::paused() || Reputation_Feed::unchecked() );
		if ( $paused ) {
			$pill = Ui::pill( Feed_Copy::pill_paused() );
			$help = Feed_Copy::help_paused();
		} elseif ( $works ) {
			// Last checked: the newer of the last good report sync and the last verified feed pull.
			$st   = Reputation_Reporter::state();
			$ft   = Reputation_Feed::state();
			$last = max( (int) $st['last_ok'], (int) $ft['fetched_at'] );
			$pill = Ui::pill( Feed_Copy::pill_on(), 'on' );
			$help = strtr( Feed_Copy::help_on(), array( '{last_checked}' => $last ? wp_date( 'M j, Y, g:i A T', $last ) : __( 'Never', 'ffl-firewall' ) ) );
		} else {
			$pill = Ui::pill( Feed_Copy::pill_off() );
			$help = Feed_Copy::help_off();
		}

		echo '<form class="fflfw-settings__form fflfw-feed" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="fflfw_save_reputation" />';
		wp_nonce_field( self::FEED_NONCE );
		echo '<div class="fflfw-panel fflfw-panel--pad">';
		echo '<h2>' . esc_html( Feed_Copy::heading() ) . ' ' . $pill . '</h2>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in Ui.
		echo '<p class="fflfw-help fflfw-help--flush">' . esc_html( Feed_Copy::sub_label() ) . '</p>';
		echo '<p class="fflfw-help fflfw-feed__status">' . esc_html( $help ) . '</p>';
		// FFLFW-AD-AUTOBLOCK: the S6D upgrade notice (Feed_Copy::notice_upgrade, "off unless you turn it on")
		// is no longer shown, since every licensed store now shares by default; its wording waits on Brandy and Paul.
		if ( $paused ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html( Feed_Copy::notice_unchecked() ) . '</p></div>';
		}
		if ( 'feed_consent' === $flag ) {
			echo '<div class="fflfw-inline-notice" role="alert">' . esc_html( Feed_Copy::error_consent() ) . '</div>';
		}
		if ( 'feed_license' === $flag || ( $joined && ! $licensed ) ) {
			echo '<div class="fflfw-inline-notice" role="alert">' . esc_html( Feed_Copy::notice_license() ) . '</div>';
		}
		if ( 'feed_ad' === $flag || ( $joined && ! $ad_on ) ) {
			echo '<div class="fflfw-inline-notice" role="alert">' . esc_html( Feed_Copy::note_ad_off() ) . '</div>';
		}
		echo '<label class="fflfw-check"><input type="checkbox" id="fflfw-feed-on" name="fflfw_feed[on]" value="1"' . checked( $joined, true, false ) . ' /> <strong>' . esc_html( Feed_Copy::toggle() ) . '</strong></label>';
		echo '<p class="fflfw-help">' . esc_html( Feed_Copy::explainer() ) . '</p>';
		echo '<div class="fflfw-consent">';
		echo '<p class="fflfw-help">' . esc_html( Feed_Copy::consent_paragraph() ) . '</p>';
		echo '<label class="fflfw-check fflfw-check--top"><input type="checkbox" id="fflfw-feed-consent" name="fflfw_feed[consent]" value="1"' . checked( $optin->consent_given(), true, false ) . ' /> <span>' . esc_html( Feed_Copy::consent_label() ) . '</span></label>';
		echo '</div>';
		echo '<p class="fflfw-help">' . esc_html( Feed_Copy::turn_off() ) . '</p>';
		echo '<button type="submit" class="button">' . esc_html( Feed_Copy::save() ) . '</button>';
		echo '</div></form>';
	}

	/**
	 * Save the feed switch and its consent (S6D). Server-side rules:
	 *   - joining without the box ticked is refused (S6D.19), and nothing changes;
	 *   - on needs an active license (S6D.16) and ACTIVE DEFENSE switched on (S6D.20);
	 *   - unticking the box turns the feed off;
	 *   - off clears the local buffer, the sync state and the schedule.
	 *
	 * @return void
	 */
	public function handle_save_feed() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'ffl-firewall' ), 403 );
		}
		check_admin_referer( self::FEED_NONCE );

		$raw     = isset( $_POST['fflfw_feed'] ) && is_array( $_POST['fflfw_feed'] ) ? wp_unslash( $_POST['fflfw_feed'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Only checked for presence.
		$on      = ! empty( $raw['on'] );
		$consent = ! empty( $raw['consent'] );
		$optin   = new Feed_Optin();
		$back    = Page::url( 'active-defense' );

		if ( $on && ! $consent ) {
			if ( ! $optin->opted_in() ) {
				// Joining needs the box ticked (S6D.19). Nothing is saved.
				wp_safe_redirect( add_query_arg( 'fflfw_notice', 'feed_consent', $back ) );
				exit;
			}
			// Already joined and the box was unticked: that turns the feed off.
			$on = false;
		}
		list( $ad_on, $licensed ) = Feed_Optin::preconditions( $this->config );
		if ( $on && ! $licensed ) {
			wp_safe_redirect( add_query_arg( 'fflfw_notice', 'feed_license', $back ) );
			exit;
		}
		if ( $on && ! $ad_on ) {
			wp_safe_redirect( add_query_arg( 'fflfw_notice', 'feed_ad', $back ) );
			exit;
		}

		$optin->save( $on, $consent, get_current_user_id() );
		if ( ! $optin->opted_in() ) {
			( new Reputation_Buffer() )->clear();
			Reputation_Reporter::reset();
			Reputation_Feed::reset();
			Reputation_Unblocks::clear();
		}
		$client = new Client( new Repository() );
		( new Reputation_Reporter( $client, $optin ) )->schedule();
		( new Reputation_Feed( $client, $optin ) )->schedule();

		wp_safe_redirect( add_query_arg( 'updated', '1', $back ) );
		exit;
	}

	/**
	 * Editable checkout block message.
	 *
	 * @return void
	 */
	private function render_message_form() {
		echo '<form class="fflfw-settings__form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="fflfw_save_defense_message" />';
		wp_nonce_field( self::MSG_NONCE );
		echo '<div class="fflfw-panel fflfw-panel--pad">';
		echo '<h2>' . esc_html__( 'Checkout block message', 'ffl-firewall' ) . '</h2>';
		echo '<p class="fflfw-help">' . esc_html__( 'Shoppers see this when ACTIVE DEFENSE stops a checkout. Leave it empty to use the default text.', 'ffl-firewall' ) . '</p>';
		echo '<div class="fflfw-msg"><label class="screen-reader-text" for="fflfw-defense-message">' . esc_html__( 'Checkout block message', 'ffl-firewall' ) . '</label>';
		echo '<textarea id="fflfw-defense-message" name="fflfw_defense_message" rows="3" maxlength="500" data-fflfw-default="' . esc_attr( Config::default_message() ) . '">' . esc_textarea( $this->config->message() ) . '</textarea></div>';
		echo '<button type="submit" class="button">' . esc_html__( 'Save message', 'ffl-firewall' ) . '</button> ';
		echo '<button type="submit" class="button-link" name="fflfw_defense_message_reset" value="1">' . esc_html__( 'Restore the default text', 'ffl-firewall' ) . '</button>';
		echo '</div></form>';
	}

	/**
	 * The countermeasures (Brandy's A03 and A04 list, plus the shared feed, S6E.1 and S6E.2).
	 *
	 * @return array<int, array<int, string>> Name, one-line description.
	 */
	private function countermeasures() {
		return array(
			array( __( 'Rate limits', 'ffl-firewall' ), __( 'Slows down any visitor that requests pages at a rate no real shopper would.', 'ffl-firewall' ) ),
			array( __( 'User agent and headers', 'ffl-firewall' ), __( "Turns away requests whose user agent and headers don't match what a real browser sends.", 'ffl-firewall' ) ),
			array( __( 'Honeypots', 'ffl-firewall' ), __( 'Hidden form fields that only bots fill in, so the plugin can spot and block them.', 'ffl-firewall' ) ),
			array( __( 'Checkout velocity and card-testing', 'ffl-firewall' ), __( 'Stops the rapid runs of small test payments that card testers send at checkout.', 'ffl-firewall' ) ),
			array( __( 'Datacenter IP block list', 'ffl-firewall' ), __( 'Blocks requests that come from datacenter address ranges on the list.', 'ffl-firewall' ) ),
			array( Feed_Copy::cm_name(), Feed_Copy::cm_line() ),
		);
	}

	/**
	 * Right column: what turns on (or what is running) and the scope line. The "Coming later" feed
	 * line came off when the feed shipped (S6E).
	 *
	 * @param bool $active Whether ACTIVE DEFENSE is running.
	 * @return void
	 */
	private function render_countermeasures( $active ) {
		echo '<div class="fflfw-panel fflfw-panel--pad">';
		if ( $active ) {
			echo '<h2>' . esc_html__( 'Countermeasures', 'ffl-firewall' ) . '</h2>';
			echo '<p class="fflfw-help">' . esc_html__( 'All of these are running on your store now.', 'ffl-firewall' ) . '</p>';
		} else {
			echo '<h2>' . esc_html__( 'What turns on', 'ffl-firewall' ) . '</h2>';
			echo '<p class="fflfw-help">' . esc_html__( 'These countermeasures start together once the plugin has seen the script in the last 24 hours.', 'ffl-firewall' ) . '</p>';
		}
		echo '<ul class="fflfw-cm">';
		foreach ( $this->countermeasures() as $cm ) {
			echo '<li><strong>' . esc_html( $cm[0] ) . '</strong><span class="fflfw-help">' . esc_html( $cm[1] ) . '</span></li>';
		}
		echo '</ul>';
		echo '<p class="fflfw-scope">' . esc_html__( 'ACTIVE DEFENSE works only on your own site. A request it catches is blocked or slowed down.', 'ffl-firewall' ) . '</p>';
		echo '</div>';
	}

	/**
	 * One numbered step row.
	 *
	 * @param string $num  Step number.
	 * @param string $html Field HTML (already escaped).
	 * @return void
	 */
	private function row( $num, $html ) {
		echo '<div class="fflfw-row"><div class="fflfw-row__label">' . esc_html( $num ) . '</div><div class="fflfw-row__field">' . $html . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts.
	}

	/**
	 * Save the switch and the site key, then look the script up once. Nothing here can block anything:
	 * the lookup fails closed to "not seen".
	 *
	 * @return void
	 */
	public function handle_save() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'ffl-firewall' ), 403 );
		}
		check_admin_referer( self::NONCE );

		$raw      = isset( $_POST['fflfw_defense'] ) && is_array( $_POST['fflfw_defense'] ) ? wp_unslash( $_POST['fflfw_defense'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Cleaned below.
		$previous = $this->embed->site_key();
		$key      = Embed::clean_key( isset( $raw['site_key'] ) ? $raw['site_key'] : '' );
		$enabled  = ! empty( $raw['enabled'] );

		// FFLFW-AD-DEFAULT-ON C2: no consent tick; the disclosure is in the install notice and paragraph().

		// FFLFW-ONBOARD-SITEKEY: a paying store that turns the service on without a key gets one from the
		// proxy. A pasted key always wins. Check for script re-checks a provisioned key.
		// FFLFW-ONBOARD-SITEKEY-CHECKOUT: the key was made at paid checkout; this call binds it to this site.
		$auto = false;
		if ( $enabled && '' === $key && $this->provision()->can_run() ) {
			$got = $this->provision()->fetch();
			if ( '' !== $got['key'] ) {
				$key  = $got['key'];
				$auto = true;
				if ( '' !== $got['script_url'] ) {
					$this->embed->save_script_url( $got['script_url'] );
				}
			}
		} elseif ( $enabled && '' !== $key && $key === $previous && Provision::is_auto() && ! empty( $_POST['fflfw_check_script'] ) && $this->provision()->can_run() ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Checked above.
			$this->provision()->fetch();
		}

		$this->config->save( $this->config->sanitize( array_merge( $this->config->all(), array( 'enabled' => $enabled ) ) ) );
		$this->embed->save_key( $key );
		if ( $auto ) {
			Provision::mark_auto( true );
		} elseif ( $key !== $previous ) {
			Provision::mark_auto( false );
		}

		if ( $previous !== $key || ! $enabled ) {
			$this->signal->clear();
		}
		if ( $enabled && '' !== $key ) {
			$this->embed->detect_foreign();
		} else {
			$this->embed->clear_foreign();
		}
		if ( $enabled && '' !== $key && ( $previous !== $key || ! empty( $_POST['fflfw_check_script'] ) || 0 === $this->signal->last_seen() ) ) {
			$this->signal->refresh();
		}
		$this->signal->schedule();

		wp_safe_redirect( add_query_arg( 'updated', '1', Page::url( 'active-defense' ) ) );
		exit;
	}

	/**
	 * Save the checkout block message ("Restore the default text" saves the default).
	 *
	 * @return void
	 */
	public function handle_save_message() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'ffl-firewall' ), 403 );
		}
		check_admin_referer( self::MSG_NONCE );

		$text = ! empty( $_POST['fflfw_defense_message_reset'] ) || ! isset( $_POST['fflfw_defense_message'] ) ? '' : sanitize_textarea_field( wp_unslash( $_POST['fflfw_defense_message'] ) );
		$this->config->save( $this->config->sanitize( array_merge( $this->config->all(), array( 'message' => $text ) ) ) );

		wp_safe_redirect( add_query_arg( 'updated', '1', Page::url( 'active-defense' ) ) );
		exit;
	}
}