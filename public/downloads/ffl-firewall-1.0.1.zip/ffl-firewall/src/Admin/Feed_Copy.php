<?php
/**
 * Shared reputation feed copy (S6D opt-in, S6E countermeasure, S6F Not a bot). Brandy's final copy, word for word, from
 * COPY-S6-2026-11-19.md (approved by Paul as written, 2026-11-19 1:41 PM ET). Slot IDs in each docblock.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * S6D strings.
 */
class Feed_Copy {

	/** S6D.1 */
	public static function heading() {
		return __( 'Shared reputation feed', 'ffl-firewall' );
	}

	/** S6D.2 */
	public static function sub_label() {
		return __( 'On by default for new installs once FFL Firewall · ACTIVE DEFENSE is switched on. You can switch it on or off here.', 'ffl-firewall' );
	}

	/** S6D.3 */
	public static function toggle() {
		return __( 'Join the shared reputation feed', 'ffl-firewall' );
	}

	/** S6D.4 */
	public static function pill_on() {
		return __( 'Feed on', 'ffl-firewall' );
	}

	/** S6D.5 */
	public static function pill_paused() {
		return __( 'Feed paused', 'ffl-firewall' );
	}

	/** S6D.6 */
	public static function pill_off() {
		return __( 'Feed off', 'ffl-firewall' );
	}

	/** S6D.7, token {last_checked}. */
	public static function help_on() {
		return __( 'Sharing and receiving bot signals. Last checked {last_checked}.', 'ffl-firewall' );
	}

	/** S6D.8 */
	public static function help_paused() {
		return __( 'The feed step is paused, and your other checks keep running.', 'ffl-firewall' );
	}

	/** S6D.9 */
	public static function help_off() {
		return __( "Your store isn't sharing or receiving bot signals.", 'ffl-firewall' );
	}

	/** S6D.10 */
	public static function save() {
		return __( 'Save feed setting', 'ffl-firewall' );
	}

	/** S6D.11 */
	public static function explainer() {
		return __( "New installs with FFL Firewall · ACTIVE DEFENSE switched on and an active license are in the shared reputation feed by default; stores that already had FFL Firewall keep the feed setting they had, and if you never made a choice, the feed stays off until you switch it on. One switch covers both directions: in the feed, your store sends Coriolis, LLC the bots it catches and gets back a list reported by the rest of the FFL Firewall network. The feed works on your store's other pages and never touches checkout, login, the cart, My Account or wp-admin, and search engine crawlers aren't affected by it. The feed needs FFL Firewall · ACTIVE DEFENSE switched on and an active FFL Firewall license. To leave the feed, untick \"Join the shared reputation feed\" and click \"Save feed setting\".", 'ffl-firewall' );
	}

	/** S6D.12 */
	public static function consent_paragraph() {
		return __( "While your store is in the feed, the plugin sends Coriolis, LLC signals about the bots your store catches. The signals are hashes of the IP addresses and IPv6 networks the bots came from and, when a request fails the user agent check, of the bot's user agent, all made with one salt shared by every FFL Firewall store, plus the type of pattern caught, such as a honeypot form field or a run of failed payments. The plugin's feed reports carry no raw IP addresses, because the plugin hashes them before anything is sent. Rate-limit hits stay on your store too and are never sent to the feed. Each signal shared on the blocklist is a hash, not a shopper's identity, and the plugin sends no names, emails, addresses, orders, cart contents or payment details to the feed. In the feed, your store appears only as a coded ID. Coriolis, LLC uses those reports to build the shared list. Each report is deleted 30 days after it was last seen, a record on the shared list is kept about 37 days and a reviewed record 180 days; deletion runs only when new reports come in, so records can stay longer when reports are quiet.", 'ffl-firewall' );
	}

	/** S6D.13 */
	public static function consent_label() {
		return __( 'I agree that while the shared reputation feed is on, my store sends Coriolis, LLC hashes of IP addresses, IPv6 networks and bot user agents, made with one salt shared by every FFL Firewall store, plus pattern types, for the shared reputation list, and no shopper names, emails, addresses, orders or payment details.', 'ffl-firewall' );
	}

	/** S6D.14 */
	public static function turn_off() {
		return __( "You can leave the feed at any time by switching it off here or unticking the box. Once you switch the feed off, your store stops sending signals and stops using the shared list. FFL Firewall · ACTIVE DEFENSE keeps running its own checks if it's on. Your store's reports are deleted 30 days after each one was last seen, a record on the shared list is kept about 37 days and a reviewed record 180 days; deletion runs only when new reports come in, so records can stay longer when reports are quiet. Your price stays $79 a month whether the feed is on or off.", 'ffl-firewall' );
	}

	/** S6D.15 */
	public static function notice_unchecked() {
		return __( "FFL Firewall couldn't confirm a current shared list, so the shared feed step is paused for now. Your other FFL Firewall · ACTIVE DEFENSE checks keep running as usual, and the feed step comes back by itself once a current, verified list arrives.", 'ffl-firewall' );
	}

	/** S6D.16 */
	public static function notice_license() {
		return __( "The shared reputation feed needs an active FFL Firewall license. Add your license on the License tab, and once it's active, the feed follows the setting on this tab.", 'ffl-firewall' );
	}

	/** S6D.17 */
	public static function notice_upgrade() {
		return __( 'FFL Firewall · ACTIVE DEFENSE now includes the shared reputation feed, and your store keeps the feed setting it already had; if you never made a choice, the feed stays off until you switch it on. It shares the bots your checks stop and blocks the ones other stores have flagged, and you can switch the feed off any time in the Shared reputation feed section of the FFL Firewall · ACTIVE DEFENSE tab.', 'ffl-firewall' );
	}

	/** S6D.19 */
	public static function error_consent() {
		return __( 'Tick the box below to join the feed, or switch the feed off to save.', 'ffl-firewall' );
	}

	/** S6E.1 Countermeasure name. */
	public static function cm_name() {
		return __( 'Shared reputation feed', 'ffl-firewall' );
	}

	/** S6E.2 Sidebar line ("What turns on"). */
	public static function cm_line() {
		return __( "The feed acts on bots other FFL Firewall stores have reported, on every page except checkout, login, the cart, My Account and wp-admin. It's on by default for new installs, and you can switch it on or off in the Shared reputation feed section.", 'ffl-firewall' );
	}

	/** S6D.20 */
	public static function note_ad_off() {
		return __( 'The shared reputation feed runs only when FFL Firewall · ACTIVE DEFENSE is switched on. Switch it on above to start sharing and receiving bot signals.', 'ffl-firewall' );
	}


	/** S6F.1 Button label. */
	public static function nab_button() {
		return __( 'Not a bot', 'ffl-firewall' );
	}

	/** S6F.2 Note field label. */
	public static function nab_note_label() {
		return __( 'Add a note for Coriolis (optional)', 'ffl-firewall' );
	}

	/** S6F.3 Note field hint. */
	public static function nab_note_hint() {
		return __( 'Up to 200 characters', 'ffl-firewall' );
	}

	/** S6F.4 Note placeholder. */
	public static function nab_note_placeholder() {
		return __( 'Regular customer on a phone carrier network', 'ffl-firewall' );
	}

	/** S6F.5 Confirm button. */
	public static function nab_confirm() {
		return __( 'Unblock on my store', 'ffl-firewall' );
	}

	/** S6F.6 Cancel button. */
	public static function nab_cancel() {
		return __( 'Cancel', 'ffl-firewall' );
	}

	/** S6F.7 Row badge after the click. */
	public static function nab_badge_sent() {
		return __( 'Unblocked here · Coriolis review pending', 'ffl-firewall' );
	}

	/** S6F.12 Row badge if the report is queued. */
	public static function nab_badge_retry() {
		return __( 'Unblocked here · Report will retry', 'ffl-firewall' );
	}

	/** S6F.8 Explainer (dialog body). */
	public static function nab_explainer() {
		return __( 'If the shared feed blocked or slowed down a real visitor, use Not a bot. The visitor is unblocked on your store right away, and Coriolis reviews whether to take them off the network list.', 'ffl-firewall' );
	}

	/** S6F.9 Confirmation / success line; {visitor} is the row IP. */
	public static function nab_sent() {
		return __( '{visitor} is unblocked on your store as of now. We\'ve sent the report to Coriolis, and Coriolis reviews whether to take them off the network list.', 'ffl-firewall' );
	}

	/** S6F.10 Already reported. */
	public static function nab_already() {
		return __( 'You\'ve already marked this visitor as not a bot, so it\'s unblocked on your store, and the request for removal from the network list is with Coriolis for review.', 'ffl-firewall' );
	}

	/** S6F.11 Report didn't send (store unblock still applied); {visitor} is the row IP. */
	public static function nab_retry() {
		return __( '{visitor} is unblocked on your store as of now, but the report hasn\'t reached Coriolis yet. The plugin will retry it automatically on its next sync, so there\'s nothing you need to do.', 'ffl-firewall' );
	}

	/** S6F {visitor} fallback when the row has no IP. */
	public static function nab_visitor_fallback() {
		return __( 'This visitor', 'ffl-firewall' );
	}
}
