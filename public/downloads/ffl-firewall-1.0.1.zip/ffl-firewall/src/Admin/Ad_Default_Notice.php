<?php
/**
 * Admin notice that FFL Firewall · ACTIVE DEFENSE is on by default, with a one-click off switch.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Admin;

use FFL_Firewall\Defense\Config;

defined( 'ABSPATH' ) || exit;

/**
 * Shows N1 while ACTIVE DEFENSE is on, and N3 once after the dealer switches it off from the notice.
 */
class Ad_Default_Notice {

	const ACTION = 'fflfw_ad_switch_off';
	const NONCE  = 'fflfw_ad_switch_off';

	/**
	 * Hook the notice and the off-switch action.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_notices', array( $this, 'render' ) );
		add_action( 'admin_post_' . self::ACTION, array( $this, 'handle_switch_off' ) );
	}

	/**
	 * Whether the current user can switch ACTIVE DEFENSE.
	 *
	 * @return bool
	 */
	private function can_manage() {
		return current_user_can( 'manage_woocommerce' ) || current_user_can( 'manage_options' );
	}

	/**
	 * Print I9+I10 on other wp-admin screens until the first-open screen is answered,
	 * I7 after Keep, or N3 after Switch off. The standing N1 notice is gone (FFLFW-101-01).
	 *
	 * @return void
	 */
	public function render() {
		if ( ! $this->can_manage() ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only notice flag.
		$flag = isset( $_GET['fflfw_notice'] ) ? sanitize_key( wp_unslash( $_GET['fflfw_notice'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page slug.
		$page      = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		$on_plugin = 'ffl-firewall' === $page;

		if ( 'ad_off' === $flag ) {
			echo '<div class="notice notice-info is-dismissible"><p>';
			echo esc_html( Ad_Default_Copy::off_notice() );
			echo '</p></div>';
			return;
		}

		if ( 'ad_keep' === $flag ) {
			echo '<div class="notice notice-info is-dismissible"><p>';
			echo esc_html( Ad_Default_Copy::kept_notice() );
			echo '</p></div>';
			return;
		}

		if ( $on_plugin || ! Ad_Interstitial::needed() ) {
			return;
		}

		echo '<div class="notice notice-info"><p>';
		echo esc_html( Ad_Default_Copy::short_notice() );
		echo ' <a href="' . esc_url( Page::url() ) . '">' . esc_html( Ad_Default_Copy::open_label() ) . '</a>';
		echo '</p></div>';
	}

	/**
	 * Turn ACTIVE DEFENSE off and show N3.
	 *
	 * @return void
	 */
	public function handle_switch_off() {
		if ( ! $this->can_manage() ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'ffl-firewall' ), 403 );
		}
		check_admin_referer( self::NONCE );

		$config = new Config();
		$config->save( $config->sanitize( array_merge( $config->all(), array( 'enabled' => false ) ) ) );

		$back = admin_url( 'admin.php?page=ffl-firewall' );
		wp_safe_redirect( add_query_arg( 'fflfw_notice', 'ad_off', $back ) );
		exit;
	}
}
