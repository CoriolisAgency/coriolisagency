<?php
/**
 * WooCommerce > FFL Firewall > RECON tab (Brandy's mockup A07, tense adjusted because RECON is built). Labels and
 * the report columns follow the mockup; the rest is plain working copy (listed in the pull request). Report only: this tab has one button, Run scan, and
 * nothing it shows changes the site.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Admin;

use FFL_Firewall\Recon\Module;
use FFL_Firewall\Recon\Scanner;
use FFL_Firewall\Settings\Repository;

defined( 'ABSPATH' ) || exit;

/**
 * Renders the tab and handles the Run scan post.
 */
class Recon_Tab {

	const NONCE = 'fflfw_recon';


	/**
	 * Module.
	 *
	 * @var Module
	 */
	private $module;

	/**
	 * Constructor.
	 *
	 * @param Module $module RECON module.
	 */
	public function __construct( Module $module ) {
		$this->module = $module;
	}

	/**
	 * Default wiring for a Page built without one.
	 *
	 * @param Repository $settings Settings.
	 * @return Recon_Tab
	 */
	public static function make( Repository $settings ) {
		return new self( new Module( $settings ) );
	}

	/**
	 * Hook the form post.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_post_fflfw_run_recon', array( $this, 'handle_run' ) );
	}

	/**
	 * Run scan. Needs the capability, the nonce and an active license.
	 *
	 * @return void
	 */
	public function handle_run() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'ffl-firewall' ) );
		}
		check_admin_referer( self::NONCE );
		if ( $this->module->licensed() ) {
			$ran = $this->module->scan( 'manual' );
		} elseif ( $this->module->first_available() ) {
			$ran = $this->module->scan( 'first' );
		} else {
			$ran = null;
		}
		wp_safe_redirect( add_query_arg( 'recon', null === $ran ? 'locked' : 'done', Page::url( 'recon' ) ) );
		exit;
	}

	/**
	 * Severity labels (Brandy's A07 wording).
	 *
	 * @return array<string, string>
	 */
	private function labels() {
		return array(
			Scanner::SEV_FIRST => __( 'Fix first', 'ffl-firewall' ),
			Scanner::SEV_SOON  => __( 'Fix soon', 'ffl-firewall' ),
			Scanner::SEV_LOOK  => __( 'Worth a look', 'ffl-firewall' ),
		);
	}

	/**
	 * Whether a report has been kept.
	 *
	 * @return bool
	 */
	public function has_report() {
		return null !== $this->module->last_report();
	}

	/**
	 * Whether the one unlicensed first scan has not run yet.
	 *
	 * @return bool
	 */
	public function first_available() {
		return $this->module->first_available();
	}

	/**
	 * "Last scan" value.
	 *
	 * @return string
	 */
	public function last_scan_text() {
		$report = $this->module->last_report();
		return $report ? wp_date( 'M j, Y, g:i A T', (int) $report['ran_at'] ) : __( 'No scan yet', 'ffl-firewall' );
	}

	/**
	 * "Next weekly scan" value.
	 *
	 * @return string
	 */
	public function next_scan_text() {
		$next = $this->module->next_run();
		return $next > 0 ? wp_date( 'M j', $next ) : __( 'Not scheduled yet', 'ffl-firewall' );
	}

	/**
	 * The Run scan form (a plain post, works without JavaScript).
	 *
	 * @param string $variant Button style, 'primary' (red) or 'ghost'.
	 * @return string
	 */
	public function run_form_html( $variant = 'primary', $mode = 'manual' ) {
		$label = 'first' === $mode
			? __( 'Run first scan', 'ffl-firewall' )
			: __( 'Run scan', 'ffl-firewall' );
		$html  = '<form class="fflfw-inline-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		$html .= '<input type="hidden" name="action" value="fflfw_run_recon" />';
		$html .= wp_nonce_field( self::NONCE, '_wpnonce', true, false );
		$html .= '<button type="submit" class="fflfw-btn fflfw-btn--' . ( 'ghost' === $variant ? 'ghost' : 'primary' ) . '">' . esc_html( $label ) . '</button>';
		return $html . '</form>';
	}

	/**
	 * What kind of finding this is (Brandy's A07 "Area" column).
	 *
	 * @param string $id Finding id.
	 * @return string
	 */
	private function area( $id ) {
		$id = (string) $id;
		foreach ( array( 'core-update', 'plugin-update', 'theme-update' ) as $prefix ) {
			if ( 0 === strpos( $id, $prefix ) ) {
				return __( 'WordPress.org version', 'ffl-firewall' );
			}
		}
		if ( 0 === strpos( $id, 'php-' ) ) {
			return __( 'PHP version', 'ffl-firewall' );
		}
		foreach ( array( 'no-https', 'registration-role', 'debug-display', 'admin-username', 'file-edit', 'plugin-inactive' ) as $prefix ) {
			if ( 0 === strpos( $id, $prefix ) ) {
				return __( 'Configuration gap', 'ffl-firewall' );
			}
		}
		return '';
	}

	/**
	 * Render the tab.
	 *
	 * @return void
	 */
	public function render() {
		$licensed = $this->module->licensed();
		echo '<div class="fflfw-recon">';
		$head_extra = ( ! $licensed && $this->module->last_report() )
			? Ui::pill( __( 'First scan done', 'ffl-firewall' ) )
			: '';
		echo Ui::head( 'RECON', __( 'Store hardening report', 'ffl-firewall' ), $head_extra ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in Ui.
		echo '<p class="fflfw-settings__intro">' . esc_html__( "RECON is FFL Firewall's store hardening report. It runs every week and whenever you press Run scan, checks the versions of your plugins, themes and WordPress core against the current releases on WordPress.org, flags configuration gaps in your setup and lists what to fix first. It reports only and never fixes anything automatically, so every change stays in your hands. The first scan after install needs no license and includes the known plugin vulnerability check. Weekly scans, Run scan and later vulnerability checks need an FFL Firewall license.", 'ffl-firewall' ) . '</p>';

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only notice flag.
		$flag = isset( $_GET['recon'] ) ? sanitize_key( wp_unslash( $_GET['recon'] ) ) : '';
		if ( 'locked' === $flag ) {
			echo '<div class="fflfw-inline-notice">' . esc_html__( "The scan didn't run. RECON's first scan needs no license, and every scan after it needs an active license.", 'ffl-firewall' ) . '</div>';
		}

		if ( ! $licensed ) {
			$this->render_unlicensed();
			return;
		}

		$report = $this->module->last_report();

		echo '<div class="fflfw-panel fflfw-recon__panel">';
		echo '<div class="fflfw-recon__meta">';
		echo '<p><strong>' . esc_html__( 'Last scan', 'ffl-firewall' ) . '</strong><br />' . esc_html( $report ? $this->last_scan_text() : __( 'Never', 'ffl-firewall' ) ) . '</p>';
		echo '<p><strong>' . esc_html__( 'Weekly scan', 'ffl-firewall' ) . '</strong><br />';
		$next = $this->module->next_run();
		if ( $next > 0 ) {
			/* translators: %s: date */
			echo esc_html( sprintf( __( 'Next run: %s', 'ffl-firewall' ), wp_date( 'M j, Y', $next ) ) );
		} else {
			echo esc_html__( 'Not scheduled yet', 'ffl-firewall' );
		}
		echo '</p></div>';
		echo '<p class="fflfw-help">' . esc_html__( "Runs weekly and whenever you press Run scan. It reports only and doesn't fix anything automatically.", 'ffl-firewall' ) . '</p>';
		echo $this->run_form_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above.
		echo '</div>';

		if ( null === $report ) {
			echo '<p class="fflfw-help">' . esc_html__( 'No scan has run yet. Press Run scan to see your first report.', 'ffl-firewall' ) . '</p>';
			echo '</div>';
			return;
		}

		$this->render_findings( $report );
		echo '</div>';
	}

	/**
	 * Findings table plus the known-plugin section.
	 *
	 * @param array<string, mixed> $report Stored report.
	 * @return void
	 */
	private function render_findings( $report ) {
		$findings = array();
		foreach ( $report['findings'] as $finding ) {
			if ( is_array( $finding ) && isset( $finding['severity'], $finding['title'] ) ) {
				$findings[] = $finding;
			}
		}
		$counts = array();
		foreach ( $this->labels() as $severity => $label ) {
			$counts[ $severity ] = 0;
			foreach ( $findings as $finding ) {
				if ( $finding['severity'] === $severity ) {
					++$counts[ $severity ];
				}
			}
		}

		echo '<h2>' . esc_html__( 'Findings', 'ffl-firewall' ) . ' <span class="fflfw-recon__count">' . esc_html( (string) count( $findings ) ) . '</span></h2>';
		echo '<p class="fflfw-recon__tally">';
		foreach ( $this->labels() as $severity => $label ) {
			echo '<span class="fflfw-recon__chip fflfw-recon__chip--' . esc_attr( $severity ) . '">' . esc_html( $label ) . ' <strong>' . esc_html( (string) $counts[ $severity ] ) . '</strong></span> ';
		}
		echo '</p>';
		if ( ! $findings ) {
			echo '<p class="fflfw-help">' . esc_html__( 'This scan found nothing to report. It covers only the items RECON checks.', 'ffl-firewall' ) . '</p>';
			echo $this->known_html( $report ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in known_html().
			return;
		}

		echo '<table class="widefat striped fflfw-recon__table"><thead><tr>';
		foreach ( array( __( 'Priority', 'ffl-firewall' ), __( 'Area', 'ffl-firewall' ), __( 'What RECON found', 'ffl-firewall' ), __( 'What to do', 'ffl-firewall' ) ) as $col ) {
			echo '<th scope="col">' . esc_html( $col ) . '</th>';
		}
		echo '</tr></thead><tbody>';
		foreach ( $this->labels() as $severity => $label ) {
			foreach ( $findings as $finding ) {
				if ( $finding['severity'] !== $severity ) {
					continue;
				}
				$area = $this->area( isset( $finding['id'] ) ? $finding['id'] : '' );
				echo '<tr class="fflfw-recon__finding fflfw-recon__finding--' . esc_attr( $severity ) . '">';
				echo '<td data-colname="' . esc_attr__( 'Priority', 'ffl-firewall' ) . '"><span class="fflfw-recon__sev">' . esc_html( $label ) . '</span></td>';
				echo '<td data-colname="' . esc_attr__( 'Area', 'ffl-firewall' ) . '">' . ( '' === $area ? '&mdash;' : esc_html( $area ) ) . '</td>';
				echo '<td data-colname="' . esc_attr__( 'What RECON found', 'ffl-firewall' ) . '"><strong>' . esc_html( (string) $finding['title'] ) . '</strong></td>';
				echo '<td data-colname="' . esc_attr__( 'What to do', 'ffl-firewall' ) . '">' . ( empty( $finding['detail'] ) ? '&mdash;' : esc_html( (string) $finding['detail'] ) ) . '</td>';
				echo '</tr>';
			}
		}
		echo '</tbody></table>';
		echo $this->known_html( $report ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in known_html().
	}

	/**
	 * The known plugin vulnerabilities section of a report. Strings: Brandy's
	 * FINAL-strings-2026-11-24 R1 to R9, Karp-cleared. Every notice, license text and record link comes
	 * from the feed data in the report; none is written here.
	 *
	 * @param array<string, mixed> $report Stored report.
	 * @return string
	 */
	public function known_html( $report ) {
		if ( ! is_array( $report ) || empty( $report['known'] ) || ! is_array( $report['known'] ) ) {
			return '';
		}
		$k     = $report['known'];
		$rows  = isset( $k['rows'] ) && is_array( $k['rows'] ) ? $k['rows'] : array();
		$html  = '<div class="fflfw-recon__known">';
		$html .= '<h2>' . esc_html__( 'Known plugin vulnerabilities', 'ffl-firewall' ) . '</h2>';
		$html .= '<p class="fflfw-help fflfw-recon__disclosure">' . esc_html__( 'To run this check, FFL Firewall sends the names and versions of your installed plugins to the Coriolis server.', 'ffl-firewall' ) . '</p>';

		$status = isset( $k['status'] ) ? (string) $k['status'] : '';
		if ( 'no_site_key' === $status ) {
			$html .= '<p class="fflfw-inline-notice fflfw-recon__needs-key">' . esc_html__( 'RECON needs an ACTIVE DEFENSE site key to check your plugins. Turn on ACTIVE DEFENSE to get results.', 'ffl-firewall' ) . '</p>';
			return $html . '</div>';
		}
		if ( 'first_used' === $status ) {
			$html .= '<p class="fflfw-inline-notice">' . esc_html__( 'The one known plugin vulnerability check that needs no license has already been used on this site. Add your FFL Firewall license ($79/month) to check again.', 'ffl-firewall' ) . '</p>';
			return $html . '</div>';
		}
		if ( 'ok' !== $status ) {
			$html .= '<p class="fflfw-inline-notice">' . esc_html__( 'RECON could not reach the vulnerability feed, so it cannot check your plugins right now.', 'ffl-firewall' ) . '</p>';
			return $html . '</div>';
		}

		$checked = isset( $k['checked_at'] ) ? (int) $k['checked_at'] : 0;
		$updated = isset( $k['feed_updated_at'] ) ? (int) $k['feed_updated_at'] : 0;
		if ( $updated > 0 && $checked - $updated > \FFL_Firewall\Recon\Proxy_Feed::STALE_AFTER ) {
			/* translators: %s: date and time the vulnerability feed last updated */
			$html .= '<p class="fflfw-inline-notice">' . esc_html( sprintf( __( 'The vulnerability feed has not updated since %s, so these results may be out of date.', 'ffl-firewall' ), wp_date( 'M j, Y, g:i A T', $updated ) ) ) . '</p>';
		}

		if ( ! $rows ) {
			/* translators: 1: number of installed plugins, 2: date and time of the check */
			$html .= '<p class="fflfw-help">' . esc_html( sprintf( __( 'None of your %1$s installed plugins matched a known vulnerability when RECON last checked them on %2$s. RECON can only match issues that the feed has published.', 'ffl-firewall' ), (string) ( isset( $k['plugin_count'] ) ? (int) $k['plugin_count'] : 0 ), wp_date( 'M j, Y, g:i A T', $checked ) ) ) . '</p>';
			return $html . '</div>';
		}

		$cols  = array( __( 'Plugin', 'ffl-firewall' ), __( 'Affected versions', 'ffl-firewall' ), __( 'Fixed in', 'ffl-firewall' ) );
		$html .= '<table class="widefat striped fflfw-recon__table fflfw-recon__known-table"><thead><tr>';
		foreach ( $cols as $col ) {
			$html .= '<th scope="col">' . esc_html( $col ) . '</th>';
		}
		$html .= '</tr></thead><tbody>';
		$used  = array();
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$fixed = isset( $row['fixed'] ) && is_array( $row['fixed'] ) ? implode( ', ', array_map( 'strval', $row['fixed'] ) ) : '';
			$ci    = isset( $row['c'] ) ? (int) $row['c'] : -1;
			if ( $ci >= 0 ) {
				$used[ $ci ] = true;
			}
			$html .= '<tr class="fflfw-recon__known-row">';
			$html .= '<td data-colname="' . esc_attr( $cols[0] ) . '"><strong>' . esc_html( (string) $row['plugin'] ) . '</strong> ' . esc_html( (string) $row['version'] );
			if ( ! empty( $row['record_url'] ) ) {
				$html .= '<br /><a class="fflfw-recon__record" href="' . esc_url( (string) $row['record_url'] ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'View record', 'ffl-firewall' ) . '</a>';
			}
			$html .= '</td>';
			$html .= '<td data-colname="' . esc_attr( $cols[1] ) . '">' . ( '' === (string) $row['affected'] ? '&mdash;' : esc_html( (string) $row['affected'] ) ) . '</td>';
			$html .= '<td data-colname="' . esc_attr( $cols[2] ) . '">' . ( '' === $fixed ? esc_html__( 'Not listed yet', 'ffl-firewall' ) : esc_html( $fixed ) ) . '</td>';
			$html .= '</tr>';
		}
		$html .= '</tbody></table>';

		$copyrights = isset( $k['copyrights'] ) && is_array( $k['copyrights'] ) ? $k['copyrights'] : array();
		$shown      = array();
		foreach ( array_keys( $used ) as $ci ) {
			foreach ( isset( $copyrights[ $ci ] ) && is_array( $copyrights[ $ci ] ) ? $copyrights[ $ci ] : array() as $entry ) {
				if ( ! is_array( $entry ) || empty( $entry['notice'] ) ) {
					continue;
				}
				$sig = md5( (string) wp_json_encode( $entry ) );
				if ( isset( $shown[ $sig ] ) ) {
					continue;
				}
				$shown[ $sig ] = true;

				$mitre = 'mitre' === ( isset( $entry['holder'] ) ? $entry['holder'] : '' );
				$line  = $mitre
					/* translators: %s: the MITRE copyright notice from the vulnerability feed */
					? sprintf( __( 'CVE data %s.', 'ffl-firewall' ), (string) $entry['notice'] )
					/* translators: %s: the copyright notice from the vulnerability feed */
					: sprintf( __( 'Vulnerability data %s', 'ffl-firewall' ), (string) $entry['notice'] );
				// R9 and M2: each licensor's own license text from the feed, byte for byte (Karp 12:17 PM ET).
				$license = isset( $entry['license'] ) ? (string) $entry['license'] : '';
				$html .= '<p class="fflfw-help fflfw-recon__attribution">' . esc_html( $line );
				if ( ! empty( $entry['license_url'] ) ) {
					$html .= ' <a href="' . esc_url( (string) $entry['license_url'] ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'License', 'ffl-firewall' ) . '</a>';
				}
				$html .= '</p>';
				if ( '' !== $license ) {
					$html .= '<details class="fflfw-recon__license"><summary>' . esc_html__( 'Data license', 'ffl-firewall' ) . '</summary><p>' . esc_html( $license ) . '</p></details>';
				}
			}
		}
		return $html . '</div>';
	}

	/**
	 * Unlicensed first-scan states (FFLFW-101-03).
	 *
	 * @return void
	 */
	private function render_unlicensed() {
		$report = $this->module->last_report();
		if ( $this->module->first_available() ) {
			echo '<p>' . esc_html__( 'RECON runs one scan with no license needed. It checks your plugins, themes and core against WordPress.org, looks for setup gaps, and matches your installed plugins against known plugin vulnerabilities, with no automatic fixes.', 'ffl-firewall' ) . '</p>';
			echo '<p class="fflfw-help">' . esc_html__( 'To run this check, FFL Firewall sends the names and versions of your installed plugins to the Coriolis server.', 'ffl-firewall' ) . '</p>';
			echo $this->run_form_html( 'primary', 'first' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above.
			echo '</div>';
			return;
		}
		if ( null === $report ) {
			echo '<p class="fflfw-help">' . esc_html__( "The scan didn't run. RECON's first scan needs no license, and every scan after it needs an active license.", 'ffl-firewall' ) . '</p>';
			echo '</div>';
			return;
		}
		$date = $this->last_scan_text();
		echo '<p>' . esc_html( str_replace( '{date}', $date, __( 'This is your first RECON scan, run on {date} with no license needed. It covers waiting updates, setup gaps and known plugin vulnerabilities on this site.', 'ffl-firewall' ) ) ) . '</p>';
		echo '<p>' . esc_html__( 'Add your FFL Firewall license ($79/month) to get weekly RECON scans, Run scan and later known plugin vulnerability checks.', 'ffl-firewall' ) . '</p>';
		$this->render_findings( $report );
		echo '</div>';
	}
}
