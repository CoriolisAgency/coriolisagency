<?php
/**
 * One-time first-open screen for FFL Firewall · ACTIVE DEFENSE (FFLFW-101-01).
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Admin;

use FFL_Firewall\Defense\Config;
use FFL_Firewall\Recon\Module;
use FFL_Firewall\Settings\Repository;

defined( 'ABSPATH' ) || exit;

/**
 * Blocks every FFL Firewall tab until the dealer keeps or switches off ACTIVE DEFENSE.
 */
class Ad_Interstitial {

	const OPTION = 'fflfw_ad_ack';
	const ACTION = 'fflfw_ad_ack';
	const NONCE  = 'fflfw_ad_ack';

	/**
	 * Hook the form handler.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_post_' . self::ACTION, array( $this, 'handle' ) );
	}

	/**
	 * Whether the current user can answer the screen.
	 *
	 * @return bool
	 */
	public static function can_manage() {
		return current_user_can( 'manage_woocommerce' ) || current_user_can( 'manage_options' );
	}

	/**
	 * The stored answer, or null.
	 *
	 * @return array<string, mixed>|null
	 */
	public static function record() {
		$row = get_option( self::OPTION, null );
		if ( ! is_array( $row ) || ! isset( $row['v'], $row['at'], $row['choice'] ) ) {
			return null;
		}
		return $row;
	}

	/**
	 * Whether this site still needs an answer for the current disclosure version.
	 *
	 * @return bool
	 */
	public static function needed() {
		if ( true !== ( new Config() )->get( 'enabled' ) ) {
			return false;
		}
		$row = self::record();
		if ( null === $row ) {
			return true;
		}
		return (int) $row['v'] < Ad_Default_Copy::VERSION;
	}

	/**
	 * The dialog and the dimmed, inert page behind it.
	 *
	 * @param callable $render_page Renders the usual FFL Firewall page body.
	 * @return void
	 */
	public function render( $render_page ) {
		echo '<div class="fflfw-ad-ack" id="fflfw-ad-ack">';
		echo '<div class="fflfw-ad-ack__dialog" role="dialog" aria-modal="true" aria-labelledby="fflfw-ad-ack-title">';
		echo '<h2 id="fflfw-ad-ack-title" tabindex="-1">' . esc_html( Ad_Default_Copy::interstitial_title() ) . '</h2>';
		echo '<p class="fflfw-ad-ack__lead">' . esc_html( Ad_Default_Copy::interstitial_lead() ) . '</p>';
		echo '<div class="fflfw-ad-ack__body" tabindex="0"><p>' . esc_html( Ad_Default_Copy::notice() ) . '</p></div>';
		echo '<div class="fflfw-ad-ack__actions">';
		echo self::form( 'on', 'fflfw-btn fflfw-btn--primary', Ad_Default_Copy::keep_on() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in form().
		echo self::form( 'off', 'button', Ad_Default_Copy::switch_off() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in form().
		echo '</div>';
		echo '<p class="fflfw-ad-ack__foot">' . esc_html( Ad_Default_Copy::interstitial_foot() ) . '</p>';
		echo '</div>';
		echo '<div class="fflfw-ad-ack__page" inert>';
		$render_page();
		echo '</div></div>';
	}

	/**
	 * One choice form.
	 *
	 * @param string $choice 'on' or 'off'.
	 * @param string $class  Button class.
	 * @param string $label  Button label.
	 * @return string
	 */
	private static function form( $choice, $class, $label ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only tab carry.
		$tab   = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'overview';
		$html  = '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		$html .= '<input type="hidden" name="action" value="' . esc_attr( self::ACTION ) . '" />';
		$html .= '<input type="hidden" name="choice" value="' . esc_attr( $choice ) . '" />';
		$html .= '<input type="hidden" name="tab" value="' . esc_attr( $tab ) . '" />';
		$html .= wp_nonce_field( self::NONCE, '_wpnonce', true, false );
		$html .= '<button type="submit" class="' . esc_attr( $class ) . '">' . esc_html( $label ) . '</button>';
		$html .= '</form>';
		return $html;
	}

	/**
	 * Save the answer and redirect to the tab the dealer asked for.
	 *
	 * @return void
	 */
	public function handle() {
		if ( ! self::can_manage() ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'ffl-firewall' ), 403 );
		}
		check_admin_referer( self::NONCE );

		$choice = isset( $_POST['choice'] ) ? sanitize_key( wp_unslash( $_POST['choice'] ) ) : '';
		if ( ! in_array( $choice, array( 'on', 'off' ), true ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'ffl-firewall' ), 400 );
		}

		$tab = isset( $_POST['tab'] ) ? sanitize_key( wp_unslash( $_POST['tab'] ) ) : 'overview';
		if ( ! in_array( $tab, Page::TABS, true ) ) {
			$tab = 'overview';
		}

		update_option(
			self::OPTION,
			array(
				'v'      => Ad_Default_Copy::VERSION,
				'at'     => time(),
				'user'   => get_current_user_id(),
				'choice' => $choice,
			),
			false
		);

		if ( 'off' === $choice ) {
			$config = new Config();
			$config->save( $config->sanitize( array_merge( $config->all(), array( 'enabled' => false ) ) ) );
			$flag = 'ad_off';
		} else {
			$flag = 'ad_keep';
		}

		( new Module( new Repository() ) )->after_ack();

		wp_safe_redirect( add_query_arg( 'fflfw_notice', $flag, Page::url( $tab ) ) );
		exit;
	}
}
