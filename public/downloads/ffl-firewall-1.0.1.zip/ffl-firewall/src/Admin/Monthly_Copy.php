<?php
/**
 * Copy for the "Blocked or slowed down this month" panel (FFLF-FIREWALL-V1-S6-REPUTATION-FEED S6A).
 *
 * Brandy's S6A strings, word for word, from COPY-S6-2026-11-19.md (slot ids in each docblock).
 * STATUS: mock copy awaiting Paul's review. Do not merge until Paul approves it; swap any
 * revised wording here (the only place the panel's own strings live) and in MonthlyTest.php.
 * Tokens in braces are filled by Defense_Tab.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Panel strings.
 */
class Monthly_Copy {

	/**
	 * S6A.1 Panel title.
	 *
	 * @return string
	 */
	public static function title() {
		return __( 'Blocked or slowed down this month', 'ffl-firewall' );
	}

	/**
	 * S6A.2 Month subtitle. Tokens: {month}, {today}, {year}.
	 *
	 * @return string
	 */
	public static function subtitle() {
		/* translators: {month}: month name, {today}: day of the month, {year}: year. Keep the braces. */
		return __( '{month} 1 to {today}, {year}', 'ffl-firewall' );
	}

	/**
	 * S6A.3 Total line. Token: {count}.
	 *
	 * @return string
	 */
	public static function total() {
		/* translators: {count}: number of requests. Keep the braces. */
		return __( '{count} requests blocked or slowed down', 'ffl-firewall' );
	}

	/**
	 * S6A.4 to S6A.9 Row labels, keyed by Monthly group.
	 *
	 * @return array<string, string>
	 */
	public static function rows() {
		return array(
			'agent'      => __( 'User agent and headers', 'ffl-firewall' ),
			'rate'       => __( 'Rate limits', 'ffl-firewall' ),
			'honeypot'   => __( 'Honeypots', 'ffl-firewall' ),
			'velocity'   => __( 'Checkout velocity and card-testing', 'ffl-firewall' ),
			'datacenter' => __( 'Datacenter IP block list', 'ffl-firewall' ),
			'auto'       => Autoblock_Copy::countermeasure(),
			'feed'       => __( 'Stopped by the shared reputation feed', 'ffl-firewall' ),
		);
	}

	/**
	 * S6A.10 Feed row value when the feed is off.
	 *
	 * @return string
	 */
	public static function feed_off() {
		return __( 'Off', 'ffl-firewall' );
	}

	/**
	 * S6A.11 Feed row hint when the feed is off.
	 *
	 * @return string
	 */
	public static function feed_off_hint() {
		return __( 'Turn on the shared reputation feed to count these.', 'ffl-firewall' );
	}

	/**
	 * S6A.12 Help link text.
	 *
	 * @return string
	 */
	public static function help_link() {
		return __( 'How these counts work', 'ffl-firewall' );
	}

	/**
	 * S6A.13 Empty state, ACTIVE DEFENSE on and nothing counted yet.
	 *
	 * @return string
	 */
	public static function empty_on() {
		return __( 'Nothing has been blocked or slowed down so far this month. FFL Firewall · ACTIVE DEFENSE is on, and this panel will fill in as its checks catch bots, scrapers and card testers on your store.', 'ffl-firewall' );
	}

	/**
	 * S6A.14 Empty state, ACTIVE DEFENSE off.
	 *
	 * @return string
	 */
	public static function empty_off() {
		return __( "FFL Firewall · ACTIVE DEFENSE is off, so there's nothing for this panel to count yet. Once you switch it back on from the ACTIVE DEFENSE tab, it starts counting the requests its checks block or slow down.", 'ffl-firewall' );
	}

	/**
	 * S6A.15 Help text.
	 *
	 * @return string
	 */
	public static function help() {
		return __( "These counts come from your own store, and working them out doesn't send anything off your site. Each count goes up when one of the FFL Firewall · ACTIVE DEFENSE checks blocks or slows down a request, so a single busy bot can add a lot to a row. The panel starts again from zero on the 1st of each month.", 'ffl-firewall' );
	}

	/**
	 * S6A.16 Footnote.
	 *
	 * @return string
	 */
	public static function footnote() {
		return __( "Treat these numbers as a guide to the bot traffic your store sees, alongside your orders and your host's logs. A high count doesn't always mean an attack, and a low one doesn't mean nothing tried.", 'ffl-firewall' );
	}
}
