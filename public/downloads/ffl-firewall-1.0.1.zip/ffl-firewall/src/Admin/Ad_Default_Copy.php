<?php
/**
 * Install-notice copy for FFL Firewall · ACTIVE DEFENSE default-on (FFLFW-AD-DEFAULT-ON).
 *
 * N1, N2 and N3 ship verbatim from FINAL-ad-default-on-rev5-2026-11-25.md,
 * CLEARED by Karp 8:50 AM ET 2026-11-25.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Karp-cleared N1 / N2 / N3 strings.
 */
class Ad_Default_Copy {

	/**
	 * Disclosure version. Bump only when N1 changes in substance.
	 */
	const VERSION = 1;


	/**
	 * Install notice body (N1). One paragraph, no internal newlines.
	 *
	 * @return string
	 */
	public static function notice() {
		return __( 'FFL Firewall · ACTIVE DEFENSE is on, and once your license is active and the dealer embed script has been seen on your store in the last 24 hours, it keeps bots and scrapers off your store; signed-in store managers and verified search engines are never blocked. While it\'s on, the dealer embed script loads from gunsearchengine.com, which is operated by Coriolis, LLC: each visitor\'s browser connects to it directly, so it receives the visitor\'s IP address, and the script sends the address, title and first referrer of the pages visitors view, campaign tags and the products they look at; gunsearchengine.com keeps a visitor record with those pages and products, an order number when one appears in a page address, any email address the shopper enters in the dealer search, such as to get results by email, set a watch or sign in, the browser, operating system, language, time zone, device type and touch screen, whether the visitor interacted with the page and how long they stayed, the approximate city and other technical signals about the visit, plus hashes of the IP address, network, browser fingerprint and user agent, but not the raw IP address or full user agent. Visitor records, including that email address, are kept with no set deletion period. A shopper\'s details go only to the store they contacted and are never sold or shared with third parties. With an active license, the shared reputation feed sends Coriolis, LLC reports on the bots caught here: hashes of their IP addresses, IPv6 networks and user agents, made with one salt shared by every FFL Firewall store, plus the type of pattern caught. The plugin\'s feed reports carry no raw IP addresses and no shopper names, emails, addresses, orders, cart contents or payment details. To check a visitor that claims to be a search engine, the plugin looks up its IP address through your store\'s own DNS resolver, and the raw IP addresses the plugin acts on are kept in your store\'s own database. Coriolis, LLC uses the reports for the shared list and may use aggregated, anonymized data drawn from them for analysis, product development and other uses as needed to support Coriolis products, including security and bot prevention for FFL Firewall. Reports and watched records are deleted 30 days after they were last seen, a record on the shared list is kept about 37 days and a reviewed record 180 days; deletion runs only when new reports come in, so records can stay longer when reports are quiet. You can switch ACTIVE DEFENSE off here at any time, or leave the feed from the Shared reputation feed section of the ACTIVE DEFENSE tab.', 'ffl-firewall' );
	}

	/**
	 * Off-switch label on the install notice (N2).
	 *
	 * @return string
	 */
	public static function switch_off() {
		return __( 'Switch off ACTIVE DEFENSE', 'ffl-firewall' );
	}

	/**
	 * Notice after the dealer switches ACTIVE DEFENSE off from the install notice (N3).
	 *
	 * @return string
	 */
	public static function off_notice() {
		return __( 'FFL Firewall · ACTIVE DEFENSE is off. You can switch it back on from the ACTIVE DEFENSE tab.', 'ffl-firewall' );
	}

	/**
	 * Interstitial title (I1).
	 *
	 * @return string
	 */
	public static function interstitial_title() {
		return __( 'FFL Firewall · ACTIVE DEFENSE is on', 'ffl-firewall' );
	}

	/**
	 * Interstitial lead (I2).
	 *
	 * @return string
	 */
	public static function interstitial_lead() {
		return __( 'Before you use FFL Firewall, read what ACTIVE DEFENSE sends and keeps, then choose whether to keep it on. You can change this later on the ACTIVE DEFENSE tab.', 'ffl-firewall' );
	}

	/**
	 * Keep button (I4). Live label from the ACTIVE DEFENSE tab.
	 *
	 * @return string
	 */
	public static function keep_on() {
		return __( 'Keep ACTIVE DEFENSE on', 'ffl-firewall' );
	}

	/**
	 * Interstitial footnote (I6).
	 *
	 * @return string
	 */
	public static function interstitial_foot() {
		return __( 'Your choice applies to this whole store, and FFL Firewall saves who made it and when.', 'ffl-firewall' );
	}

	/**
	 * Notice after Keep (I7).
	 *
	 * @return string
	 */
	public static function kept_notice() {
		return __( 'FFL Firewall · ACTIVE DEFENSE stays on. You can switch it off from the ACTIVE DEFENSE tab at any time.', 'ffl-firewall' );
	}

	/**
	 * Short notice on other wp-admin screens until the interstitial is answered (I9).
	 *
	 * @return string
	 */
	public static function short_notice() {
		return __( 'FFL Firewall · ACTIVE DEFENSE is on. Open FFL Firewall to read what it sends and keeps, and to choose whether to keep it on.', 'ffl-firewall' );
	}

	/**
	 * Link label on I9 (I10).
	 *
	 * @return string
	 */
	public static function open_label() {
		return __( 'Open FFL Firewall', 'ffl-firewall' );
	}
}
