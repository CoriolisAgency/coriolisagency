<?php
/**
 * GitHub Releases update check for the direct-download build (FFLFW-UPDATER).
 *
 * Same pattern as FFL Filters: the public releases repo, the latest GitHub
 * Release only (no tags, no branch zip), the release must carry its
 * ffl-firewall-X.Y.Z.zip asset, and no token is read or sent. Unlike FFL
 * Filters this uses WordPress core's own update hooks and screens, not a
 * bundled library, so it adds no strings of its own.
 *
 * On by default. A site can switch it off with
 * add_filter( 'fflfw_release_check_enabled', '__return_false' ).
 * The WordPress.org build strips this file and the FFLFW_UPDATER block in
 * ffl-firewall.php.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Update;

defined( 'ABSPATH' ) || exit;

/**
 * Token-free GitHub Releases updater.
 */
class Release_Check {

	const RELEASES_REPO = 'CoriolisAgency/ffl-firewall-releases';
	const API_URL       = 'https://api.github.com/repos/CoriolisAgency/ffl-firewall-releases/releases/latest';
	const DOWNLOAD_BASE = 'https://github.com/CoriolisAgency/ffl-firewall-releases/releases/download/';
	const RELEASES_URL  = 'https://github.com/CoriolisAgency/ffl-firewall-releases/releases';
	const SLUG          = 'ffl-firewall';
	const ASSET_REGEX   = '/^ffl-firewall-(\d+\.\d+\.\d+)\.zip$/';
	const CACHE_KEY     = 'fflfw_release_check';
	const CACHE_TTL     = 12 * 3600;
	const FAIL_TTL      = 3600;

	/**
	 * Booted already (boot is idempotent).
	 *
	 * @var bool
	 */
	public static $booted = false;

	/**
	 * Boot the release check. On unless the fflfw_release_check_enabled filter says no.
	 *
	 * @return void
	 */
	public static function boot() {
		if ( self::$booted || ! self::enabled() ) {
			return;
		}
		self::$booted = true;
		add_filter( 'pre_set_site_transient_update_plugins', array( self::class, 'inject' ) );
		add_filter( 'plugins_api', array( self::class, 'plugins_api' ), 10, 3 );
		add_action( 'upgrader_process_complete', array( self::class, 'after_upgrade' ), 10, 2 );
	}

	/**
	 * Whether the updater is on (default true).
	 *
	 * @return bool
	 */
	public static function enabled() {
		return (bool) apply_filters( 'fflfw_release_check_enabled', true );
	}

	/**
	 * The installed version.
	 *
	 * @return string
	 */
	public static function installed_version() {
		return defined( 'FFLFW_VERSION' ) ? (string) FFLFW_VERSION : '0.0.0';
	}

	/**
	 * The plugin basename WordPress keys updates by.
	 *
	 * @return string
	 */
	public static function basename() {
		return defined( 'FFLFW_BASENAME' ) ? (string) FFLFW_BASENAME : 'ffl-firewall/ffl-firewall.php';
	}

	/**
	 * Turn a GitHub "latest release" API body into a release record, or null.
	 * Drafts, prereleases, bad tags, and releases without a matching zip asset
	 * from the releases repo are refused.
	 *
	 * @param mixed $data Decoded JSON.
	 * @return array{version:string,package:string,url:string,published:string,notes:string}|null
	 */
	public static function parse_release( $data ) {
		if ( ! is_array( $data ) || ! empty( $data['draft'] ) || ! empty( $data['prerelease'] ) ) {
			return null;
		}
		$tag = isset( $data['tag_name'] ) ? (string) $data['tag_name'] : '';
		if ( ! preg_match( '/^v?(\d+\.\d+\.\d+)$/', $tag, $m ) ) {
			return null;
		}
		$version = $m[1];
		$package = '';
		foreach ( (array) ( $data['assets'] ?? array() ) as $asset ) {
			if ( ! is_array( $asset ) ) {
				continue;
			}
			$name = isset( $asset['name'] ) ? (string) $asset['name'] : '';
			$url  = isset( $asset['browser_download_url'] ) ? (string) $asset['browser_download_url'] : '';
			if ( ! preg_match( self::ASSET_REGEX, $name, $am ) || $am[1] !== $version ) {
				continue;
			}
			if ( 0 !== strpos( $url, self::DOWNLOAD_BASE ) || '.zip' !== substr( $url, -4 ) ) {
				continue;
			}
			$package = $url;
			break;
		}
		if ( '' === $package ) {
			return null;
		}
		$html = isset( $data['html_url'] ) ? (string) $data['html_url'] : '';
		return array(
			'version'   => $version,
			'package'   => $package,
			'url'       => 0 === strpos( $html, self::RELEASES_URL ) ? $html : self::RELEASES_URL,
			'published' => isset( $data['published_at'] ) ? (string) $data['published_at'] : '',
			'notes'     => isset( $data['body'] ) ? (string) $data['body'] : '',
		);
	}

	/**
	 * The latest release, cached. No token: the request carries no Authorization header.
	 *
	 * @param bool $force Skip the cache.
	 * @return array|null
	 */
	public static function latest( $force = false ) {
		if ( ! $force ) {
			$cached = get_site_transient( self::CACHE_KEY );
			if ( is_array( $cached ) ) {
				return empty( $cached['version'] ) ? null : $cached;
			}
		}
		$res = wp_remote_get(
			self::API_URL,
			array(
				'timeout' => 10,
				'headers' => array(
					'Accept'     => 'application/vnd.github+json',
					'User-Agent' => 'ffl-firewall/' . self::installed_version(),
				),
			)
		);
		$release = null;
		if ( ! is_wp_error( $res ) && 200 === (int) wp_remote_retrieve_response_code( $res ) ) {
			$release = self::parse_release( json_decode( (string) wp_remote_retrieve_body( $res ), true ) );
		}
		if ( $release ) {
			set_site_transient( self::CACHE_KEY, $release, self::CACHE_TTL );
		} else {
			// Remember the miss for an hour so a GitHub outage or an empty repo is not hit on every check.
			set_site_transient( self::CACHE_KEY, array( 'version' => '' ), self::FAIL_TTL );
		}
		return $release;
	}

	/**
	 * Add our update to the update_plugins transient when GitHub has a newer build.
	 *
	 * @param mixed $transient The update_plugins transient.
	 * @return mixed
	 */
	public static function inject( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}
		$base    = self::basename();
		$release = self::latest();
		if ( ! $release ) {
			return $transient;
		}
		$item = (object) array(
			'id'           => self::RELEASES_URL,
			'slug'         => self::SLUG,
			'plugin'       => $base,
			'new_version'  => $release['version'],
			'url'          => $release['url'],
			'package'      => $release['package'],
			'requires_php' => '7.4',
		);
		if ( version_compare( $release['version'], self::installed_version(), '>' ) ) {
			if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
				$transient->response = array();
			}
			$transient->response[ $base ] = $item;
			if ( isset( $transient->no_update[ $base ] ) ) {
				unset( $transient->no_update[ $base ] );
			}
		} else {
			$item->new_version = self::installed_version();
			$item->package     = '';
			if ( ! isset( $transient->no_update ) || ! is_array( $transient->no_update ) ) {
				$transient->no_update = array();
			}
			$transient->no_update[ $base ] = $item;
			if ( isset( $transient->response[ $base ] ) ) {
				unset( $transient->response[ $base ] );
			}
		}
		return $transient;
	}

	/**
	 * The "View details" box for our slug. Release notes come from the GitHub Release body.
	 *
	 * @param mixed  $result Default result.
	 * @param string $action plugins_api action.
	 * @param object $args   Request args.
	 * @return mixed
	 */
	public static function plugins_api( $result, $action = '', $args = null ) {
		if ( 'plugin_information' !== $action || ! is_object( $args ) || ! isset( $args->slug ) || self::SLUG !== $args->slug ) {
			return $result;
		}
		$release = self::latest();
		if ( ! $release ) {
			return $result;
		}
		return (object) array(
			'name'          => 'FFL Firewall',
			'slug'          => self::SLUG,
			'version'       => $release['version'],
			'author'        => 'Coriolis Agency',
			'homepage'      => $release['url'],
			'download_link' => $release['package'],
			'requires_php'  => '7.4',
			'last_updated'  => $release['published'],
			'sections'      => array(
				'changelog' => nl2br( esc_html( $release['notes'] ) ),
			),
		);
	}

	/**
	 * Drop the cache after our plugin is updated so the next check is fresh.
	 *
	 * @param mixed $upgrader Upgrader instance.
	 * @param mixed $options  Upgrade details.
	 * @return void
	 */
	public static function after_upgrade( $upgrader, $options = array() ) {
		if ( ! is_array( $options ) || 'update' !== ( $options['action'] ?? '' ) || 'plugin' !== ( $options['type'] ?? '' ) ) {
			return;
		}
		if ( in_array( self::basename(), (array) ( $options['plugins'] ?? array() ), true ) ) {
			delete_site_transient( self::CACHE_KEY );
		}
	}
}
