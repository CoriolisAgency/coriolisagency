<?php
/**
 * Plugin bootstrap.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall;

defined( 'ABSPATH' ) || exit;

/**
 * Main plugin controller.
 */
class Plugin {

	/**
	 * Wire hooks once WooCommerce is present.
	 *
	 * @return void
	 */
	public function init() {
		$settings  = new Settings\Repository();
		$log       = new Log\Store();
		$client    = new Proxy\Client( $settings );
		$overwatch = new Overwatch\Module( $settings, $client, $log );

		$defense = new Defense\Config();
		$embed   = new Defense\Embed( $defense );
		$signal  = new Defense\Signal( $embed, new Defense\Proxy_Seen_Source( $client ) );
		$embed->register();
		$signal->register();
		( new Defense\Behavior_Signals() )->register();
		( new Defense\Reputation_Reporter( $client ) )->register();
		( new Defense\Reputation_Feed( $client ) )->register();
		// FFLFW-DC-LIST-SEED: daily download of the provider datacenter feeds (WP-Cron only).
		( new Defense\Datacenter_Feed() )->register();

		( new Settings\License_Recheck( $settings, $client ) )->register();
		// FFLFW-SITEKEY-PROVISION-FIX: bind the site key on any path where it is needed (cron attempt only).
		( new Defense\Provision( $client, $settings ) )->register();

		// FFLFW-RECON-WORDFENCE: known plugin vulnerabilities come through the proxy (the fflfw_recon_feed seam).
		add_filter(
			'fflfw_recon_feed',
			function ( $feed ) use ( $client ) {
				return $feed instanceof Recon\Null_Feed ? new Recon\Proxy_Feed( $client ) : $feed;
			}
		);
		$recon = new Recon\Module( $settings );
		$recon->register();

		( new Admin\Ad_Default_Notice() )->register();
		( new Admin\Ad_Interstitial() )->register();
		( new Admin\Page( $settings, $client, $log, $overwatch->resolver(), new Admin\Defense_Tab( $defense, $embed, $signal ), new Admin\Recon_Tab( $recon ) ) )->register();
		$overwatch->register();
		( new Defense\Controller( $settings, $defense ) )->register();
	}
}
