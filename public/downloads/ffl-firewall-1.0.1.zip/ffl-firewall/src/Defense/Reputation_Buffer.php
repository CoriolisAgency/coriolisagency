<?php
/**
 * Local buffer of the bot signals the shared reputation feed will report (S6D).
 *
 * Kept on the store only, in one option (autoload off). Raw addresses stay here and are hashed with
 * the fleet salt only when the buffer is flushed, so nothing raw ever leaves the site.
 *
 * What goes in (Paul, 2026-11-19 1:32 PM ET):
 *   - IPv4 addresses as kind ip, IPv6 addresses as their /64 network (kind ip6net).
 *   - The user agent (kind ua) only when the request failed the user agent check.
 *   - Patterns: agent, honeypot, velocity_attempts, velocity_failed_payments, velocity_small_orders.
 *   - Never rate-limit hits (they stay local), never datacenter list hits, never the feed's own blocks.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

defined( 'ABSPATH' ) || exit;

/**
 * Buffer of signals waiting to be reported.
 */
class Reputation_Buffer {

	const OPTION   = 'fflfw_reputation_buffer';
	const MAX_KEYS = 500;
	const MAX_HITS = 10000;
	const MAX_UA   = 512;
	/** Network pattern for a timed auto-block (FFLFW-AD-AUTOBLOCK). */
	const AUTO_PATTERN = 'ad_auto';

	/**
	 * Network pattern for a local reason code, or '' when the reason is never reported.
	 *
	 * @param string $reason Reason code.
	 * @return string
	 */
	public static function pattern_of( $reason ) {
		$reason = (string) $reason;
		if ( 0 === strpos( $reason, 'rate' ) || 0 === strpos( $reason, 'datacenter' ) || Monthly::FEED_REASON === $reason ) {
			return '';
		}
		if ( 0 === strpos( $reason, 'agent_' ) || 0 === strpos( $reason, 'headers_' ) ) {
			return 'agent';
		}
		if ( 0 === strpos( $reason, 'honeypot' ) ) {
			return 'honeypot';
		}
		if ( in_array( $reason, array( 'velocity_attempts', 'velocity_failed_payments', 'velocity_small_orders' ), true ) ) {
			return $reason;
		}
		// FFLFW-AD-AUTOBLOCK: a timed auto-block is shared once the signed feed lists the pattern as
		// accepted (server side not live yet); throttles and checks stay local.
		if ( Auto_Block::R_BLOCK === $reason && Reputation_Feed::accepts( self::AUTO_PATTERN ) ) {
			return self::AUTO_PATTERN;
		}
		return '';
	}

	/**
	 * Canonical subjects for a request: array of array( kind, value ).
	 *
	 * @param Request $req     Request.
	 * @param string  $pattern Network pattern.
	 * @return array<int, array{0: string, 1: string}>
	 */
	public static function subjects( Request $req, $pattern ) {
		$out = array();
		if ( ! $req->ip_unclear && Ip::is_public( $req->ip ) ) {
			$bin = @inet_pton( $req->ip ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- Validated above; false on failure.
			if ( false !== $bin && 4 === strlen( $bin ) ) {
				$out[] = array( 'ip', inet_ntop( $bin ) );
			} elseif ( false !== $bin && 16 === strlen( $bin ) ) {
				$out[] = array( 'ip6net', bin2hex( substr( $bin, 0, 8 ) ) . '/64' );
			}
		}
		if ( 'agent' === $pattern ) {
			$ua = trim( (string) $req->header( 'user-agent' ) );
			if ( '' !== $ua ) {
				$out[] = array( 'ua', substr( $ua, 0, self::MAX_UA ) );
			}
		}
		return $out;
	}

	/**
	 * Entries keyed by kind|value|pattern.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public function all() {
		$raw = get_option( self::OPTION, array() );
		return is_array( $raw ) ? $raw : array();
	}

	/**
	 * Number of buffered entries.
	 *
	 * @return int
	 */
	public function count() {
		return count( $this->all() );
	}

	/**
	 * Add one blocked or slowed-down request. Reasons that are never reported are ignored.
	 *
	 * @param Request $req    Request.
	 * @param string  $reason Local reason code.
	 * @param int     $ts     Unix time.
	 * @return void
	 */
	public function record( Request $req, $reason, $ts = 0 ) {
		$pattern = self::pattern_of( $reason );
		if ( '' === $pattern ) {
			return;
		}
		$subjects = self::subjects( $req, $pattern );
		if ( ! $subjects ) {
			return;
		}
		$ts   = $ts ? (int) $ts : Counter::now();
		$rows = $this->all();
		foreach ( $subjects as $s ) {
			$key = $s[0] . '|' . $s[1] . '|' . $pattern;
			if ( isset( $rows[ $key ] ) ) {
				$rows[ $key ]['hits'] = min( self::MAX_HITS, (int) $rows[ $key ]['hits'] + 1 );
				$rows[ $key ]['last'] = max( (int) $rows[ $key ]['last'], $ts );
			} elseif ( count( $rows ) < self::MAX_KEYS ) {
				$rows[ $key ] = array(
					'kind'  => $s[0],
					'value' => $s[1],
					'p'     => $pattern,
					'hits'  => 1,
					'first' => $ts,
					'last'  => $ts,
				);
			}
		}
		update_option( self::OPTION, $rows, false );
	}

	/**
	 * Remove sent entries.
	 *
	 * @param array<int, string> $keys Keys.
	 * @return void
	 */
	public function remove( $keys ) {
		$rows = $this->all();
		foreach ( (array) $keys as $k ) {
			unset( $rows[ $k ] );
		}
		if ( $rows ) {
			update_option( self::OPTION, $rows, false );
		} else {
			delete_option( self::OPTION );
		}
	}

	/**
	 * Drop everything (feed turned off, license gone, or the salt changed).
	 *
	 * @return void
	 */
	public function clear() {
		delete_option( self::OPTION );
	}
}
