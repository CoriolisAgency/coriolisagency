<?php
/**
 * Where the "dealer embed script last seen" answer comes from, behind one interface so the
 * endpoint, its auth and its transport can change without touching the gate.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

defined( 'ABSPATH' ) || exit;

/**
 * A last-seen lookup.
 */
interface Seen_Source {

	/**
	 * Look up when the embed script was last seen for a site key.
	 *
	 * @param string $site_key The dealer's saved site key.
	 * @return array{ok: bool, last_seen: int|null, script_url?: string} ok=false means the lookup failed
	 *         (treated as not seen). last_seen is a Unix time, or null for never. script_url is the
	 *         address to load the script from, when the source sends one.
	 */
	public function fetch( $site_key );
}