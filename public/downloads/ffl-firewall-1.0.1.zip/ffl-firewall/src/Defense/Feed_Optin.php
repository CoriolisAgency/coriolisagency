<?php
/**
 * The shared reputation feed switch (S6D). Separate from ACTIVE DEFENSE and its consent. One switch
 * covers both directions: no receive-only mode (Paul, 1:41 PM ET), so joining means the store reports
 * and receives.
 *
 * FFLFW-TERMS-DEFAULT-SHARE (Paul, 2026-11-23 10:34 and 10:45 AM ET via Chief): "Default-on applies to
 * new installs only; existing installs keep their current setting" and "Existing installs with no saved
 * choice are off unless they opt in." So the store's starting point is stamped once, explicitly:
 *   - fresh install (no FFL Firewall option of any kind yet): origin 'fresh', in the feed by default;
 *   - existing install (an earlier version left options behind) with no saved choice: origin
 *     'existing', off until the dealer opts in;
 *   - a saved choice (saved > 0), on or off, is never touched by the stamp or by an update.
 * stamp() runs on activation and early on plugins_loaded (so updates that skip activation get it too).
 *
 * Stored in its own option: array( 'on' => bool, 'consent' => array( 'v', 'at', 'user' ), 'saved' => unix
 * time, 'origin' => 'fresh'|'existing', 'stamped' => unix time ). The feed only works while it is on, its
 * consent box is ticked, ACTIVE DEFENSE is switched on and the license is active.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

use FFL_Firewall\Settings\Repository;

defined( 'ABSPATH' ) || exit;

/**
 * Feed opt-in record and the "feed on" answer.
 */
class Feed_Optin {

	const OPTION          = 'fflfw_reputation';
	const CONSENT_VERSION = 1;

	/**
	 * Options an earlier FFL Firewall version leaves behind. Any one of them present when the feed record
	 * is first stamped means this is an existing install, not a fresh one (uninstall deletes them all).
	 */
	const PRIOR_OPTIONS = array(
		'fflfw_settings',
		'fflfw_license_status',
		'fflfw_log',
		'fflfw_defense',
		'fflfw_defense_log',
		'fflfw_defense_monthly',
		'fflfw_defense_site_key',
		'fflfw_defense_consent',
		'fflfw_defense_seen',
		'fflfw_defense_script_url',
		'fflfw_defense_foreign',
		'fflfw_recon',
		'fflfw_reputation_state',
		'fflfw_reputation_buffer',
		'fflfw_reputation_feed',
		'fflfw_reputation_unblocks',
		'fflfw_license_recheck',
		'fflfw_ad_signals',
		'fflfw_ad_state',
		'fflfw_ad_autoblock',
		'fflfw_ad_unblocked',
		'fflfw_ad_secret',
	);

	/**
	 * Whether an earlier FFL Firewall version left any option behind.
	 *
	 * @return bool
	 */
	public static function prior_install() {
		foreach ( self::PRIOR_OPTIONS as $name ) {
			if ( false !== get_option( $name, false ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Where a store with no saved choice starts: 'fresh' (in by default) or 'existing' (off).
	 *
	 * @param mixed $raw Stored option value, or false when there is none.
	 * @return string
	 */
	public static function origin( $raw ) {
		if ( is_array( $raw ) && isset( $raw['origin'] ) && in_array( $raw['origin'], array( 'fresh', 'existing' ), true ) ) {
			return $raw['origin'];
		}
		if ( false === $raw ) {
			// Not stamped yet (stamp() runs first on every request, so this is rare): decide the same way.
			return self::prior_install() ? 'existing' : 'fresh';
		}
		// A record without an origin can only come from code before this change: an existing install.
		return 'existing';
	}

	/**
	 * Stamp the store's starting point once, explicitly, so nothing downstream has to guess. A saved
	 * choice and an already-stamped record are left exactly as they are. Never throws.
	 *
	 * @return void
	 */
	public static function stamp() {
		try {
			$raw = get_option( self::OPTION, false );
			if ( is_array( $raw ) && ( ! empty( $raw['saved'] ) || isset( $raw['origin'] ) ) ) {
				return;
			}
			$origin = self::origin( $raw );
			update_option(
				self::OPTION,
				array(
					'on'      => 'fresh' === $origin,
					'consent' => array(),
					'saved'   => 0,
					'origin'  => $origin,
					'stamped' => time(),
				),
				false
			);
		} catch ( \Throwable $e ) {
			unset( $e );
		}
	}

	/**
	 * Stored record.
	 *
	 * @return array<string, mixed>
	 */
	public function all() {
		$raw = get_option( self::OPTION, false );
		$r   = is_array( $raw ) ? $raw : array();
		if ( empty( $r['saved'] ) ) {
			if ( 'existing' === self::origin( $raw ) ) {
				// An existing install with no saved choice is off until the dealer opts in (Paul 10:45 AM ET).
				return array(
					'on'      => false,
					'consent' => array(),
					'saved'   => 0,
				);
			}
			// A fresh install shares by default (FFLFW-AD-AUTOBLOCK, Paul 2026-11-21 3:39 PM ET; new installs
			// only, Paul 2026-11-23 10:34 AM ET). effective() still needs ACTIVE DEFENSE on and an active
			// license, so an unlicensed store never shares.
			return array(
				'on'      => true,
				'consent' => array(
					'v'       => self::CONSENT_VERSION,
					'at'      => 0,
					'user'    => 0,
					'default' => true,
				),
				'saved'   => 0,
			);
		}
		$c = isset( $r['consent'] ) && is_array( $r['consent'] ) && ! empty( $r['consent']['at'] ) ? $r['consent'] : array();
		return array(
			'on'      => ! empty( $r['on'] ) && ! empty( $c ),
			'consent' => $c,
			'saved'   => isset( $r['saved'] ) ? (int) $r['saved'] : 0,
		);
	}

	/**
	 * Whether the dealer has joined the feed (switch on and consent ticked).
	 *
	 * @return bool
	 */
	public function opted_in() {
		$r = $this->all();
		return $r['on'];
	}

	/**
	 * Whether the feed consent box is ticked.
	 *
	 * @return bool
	 */
	public function consent_given() {
		$r = $this->all();
		return ! empty( $r['consent'] );
	}

	/**
	 * Whether the dealer has ever saved the feed setting.
	 *
	 * @return bool
	 */
	public function ever_saved() {
		$r = $this->all();
		return $r['saved'] > 0;
	}

	/**
	 * Save the switch and the consent. On without consent is never stored: callers check first, and
	 * this method turns the switch off when the consent is missing as a last guard.
	 *
	 * @param bool $on      Switch.
	 * @param bool $consent Box ticked.
	 * @param int  $user_id User saving.
	 * @return void
	 */
	public function save( $on, $consent, $user_id ) {
		$prev = $this->all();
		$c    = array();
		if ( $consent ) {
			$c = ( ! empty( $prev['consent'] ) && empty( $prev['consent']['default'] ) ) ? $prev['consent'] : array(
				'v'    => self::CONSENT_VERSION,
				'at'   => time(),
				'user' => (int) $user_id,
			);
		}
		update_option(
			self::OPTION,
			array(
				'on'      => (bool) $on && ! empty( $c ),
				'consent' => $c,
				'saved'   => time(),
			),
			false
		);
	}

	/**
	 * Whether ACTIVE DEFENSE is switched on and the license is active (the feed's preconditions).
	 *
	 * @param Config $config Defense config.
	 * @return array{0: bool, 1: bool} ACTIVE DEFENSE switched on, license active.
	 */
	public static function preconditions( Config $config ) {
		return array(
			true === $config->get( 'enabled' ),
			'active' === ( new Repository() )->license_status(),
		);
	}

	/**
	 * Whether the feed works right now: joined, ACTIVE DEFENSE on, license active.
	 *
	 * @param Config|null $config Defense config.
	 * @return bool
	 */
	public function effective( ?Config $config = null ) {
		try {
			if ( ! $this->opted_in() ) {
				return false;
			}
			list( $ad_on, $licensed ) = self::preconditions( $config ? $config : new Config() );
			return $ad_on && $licensed;
		} catch ( \Throwable $e ) {
			return false;
		}
	}

	/**
	 * Filter callback for fflfw_reputation_feed_on.
	 *
	 * @param bool $value Incoming value.
	 * @return bool
	 */
	public function filter( $value = false ) {
		unset( $value );
		return $this->effective();
	}
}
