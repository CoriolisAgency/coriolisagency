<?php
/**
 * Hosting and datacenter address ranges (IPv4). The plugin ships none. FFLFW-DC-LIST-SEED: ranges come
 * from the provider feeds the store downloads daily (Datacenter_Feed, cache only, never fetched here)
 * plus the `fflfw_defense_datacenter_ranges` filter, which adds to them. With no current ranges this
 * check matches nothing (fails open).
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

defined( 'ABSPATH' ) || exit;

/**
 * Sorted start/end pairs, binary search.
 */
class Datacenter_List {

	/**
	 * Flat sorted list: start0, end0, start1, end1, ...
	 *
	 * @var array<int, int>|null
	 */
	private $ranges;

	/**
	 * Constructor.
	 *
	 * @param array<int, int>|null $ranges Flat sorted pairs; null reads the cached feeds plus the `fflfw_defense_datacenter_ranges` filter.
	 */
	public function __construct( $ranges = null ) {
		$this->ranges = $ranges;
	}

	/**
	 * Pairs in use.
	 *
	 * @return array<int, int>
	 */
	private function ranges() {
		if ( null === $this->ranges ) {
			$cidrs        = function_exists( 'apply_filters' ) ? apply_filters( 'fflfw_defense_datacenter_ranges', array() ) : array();
			$extra        = self::from_cidrs( $cidrs );
			$feed         = Datacenter_Feed::pairs();
			$this->ranges = $feed && $extra ? self::merge( $feed, $extra ) : ( $feed ? $feed : $extra );
		}
		return $this->ranges;
	}

	/**
	 * Turn IPv4 CIDR strings (for example "203.0.113.0/24") into sorted, merged start/end pairs.
	 * Anything that is not a valid IPv4 CIDR or single address is ignored.
	 *
	 * @param mixed $cidrs List of strings.
	 * @return array<int, int>
	 */
	public static function from_cidrs( $cidrs ) {
		if ( ! is_array( $cidrs ) ) {
			return array();
		}
		$pairs = array();
		foreach ( $cidrs as $c ) {
			if ( ! is_string( $c ) ) {
				continue;
			}
			$parts = explode( '/', trim( $c ), 2 );
			$n     = Ip::v4_int( $parts[0] );
			$bits  = isset( $parts[1] ) ? $parts[1] : '32';
			if ( null === $n || ! ctype_digit( $bits ) || (int) $bits > 32 ) {
				continue;
			}
			$size    = 1 << ( 32 - (int) $bits );
			$start   = $n - ( $n % $size );
			$pairs[] = array( $start, $start + $size - 1 );
		}
		usort( $pairs, function ( $x, $y ) { return $x[0] <=> $y[0]; } );
		$out = array();
		foreach ( $pairs as $p ) {
			$last = count( $out ) - 1;
			if ( $last >= 1 && $p[0] <= $out[ $last ] + 1 ) {
				$out[ $last ] = max( $out[ $last ], $p[1] );
			} else {
				$out[] = $p[0];
				$out[] = $p[1];
			}
		}
		return $out;
	}
	/**
	 * Merge two flat sorted pair lists into one sorted, merged list.
	 *
	 * @param array<int, int> $a Pairs.
	 * @param array<int, int> $b Pairs.
	 * @return array<int, int>
	 */
	public static function merge( array $a, array $b ) {
		$pairs = array();
		foreach ( array( $a, $b ) as $list ) {
			$n = count( $list );
			for ( $i = 0; $i + 1 < $n; $i += 2 ) {
				$pairs[] = array( (int) $list[ $i ], (int) $list[ $i + 1 ] );
			}
		}
		usort( $pairs, function ( $x, $y ) { return $x[0] <=> $y[0]; } );
		$out = array();
		foreach ( $pairs as $p ) {
			$last = count( $out ) - 1;
			if ( $last >= 1 && $p[0] <= $out[ $last ] + 1 ) {
				$out[ $last ] = max( $out[ $last ], $p[1] );
			} else {
				$out[] = $p[0];
				$out[] = $p[1];
			}
		}
		return $out;
	}

	/**
	 * Number of ranges.
	 *
	 * @return int
	 */
	public function count() {
		return (int) floor( count( $this->ranges() ) / 2 );
	}

	/**
	 * Whether the address is inside a listed range.
	 *
	 * @param string $ip Address.
	 * @return bool
	 */
	public function contains( $ip ) {
		$n = Ip::v4_int( Ip::normalize( $ip ) );
		if ( null === $n ) {
			return false;
		}
		$r  = $this->ranges();
		$lo = 0;
		$hi = (int) floor( count( $r ) / 2 ) - 1;
		while ( $lo <= $hi ) {
			$mid = ( $lo + $hi ) >> 1;
			if ( $n < $r[ 2 * $mid ] ) {
				$hi = $mid - 1;
			} elseif ( $n > $r[ 2 * $mid + 1 ] ) {
				$lo = $mid + 1;
			} else {
				return true;
			}
		}
		return false;
	}
}
