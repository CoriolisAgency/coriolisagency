<?php
/**
 * FFLFW-AD-AUTOBLOCK: behavior signals from the dealer embed script, as the bot-detection service
 * scores them (fingerprint, ua_hash, IP or network cluster). Only high-confidence entries are kept
 * and matched; low and medium never block. Requests only read the stored list, so a slow or failing
 * delivery can never delay a page, and any problem (no list, expired list, bad shape) matches nothing.
 *
 * Delivery shape (from the embed-seen answer's optional "behavior" field, or the
 * fflfw_ad_behavior_signals action):
 *   array(
 *     'salt'       => string, 32+ chars, used for the ip, net and fp hashes,
 *     'issued_at'  => unix time,
 *     'expires_at' => unix time,
 *     'entries'    => array( array( 'k' => ua|ip|net|fp, 'h' => hex, 'c' => high|medium|low, 'exp' => unix time (optional) ) ),
 *   )
 * Hashes:
 *   ua  : first 16 hex of sha256( trimmed user agent ), the embed sensor's ua_hash.
 *   ip  : sha256( "salt|ip|<address>" ).
 *   net : sha256( "salt|net|<a.b.c.0/24>" ) for IPv4, sha256( "salt|net|<first 8 bytes hex>/64" ) for IPv6.
 *   fp  : sha256( "salt|fp|<ua_hash>|<accept-language>|<sec-ch-ua-platform>" ), the request-side fingerprint.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

defined( 'ABSPATH' ) || exit;

/**
 * Stored high-confidence signal list and the request matcher.
 */
class Behavior_Signals {

	const OPTION      = 'fflfw_ad_signals';
	const KINDS       = array( 'ip', 'net', 'fp', 'ua' );
	const MAX_ENTRIES = 20000;
	/** A list older than this is not trusted (fail open). */
	const STALE_AFTER = 172800;
	/** Only this confidence level is stored or matched. */
	const HIGH = 'high';

	/**
	 * Clock override for tests.
	 *
	 * @var int|null
	 */
	public static $now = null;

	/**
	 * Current time.
	 *
	 * @return int
	 */
	private static function now() {
		return null !== self::$now ? (int) self::$now : Counter::now();
	}

	/**
	 * Add the delivery hook.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'fflfw_ad_behavior_signals', array( $this, 'ingest' ) );
	}

	/**
	 * Store a delivered list. Low and medium confidence entries are dropped here.
	 *
	 * @param mixed $payload Delivered list.
	 * @return int Number of high-confidence entries kept (0 on a bad payload, which keeps nothing).
	 */
	public function ingest( $payload ) {
		try {
			$now = self::now();
			if ( ! is_array( $payload ) || ! isset( $payload['entries'] ) || ! is_array( $payload['entries'] ) ) {
				return 0;
			}
			$salt = isset( $payload['salt'] ) && is_string( $payload['salt'] ) ? $payload['salt'] : '';
			$exp  = isset( $payload['expires_at'] ) ? (int) $payload['expires_at'] : 0;
			if ( $exp <= $now ) {
				return 0;
			}
			$index = array();
			foreach ( $payload['entries'] as $e ) {
				if ( count( $index ) >= self::MAX_ENTRIES ) {
					break;
				}
				if ( ! is_array( $e ) || ! isset( $e['k'], $e['h'], $e['c'] ) || self::HIGH !== $e['c'] ) {
					continue;
				}
				$k = (string) $e['k'];
				$h = strtolower( (string) $e['h'] );
				if ( ! self::valid( $k, $h ) ) {
					continue;
				}
				if ( 'ua' !== $k && strlen( $salt ) < 32 ) {
					continue;
				}
				$until = isset( $e['exp'] ) ? min( (int) $e['exp'], $exp ) : $exp;
				if ( $until > $now ) {
					$index[ $k . '|' . $h ] = $until;
				}
			}
			update_option(
				self::OPTION,
				array(
					'salt'        => $salt,
					'issued_at'   => isset( $payload['issued_at'] ) ? (int) $payload['issued_at'] : $now,
					'expires_at'  => $exp,
					'received_at' => $now,
					'index'       => $index,
				),
				false
			);
			return count( $index );
		} catch ( \Throwable $e ) {
			return 0;
		}
	}

	/**
	 * Whether a kind and hash have the right shape.
	 *
	 * @param string $k Kind.
	 * @param string $h Hash.
	 * @return bool
	 */
	public static function valid( $k, $h ) {
		if ( ! in_array( $k, self::KINDS, true ) ) {
			return false;
		}
		return 'ua' === $k ? (bool) preg_match( '/^[0-9a-f]{16}$/', $h ) : (bool) preg_match( '/^[0-9a-f]{64}$/', $h );
	}

	/**
	 * Stored list.
	 *
	 * @return array<string, mixed>
	 */
	public static function state() {
		$s = get_option( self::OPTION, array() );
		$s = is_array( $s ) ? $s : array();
		$s = array_merge(
			array(
				'salt'        => '',
				'issued_at'   => 0,
				'expires_at'  => 0,
				'received_at' => 0,
				'index'       => array(),
			),
			$s
		);
		$s['index'] = is_array( $s['index'] ) ? $s['index'] : array();
		return $s;
	}

	/**
	 * Forget the list (uninstall).
	 *
	 * @return void
	 */
	public static function clear() {
		delete_option( self::OPTION );
	}

	/**
	 * The embed sensor's ua_hash for a user agent.
	 *
	 * @param string $ua User agent.
	 * @return string 16 hex, or '' for an empty agent.
	 */
	public static function ua_hash( $ua ) {
		$ua = trim( (string) $ua );
		return '' === $ua ? '' : substr( hash( 'sha256', $ua ), 0, 16 );
	}

	/**
	 * Network cluster value for an address: IPv4 /24, IPv6 /64.
	 *
	 * @param string $ip Address.
	 * @return string
	 */
	public static function net_of( $ip ) {
		$bin = @inet_pton( (string) $ip ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- false on failure.
		if ( false === $bin ) {
			return '';
		}
		if ( 4 === strlen( $bin ) ) {
			return inet_ntop( substr( $bin, 0, 3 ) . "\0" ) . '/24';
		}
		return 16 === strlen( $bin ) ? bin2hex( substr( $bin, 0, 8 ) ) . '/64' : '';
	}

	/**
	 * Request-side fingerprint value (before salting).
	 *
	 * @param Request $req Request.
	 * @return string
	 */
	public static function fingerprint_of( Request $req ) {
		$ua = self::ua_hash( $req->user_agent );
		if ( '' === $ua ) {
			return '';
		}
		return $ua . '|' . strtolower( trim( $req->header( 'accept-language' ) ) ) . '|' . strtolower( trim( $req->header( 'sec-ch-ua-platform' ), " \t\"" ) );
	}

	/**
	 * Subjects for a request: array of array( kind, hash ), in match order.
	 *
	 * @param Request $req  Request.
	 * @param string  $salt Salt.
	 * @return array<int, array{0: string, 1: string}>
	 */
	public static function subjects( Request $req, $salt ) {
		$out = array();
		if ( strlen( (string) $salt ) >= 32 && ! $req->ip_unclear && Ip::is_public( $req->ip ) ) {
			$out[] = array( 'ip', hash( 'sha256', $salt . '|ip|' . $req->ip ) );
			$net   = self::net_of( $req->ip );
			if ( '' !== $net ) {
				$out[] = array( 'net', hash( 'sha256', $salt . '|net|' . $net ) );
			}
		}
		if ( strlen( (string) $salt ) >= 32 ) {
			$fp = self::fingerprint_of( $req );
			if ( '' !== $fp ) {
				$out[] = array( 'fp', hash( 'sha256', $salt . '|fp|' . $fp ) );
			}
		}
		$ua = self::ua_hash( $req->user_agent );
		if ( '' !== $ua ) {
			$out[] = array( 'ua', $ua );
		}
		return $out;
	}

	/**
	 * First high-confidence entry the request matches, or null. Any problem matches nothing.
	 *
	 * @param Request $req Request.
	 * @return array{k: string, h: string}|null
	 */
	public function match( Request $req ) {
		try {
			$s   = self::state();
			$now = self::now();
			if ( empty( $s['index'] ) || (int) $s['expires_at'] <= $now || ( $now - (int) $s['received_at'] ) > self::STALE_AFTER ) {
				return null;
			}
			foreach ( self::subjects( $req, (string) $s['salt'] ) as $sub ) {
				$key = $sub[0] . '|' . $sub[1];
				if ( isset( $s['index'][ $key ] ) && (int) $s['index'][ $key ] > $now ) {
					return array(
						'k' => $sub[0],
						'h' => $sub[1],
					);
				}
			}
			return null;
		} catch ( \Throwable $e ) {
			return null;
		}
	}
}
