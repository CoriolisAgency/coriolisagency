<?php
/**
 * Flushes the reputation buffer to the proxy every 15 minutes (S6D).
 *
 * Fails open by design: if the proxy route is missing, answers 503, times out or says anything
 * unexpected, the buffer is kept (it is capped) and retried on the next run. Nothing here can block
 * or slow a page, a login or a checkout, and nothing raw leaves the site: every subject is hashed
 * with the fleet salt first, as sha256( "salt|kind|value" ).
 *
 * The fleet salt comes from the proxy's feed answer (POST /api/reputation/feed with share: true;
 * there is no receive-only mode). S6E adds the signature check and uses the feed's entries; S6D only
 * reads the salt from it.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

use FFL_Firewall\Proxy\Client;
use FFL_Firewall\Settings\Repository;

defined( 'ABSPATH' ) || exit;

/**
 * Cron flush of the buffer.
 */
class Reputation_Reporter {

	const CRON     = 'fflfw_reputation_flush';
	const SCHEDULE = 'fflfw_15min';
	const STATE    = 'fflfw_reputation_state';
	const BATCH    = 200;
	const BATCHES  = 3;
	/** The proxy takes up to 20 unblocks per call. */
	const UNBLOCK_BATCH = 20;
	/** Re-read the salt at least this often. */
	const SALT_TTL = 86400;
	/** Ops drops reports older than 8 days; stay inside that. */
	const MAX_AGE = 604800;
	/** Paused when nothing has gone through for this long. */
	const PAUSE_AFTER = 172800;

	/**
	 * Proxy client.
	 *
	 * @var Client
	 */
	private $client;

	/**
	 * Opt-in.
	 *
	 * @var Feed_Optin
	 */
	private $optin;

	/**
	 * Buffer.
	 *
	 * @var Reputation_Buffer
	 */
	private $buffer;

	/**
	 * Clock override for tests.
	 *
	 * @var int|null
	 */
	public static $now = null;

	/**
	 * Constructor.
	 *
	 * @param Client                 $client Proxy client.
	 * @param Feed_Optin|null        $optin  Opt-in.
	 * @param Reputation_Buffer|null $buffer Buffer.
	 */
	public function __construct( Client $client, ?Feed_Optin $optin = null, ?Reputation_Buffer $buffer = null ) {
		$this->client = $client;
		$this->optin  = $optin ? $optin : new Feed_Optin();
		$this->buffer = $buffer ? $buffer : new Reputation_Buffer();
	}

	/**
	 * Hooks: the feed-on filter, the 15-minute schedule and the flush.
	 *
	 * @return void
	 */
	public function register() {
		add_filter( 'fflfw_reputation_feed_on', array( $this->optin, 'filter' ) );
		add_filter( 'cron_schedules', array( __CLASS__, 'schedules' ) ); // phpcs:ignore WordPress.WP.CronInterval.CronSchedulesInterval -- 15 minutes on purpose.
		add_action( self::CRON, array( $this, 'flush' ) );
		add_action( 'init', array( $this, 'schedule' ) );
	}

	/**
	 * Add the 15-minute interval.
	 *
	 * @param array<string, array<string, mixed>> $s Schedules.
	 * @return array<string, array<string, mixed>>
	 */
	public static function schedules( $s ) {
		$s                   = is_array( $s ) ? $s : array();
		$s[ self::SCHEDULE ] = array(
			'interval' => 900,
			'display'  => 'Every 15 minutes (FFL Firewall)',
		);
		return $s;
	}

	/**
	 * Current time.
	 *
	 * @return int
	 */
	private static function now() {
		return null !== self::$now ? (int) self::$now : time();
	}

	/**
	 * Keep the flush scheduled while the feed works, and none otherwise.
	 *
	 * @return void
	 */
	public function schedule() {
		try {
			$next = wp_next_scheduled( self::CRON );
			if ( $this->optin->effective() ) {
				if ( ! $next ) {
					wp_schedule_event( self::now() + 300, self::SCHEDULE, self::CRON );
				}
			} elseif ( $next ) {
				wp_clear_scheduled_hook( self::CRON );
			}
		} catch ( \Throwable $e ) {
			return;
		}
	}

	/**
	 * Stored sync state.
	 *
	 * @return array<string, mixed>
	 */
	public static function state() {
		$s = get_option( self::STATE, array() );
		$s = is_array( $s ) ? $s : array();
		return array_merge(
			array(
				'salt'       => '',
				'salt_id'    => '',
				'salt_at'    => 0,
				'last_ok'    => 0,
				'last_try'   => 0,
				'first_try'  => 0,
				'last_error' => '',
			),
			$s
		);
	}

	/**
	 * Save part of the state.
	 *
	 * @param array<string, mixed> $patch Changes.
	 * @return void
	 */
	private static function patch( $patch ) {
		update_option( self::STATE, array_merge( self::state(), $patch ), false );
	}

	/**
	 * Whether the feed step should show as paused: joined and working, but nothing has gone through
	 * for 48 hours.
	 *
	 * @return bool
	 */
	public static function paused() {
		$s   = self::state();
		$ref = $s['last_ok'] ? (int) $s['last_ok'] : (int) $s['first_try'];
		return $ref > 0 && (int) $s['last_try'] > 0 && ( self::now() - $ref ) > self::PAUSE_AFTER;
	}

	/**
	 * Forget the salt and sync state (feed turned off).
	 *
	 * @return void
	 */
	public static function reset() {
		delete_option( self::STATE );
	}

	/**
	 * Fleet salt and its id, read from the feed answer when missing or older than a day.
	 *
	 * @param string $key License key.
	 * @return array{0: string, 1: string}|null
	 */
	private function salt( $key ) {
		$s = self::state();
		if ( '' !== $s['salt'] && '' !== $s['salt_id'] && ( self::now() - (int) $s['salt_at'] ) < self::SALT_TTL ) {
			return array( $s['salt'], $s['salt_id'] );
		}
		$r = $this->client->reputation(
			'/api/reputation/feed',
			array(
				'license_key' => $key,
				'share'       => true,
			)
		);
		$payload = ( 200 === $r['code'] && ! empty( $r['json']['ok'] ) && isset( $r['json']['payload'] ) && is_string( $r['json']['payload'] ) )
			? json_decode( $r['json']['payload'], true )
			: null;
		if ( ! is_array( $payload ) || empty( $payload['salt'] ) || ! is_string( $payload['salt'] ) || empty( $payload['salt_id'] ) || ! preg_match( '/^[0-9a-f]{8,16}$/', (string) $payload['salt_id'] ) ) {
			self::patch( array( 'last_error' => $this->error_of( $r, 'salt' ) ) );
			return null;
		}
		self::patch(
			array(
				'salt'    => (string) $payload['salt'],
				'salt_id' => (string) $payload['salt_id'],
				'salt_at' => self::now(),
				'last_ok' => self::now(),
			)
		);
		return array( (string) $payload['salt'], (string) $payload['salt_id'] );
	}

	/**
	 * Short error name for the state.
	 *
	 * @param array<string, mixed> $r        Client answer.
	 * @param string               $fallback Fallback.
	 * @return string
	 */
	private function error_of( $r, $fallback ) {
		if ( isset( $r['json']['error'] ) && is_string( $r['json']['error'] ) ) {
			return substr( sanitize_key( $r['json']['error'] ), 0, 40 );
		}
		return $r['code'] ? 'http_' . (int) $r['code'] : $fallback . '_unreachable';
	}

	/**
	 * Send queued Not a bot review requests (S6F). Each group goes with the salt id its hashes were
	 * made with; the proxy withdraws this store's reports and queues an Ops review. Anything that
	 * doesn't go through stays queued for the next run (the local unblock already applies). Never
	 * throws.
	 *
	 * @return string 'none', 'ok', 'off' or an error code.
	 */
	public function send_unblocks() {
		try {
			if ( ! $this->optin->effective() ) {
				return 'off';
			}
			$groups = Reputation_Unblocks::pending();
			if ( ! $groups ) {
				return 'none';
			}
			$key   = (string) ( new Repository() )->get( 'license_key', '' );
			$state = 'ok';
			$calls = 0;
			foreach ( $groups as $salt_id => $rows ) {
				foreach ( array_chunk( $rows, self::UNBLOCK_BATCH, true ) as $chunk ) {
					if ( ++$calls > self::BATCHES ) {
						return $state;
					}
					$keys     = array_keys( $chunk );
					$unblocks = array();
					foreach ( $chunk as $row ) {
						$u = array(
							'kind' => (string) $row['k'],
							'h'    => (string) $row['h'],
						);
						if ( '' !== (string) $row['note'] ) {
							$u['note'] = (string) $row['note'];
						}
						$unblocks[] = $u;
					}
					$r = $this->client->reputation(
						'/api/reputation/report',
						array(
							'license_key' => $key,
							'salt_id'     => (string) $salt_id,
							'entries'     => array(),
							'unblocks'    => $unblocks,
						)
					);
					if ( 200 === $r['code'] && ! empty( $r['json']['ok'] ) ) {
						Reputation_Unblocks::mark( $keys, self::now() );
						continue;
					}
					$err = $this->error_of( $r, 'report' );
					if ( 'salt_rotated' === $err ) {
						// The fleet salt changed, so these hashes match nothing any more, here or in Ops.
						Reputation_Unblocks::remove( $keys );
						continue;
					}
					Reputation_Unblocks::mark( $keys, 0 );
					$state = $err;
				}
			}
			return $state;
		} catch ( \Throwable $e ) {
			return 'error';
		}
	}

	/**
	 * Send what is buffered. Never throws.
	 *
	 * @return array<string, mixed> Summary (for tests and the admin screen).
	 */
	public function flush() {
		try {
			if ( ! $this->optin->effective() ) {
				$this->buffer->clear();
				return array( 'sent' => 0, 'state' => 'off' );
			}
			$now = self::now();
			$s   = self::state();
			self::patch(
				array(
					'last_try'  => $now,
					'first_try' => $s['first_try'] ? $s['first_try'] : $now,
				)
			);
			$key = (string) ( new Repository() )->get( 'license_key', '' );
			// S6F: Not a bot review requests go first; they don't depend on the cached salt.
			$this->send_unblocks();
			$salt = $this->salt( $key );
			if ( null === $salt ) {
				return array( 'sent' => 0, 'state' => 'no_salt' );
			}
			$sent = 0;
			for ( $i = 0; $i < self::BATCHES; $i++ ) {
				$rows = $this->buffer->all();
				if ( ! $rows ) {
					break;
				}
				$keys    = array();
				$entries = array();
				foreach ( array_slice( $rows, 0, self::BATCH, true ) as $k => $row ) {
					$keys[] = $k;
					if ( (int) $row['last'] < $now - self::MAX_AGE ) {
						continue;
					}
					$entries[] = array(
						'kind'  => (string) $row['kind'],
						'h'     => hash( 'sha256', $salt[0] . '|' . $row['kind'] . '|' . $row['value'] ),
						'p'     => (string) $row['p'],
						'hits'  => (int) $row['hits'],
						'first' => max( (int) $row['first'], $now - self::MAX_AGE ),
						'last'  => (int) $row['last'],
					);
				}
				if ( ! $entries ) {
					$this->buffer->remove( $keys );
					continue;
				}
				$r = $this->client->reputation(
					'/api/reputation/report',
					array(
						'license_key' => $key,
						'salt_id'     => $salt[1],
						'entries'     => $entries,
					)
				);
				if ( 200 === $r['code'] && ! empty( $r['json']['ok'] ) ) {
					$this->buffer->remove( $keys );
					$sent += count( $entries );
					self::patch( array( 'last_ok' => $now, 'last_error' => '' ) );
					continue;
				}
				$err = $this->error_of( $r, 'report' );
				if ( 'salt_rotated' === $err ) {
					// Hashes made with the old salt are useless now; start again with the new one.
					$this->buffer->clear();
					self::patch( array( 'salt' => '', 'salt_id' => '', 'salt_at' => 0, 'last_error' => $err ) );
					return array( 'sent' => $sent, 'state' => $err );
				}
				if ( 'license_not_active' === $err ) {
					$this->buffer->clear();
				}
				// 503, 404, 429, timeouts and anything else: keep the buffer and retry next run.
				self::patch( array( 'last_error' => $err ) );
				return array( 'sent' => $sent, 'state' => $err );
			}
			return array( 'sent' => $sent, 'state' => 'ok' );
		} catch ( \Throwable $e ) {
			return array( 'sent' => 0, 'state' => 'error' );
		}
	}
}
