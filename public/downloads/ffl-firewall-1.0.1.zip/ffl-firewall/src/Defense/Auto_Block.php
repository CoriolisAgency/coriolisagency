<?php
/**
 * FFLFW-AD-AUTOBLOCK: ACTIVE DEFENSE acts on its own, as soon as it is active (dealer embed script
 * seen in the last 24 hours), on high-confidence behavior signals (Behavior_Signals). There is no
 * suggest-only phase (Paul, 2026-11-21 3:31 PM ET).
 *
 * Escalation for one matched subject: throttle, then challenge, then a timed block that expires
 * by itself.
 *   throttle  : THROTTLE_BUDGET requests per THROTTLE_WINDOW seconds, then 429 (one strike each).
 *   challenge : from CHALLENGE_AFTER strikes, a page that needs JavaScript to set a short-lived
 *               cookie; each challenge served without the cookie is one strike. A visitor with the
 *               cookie goes back to the throttle budget.
 *   block     : from BLOCK_AFTER strikes, 403 until the block ends (BLOCK_TTLS, longer for a repeat).
 *               When it ends the subject starts over at throttle.
 *
 * Never acted on: verified search and SEO crawlers (Crawler_Verify), and cart, checkout, my-account,
 * wp-admin, login, admin-ajax, the WooCommerce Store API and wc-ajax / wc-api requests. Fails open:
 * the gate closed, the dealer's off switch, a locally unblocked subject or any error means allow.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

defined( 'ABSPATH' ) || exit;

/**
 * Auto-block state, escalation and the dealer controls.
 */
class Auto_Block {

	const STATE      = 'fflfw_ad_state';
	const SWITCH_OPT = 'fflfw_ad_autoblock';
	const UNBLOCKED  = 'fflfw_ad_unblocked';
	const SECRET     = 'fflfw_ad_secret';
	const COOKIE     = 'fflfw_adc';

	const THROTTLE_BUDGET = 6;
	const THROTTLE_WINDOW = 60;
	const CHALLENGE_AFTER = 3;
	const BLOCK_AFTER     = 6;
	/** Timed block lengths: first, second, third and later. */
	const BLOCK_TTLS = array( 3600, 21600, 86400 );
	/** A subject with no hits for this long is forgotten. */
	const IDLE_FORGET = 604800;
	/** A dealer unblock keeps the subject off auto-block this long. */
	const UNBLOCK_TTL = 2592000;
	const MAX         = 500;

	const R_THROTTLE  = 'ad_auto_throttle';
	const R_CHALLENGE = 'ad_auto_challenge';
	const R_BLOCK     = 'ad_auto_block';

	/**
	 * Signals.
	 *
	 * @var Behavior_Signals
	 */
	private $signals;

	/**
	 * Constructor.
	 *
	 * @param Behavior_Signals|null $signals Signals.
	 */
	public function __construct( ?Behavior_Signals $signals = null ) {
		$this->signals = $signals ? $signals : new Behavior_Signals();
	}

	/**
	 * Current time.
	 *
	 * @return int
	 */
	private static function now() {
		return Counter::now();
	}

	/**
	 * Whether the dealer's auto-block switch is on (on unless the dealer turns it off).
	 *
	 * @return bool
	 */
	public static function is_on() {
		$s = get_option( self::SWITCH_OPT, array() );
		return ! ( is_array( $s ) && array_key_exists( 'on', $s ) && ! $s['on'] );
	}

	/**
	 * Save the dealer's switch.
	 *
	 * @param bool $on      On.
	 * @param int  $user_id User saving.
	 * @return void
	 */
	public static function set_on( $on, $user_id = 0 ) {
		update_option(
			self::SWITCH_OPT,
			array(
				'on'    => (bool) $on,
				'saved' => self::now(),
				'user'  => (int) $user_id,
			),
			false
		);
	}

	/**
	 * Whether ACTIVE DEFENSE is active right now: the same signal the gate reads (script seen in
	 * the last 24 hours). False on any error.
	 *
	 * @return bool
	 */
	public static function active() {
		try {
			return true === apply_filters( 'fflfw_active_defense_signal_seen', false );
		} catch ( \Throwable $e ) {
			return false;
		}
	}

	/**
	 * Path prefixes auto-block never acts on.
	 *
	 * @return array<int, string>
	 */
	public static function protected_prefixes() {
		$list = array( '/cart', '/checkout', '/my-account', '/wp-admin', '/wp-login.php', '/wp-json/wc/store', '/wc-api/', '/wp-json/wc/' );
		if ( function_exists( 'wc_get_page_permalink' ) ) {
			foreach ( array( 'cart', 'checkout', 'myaccount' ) as $page ) {
				$p = wp_parse_url( (string) wc_get_page_permalink( $page ), PHP_URL_PATH );
				if ( is_string( $p ) && '' !== trim( $p, '/' ) ) {
					$list[] = '/' . trim( strtolower( $p ), '/' );
				}
			}
		}
		$out = apply_filters( 'fflfw_ad_protected_paths', $list );
		return is_array( $out ) ? array_values( array_unique( array_merge( $list, array_map( 'strval', $out ) ) ) ) : $list;
	}

	/**
	 * Whether the request is on a path auto-block never acts on.
	 *
	 * @param Request $req Request.
	 * @return bool
	 */
	public static function protected_request( Request $req ) {
		$path = strtolower( rawurldecode( (string) $req->path ) );
		if ( false !== strpos( $path, 'admin-ajax.php' ) || false !== strpos( $path, 'wp-admin' ) ) {
			return true;
		}
		$query = strtolower( (string) $req->query );
		if ( preg_match( '/(^|&)(wc-ajax|wc-api)=/', $query ) ) {
			return true;
		}
		foreach ( self::protected_prefixes() as $prefix ) {
			$prefix = rtrim( strtolower( $prefix ), '/' );
			if ( '' !== $prefix && ( $path === $prefix || 0 === strpos( $path, $prefix . '/' ) || 0 === strpos( $path, $prefix . '?' ) || ( '.php' === substr( $prefix, -4 ) && 0 === strpos( $path, $prefix ) ) ) ) {
				return true;
			}
		}
		foreach ( array( 'is_cart', 'is_checkout', 'is_account_page' ) as $fn ) {
			if ( function_exists( $fn ) && call_user_func( $fn ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Decision for a front-end page request, or null to let it through. Any error lets it through.
	 *
	 * @param Request $req Request.
	 * @return array<string, mixed>|null
	 */
	public function decide( Request $req ) {
		try {
			if ( ! self::is_on() || ! self::active() || self::protected_request( $req ) ) {
				return null;
			}
			$m = $this->signals->match( $req );
			if ( null === $m || self::unblocked( $m['k'], $m['h'] ) ) {
				return null;
			}
			if ( Crawler_Verify::exempt( $req ) ) {
				return null;
			}
			return $this->escalate( $req, $m );
		} catch ( \Throwable $e ) {
			return null;
		}
	}

	/**
	 * Build a decision.
	 *
	 * @param string               $action throttle, challenge or block.
	 * @param int                  $retry  Seconds.
	 * @param array<string, mixed> $m      Matched subject.
	 * @return array<string, mixed>
	 */
	private static function decision( $action, $retry, $m ) {
		$reasons = array(
			'throttle'  => self::R_THROTTLE,
			'challenge' => self::R_CHALLENGE,
			'block'     => self::R_BLOCK,
		);
		return array(
			'action'      => $action,
			'status'      => 'block' === $action ? 403 : 429,
			'reason'      => $reasons[ $action ],
			'retry_after' => max( 0, (int) $retry ),
			'ad'          => array(
				'k' => (string) $m['k'],
				'h' => (string) $m['h'],
			),
		);
	}

	/**
	 * Escalate one matched subject.
	 *
	 * @param Request              $req Request.
	 * @param array<string, mixed> $m   Matched subject.
	 * @return array<string, mixed>|null
	 */
	private function escalate( Request $req, $m ) {
		$now   = self::now();
		$key   = $m['k'] . '|' . $m['h'];
		$all   = self::all();
		$e     = isset( $all[ $key ] ) ? $all[ $key ] : array(
			'k'       => $m['k'],
			'h'       => $m['h'],
			'strikes' => 0,
			'blocks'  => 0,
			'until'   => 0,
			'first'   => $now,
			'ip'      => '',
		);
		$e['last'] = $now;
		$e['ip']   = (string) $req->ip;

		if ( (int) $e['until'] > $now ) {
			self::put( $key, $e );
			return self::decision( 'block', (int) $e['until'] - $now, $m );
		}
		if ( (int) $e['until'] > 0 ) {
			// The timed block ended by itself: start over at throttle.
			$e['until']   = 0;
			$e['strikes'] = 0;
		}

		if ( (int) $e['strikes'] >= self::BLOCK_AFTER ) {
			$ttls         = self::BLOCK_TTLS;
			$ttl          = $ttls[ min( (int) $e['blocks'], count( $ttls ) - 1 ) ];
			$e['until']   = $now + $ttl;
			$e['blocks']  = (int) $e['blocks'] + 1;
			$e['strikes'] = 0;
			self::put( $key, $e );
			try {
				if ( function_exists( 'do_action' ) ) {
					do_action( 'fflfw_ad_timed_block', $e );
				}
			} catch ( \Throwable $x ) {
				unset( $x );
			}
			return self::decision( 'block', $ttl, $m );
		}

		if ( (int) $e['strikes'] >= self::CHALLENGE_AFTER && ! self::challenge_passed( $req, $key ) ) {
			++$e['strikes'];
			self::put( $key, $e );
			$d              = self::decision( 'challenge', 0, $m );
			$d['challenge'] = self::challenge_token( $key );
			return $d;
		}

		list( $n, $left ) = Counter::hit( 'adt', $key, self::THROTTLE_WINDOW );
		if ( $n <= self::THROTTLE_BUDGET ) {
			self::put( $key, $e );
			return null;
		}
		++$e['strikes'];
		self::put( $key, $e );
		return self::decision( 'throttle', $left, $m );
	}

	/**
	 * Secret for challenge cookies (a random value made once per site).
	 *
	 * @return string
	 */
	private static function secret() {
		$s = get_option( self::SECRET, '' );
		if ( ! is_string( $s ) || strlen( $s ) < 32 ) {
			$s = bin2hex( random_bytes( 32 ) );
			update_option( self::SECRET, $s, false );
		}
		return $s;
	}

	/**
	 * Challenge cookie value for a subject (good for the current and the previous hour).
	 *
	 * @param string $key    Subject key.
	 * @param int    $offset Hours back.
	 * @return string
	 */
	public static function challenge_token( $key, $offset = 0 ) {
		$slot = (int) floor( self::now() / 3600 ) - (int) $offset;
		return substr( hash_hmac( 'sha256', $key . '|' . $slot, self::secret() ), 0, 32 );
	}

	/**
	 * Whether the request carries a valid challenge cookie for the subject.
	 *
	 * @param Request $req Request.
	 * @param string  $key Subject key.
	 * @return bool
	 */
	private static function challenge_passed( Request $req, $key ) {
		$cookie = '';
		foreach ( explode( ';', (string) $req->header( 'cookie' ) ) as $part ) {
			$part = trim( $part );
			if ( 0 === strpos( $part, self::COOKIE . '=' ) ) {
				$cookie = substr( $part, strlen( self::COOKIE ) + 1 );
			}
		}
		if ( '' === $cookie ) {
			return false;
		}
		return hash_equals( self::challenge_token( $key ), $cookie ) || hash_equals( self::challenge_token( $key, 1 ), $cookie );
	}

	/**
	 * Challenge page markup: sets the cookie with JavaScript and reloads.
	 *
	 * @param string $token Cookie value.
	 * @return string
	 */
	public static function challenge_html( $token ) {
		$token = preg_replace( '/[^0-9a-f]/', '', (string) $token );
		$title = \FFL_Firewall\Admin\Autoblock_Copy::challenge_title();
		$body  = \FFL_Firewall\Admin\Autoblock_Copy::challenge_body();
		$nojs  = \FFL_Firewall\Admin\Autoblock_Copy::challenge_noscript();
		return '<!doctype html><html><head><meta charset="utf-8"><meta name="robots" content="noindex"><title>' . esc_html( $title ) . '</title></head><body>'
			. '<p>' . esc_html( $body ) . '</p><noscript><p>' . esc_html( $nojs ) . '</p></noscript>'
			. '<script>document.cookie="' . self::COOKIE . '=' . $token . '; path=/; max-age=3600; SameSite=Lax";setTimeout(function(){location.reload();},800);</script>'
			. '</body></html>';
	}

	/**
	 * All tracked subjects, with idle ones dropped.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public static function all() {
		$rows = get_option( self::STATE, array() );
		$rows = is_array( $rows ) ? $rows : array();
		$now  = self::now();
		foreach ( $rows as $k => $r ) {
			if ( ! is_array( $r ) || ( $now - (int) ( isset( $r['last'] ) ? $r['last'] : 0 ) ) > self::IDLE_FORGET && (int) ( isset( $r['until'] ) ? $r['until'] : 0 ) <= $now ) {
				unset( $rows[ $k ] );
			}
		}
		return $rows;
	}

	/**
	 * Save one subject (newest kept when the list is full).
	 *
	 * @param string               $key Subject key.
	 * @param array<string, mixed> $e   Entry.
	 * @return void
	 */
	private static function put( $key, $e ) {
		$rows         = self::all();
		$rows[ $key ] = $e;
		if ( count( $rows ) > self::MAX ) {
			uasort(
				$rows,
				function ( $a, $b ) {
					return (int) $b['last'] - (int) $a['last'];
				}
			);
			$rows = array_slice( $rows, 0, self::MAX, true );
		}
		update_option( self::STATE, $rows, false );
	}

	/**
	 * Timed blocks in force now, newest first.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function active_blocks() {
		$now = self::now();
		$out = array();
		foreach ( self::all() as $r ) {
			if ( (int) $r['until'] > $now ) {
				$out[] = $r;
			}
		}
		usort(
			$out,
			function ( $a, $b ) {
				return (int) $b['until'] - (int) $a['until'];
			}
		);
		return $out;
	}

	/**
	 * Dealer unblock: drop the subject's state right away and keep it off auto-block for UNBLOCK_TTL.
	 *
	 * @param string $k Kind.
	 * @param string $h Hash.
	 * @return bool Whether the subject was valid.
	 */
	public static function unblock( $k, $h ) {
		$k = (string) $k;
		$h = strtolower( (string) $h );
		if ( ! Behavior_Signals::valid( $k, $h ) ) {
			return false;
		}
		$key  = $k . '|' . $h;
		$rows = self::all();
		unset( $rows[ $key ] );
		update_option( self::STATE, $rows, false );
		$u         = get_option( self::UNBLOCKED, array() );
		$u         = is_array( $u ) ? $u : array();
		$u[ $key ] = self::now();
		arsort( $u );
		update_option( self::UNBLOCKED, array_slice( $u, 0, self::MAX, true ), false );
		return true;
	}

	/**
	 * Whether the dealer unblocked the subject recently.
	 *
	 * @param string $k Kind.
	 * @param string $h Hash.
	 * @return bool
	 */
	public static function unblocked( $k, $h ) {
		$u   = get_option( self::UNBLOCKED, array() );
		$key = $k . '|' . $h;
		return is_array( $u ) && isset( $u[ $key ] ) && ( self::now() - (int) $u[ $key ] ) < self::UNBLOCK_TTL;
	}

	/**
	 * This month's auto-block counts from the local monthly panel.
	 *
	 * @return array{throttle: int, challenge: int, block: int}
	 */
	public static function month_counts() {
		$months = ( new Monthly() )->all();
		$key    = Monthly::month_key( self::now() );
		$r      = isset( $months[ $key ]['r'] ) && is_array( $months[ $key ]['r'] ) ? $months[ $key ]['r'] : array();
		return array(
			'throttle'  => isset( $r[ self::R_THROTTLE ] ) ? (int) $r[ self::R_THROTTLE ] : 0,
			'challenge' => isset( $r[ self::R_CHALLENGE ] ) ? (int) $r[ self::R_CHALLENGE ] : 0,
			'block'     => isset( $r[ self::R_BLOCK ] ) ? (int) $r[ self::R_BLOCK ] : 0,
		);
	}

	/**
	 * Forget everything (uninstall).
	 *
	 * @return void
	 */
	public static function clear() {
		delete_option( self::STATE );
		delete_option( self::SWITCH_OPT );
		delete_option( self::UNBLOCKED );
		delete_option( self::SECRET );
	}
}
