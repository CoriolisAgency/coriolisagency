<?php
/**
 * ACTIVE DEFENSE settings (their own option, so saving the checkout settings never touches them).
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

defined( 'ABSPATH' ) || exit;

/**
 * Reads, sanitizes and saves the fflfw_defense option.
 */
class Config {

	const OPTION = 'fflfw_defense';

	/**
	 * Defaults. The master switch is on when you install the plugin. The countermeasures
	 * start together once the license is active and the script signal has been seen (see Gate).
	 *
	 * @return array<string, mixed>
	 */
	public static function defaults() {
		return array(
			'enabled'         => true,
			'message'         => self::default_message(),
			'allow_ips'       => array(),
			'trusted_proxies' => array(),
			'rate_limit'      => array(
				'enabled' => true,
				'max'     => 120,
				'window'  => 60,
			),
			'agent_check'     => array( 'enabled' => true ),
			'honeypot'        => array( 'enabled' => true ),
			'velocity'        => array(
				'enabled'        => true,
				'attempt_max'    => 8,
				'attempt_window' => 600,
				'fail_max'       => 3,
				'fail_window'    => 3600,
				'small_max'      => 3,
				'small_window'   => 900,
				'small_amount'   => 5.0,
			),
			'datacenter'      => array( 'enabled' => true ),
		);
	}

	/**
	 * Default shopper message when ACTIVE DEFENSE stops a checkout (Paul, 2026-11-19 11:36 AM ET).
	 *
	 * @return string
	 */
	public static function default_message() {
		return __( "We couldn't complete checkout. Please try again in a moment.", 'ffl-firewall' );
	}

	/**
	 * The message shoppers see when a checkout is stopped (the saved text, or the default).
	 *
	 * @return string
	 */
	public function message() {
		$m = $this->get( 'message' );
		return is_string( $m ) && '' !== trim( $m ) ? $m : self::default_message();
	}

	/**
	 * Current config merged over defaults.
	 *
	 * @return array<string, mixed>
	 */
	public function all() {
		$stored   = get_option( self::OPTION, array() );
		$stored   = is_array( $stored ) ? $stored : array();
		$defaults = self::defaults();
		$merged   = array_merge( $defaults, $stored );
		foreach ( array( 'rate_limit', 'agent_check', 'honeypot', 'velocity', 'datacenter' ) as $group ) {
			$part             = isset( $stored[ $group ] ) && is_array( $stored[ $group ] ) ? $stored[ $group ] : array();
			$merged[ $group ] = array_merge( $defaults[ $group ], $part );
		}
		return $merged;
	}

	/**
	 * One top-level value.
	 *
	 * @param string $key Key.
	 * @return mixed
	 */
	public function get( $key ) {
		$all = $this->all();
		return array_key_exists( $key, $all ) ? $all[ $key ] : null;
	}

	/**
	 * One countermeasure's settings.
	 *
	 * @param string $group Group key.
	 * @return array<string, mixed>
	 */
	public function group( $group ) {
		$all = $this->all();
		return isset( $all[ $group ] ) && is_array( $all[ $group ] ) ? $all[ $group ] : array();
	}

	/**
	 * Whether one countermeasure is switched on (it also needs the gate to be open).
	 *
	 * @param string $group Group key.
	 * @return bool
	 */
	public function on( $group ) {
		$g = $this->group( $group );
		return ! empty( $g['enabled'] );
	}

	/**
	 * Sanitize raw input into a full config. Missing or out-of-range values fall back to the defaults.
	 *
	 * @param array<string, mixed> $raw Input.
	 * @return array<string, mixed>
	 */
	public function sanitize( $raw ) {
		$raw = is_array( $raw ) ? $raw : array();
		$d   = self::defaults();
		$out = array( 'enabled' => ! empty( $raw['enabled'] ) );

		$message        = isset( $raw['message'] ) && is_string( $raw['message'] ) ? sanitize_textarea_field( $raw['message'] ) : '';
		$out['message'] = '' === trim( $message ) ? self::default_message() : substr( $message, 0, 500 );

		foreach ( array( 'allow_ips', 'trusted_proxies' ) as $list ) {
			$out[ $list ] = array();
			$items        = isset( $raw[ $list ] ) ? $raw[ $list ] : array();
			$items        = is_array( $items ) ? $items : preg_split( '/[\s,]+/', (string) $items );
			foreach ( $items as $item ) {
				$item = trim( (string) $item );
				$base = false !== strpos( $item, '/' ) ? substr( $item, 0, strpos( $item, '/' ) ) : $item;
				if ( '' !== $item && '' !== Ip::normalize( $base ) ) {
					$out[ $list ][] = $item;
				}
			}
			$out[ $list ] = array_slice( array_values( array_unique( $out[ $list ] ) ), 0, 200 );
		}

		$ints = array(
			'rate_limit' => array(
				'max'    => array( 10, 10000 ),
				'window' => array( 10, 3600 ),
			),
			'velocity'   => array(
				'attempt_max'    => array( 2, 100 ),
				'attempt_window' => array( 60, 86400 ),
				'fail_max'       => array( 1, 50 ),
				'fail_window'    => array( 60, 86400 ),
				'small_max'      => array( 2, 50 ),
				'small_window'   => array( 60, 86400 ),
			),
		);
		foreach ( array( 'rate_limit', 'agent_check', 'honeypot', 'velocity', 'datacenter' ) as $group ) {
			$in            = isset( $raw[ $group ] ) && is_array( $raw[ $group ] ) ? $raw[ $group ] : array();
			$out[ $group ] = array( 'enabled' => array_key_exists( 'enabled', $in ) ? ! empty( $in['enabled'] ) : $d[ $group ]['enabled'] );
			foreach ( isset( $ints[ $group ] ) ? $ints[ $group ] : array() as $key => $bounds ) {
				$v                     = isset( $in[ $key ] ) ? (int) $in[ $key ] : $d[ $group ][ $key ];
				$out[ $group ][ $key ] = ( $v >= $bounds[0] && $v <= $bounds[1] ) ? $v : $d[ $group ][ $key ];
			}
		}
		$amount                          = ( isset( $raw['velocity']['small_amount'] ) && is_numeric( $raw['velocity']['small_amount'] ) ) ? (float) $raw['velocity']['small_amount'] : $d['velocity']['small_amount'];
		$out['velocity']['small_amount'] = ( $amount >= 0 && $amount <= 1000 ) ? $amount : $d['velocity']['small_amount'];

		return $out;
	}

	/**
	 * Save sanitized config.
	 *
	 * @param array<string, mixed> $config Sanitized config.
	 * @return void
	 */
	public function save( $config ) {
		update_option( self::OPTION, $config, false );
	}
}
