<?php
/**
 * IP helpers for ACTIVE DEFENSE.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

defined( 'ABSPATH' ) || exit;

/**
 * Address checks. IPv4 supports ranges (a.b.c.d/n); IPv6 matches exact addresses only.
 */
class Ip {

	/**
	 * Normalize an address: trims, and unwraps IPv4-mapped IPv6. Returns '' when it isn't an address.
	 *
	 * @param string $ip Raw address.
	 * @return string
	 */
	public static function normalize( $ip ) {
		$ip = trim( (string) $ip );
		if ( 0 === stripos( $ip, '::ffff:' ) && false !== filter_var( substr( $ip, 7 ), FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
			$ip = substr( $ip, 7 );
		}
		return false !== filter_var( $ip, FILTER_VALIDATE_IP ) ? strtolower( $ip ) : '';
	}

	/**
	 * Whether the address is a public one (not private, loopback or reserved).
	 *
	 * @param string $ip Address.
	 * @return bool
	 */
	public static function is_public( $ip ) {
		return '' !== $ip && false !== filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE );
	}

	/**
	 * IPv4 address as an unsigned integer, or null.
	 *
	 * @param string $ip Address.
	 * @return int|null
	 */
	public static function v4_int( $ip ) {
		if ( false === filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
			return null;
		}
		$n = ip2long( $ip );
		return false === $n ? null : (int) sprintf( '%u', $n );
	}

	/**
	 * Whether the address matches any entry (exact address or IPv4 range).
	 *
	 * @param string            $ip      Address.
	 * @param array<int,string> $entries Entries.
	 * @return bool
	 */
	public static function in_list( $ip, $entries ) {
		$ip = self::normalize( $ip );
		if ( '' === $ip || ! is_array( $entries ) ) {
			return false;
		}
		$n = self::v4_int( $ip );
		foreach ( $entries as $entry ) {
			$entry = trim( (string) $entry );
			if ( '' === $entry ) {
				continue;
			}
			if ( false !== strpos( $entry, '/' ) ) {
				list( $base, $bits ) = explode( '/', $entry, 2 );
				$b                   = self::v4_int( trim( $base ) );
				$bits                = (int) $bits;
				if ( null === $n || null === $b || $bits < 0 || $bits > 32 ) {
					continue;
				}
				$mask = 0 === $bits ? 0 : ( ( 0xFFFFFFFF << ( 32 - $bits ) ) & 0xFFFFFFFF );
				if ( ( $n & $mask ) === ( $b & $mask ) ) {
					return true;
				}
			} elseif ( self::normalize( $entry ) === $ip ) {
				return true;
			}
		}
		return false;
	}
}
