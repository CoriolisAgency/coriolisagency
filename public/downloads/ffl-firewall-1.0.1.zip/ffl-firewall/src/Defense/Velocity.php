<?php
/**
 * Checkout velocity and card-testing blocks.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

defined( 'ABSPATH' ) || exit;

/**
 * Counts, per address: checkout attempts, failed payments and runs of small orders. Past a
 * limit, further checkout attempts from that address are refused until the window ends.
 */
class Velocity {

	/**
	 * Settings group.
	 *
	 * @var array<string, mixed>
	 */
	private $cfg;

	/**
	 * Constructor.
	 *
	 * @param array<string, mixed> $cfg Group settings.
	 */
	public function __construct( $cfg ) {
		$this->cfg = $cfg;
	}

	/**
	 * Count a checkout attempt and decide. Returns array( reason, seconds ) or null to let it through.
	 *
	 * @param Request $req Request.
	 * @return array{0:string,1:int}|null
	 */
	public function check( Request $req ) {
		if ( ! $req->ip_usable() ) {
			return null;
		}
		list( $fails, $fail_left ) = Counter::peek( 'fail', $req->ip, (int) $this->cfg['fail_window'] );
		if ( $fails >= (int) $this->cfg['fail_max'] ) {
			return array( 'velocity_failed_payments', $fail_left );
		}
		list( $small, $small_left ) = Counter::peek( 'small', $req->ip, (int) $this->cfg['small_window'] );
		if ( $small >= (int) $this->cfg['small_max'] ) {
			return array( 'velocity_small_orders', $small_left );
		}
		list( $n, $left ) = Counter::hit( 'attempt', $req->ip, (int) $this->cfg['attempt_window'] );
		if ( $n > (int) $this->cfg['attempt_max'] ) {
			return array( 'velocity_attempts', $left );
		}
		return null;
	}

	/**
	 * Record a failed payment for an address.
	 *
	 * @param string $ip Address.
	 * @return void
	 */
	public function record_failure( $ip ) {
		$ip = Ip::normalize( $ip );
		if ( Ip::is_public( $ip ) ) {
			Counter::hit( 'fail', $ip, (int) $this->cfg['fail_window'] );
		}
	}

	/**
	 * Record a placed order; only small ones count.
	 *
	 * @param string $ip    Address.
	 * @param float  $total Order total.
	 * @return void
	 */
	public function record_order( $ip, $total ) {
		$ip = Ip::normalize( $ip );
		if ( Ip::is_public( $ip ) && (float) $total <= (float) $this->cfg['small_amount'] ) {
			Counter::hit( 'small', $ip, (int) $this->cfg['small_window'] );
		}
	}
}
