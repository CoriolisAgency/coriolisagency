<?php
/**
 * The ACTIVE DEFENSE gate: everything stays fully off until all three hold.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

use FFL_Firewall\Settings\Repository;

defined( 'ABSPATH' ) || exit;

/**
 * Open only when the service is switched on, the license is active and the dealer embed script
 * signal has been seen. The signal is supplied through the fflfw_active_defense_signal_seen
 * filter, which answers false until the activation step wires it in.
 */
class Gate {

	/**
	 * Settings.
	 *
	 * @var Repository
	 */
	private $settings;

	/**
	 * Config.
	 *
	 * @var Config
	 */
	private $config;

	/**
	 * Constructor.
	 *
	 * @param Repository $settings Settings.
	 * @param Config     $config   Config.
	 */
	public function __construct( Repository $settings, Config $config ) {
		$this->settings = $settings;
		$this->config   = $config;
	}

	/**
	 * Whether the countermeasures may run. Any error means closed (nothing is blocked).
	 *
	 * @return bool
	 */
	public function open() {
		try {
			if ( true !== $this->config->get( 'enabled' ) ) {
				return false;
			}
			if ( 'active' !== $this->settings->license_status() ) {
				return false;
			}
			return true === apply_filters( 'fflfw_active_defense_signal_seen', false );
		} catch ( \Throwable $e ) {
			return false;
		}
	}
}
