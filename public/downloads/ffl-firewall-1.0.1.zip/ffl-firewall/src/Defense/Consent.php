<?php
/**
 * The dealer's consent to the ACTIVE DEFENSE embed data disclosure.
 *
 * Stored in its own option as array( 'v' => disclosure version, 'at' => unix time (UTC) the box was
 * ticked, 'user' => id of the user who ticked it ). The ACTIVE DEFENSE embed no longer requires a
 * consent record (FFLFW-AD-DEFAULT-ON, C2); the disclosure lives in the install notice and in paragraph().
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

defined( 'ABSPATH' ) || exit;

/**
 * Consent record and its disclosure copy.
 */
class Consent {

	const OPTION = 'fflfw_defense_consent';

	/**
	 * Disclosure version. Stays 1: only the wording changed (Paul, 2026-11-19 1:36 PM ET, "Keep consent
	 * v1 valid; only the wording changes"), so existing installs are not asked to tick again.
	 */
	const VERSION = 1;

	/**
	 * Admin-page paragraph: Brandy's S6D.18 disclosure v2 naming Coriolis, LLC (Paul 1:35 PM ET "Switch
	 * the disclosure to Coriolis, LLC"; copy approved as written 1:41 PM ET).
	 *
	 * @return string
	 */
	public static function paragraph() {
		return __( "While FFL Firewall · ACTIVE DEFENSE is on, the dealer embed script loads from gunsearchengine.com, which is operated by Coriolis, LLC; it receives each visitor's IP address and keeps a record of each visit, including the pages and products they view, any email address they enter, their browser and approximate city, and hashes of their IP address rather than the raw value. FFL Firewall · ACTIVE DEFENSE switches on when you install the plugin, and you can turn it off at any time. On a new install, while it's on and your license is active, your store is also in the shared reputation feed by default (if FFL Firewall was already installed, your feed setting stays as it was, and if you never made a choice, the feed stays off until you switch it on), so it sends Coriolis, LLC reports on the bots caught here and uses the shared list built from other stores' reports. Coriolis, LLC uses those reports to build the shared list. Each report is deleted 30 days after it was last seen, a record on the shared list is kept about 37 days and a reviewed record 180 days; deletion runs only when new reports come in, so records can stay longer when reports are quiet. To stop sharing, untick \"Join the shared reputation feed\" in the Shared reputation feed section of this tab and click \"Save feed setting\".", 'ffl-firewall' );
	}

	/**
	 * Checkbox label (S6D.18, same approval).
	 *
	 * @return string
	 */
	public static function label() {
		return __( 'I understand that when FFL Firewall · ACTIVE DEFENSE is on, the dealer embed script loads from gunsearchengine.com, operated by Coriolis, LLC, which receives visitors\' IP addresses and keeps a record of each visit, including the pages and products they view, any email address they enter, their browser and approximate city, and hashes of their IP addresses, and that my store is in the shared reputation feed unless I switch it off.', 'ffl-firewall' );
	}

	/**
	 * Stored record, or an empty array.
	 *
	 * @return array<string, int>
	 */
	public function record() {
		$r = get_option( self::OPTION, array() );
		if ( ! is_array( $r ) || empty( $r['at'] ) ) {
			return array();
		}
		return array(
			'v'    => isset( $r['v'] ) ? (int) $r['v'] : self::VERSION,
			'at'   => (int) $r['at'],
			'user' => isset( $r['user'] ) ? (int) $r['user'] : 0,
		);
	}

	/**
	 * Whether consent has been given.
	 *
	 * @return bool
	 */
	public function given() {
		$r = $this->record();
		return ! empty( $r['at'] );
	}

	/**
	 * Unix time consent was given, or 0.
	 *
	 * @return int
	 */
	public function at() {
		$r = $this->record();
		return isset( $r['at'] ) ? $r['at'] : 0;
	}

	/**
	 * Record consent now. An existing record is kept as it is.
	 *
	 * @param int $user_id User who ticked the box.
	 * @return void
	 */
	public function record_now( $user_id ) {
		if ( $this->given() ) {
			return;
		}
		update_option(
			self::OPTION,
			array(
				'v'    => self::VERSION,
				'at'   => time(),
				'user' => (int) $user_id,
			),
			false
		);
	}

	/**
	 * Withdraw consent.
	 *
	 * @return void
	 */
	public function clear() {
		delete_option( self::OPTION );
	}
}
