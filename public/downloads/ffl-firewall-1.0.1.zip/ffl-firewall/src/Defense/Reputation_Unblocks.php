<?php
/**
 * Not a bot (S6F): the dealer's local unblocks of shared-feed subjects, and the queue of review
 * requests still to reach Coriolis.
 *
 * The unblock is local and instant: once a hashed subject is here, the feed step stops matching it
 * on this store. The report to Coriolis (proxy POST /api/reputation/report with `unblocks`)
 * withdraws this store's own reports and queues an Ops review. Only an Ops admin can take a
 * subject off the network list; nothing here changes the list for other stores.
 *
 * Only hashes are kept (kind, salted subject hash, salt id), plus the dealer's optional note.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

defined( 'ABSPATH' ) || exit;

/**
 * Unblock list in one option, keyed "kind|hash".
 */
class Reputation_Unblocks {

	const OPTION   = 'fflfw_reputation_unblocks';
	const MAX      = 500;
	const NOTE_MAX = 200;
	const KINDS    = array( 'ip', 'ip6net', 'ua' );

	/**
	 * All rows: "k|h" => { k, h, salt_id, note, at, sent, tries }.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public static function all() {
		$rows = get_option( self::OPTION, array() );
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Whether a kind and hash look right.
	 *
	 * @param string $kind Kind.
	 * @param string $hash Hash.
	 * @return bool
	 */
	public static function valid( $kind, $hash ) {
		return in_array( (string) $kind, self::KINDS, true ) && 1 === preg_match( '/^[0-9a-f]{64}$/', (string) $hash );
	}

	/**
	 * Clean a dealer note: plain text, one line, at most 200 characters.
	 *
	 * @param mixed $note Raw note.
	 * @return string
	 */
	public static function clean_note( $note ) {
		$note = is_string( $note ) ? sanitize_textarea_field( $note ) : '';
		$note = trim( (string) preg_replace( '/[\x00-\x1F\x7F\s]+/u', ' ', $note ) );
		return function_exists( 'mb_substr' ) ? mb_substr( $note, 0, self::NOTE_MAX, 'UTF-8' ) : substr( $note, 0, self::NOTE_MAX );
	}

	/**
	 * One row, or null.
	 *
	 * @param string $kind Kind.
	 * @param string $hash Hash.
	 * @return array<string, mixed>|null
	 */
	public static function get( $kind, $hash ) {
		$rows = self::all();
		$key  = $kind . '|' . $hash;
		return isset( $rows[ $key ] ) && is_array( $rows[ $key ] ) ? $rows[ $key ] : null;
	}

	/**
	 * Whether the dealer unblocked this subject here.
	 *
	 * @param string $kind Kind.
	 * @param string $hash Hash.
	 * @return bool
	 */
	public static function has( $kind, $hash ) {
		return null !== self::get( $kind, $hash );
	}

	/**
	 * Unblock a subject here and queue its review request.
	 *
	 * @param string $kind    Kind.
	 * @param string $hash    Hash.
	 * @param string $salt_id Salt the hash was made with.
	 * @param string $note    Dealer note (cleaned here).
	 * @param int    $now     Time.
	 * @return bool False when it was already unblocked or the input is bad.
	 */
	public static function add( $kind, $hash, $salt_id, $note, $now ) {
		if ( ! self::valid( $kind, $hash ) || self::has( $kind, $hash ) ) {
			return false;
		}
		$rows = self::all();
		$key  = $kind . '|' . $hash;

		$rows[ $key ] = array(
			'k'       => (string) $kind,
			'h'       => (string) $hash,
			'salt_id' => (string) $salt_id,
			'note'    => self::clean_note( $note ),
			'at'      => (int) $now,
			'sent'    => 0,
			'tries'   => 0,
		);
		if ( count( $rows ) > self::MAX ) {
			uasort(
				$rows,
				function ( $a, $b ) {
					return (int) $b['at'] - (int) $a['at'];
				}
			);
			$rows = array_slice( $rows, 0, self::MAX, true );
		}
		update_option( self::OPTION, $rows, false );
		return true;
	}

	/**
	 * Review requests that haven't reached Coriolis yet, grouped by salt id.
	 *
	 * @return array<string, array<string, array<string, mixed>>>
	 */
	public static function pending() {
		$out = array();
		foreach ( self::all() as $key => $row ) {
			if ( is_array( $row ) && empty( $row['sent'] ) && '' !== (string) $row['salt_id'] ) {
				$out[ (string) $row['salt_id'] ][ $key ] = $row;
			}
		}
		return $out;
	}

	/**
	 * Mark rows as sent, or count a failed try.
	 *
	 * @param array<int, string> $keys Row keys.
	 * @param int                $now  Time (0 = failed try).
	 * @return void
	 */
	public static function mark( $keys, $now ) {
		$rows = self::all();
		foreach ( $keys as $key ) {
			if ( isset( $rows[ $key ] ) ) {
				if ( $now > 0 ) {
					$rows[ $key ]['sent'] = (int) $now;
				} else {
					$rows[ $key ]['tries'] = (int) $rows[ $key ]['tries'] + 1;
				}
			}
		}
		update_option( self::OPTION, $rows, false );
	}

	/**
	 * Forget rows (their salt was rotated, so the hashes no longer mean anything).
	 *
	 * @param array<int, string> $keys Row keys.
	 * @return void
	 */
	public static function remove( $keys ) {
		$rows = self::all();
		foreach ( $keys as $key ) {
			unset( $rows[ $key ] );
		}
		update_option( self::OPTION, $rows, false );
	}

	/**
	 * Forget everything (feed turned off, uninstall).
	 *
	 * @return void
	 */
	public static function clear() {
		delete_option( self::OPTION );
	}
}
