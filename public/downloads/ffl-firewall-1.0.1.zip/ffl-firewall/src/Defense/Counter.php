<?php
/**
 * Fixed-window counters kept in transients. Keys are hashed, so no address is part of a key.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

defined( 'ABSPATH' ) || exit;

/**
 * Counter store.
 */
class Counter {

	/**
	 * Clock override for tests.
	 *
	 * @var int|null
	 */
	public static $now = null;

	/**
	 * Current time.
	 *
	 * @return int
	 */
	public static function now() {
		return null === self::$now ? time() : (int) self::$now;
	}

	/**
	 * Transient key.
	 *
	 * @param string $kind Counter kind.
	 * @param string $id   Subject (such as an address).
	 * @return string
	 */
	private static function key( $kind, $id ) {
		return 'fflfw_d_' . substr( hash( 'sha256', $kind . '|' . $id ), 0, 32 );
	}

	/**
	 * Add one to the counter and return the new count and the seconds left in the window.
	 *
	 * @param string $kind   Kind.
	 * @param string $id     Subject.
	 * @param int    $window Window in seconds.
	 * @return array{0:int,1:int} Count, seconds left.
	 */
	public static function hit( $kind, $id, $window ) {
		$window = max( 1, (int) $window );
		$key    = self::key( $kind, $id );
		$now    = self::now();
		$row    = get_transient( $key );
		if ( ! is_array( $row ) || ! isset( $row[0], $row[1] ) || $now - (int) $row[0] >= $window ) {
			$row = array( $now, 0 );
		}
		++$row[1];
		set_transient( $key, $row, $window );
		return array( (int) $row[1], max( 1, $window - ( $now - (int) $row[0] ) ) );
	}

	/**
	 * Current count without changing it.
	 *
	 * @param string $kind   Kind.
	 * @param string $id     Subject.
	 * @param int    $window Window in seconds.
	 * @return array{0:int,1:int} Count, seconds left.
	 */
	public static function peek( $kind, $id, $window ) {
		$window = max( 1, (int) $window );
		$row    = get_transient( self::key( $kind, $id ) );
		$now    = self::now();
		if ( ! is_array( $row ) || ! isset( $row[0], $row[1] ) || $now - (int) $row[0] >= $window ) {
			return array( 0, 0 );
		}
		return array( (int) $row[1], max( 1, $window - ( $now - (int) $row[0] ) ) );
	}
}
