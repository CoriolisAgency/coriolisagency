<?php
/**
 * Last-seen lookup through the Coriolis proxy. The proxy checks the license and holds the
 * secret for the read-only endpoint, so no shared secret ships inside the plugin.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

use FFL_Firewall\Proxy\Client;

defined( 'ABSPATH' ) || exit;

/**
 * Seen_Source backed by POST /api/embed-seen on the proxy.
 */
class Proxy_Seen_Source implements Seen_Source {

	/**
	 * Proxy client.
	 *
	 * @var Client
	 */
	private $client;

	/**
	 * Constructor.
	 *
	 * @param Client $client Proxy client.
	 */
	public function __construct( Client $client ) {
		$this->client = $client;
	}

	/**
	 * Site origin (scheme and host) the embed runs on.
	 *
	 * @return string
	 */
	public static function origin() {
		$parts = wp_parse_url( home_url() );
		if ( ! is_array( $parts ) || empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
			return '';
		}
		return strtolower( $parts['scheme'] . '://' . $parts['host'] . ( ! empty( $parts['port'] ) ? ':' . $parts['port'] : '' ) );
	}

	/**
	 * Look up the last-seen time.
	 *
	 * @param string $site_key Site key.
	 * @return array{ok: bool, last_seen: int|null}
	 */
	public function fetch( $site_key ) {
		$answer = $this->client->embed_seen( $site_key, self::origin() );
		$extra  = ( isset( $answer['script_url'] ) && is_string( $answer['script_url'] ) ) ? array( 'script_url' => $answer['script_url'] ) : array();
		if ( isset( $answer['behavior'] ) && is_array( $answer['behavior'] ) ) {
			$extra['behavior'] = $answer['behavior'];
		}
		if ( empty( $answer['ok'] ) || ! array_key_exists( 'last_seen_at', $answer ) ) {
			return array( 'ok' => false, 'last_seen' => null ) + $extra;
		}
		if ( null === $answer['last_seen_at'] ) {
			return array( 'ok' => true, 'last_seen' => null ) + $extra;
		}
		$ts = is_string( $answer['last_seen_at'] ) ? strtotime( $answer['last_seen_at'] ) : false;
		return false === $ts ? array( 'ok' => false, 'last_seen' => null ) + $extra : array( 'ok' => true, 'last_seen' => (int) $ts ) + $extra;
	}
}