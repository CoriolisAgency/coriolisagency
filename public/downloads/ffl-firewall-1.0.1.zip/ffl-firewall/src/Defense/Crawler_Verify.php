<?php
/**
 * FFLFW-CRAWLER-GRACE (Paul, 2026-11-23 11:25 AM ET): verified search and SEO crawlers are exempt
 * from every block path. That is the datacenter list, the user agent and header check, the rate
 * limit, ACTIVE DEFENSE auto-block, the shared reputation feed, and the checkout and form POST
 * checks (honeypot, velocity). FFLFW-AD-AUTOBLOCK started this list with four search crawlers.
 *
 * Verified means one of two things. Either the address is inside the crawler's own published IP
 * ranges (bundled in Crawler_Ranges, nothing fetched at request time), or reverse DNS names a host
 * under the crawler's domain and a forward lookup of that host returns the same address.
 *
 * A user agent alone is never enough. A request that claims a crawler and fails verification gets
 * no exemption, and neither does one whose lookup fails, is too slow or is over the lookup budget.
 * It goes through the normal checks (fail safe, not fail open).
 *
 * Bots with no way to verify them are listed in unverifiable() and never get the exemption.
 *
 * Page latency: verification only runs for a request that claims a crawler AND would otherwise be
 * blocked or slowed down (Guard asks last, Auto_Block asks before it acts). Verdicts are cached per
 * crawler family and address: verified and fake for CACHE_TTL, unverified for UNVERIFIED_TTL.
 * Range checks need no DNS. Uncached DNS verifications are capped at LOOKUP_BUDGET per
 * LOOKUP_WINDOW seconds for the whole site, and a lookup slower than SLOW_LOOKUP seconds turns DNS
 * verification off for SLOW_PAUSE seconds.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

defined( 'ABSPATH' ) || exit;

/**
 * User agent claim, then published ranges or reverse DNS plus forward-confirm.
 */
class Crawler_Verify {

	/** Verified and fake verdicts are kept this long. */
	const CACHE_TTL = 86400;

	/** An unverified verdict (no reverse name, lookup failed) is retried after this long. */
	const UNVERIFIED_TTL = 3600;

	/** Uncached DNS verifications allowed per window, for the whole site. */
	const LOOKUP_BUDGET = 20;

	/** Lookup budget window in seconds. */
	const LOOKUP_WINDOW = 60;

	/** A single lookup slower than this many seconds trips the breaker. */
	const SLOW_LOOKUP = 2.0;

	/** Seconds DNS verification stays off after a slow lookup. */
	const SLOW_PAUSE = 600;

	/** Transient that holds the slow-lookup breaker. */
	const SLOW_KEY = 'fflfw_adcv_slow';

	/**
	 * DNS resolver override for tests: callable( 'ptr'|'forward', string ): string|array|false.
	 *
	 * @var callable|null
	 */
	public static $resolver = null;

	/**
	 * Clock override for tests (seconds, float): callable(): float.
	 *
	 * @var callable|null
	 */
	public static $clock = null;

	/**
	 * User agent token (lowercase substring) => crawler family. Checked in this order.
	 *
	 * @return array<string, string>
	 */
	public static function tokens() {
		return array(
			'googlebot'             => 'google',
			'adsbot-google'         => 'google',
			'mediapartners-google'  => 'google',
			'storebot-google'       => 'google',
			'google-inspectiontool' => 'google',
			'googleother'           => 'google',
			'bingbot'               => 'bing',
			'bingpreview'           => 'bing',
			'msnbot'                => 'bing',
			'applebot'              => 'apple',
			'duckduckbot'           => 'duckduckgo',
			'yandexbot'             => 'yandex',
			'yandeximages'          => 'yandex',
			'baiduspider'           => 'baidu',
			'slurp'                 => 'yahoo',
			'petalbot'              => 'petal',
			'ahrefsbot'             => 'ahrefs',
			'ahrefssiteaudit'       => 'ahrefs',
			'semrushbot'            => 'semrush',
			'siteauditbot'          => 'semrush',
		);
	}

	/**
	 * Crawler family => host suffixes its reverse DNS names end with. Each operator documents these
	 * names, except Semrush, which documents none; its crawlers' reverse names end in .semrush.com
	 * and the forward-confirm step still has to pass. Published IP ranges for a family, where they
	 * exist, are in Crawler_Ranges.
	 *
	 * @return array<string, array<int, string>>
	 */
	public static function host_suffixes() {
		return array(
			'google'     => array( '.googlebot.com', '.google.com', '.googleusercontent.com' ),
			'bing'       => array( '.search.msn.com' ),
			'apple'      => array( '.applebot.apple.com' ),
			'duckduckgo' => array( '.duckduckgo.com' ),
			'yandex'     => array( '.yandex.ru', '.yandex.net', '.yandex.com' ),
			'baidu'      => array( '.baidu.com', '.baidu.jp' ),
			'yahoo'      => array( '.crawl.yahoo.net' ),
			'petal'      => array( '.petalsearch.com' ),
			'ahrefs'     => array( '.ahrefs.com', '.ahrefs.net' ),
			'semrush'    => array( '.semrush.com' ),
		);
	}

	/**
	 * Crawler token => reverse DNS suffixes (kept for callers of the earlier four-crawler list).
	 *
	 * @return array<string, array<int, string>>
	 */
	public static function crawlers() {
		$suffixes = self::host_suffixes();
		$out = array();
		foreach ( self::tokens() as $token => $family ) {
			$out[ $token ] = $suffixes[ $family ];
		}
		return $out;
	}

	/**
	 * SEO bots with no way to verify them. They get NO exemption: they go through the rate limit,
	 * auto-block, datacenter, honeypot and velocity checks like any visitor, because their user
	 * agent can be faked by anyone and nothing else can tell the real bot from a scraper using its name.
	 *   rogerbot, dotbot (Moz): Moz publishes no IP ranges and no reverse DNS names for them.
	 *   mj12bot (Majestic): a distributed crawler that runs on volunteers' machines, so it can come
	 *   from any address and has no ranges or DNS names to check.
	 * Link previewers on the Agent_Check allow list (facebookexternalhit, twitterbot, slackbot and
	 * the like) are in the same position: they only skip the header check, nothing else.
	 *
	 * @return array<int, string>
	 */
	public static function unverifiable() {
		return array( 'rogerbot', 'dotbot', 'mj12bot' );
	}

	/**
	 * Which verifiable crawler the user agent claims to be (its token), or ''.
	 *
	 * @param Request $req Request.
	 * @return string
	 */
	public static function claimed( Request $req ) {
		$ua = strtolower( (string) $req->user_agent );
		if ( '' === $ua ) {
			return '';
		}
		foreach ( array_keys( self::tokens() ) as $token ) {
			if ( false !== strpos( $ua, $token ) ) {
				return $token;
			}
		}
		return '';
	}

	/**
	 * Current time in seconds.
	 *
	 * @return float
	 */
	private static function clock() {
		return is_callable( self::$clock ) ? (float) call_user_func( self::$clock ) : microtime( true );
	}

	/**
	 * Run one lookup.
	 *
	 * @param string $type  ptr or forward.
	 * @param string $value Address or host.
	 * @return mixed
	 */
	private static function lookup( $type, $value ) {
		if ( is_callable( self::$resolver ) ) {
			return call_user_func( self::$resolver, $type, $value );
		}
		if ( 'ptr' === $type ) {
			return function_exists( 'gethostbyaddr' ) ? @gethostbyaddr( $value ) : false; // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- false on failure.
		}
		$out = function_exists( 'gethostbynamel' ) ? @gethostbynamel( $value ) : false; // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- false on failure.
		$out = is_array( $out ) ? $out : array();
		if ( function_exists( 'dns_get_record' ) && defined( 'DNS_AAAA' ) ) {
			$six = @dns_get_record( $value, DNS_AAAA ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- false on failure.
			foreach ( is_array( $six ) ? $six : array() as $r ) {
				if ( isset( $r['ipv6'] ) ) {
					$out[] = (string) $r['ipv6'];
				}
			}
		}
		return $out;
	}

	/**
	 * One lookup, timed: a slow one turns DNS verification off for SLOW_PAUSE seconds.
	 *
	 * @param string $type  ptr or forward.
	 * @param string $value Address or host.
	 * @return mixed
	 */
	private static function timed_lookup( $type, $value ) {
		$t0  = self::clock();
		$out = self::lookup( $type, $value );
		if ( self::clock() - $t0 > self::SLOW_LOOKUP ) {
			set_transient( self::SLOW_KEY, 1, self::SLOW_PAUSE );
		}
		return $out;
	}

	/**
	 * Whether one more uncached DNS verification may run now.
	 *
	 * @return bool
	 */
	private static function may_look_up() {
		if ( get_transient( self::SLOW_KEY ) ) {
			return false;
		}
		list( $n ) = Counter::hit( 'crawler_dns', 'site', self::LOOKUP_WINDOW );
		return $n <= self::LOOKUP_BUDGET;
	}

	/**
	 * Verdict for a request: none (claims no verifiable crawler), verified, unverified (could not be
	 * checked: no reverse name, lookup failed, slow or over budget) or fake (proven not to be the
	 * crawler it claims). Only verified is exempt.
	 *
	 * @param Request $req Request.
	 * @return string
	 */
	public static function verdict( Request $req ) {
		$token = self::claimed( $req );
		if ( '' === $token ) {
			return 'none';
		}
		try {
			$ip = Ip::normalize( (string) $req->ip );
			if ( '' === $ip || $req->ip_unclear ) {
				return 'unverified';
			}
			$family = self::tokens()[ $token ];
			$ck     = 'fflfw_adcv_' . substr( hash( 'sha256', $family . '|' . $ip ), 0, 24 );
			$cached = get_transient( $ck );
			if ( is_string( $cached ) && in_array( $cached, array( 'verified', 'unverified', 'fake' ), true ) ) {
				return $cached;
			}
			if ( Crawler_Ranges::contains( $family, $ip ) ) {
				set_transient( $ck, 'verified', self::CACHE_TTL );
				return 'verified';
			}
			if ( ! self::may_look_up() ) {
				return 'unverified';
			}
			$v = self::resolve( $family, $ip );
			set_transient( $ck, $v, 'unverified' === $v ? self::UNVERIFIED_TTL : self::CACHE_TTL );
			return $v;
		} catch ( \Throwable $e ) {
			return 'unverified';
		}
	}

	/**
	 * Reverse DNS then forward-confirm.
	 *
	 * @param string $family Crawler family.
	 * @param string $ip     Address.
	 * @return string
	 */
	private static function resolve( $family, $ip ) {
		$host = self::timed_lookup( 'ptr', $ip );
		if ( ! is_string( $host ) || '' === $host || $host === $ip ) {
			return 'unverified';
		}
		$host  = strtolower( rtrim( $host, '.' ) );
		$match = false;
		foreach ( self::host_suffixes()[ $family ] as $suffix ) {
			if ( substr( $host, -strlen( $suffix ) ) === $suffix ) {
				$match = true;
				break;
			}
		}
		if ( ! $match ) {
			return 'fake';
		}
		$ips = self::timed_lookup( 'forward', $host );
		if ( ! is_array( $ips ) || empty( $ips ) ) {
			return 'unverified';
		}
		$want = @inet_pton( $ip ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- false on failure.
		foreach ( $ips as $a ) {
			if ( false !== $want && @inet_pton( (string) $a ) === $want ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- false on failure.
				return 'verified';
			}
		}
		return 'fake';
	}

	/**
	 * Whether the request is a verified crawler that no check may block or slow down. A spoofed,
	 * unverified or unverifiable crawler is not exempt.
	 *
	 * @param Request $req Request.
	 * @return bool
	 */
	public static function exempt( Request $req ) {
		return 'verified' === self::verdict( $req );
	}
}
