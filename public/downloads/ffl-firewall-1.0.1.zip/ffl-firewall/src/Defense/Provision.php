<?php
/**
 * FFLFW-ONBOARD-SITEKEY: self-serve ACTIVE DEFENSE site key.
 *
 * When a store with an active (paid) license turns ACTIVE DEFENSE on with the data disclosure ticked
 * and has no site key, the plugin asks the proxy for one. The proxy checks the license with Stripe and
 * has GSE create the store's site key with this site's origin as its allowed origin. A key the dealer
 * pastes themselves always wins; a provisioned key is only re-checked when the dealer presses Check for
 * script. No new dealer-facing text: on any failure the tab stays as it is today (paste a key).
 *
 * FFLFW-ONBOARD-SITEKEY-CHECKOUT: the key itself is made at paid checkout (unbound, it serves nothing).
 * The first turn-on here, or the license turning active with ACTIVE DEFENSE on (maybe_fill), binds it to
 * this site's origin. First bind wins: a store on another host gets origin_mismatch and keeps the paste flow.
 *
 * FFLFW-SITEKEY-PROVISION-FIX: one shared, idempotent helper (ensure_key) binds the key on every path where
 * the license is active, ACTIVE DEFENSE is on and there is no key: the dealer saving an active license
 * (maybe_fill), the automatic 'unknown' to 'active' license recheck, plugin activation, and an admin_init
 * check that schedules a WP-Cron attempt (never a proxy call on the admin page itself). Automatic attempts
 * back off (5 min, 15 min, 1 h, then 6 h) and stop for an origin the proxy answered origin_mismatch for.
 * It fails open: any error leaves the store as it is (no key, paste flow) and never breaks a page.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

use FFL_Firewall\Proxy\Client;
use FFL_Firewall\Settings\Repository;

defined( 'ABSPATH' ) || exit;

/**
 * Asks the proxy for this store's site key.
 */
class Provision {

	/** Set while the saved site key is the one the proxy provisioned. */
	const AUTO = 'fflfw_defense_site_key_auto';

	/** FFLFW-SITEKEY-PROVISION-FIX: WP-Cron hook for an automatic attempt. */
	const CRON = 'fflfw_site_key_provision';

	/** FFLFW-SITEKEY-PROVISION-FIX: last automatic attempt (attempts, next_at, error, origin). */
	const STATE = 'fflfw_site_key_provision_state';

	/**
	 * Seconds to wait after attempt 1, 2, 3; the last value repeats.
	 *
	 * @var int[]
	 */
	const STEPS = array( 300, 900, 3600, 21600 );

	/**
	 * Clock override for tests.
	 *
	 * @var int|null
	 */
	public static $now = null;

	/**
	 * Proxy client.
	 *
	 * @var Client
	 */
	private $client;

	/**
	 * Settings.
	 *
	 * @var Repository
	 */
	private $settings;

	/**
	 * Constructor.
	 *
	 * @param Client     $client   Proxy client.
	 * @param Repository $settings Settings.
	 */
	public function __construct( Client $client, Repository $settings ) {
		$this->client   = $client;
		$this->settings = $settings;
	}

	/**
	 * Only a store whose license is active can ask.
	 *
	 * @return bool
	 */
	public function can_run() {
		return 'active' === $this->settings->license_status();
	}

	/**
	 * Ask the proxy for the site key (and the script address).
	 *
	 * @return array{key: string, script_url: string, error: string} Empty key when the proxy gave none; error
	 *         names why (the proxy's error, e.g. origin_mismatch, or not_run / proxy_error / bad_key / exception).
	 */
	public function fetch() {
		$out = array(
			'key'        => '',
			'script_url' => '',
			'error'      => '',
		);
		try {
			$origin = Proxy_Seen_Source::origin();
			if ( '' === $origin || ! $this->can_run() ) {
				$out['error'] = 'not_run';
				return $out;
			}
			$answer = $this->client->embed_provision( $origin );
			if ( ! is_array( $answer ) || empty( $answer['ok'] ) || ! isset( $answer['site_key'] ) || ! is_string( $answer['site_key'] ) ) {
				$out['error'] = is_array( $answer ) && isset( $answer['error'] ) && is_string( $answer['error'] ) ? sanitize_key( $answer['error'] ) : 'proxy_error';
				return $out;
			}
			$out['key']        = Embed::clean_key( $answer['site_key'] );
			$out['script_url'] = isset( $answer['script_url'] ) && is_string( $answer['script_url'] ) ? $answer['script_url'] : '';
			if ( '' === $out['key'] ) {
				$out['error'] = 'bad_key';
			}
		} catch ( \Throwable $e ) {
			$out['error'] = 'exception';
		}
		return $out;
	}

	/**
	 * Whether the saved key came from the proxy.
	 *
	 * @return bool
	 */
	public static function is_auto() {
		return (bool) get_option( self::AUTO, false );
	}

	/**
	 * Mark the saved key as provisioned, or not.
	 *
	 * @param bool $on On.
	 * @return void
	 */
	public static function mark_auto( $on ) {
		if ( $on ) {
			update_option( self::AUTO, 1, false );
		} else {
			delete_option( self::AUTO );
		}
	}

	/**
	 * After the license turns active (the dealer saved or checked it): fill the key when ACTIVE DEFENSE is
	 * already on, the disclosure is ticked and there is no key yet. Returns whether a key was saved.
	 * Dealer-initiated, so it skips the automatic backoff.
	 *
	 * @param Config $config Defense config.
	 * @param Embed  $embed  Embed.
	 * @return bool
	 */
	public function maybe_fill( Config $config, Embed $embed ) {
		return $this->ensure_key( $config, $embed, false );
	}

	/**
	 * FFLFW-SITEKEY-PROVISION-FIX: the consent-tick condition, kept as one named check.
	 * FFLFW-AD-DEFAULT-ON (C2: no tick, the disclosure lives in the install notice) drops this condition by
	 * making it return true or removing it from needed(); nothing else here depends on the tick.
	 *
	 * @return bool
	 */
	public static function consent_tick_given() {
		return ( new Consent() )->given();
	}

	/**
	 * Whether this store needs a key now: ACTIVE DEFENSE on, no key saved, license active.
	 * The consent tick is not a condition (FFLFW-AD-DEFAULT-ON, C2). Reads options only; never calls out.
	 *
	 * @param Config $config Defense config.
	 * @param Embed  $embed  Embed.
	 * @return bool
	 */
	public function needed( Config $config, Embed $embed ) {
		return true === $config->get( 'enabled' ) && '' === $embed->site_key() && $this->can_run();
	}

	/**
	 * The shared, idempotent helper: bind this store's key when needed() holds. Does nothing once a key
	 * exists, so calling it again (or from two paths) never asks twice for a bound store. Automatic callers
	 * honor the backoff and never retry an origin the proxy answered origin_mismatch for (first bind wins;
	 * the dealer can still paste a key, or press a save that asks again). Fails open: returns false on any
	 * error and never throws.
	 *
	 * @param Config $config    Defense config.
	 * @param Embed  $embed     Embed.
	 * @param bool   $automatic True for recheck, activation and cron paths.
	 * @return bool Whether a key was saved.
	 */
	public function ensure_key( Config $config, Embed $embed, $automatic = true ) {
		try {
			if ( ! $this->needed( $config, $embed ) ) {
				return false;
			}
			$origin = Proxy_Seen_Source::origin();
			$state  = self::state();
			if ( $automatic && ( self::held_for( $origin, $state ) || self::now() < self::next_at_for( $origin, $state ) ) ) {
				return false;
			}
			// Claim the attempt first, so an error or a slow answer never causes a quick repeat.
			$attempts = $state['attempts'] + 1;
			self::store_attempt( $attempts, self::now() + self::delay( $attempts - 1 ), 'pending', $origin );
			$got = $this->fetch();
			if ( '' === $got['key'] ) {
				self::store_attempt( $attempts, self::now() + self::delay( $attempts - 1 ), '' !== $got['error'] ? $got['error'] : 'provision_failed', $origin );
				return false;
			}
			if ( '' !== $embed->site_key() ) {
				// A key was saved while the proxy was answering (the dealer pasted one): it wins.
				self::reset();
				return false;
			}
			$embed->save_key( $got['key'] );
			if ( '' !== $got['script_url'] ) {
				$embed->save_script_url( $got['script_url'] );
			}
			self::mark_auto( true );
			self::reset();
			return true;
		} catch ( \Throwable $e ) {
			return false;
		}
	}

	/**
	 * Hooks: the cron attempt, and an admin_init check that only schedules it.
	 *
	 * @return void
	 */
	public function register() {
		add_action( self::CRON, array( $this, 'run' ) );
		add_action( 'admin_init', array( $this, 'schedule' ) );
	}

	/**
	 * Keep one attempt scheduled while a key is needed and not held, and none otherwise. No proxy call.
	 *
	 * @return void
	 */
	public function schedule() {
		try {
			$config = new Config();
			$embed  = new Embed( $config );
			if ( ! $this->needed( $config, $embed ) || self::held_for( Proxy_Seen_Source::origin(), self::state() ) ) {
				if ( false !== wp_next_scheduled( self::CRON ) ) {
					wp_clear_scheduled_hook( self::CRON );
				}
				return;
			}
			if ( ! wp_next_scheduled( self::CRON ) ) {
				wp_schedule_single_event( max( self::now(), self::next_at_for( Proxy_Seen_Source::origin(), self::state() ) ), self::CRON );
			}
		} catch ( \Throwable $e ) {
			return;
		}
	}

	/**
	 * One automatic attempt (WP-Cron). Returns whether a key was saved.
	 *
	 * @return bool
	 */
	public function run() {
		try {
			$config = new Config();
			$saved  = $this->ensure_key( $config, new Embed( $config ), true );
			wp_clear_scheduled_hook( self::CRON );
			if ( ! $saved ) {
				$this->schedule();
			}
			return $saved;
		} catch ( \Throwable $e ) {
			return false;
		}
	}

	/**
	 * Activation: queue one attempt right away (WP-Cron), so a store whose license is already active and
	 * ACTIVE DEFENSE is on binds its key at install without the activation request waiting on the proxy.
	 *
	 * @return void
	 */
	public static function activate() {
		try {
			if ( ! wp_next_scheduled( self::CRON ) ) {
				wp_schedule_single_event( self::now(), self::CRON );
			}
		} catch ( \Throwable $e ) {
			return;
		}
	}

	/**
	 * Deactivation: no event left behind.
	 *
	 * @return void
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( self::CRON );
	}

	/**
	 * Last automatic attempt.
	 *
	 * @return array{attempts: int, next_at: int, error: string, origin: string}
	 */
	public static function state() {
		$s = get_option( self::STATE, array() );
		$s = is_array( $s ) ? $s : array();
		return array(
			'attempts' => isset( $s['attempts'] ) ? max( 0, (int) $s['attempts'] ) : 0,
			'next_at'  => isset( $s['next_at'] ) ? (int) $s['next_at'] : 0,
			'error'    => isset( $s['error'] ) && is_string( $s['error'] ) ? $s['error'] : '',
			'origin'   => isset( $s['origin'] ) && is_string( $s['origin'] ) ? $s['origin'] : '',
		);
	}

	/**
	 * Whether automatic attempts are held for this origin (the proxy answered origin_mismatch for it).
	 *
	 * @param string                    $origin Current origin.
	 * @param array<string, int|string> $state  State.
	 * @return bool
	 */
	public static function held_for( $origin, $state ) {
		return 'origin_mismatch' === $state['error'] && '' !== $origin && $origin === $state['origin'];
	}

	/**
	 * Earliest next automatic attempt for this origin: the backoff only applies to the origin it was
	 * recorded for, so a store that moved host is asked again right away.
	 *
	 * @param string                    $origin Current origin.
	 * @param array<string, int|string> $state  State.
	 * @return int
	 */
	public static function next_at_for( $origin, $state ) {
		return $origin === $state['origin'] ? (int) $state['next_at'] : 0;
	}

	/**
	 * Seconds to wait after the given attempt index.
	 *
	 * @param int $i Attempt index (0 for the first).
	 * @return int
	 */
	public static function delay( $i ) {
		$i = max( 0, min( (int) $i, count( self::STEPS ) - 1 ) );
		return self::STEPS[ $i ];
	}

	/**
	 * Forget the attempt state and any queued attempt.
	 *
	 * @return void
	 */
	public static function reset() {
		delete_option( self::STATE );
		wp_clear_scheduled_hook( self::CRON );
	}

	/**
	 * Save the attempt state.
	 *
	 * @param int    $attempts Attempts so far.
	 * @param int    $next_at  Earliest next automatic attempt.
	 * @param string $error    Last error.
	 * @param string $origin   Origin asked for.
	 * @return void
	 */
	private static function store_attempt( $attempts, $next_at, $error, $origin ) {
		update_option(
			self::STATE,
			array(
				'attempts' => (int) $attempts,
				'next_at'  => (int) $next_at,
				'error'    => (string) $error,
				'origin'   => (string) $origin,
			),
			false
		);
	}

	/**
	 * Current time.
	 *
	 * @return int
	 */
	private static function now() {
		return null !== self::$now ? (int) self::$now : time();
	}
}
