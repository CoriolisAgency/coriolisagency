<?php
/**
 * Pulls the shared reputation feed every 30 minutes and answers "is this visitor listed" (S6E).
 *
 * The feed is an Ed25519-signed payload from the proxy (POST /api/reputation/feed with share: true;
 * there is no receive-only mode). The plugin only trusts it when:
 *   - the signature verifies against a public key bundled below (key_id pinned), and
 *   - the payload is current: issued in the last 48 hours and not past its expires_at.
 * Anything else fails open: the feed step is paused (S6D.15) and nothing is blocked or slowed down
 * by the feed. The other ACTIVE DEFENSE checks keep running either way.
 *
 * Matching hashes the visitor the same way the reporter does, sha256( "salt|kind|value" ), so the
 * store never needs the network's raw values and the network never sees the store's.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

use FFL_Firewall\Proxy\Client;
use FFL_Firewall\Settings\Repository;

defined( 'ABSPATH' ) || exit;

/**
 * Feed pull, signature check, cache and lookup.
 */
class Reputation_Feed {

	const OPTION   = 'fflfw_reputation_feed';
	const CRON     = 'fflfw_reputation_pull';
	const SCHEDULE = 'fflfw_30min';
	const INTERVAL = 1800;
	/** The feed step pauses when the newest verified list is older than this. */
	const STALE_AFTER = 172800;
	/** Allowed clock skew for issued_at. */
	const SKEW = 600;
	/** Most entries kept from one feed. */
	const MAX_ENTRIES = 50000;
	/** On pages other than checkout and login, a listed visitor gets this many requests a minute. */
	const PAGE_BUDGET = 10;
	const PAGE_WINDOW = 60;

	/**
	 * Bundled feed signing keys: key_id => raw 32-byte Ed25519 public key, base64. key_id is
	 * "fflfw-rep-" plus the first 8 hex of sha256(raw key). Rotating means a new key here and a release.
	 */
	const KEYS = array(
		'fflfw-rep-c458dfa8' => 'HbpzeNMsmtUhARUeFZaLiCXPH8zK68XWK3Qil8ZKezQ=',
	);

	/**
	 * Key override for tests (null uses KEYS).
	 *
	 * @var array<string, string>|null
	 */
	public static $keys = null;

	/**
	 * Clock override for tests.
	 *
	 * @var int|null
	 */
	public static $now = null;

	/**
	 * Proxy client (only needed to pull).
	 *
	 * @var Client|null
	 */
	private $client;

	/**
	 * Opt-in.
	 *
	 * @var Feed_Optin
	 */
	private $optin;

	/**
	 * Constructor.
	 *
	 * @param Client|null     $client Proxy client.
	 * @param Feed_Optin|null $optin  Opt-in.
	 */
	public function __construct( ?Client $client = null, ?Feed_Optin $optin = null ) {
		$this->client = $client;
		$this->optin  = $optin ? $optin : new Feed_Optin();
	}

	/**
	 * Hooks: the 30-minute schedule and the pull.
	 *
	 * @return void
	 */
	public function register() {
		add_filter( 'cron_schedules', array( __CLASS__, 'schedules' ) ); // phpcs:ignore WordPress.WP.CronInterval.CronSchedulesInterval -- 30 minutes on purpose.
		add_action( self::CRON, array( $this, 'pull' ) );
		add_action( 'init', array( $this, 'schedule' ) );
	}

	/**
	 * Add the 30-minute interval.
	 *
	 * @param array<string, array<string, mixed>> $s Schedules.
	 * @return array<string, array<string, mixed>>
	 */
	public static function schedules( $s ) {
		$s                   = is_array( $s ) ? $s : array();
		$s[ self::SCHEDULE ] = array(
			'interval' => self::INTERVAL,
			'display'  => 'Every 30 minutes (FFL Firewall)',
		);
		return $s;
	}

	/**
	 * Current time.
	 *
	 * @return int
	 */
	private static function now() {
		return null !== self::$now ? (int) self::$now : time();
	}

	/**
	 * Keep the pull scheduled while the feed works, and none otherwise.
	 *
	 * @return void
	 */
	public function schedule() {
		try {
			$next = wp_next_scheduled( self::CRON );
			if ( $this->optin->effective() ) {
				if ( ! $next ) {
					wp_schedule_event( self::now() + 60, self::SCHEDULE, self::CRON );
				}
			} elseif ( $next ) {
				wp_clear_scheduled_hook( self::CRON );
			}
		} catch ( \Throwable $e ) {
			return;
		}
	}

	/**
	 * Stored cache and pull state.
	 *
	 * @return array<string, mixed>
	 */
	public static function state() {
		$s = get_option( self::OPTION, array() );
		$s = is_array( $s ) ? $s : array();
		$s = array_merge(
			array(
				'salt'       => '',
				'salt_id'    => '',
				'key_id'     => '',
				'issued_at'  => 0,
				'expires_at' => 0,
				'fetched_at' => 0,
				'last_try'   => 0,
				'last_error' => '',
				'index'      => array(),
				'patterns'   => array(),
			),
			$s
		);
		$s['index']    = is_array( $s['index'] ) ? $s['index'] : array();
		$s['patterns'] = is_array( $s['patterns'] ) ? $s['patterns'] : array();
		return $s;
	}

	/**
	 * Save part of the state.
	 *
	 * @param array<string, mixed> $patch Changes.
	 * @return void
	 */
	private static function patch( $patch ) {
		update_option( self::OPTION, array_merge( self::state(), $patch ), false );
	}

	/**
	 * Forget the feed (feed turned off).
	 *
	 * @return void
	 */
	public static function reset() {
		delete_option( self::OPTION );
	}

	/**
	 * Whether the last verified feed lists a report pattern as accepted (FFLFW-AD-AUTOBLOCK).
	 *
	 * @param string $pattern Pattern.
	 * @return bool
	 */
	public static function accepts( $pattern ) {
		try {
			$s = self::state();
			return self::usable() && in_array( (string) $pattern, $s['patterns'], true );
		} catch ( \Throwable $e ) {
			return false;
		}
	}

	/**
	 * Whether a current, verified list is in hand: verified signature on the last good pull, the
	 * newest pull wasn't a bad signature, issued in the last 48 hours and not expired.
	 *
	 * @return bool
	 */
	public static function usable() {
		$s   = self::state();
		$now = self::now();
		return '' !== $s['salt']
			&& 'bad_signature' !== $s['last_error']
			&& (int) $s['issued_at'] > 0
			&& ( $now - (int) $s['issued_at'] ) <= self::STALE_AFTER
			&& $now < (int) $s['expires_at'];
	}

	/**
	 * Whether the feed step should show as unchecked (S6D.15): at least one pull was tried and there
	 * is no current, verified list.
	 *
	 * @return bool
	 */
	public static function unchecked() {
		$s = self::state();
		return (int) $s['last_try'] > 0 && ! self::usable();
	}

	/**
	 * Verify a payload signature against the bundled keys.
	 *
	 * @param string $payload Exact payload string.
	 * @param string $sig     Base64 signature.
	 * @param string $key_id  Key id the proxy names.
	 * @return bool
	 */
	public static function verify( $payload, $sig, $key_id ) {
		try {
			$keys = null !== self::$keys ? self::$keys : self::KEYS;
			if ( ! is_string( $payload ) || ! is_string( $sig ) || ! is_string( $key_id ) || ! isset( $keys[ $key_id ] ) ) {
				return false;
			}
			if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
				return false;
			}
			$pk  = base64_decode( (string) $keys[ $key_id ], true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Public key, not obfuscation.
			$raw = base64_decode( $sig, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Signature bytes.
			if ( false === $pk || 32 !== strlen( $pk ) || false === $raw || 64 !== strlen( $raw ) ) {
				return false;
			}
			if ( 'fflfw-rep-' . substr( hash( 'sha256', $pk ), 0, 8 ) !== $key_id ) {
				return false;
			}
			return (bool) sodium_crypto_sign_verify_detached( $raw, $payload, $pk );
		} catch ( \Throwable $e ) {
			return false;
		}
	}

	/**
	 * Short error name from a client answer.
	 *
	 * @param array<string, mixed> $r Client answer.
	 * @return string
	 */
	private static function error_of( $r ) {
		if ( isset( $r['json']['error'] ) && is_string( $r['json']['error'] ) ) {
			return substr( sanitize_key( $r['json']['error'] ), 0, 40 );
		}
		return $r['code'] ? 'http_' . (int) $r['code'] : 'feed_unreachable';
	}

	/**
	 * Pull, verify and cache the feed. Never throws. A failed pull keeps the last verified list,
	 * which stops counting once it is more than 48 hours old.
	 *
	 * @return string Result code (for tests and the admin screen).
	 */
	public function pull() {
		try {
			if ( ! $this->optin->effective() ) {
				self::reset();
				return 'off';
			}
			$now = self::now();
			self::patch( array( 'last_try' => $now ) );
			$client = $this->client ? $this->client : new Client( new Repository() );
			$r      = $client->reputation(
				'/api/reputation/feed',
				array(
					'license_key' => (string) ( new Repository() )->get( 'license_key', '' ),
					'share'       => true,
				)
			);
			$j = is_array( $r['json'] ) ? $r['json'] : array();
			if ( 200 !== (int) $r['code'] || empty( $j['ok'] ) || ! isset( $j['payload'], $j['sig'], $j['key_id'] ) ) {
				$err = self::error_of( $r );
				self::patch( array( 'last_error' => $err ) );
				return $err;
			}
			if ( ! self::verify( $j['payload'], $j['sig'], $j['key_id'] ) ) {
				self::patch( array( 'last_error' => 'bad_signature' ) );
				return 'bad_signature';
			}
			$p = json_decode( (string) $j['payload'], true );
			if ( ! self::payload_ok( $p, $now ) ) {
				self::patch( array( 'last_error' => 'bad_payload' ) );
				return 'bad_payload';
			}
			self::patch(
				array(
					'salt'       => (string) $p['salt'],
					'salt_id'    => (string) $p['salt_id'],
					'key_id'     => (string) $j['key_id'],
					'issued_at'  => (int) $p['issued_at'],
					'expires_at' => (int) $p['expires_at'],
					'fetched_at' => $now,
					'last_error' => '',
					'index'      => self::index( $p['entries'], $now ),
					// FFLFW-AD-AUTOBLOCK: report patterns the server accepts, when the signed payload lists them.
					'patterns'   => isset( $p['patterns'] ) && is_array( $p['patterns'] ) ? array_values( array_filter( array_map( 'strval', $p['patterns'] ), 'strlen' ) ) : array(),
				)
			);
			return 'ok';
		} catch ( \Throwable $e ) {
			return 'error';
		}
	}

	/**
	 * Whether a decoded payload has the shape the proxy signs.
	 *
	 * @param mixed $p   Decoded payload.
	 * @param int   $now Now.
	 * @return bool
	 */
	private static function payload_ok( $p, $now ) {
		if ( ! is_array( $p ) || 1 !== ( isset( $p['v'] ) ? $p['v'] : null ) ) {
			return false;
		}
		if ( empty( $p['salt'] ) || ! is_string( $p['salt'] ) || strlen( $p['salt'] ) < 32 ) {
			return false;
		}
		if ( ! isset( $p['salt_id'] ) || substr( hash( 'sha256', 'fflfw-rep-salt:' . $p['salt'] ), 0, 12 ) !== $p['salt_id'] ) {
			return false;
		}
		if ( ! isset( $p['issued_at'], $p['expires_at'], $p['entries'] ) || ! is_int( $p['issued_at'] ) || ! is_int( $p['expires_at'] ) || ! is_array( $p['entries'] ) ) {
			return false;
		}
		return $p['issued_at'] <= $now + self::SKEW && $p['expires_at'] > $p['issued_at'];
	}

	/**
	 * Lookup index "kind|hash" => array( pattern, expires ) for live, well-formed entries.
	 *
	 * @param array<int, mixed> $entries Feed entries.
	 * @param int               $now     Now.
	 * @return array<string, array{0: string, 1: int}>
	 */
	private static function index( $entries, $now ) {
		$out = array();
		foreach ( $entries as $e ) {
			if ( count( $out ) >= self::MAX_ENTRIES ) {
				break;
			}
			if ( ! is_array( $e ) || ! isset( $e['k'], $e['h'], $e['p'], $e['x'] ) || ! in_array( $e['k'], array( 'ip', 'ip6net', 'ua' ), true ) ) {
				continue;
			}
			if ( ! is_string( $e['h'] ) || ! preg_match( '/^[0-9a-f]{64}$/', $e['h'] ) || ! is_int( $e['x'] ) || $e['x'] <= $now ) {
				continue;
			}
			$out[ $e['k'] . '|' . $e['h'] ] = array( substr( (string) $e['p'], 0, 40 ), (int) $e['x'] );
		}
		return $out;
	}

	/**
	 * The visitor's listed subject, or null. Only answers while the feed works and the list is
	 * current and verified; local Not a bot unblocks (S6F) always win.
	 *
	 * @param Request $req Request.
	 * @return array{k: string, h: string, p: string}|null
	 */
	public function match( Request $req ) {
		try {
			if ( ! $this->optin->effective() || ! self::usable() ) {
				return null;
			}
			$s   = self::state();
			$now = self::now();
			foreach ( Reputation_Buffer::subjects( $req, 'agent' ) as $sub ) {
				$h   = hash( 'sha256', $s['salt'] . '|' . $sub[0] . '|' . $sub[1] );
				$key = $sub[0] . '|' . $h;
				if ( isset( $s['index'][ $key ] ) && (int) $s['index'][ $key ][1] > $now && ! self::locally_unblocked( $sub[0], $h ) ) {
					return array(
						'k' => $sub[0],
						'h' => $h,
						'p' => (string) $s['index'][ $key ][0],
					);
				}
			}
			return null;
		} catch ( \Throwable $e ) {
			return null;
		}
	}

	/**
	 * Whether the dealer marked this subject as Not a bot on this store (S6F).
	 *
	 * @param string $kind Kind.
	 * @param string $hash Subject hash.
	 * @return bool
	 */
	private static function locally_unblocked( $kind, $hash ) {
		return Reputation_Unblocks::has( $kind, $hash );
	}
}
