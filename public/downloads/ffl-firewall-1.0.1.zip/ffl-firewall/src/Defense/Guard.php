<?php
/**
 * Runs the countermeasures and returns a decision. Any error lets the request through.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

defined( 'ABSPATH' ) || exit;

/**
 * Decision engine, no WordPress hooks of its own.
 *
 * A decision is array( action => 'block' | 'throttle', status => int, reason => string, retry_after => int ).
 * null means let the request through.
 */
class Guard {

	/**
	 * Config.
	 *
	 * @var Config
	 */
	private $config;

	/**
	 * Activity log.
	 *
	 * @var Activity_Log
	 */
	private $log;

	/**
	 * Datacenter list.
	 *
	 * @var Datacenter_List
	 */
	private $datacenter;

	/**
	 * Shared reputation feed (S6E), made on first use.
	 *
	 * @var Reputation_Feed|null
	 */
	private $feed;

	/**
	 * Auto-block (FFLFW-AD-AUTOBLOCK), made on first use.
	 *
	 * @var Auto_Block|null
	 */
	private $auto;

	/**
	 * Constructor.
	 *
	 * @param Config               $config     Config.
	 * @param Activity_Log|null    $log        Log.
	 * @param Datacenter_List|null $datacenter Datacenter list.
	 * @param Reputation_Feed|null $feed       Shared reputation feed.
	 * @param Auto_Block|null      $auto       Auto-block.
	 */
	public function __construct( Config $config, ?Activity_Log $log = null, ?Datacenter_List $datacenter = null, ?Reputation_Feed $feed = null, ?Auto_Block $auto = null ) {
		$this->config     = $config;
		$this->log        = $log ? $log : new Activity_Log();
		$this->datacenter = $datacenter ? $datacenter : new Datacenter_List();
		$this->feed       = $feed;
		$this->auto       = $auto;
	}

	/**
	 * Build a decision.
	 *
	 * @param string $action      block or throttle.
	 * @param string $reason      Reason code.
	 * @param int    $retry_after Seconds.
	 * @return array<string, mixed>
	 */
	private function decision( $action, $reason, $retry_after = 0 ) {
		return array(
			'action'      => $action,
			'status'      => 'throttle' === $action ? 429 : 403,
			'reason'      => $reason,
			'retry_after' => (int) $retry_after,
		);
	}

	/**
	 * Whether the visitor's address is on the allow list.
	 *
	 * @param Request $req Request.
	 * @return bool
	 */
	public function allowed( Request $req ) {
		return Ip::in_list( $req->ip, (array) $this->config->get( 'allow_ips' ) );
	}

	/**
	 * Trusted proxies for building a request.
	 *
	 * @return array<int, string>
	 */
	public function trusted_proxies() {
		return (array) $this->config->get( 'trusted_proxies' );
	}

	/**
	 * Page-level checks: datacenter list, user agent and headers, rate limit, auto-block, feed.
	 * FFLFW-CRAWLER-GRACE: a verified crawler passes all of them (unless_crawler).
	 * FFLFW-EXEMPT-ALL-LAYERS (Chief option (a), 2026-11-24): on a path ACTIVE DEFENSE never blocks
	 * (Auto_Block::protected_request: cart, checkout, my-account, wp-admin, login, admin-ajax, Store
	 * API, wc-ajax, wc-api) none of the page-level checks run. The checkout submit checks in
	 * checkout() (datacenter, honeypot, velocity and card testing) still run.
	 *
	 * @param Request $req Request.
	 * @return array<string, mixed>|null
	 */
	public function page( Request $req ) {
		try {
			if ( $this->allowed( $req ) || Auto_Block::protected_request( $req ) ) {
				return null;
			}
			$d = $this->datacenter_decision( $req );
			if ( null === $d && $this->config->on( 'agent_check' ) && ! self::header_pass( $req ) ) {
				$reason = ( new Agent_Check() )->check( $req );
				$d      = '' !== $reason ? $this->decision( 'block', $reason ) : null;
			}
			if ( null === $d && $this->config->on( 'rate_limit' ) ) {
				$wait = ( new Rate_Limit( $this->config->group( 'rate_limit' ) ) )->check( $req );
				$d    = $wait > 0 ? $this->decision( 'throttle', 'rate_limit', $wait ) : null;
			}
			if ( null === $d ) {
				$d = $this->auto_decision( $req );
			}
			if ( null === $d ) {
				$d = $this->feed_decision( $req );
			}
			return $this->finish( $req, $this->unless_crawler( $req, $d ) );
		} catch ( \Throwable $e ) {
			return null;
		}
	}

	/**
	 * Checkout checks: datacenter list, honeypot field, velocity and card testing.
	 * FFLFW-CRAWLER-GRACE: a verified crawler passes all of them (unless_crawler).
	 *
	 * @param Request $req Request.
	 * @return array<string, mixed>|null
	 */
	public function checkout( Request $req ) {
		try {
			if ( $this->allowed( $req ) ) {
				return null;
			}
			$d = $this->datacenter_decision( $req );
			if ( null === $d && $this->config->on( 'honeypot' ) && Honeypot::tripped( $req->post ) ) {
				$d = $this->decision( 'block', 'honeypot' );
			}
			if ( null === $d && $this->config->on( 'velocity' ) ) {
				$v = ( new Velocity( $this->config->group( 'velocity' ) ) )->check( $req );
				$d = null !== $v ? $this->decision( 'throttle', $v[0], $v[1] ) : null;
			}
			return $this->finish( $req, $this->unless_crawler( $req, $d ) );
		} catch ( \Throwable $e ) {
			return null;
		}
	}

	/**
	 * Shared reputation feed step (S6E, countermeasure shared_reputation). Runs after the local
	 * checks, only while the feed works and its list is current and verified (else it fails open).
	 * A listed visitor is slowed down on pages: it gets PAGE_BUDGET requests a minute, then 429
	 * until the minute is up. FFLFW-FEED-EXEMPT-CHECKOUT (Paul, 2026-11-21 4:00 PM ET): checkout and
	 * login are never blocked by the feed, and neither is any path ACTIVE DEFENSE auto-block exempts
	 * (cart, checkout, my-account, wp-admin, login, admin-ajax, Store API, wc-ajax, wc-api), and the
	 * search crawlers ACTIVE DEFENSE leaves alone (Crawler_Verify::exempt) are never slowed down by it.
	 * FFLFW-EXEMPT-ALL-LAYERS: page requests only (page() already skips the exempt paths); the
	 * unreachable checkout and login branches are removed.
	 *
	 * @param Request $req Request.
	 * @return array<string, mixed>|null
	 */
	private function feed_decision( Request $req ) {
		if ( ! apply_filters( 'fflfw_reputation_feed_on', false ) ) {
			return null;
		}
		if ( Auto_Block::protected_request( $req ) ) {
			return null;
		}
		if ( null === $this->feed ) {
			$this->feed = new Reputation_Feed();
		}
		$m = $this->feed->match( $req );
		if ( null === $m || Crawler_Verify::exempt( $req ) ) {
			return null;
		}
		list( $n, $left ) = Counter::hit( 'feed', $m['k'] . '|' . $m['h'], Reputation_Feed::PAGE_WINDOW );
		if ( $n <= Reputation_Feed::PAGE_BUDGET ) {
			return null;
		}
		$d              = $this->decision( 'throttle', Monthly::FEED_REASON, $left );
		$d['from_feed'] = true;
		$d['feed']      = array(
			'k' => $m['k'],
			'h' => $m['h'],
		);
		return $d;
	}

	/**
	 * Auto-block step (FFLFW-AD-AUTOBLOCK): page requests only, never checkout, login or forms.
	 * Any error lets the request through.
	 *
	 * @param Request $req Request.
	 * @return array<string, mixed>|null
	 */
	private function auto_decision( Request $req ) {
		try {
			if ( null === $this->auto ) {
				$this->auto = new Auto_Block();
			}
			return $this->auto->decide( $req );
		} catch ( \Throwable $e ) {
			return null;
		}
	}

	/**
	 * FFLFW-CRAWLER-GRACE (Paul, 2026-11-23 11:25 AM ET): a decision that would block or slow down
	 * a verified search or SEO crawler (Crawler_Verify) is dropped. Verification runs only here, once
	 * a check has already decided to act and only for a user agent that claims a crawler, so normal
	 * traffic never waits on a lookup. A spoofed or unverifiable crawler keeps the decision.
	 *
	 * @param Request                   $req Request.
	 * @param array<string, mixed>|null $d   Decision.
	 * @return array<string, mixed>|null
	 */
	private function unless_crawler( Request $req, $d ) {
		if ( null === $d ) {
			return null;
		}
		return Crawler_Verify::exempt( $req ) ? null : $d;
	}

	/**
	 * Whether the user agent and header check is skipped by user agent alone. Only for bots on the
	 * Agent_Check allow list that Crawler_Verify cannot verify (link previewers); a user agent that
	 * claims a crawler Crawler_Verify knows has to verify instead (unless_crawler).
	 *
	 * @param Request $req Request.
	 * @return bool
	 */
	private static function header_pass( Request $req ) {
		return Agent_Check::is_allowed_crawler( $req ) && '' === Crawler_Verify::claimed( $req );
	}

	/**
	 * Form check for forms other than checkout: honeypot only. FFLFW-CRAWLER-GRACE: a verified
	 * crawler passes it.
	 *
	 * @param Request $req Request.
	 * @return array<string, mixed>|null
	 */
	public function form( Request $req ) {
		try {
			if ( $this->allowed( $req ) || ! $this->config->on( 'honeypot' ) || ! Honeypot::tripped( $req->post ) ) {
				return null;
			}
			if ( Crawler_Verify::exempt( $req ) ) {
				return null;
			}
			return $this->finish( $req, $this->decision( 'block', 'honeypot' ) );
		} catch ( \Throwable $e ) {
			return null;
		}
	}

	/**
	 * Datacenter list decision.
	 *
	 * @param Request $req Request.
	 * @return array<string, mixed>|null
	 */
	private function datacenter_decision( Request $req ) {
		if ( ! $this->config->on( 'datacenter' ) || $req->ip_unclear || ! Ip::is_public( $req->ip ) ) {
			return null;
		}
		return $this->datacenter->contains( $req->ip ) ? $this->decision( 'block', 'datacenter' ) : null;
	}

	/**
	 * Log a decision (a logging error never changes it) and return it.
	 *
	 * @param Request                   $req Request.
	 * @param array<string, mixed>|null $d   Decision.
	 * @return array<string, mixed>|null
	 */
	private function finish( Request $req, $d ) {
		if ( null !== $d ) {
			try {
				$this->log->add( $req, $d );
			} catch ( \Throwable $e ) {
				unset( $e );
			}
			try {
				// S6A: every blocked or slowed-down request counts in the local monthly panel.
				( new Monthly() )->record( (string) $d['reason'], ! empty( $d['from_feed'] ) );
			} catch ( \Throwable $e ) {
				unset( $e );
			}
			try {
				// S6D: while the shared reputation feed works, buffer the signal for the 15-minute flush.
				// Rate-limit, datacenter and feed blocks are never buffered (Reputation_Buffer::pattern_of).
				if ( empty( $d['from_feed'] ) && apply_filters( 'fflfw_reputation_feed_on', false ) ) {
					( new Reputation_Buffer() )->record( $req, (string) $d['reason'] );
				}
			} catch ( \Throwable $e ) {
				unset( $e );
			}
		}
		return $d;
	}
}
