<?php
/**
 * Recent ACTIVE DEFENSE activity (newest first, capped).
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

defined( 'ABSPATH' ) || exit;

/**
 * Ring buffer in one option. One row per address and reason every five minutes, so a flood
 * doesn't turn into a flood of database writes.
 */
class Activity_Log {

	const OPTION = 'fflfw_defense_log';
	const MAX    = 100;

	/**
	 * Rows, newest first.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function rows() {
		$rows = get_option( self::OPTION, array() );
		return is_array( $rows ) ? array_values( $rows ) : array();
	}

	/**
	 * Add a row for a decision.
	 *
	 * @param Request              $req      Request.
	 * @param array<string, mixed> $decision Decision.
	 * @return void
	 */
	public function add( Request $req, $decision ) {
		list( $n ) = Counter::hit( 'log', $req->ip . '|' . $decision['reason'], 300 );
		if ( $n > 1 ) {
			return;
		}
		$row = array(
			'time'   => Counter::now(),
			'ip'     => $req->ip,
			'reason' => (string) $decision['reason'],
			'action' => (string) $decision['action'],
			'path'   => $req->path,
		);
		// S6E: a feed stop keeps the matched hashed subject, so Not a bot (S6F) can unblock exactly it.
		if ( ! empty( $decision['feed'] ) && is_array( $decision['feed'] ) && isset( $decision['feed']['k'], $decision['feed']['h'] ) ) {
			$row['feed'] = array(
				'k' => (string) $decision['feed']['k'],
				'h' => (string) $decision['feed']['h'],
			);
		}
		// FFLFW-AD-AUTOBLOCK: an auto-block row keeps its matched subject for the dealer unblock.
		if ( ! empty( $decision['ad'] ) && is_array( $decision['ad'] ) && isset( $decision['ad']['k'], $decision['ad']['h'] ) ) {
			$row['ad'] = array(
				'k' => (string) $decision['ad']['k'],
				'h' => (string) $decision['ad']['h'],
			);
		}
		$rows = $this->rows();
		array_unshift( $rows, $row );
		update_option( self::OPTION, array_slice( $rows, 0, self::MAX ), false );
	}

	/**
	 * Clear (uninstall).
	 *
	 * @return void
	 */
	public static function clear() {
		delete_option( self::OPTION );
	}
}
