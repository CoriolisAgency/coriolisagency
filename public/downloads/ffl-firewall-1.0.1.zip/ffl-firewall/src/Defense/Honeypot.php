<?php
/**
 * Honeypot form fields: a hidden field no person fills in.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

defined( 'ABSPATH' ) || exit;

/**
 * Hidden field markup and the check. Fields only: no hidden links and no decoy data.
 */
class Honeypot {

	const FIELD = 'fflfw_website';

	/**
	 * Markup for the hidden field. It has no visible text, is out of the tab order and is hidden
	 * from assistive technology.
	 *
	 * @return string
	 */
	public static function html() {
		return '<div class="fflfw-hp" aria-hidden="true" style="position:absolute;left:-9999px;top:auto;width:1px;height:1px;overflow:hidden;">'
			. '<input type="text" name="' . esc_attr( self::FIELD ) . '" value="" tabindex="-1" autocomplete="off" />'
			. '</div>';
	}

	/**
	 * Whether the submitted fields filled in the hidden one.
	 *
	 * @param array<string, mixed> $post Submitted fields.
	 * @return bool
	 */
	public static function tripped( $post ) {
		if ( ! is_array( $post ) || ! array_key_exists( self::FIELD, $post ) ) {
			return false;
		}
		$v = $post[ self::FIELD ];
		return is_array( $v ) || '' !== trim( (string) $v );
	}
}
