<?php
/**
 * WordPress and WooCommerce hooks for ACTIVE DEFENSE. Every hook returns straight away while
 * the gate is closed, and every error is swallowed so a legit checkout is never blocked.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

use FFL_Firewall\Settings\Repository;

defined( 'ABSPATH' ) || exit;

/**
 * Hook wiring.
 */
class Controller {

	/**
	 * Gate.
	 *
	 * @var Gate
	 */
	private $gate;

	/**
	 * Guard.
	 *
	 * @var Guard
	 */
	private $guard;

	/**
	 * Config.
	 *
	 * @var Config
	 */
	private $config;

	/**
	 * Sends a blocked or throttled response (replaced in tests).
	 *
	 * @var callable|null
	 */
	private $responder;

	/**
	 * Constructor.
	 *
	 * @param Repository    $settings  Settings.
	 * @param Config|null   $config    Config.
	 * @param Guard|null    $guard     Guard.
	 * @param callable|null $responder Responder.
	 */
	public function __construct( Repository $settings, ?Config $config = null, ?Guard $guard = null, $responder = null ) {
		$this->config    = $config ? $config : new Config();
		$this->gate      = new Gate( $settings, $this->config );
		$this->guard     = $guard ? $guard : new Guard( $this->config );
		$this->responder = is_callable( $responder ) ? $responder : null;
	}

	/**
	 * Add the hooks.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'template_redirect', array( $this, 'on_page' ), -100 );

		add_action( 'woocommerce_after_order_notes', array( $this, 'print_field' ) );
		add_action( 'woocommerce_after_checkout_validation', array( $this, 'on_classic_checkout' ), 5, 2 );
		add_action( 'woocommerce_store_api_checkout_update_order_from_request', array( $this, 'on_block_checkout' ), 5, 2 );
		add_action( 'woocommerce_checkout_order_created', array( $this, 'on_order_placed' ), 5 );
		add_action( 'woocommerce_store_api_checkout_order_processed', array( $this, 'on_order_placed' ), 5 );
		add_action( 'woocommerce_order_status_failed', array( $this, 'on_payment_failed' ), 5, 2 );

		add_action( 'woocommerce_register_form', array( $this, 'print_field' ) );
		add_action( 'register_form', array( $this, 'print_field' ) );
		add_action( 'comment_form_after_fields', array( $this, 'print_field' ) );
		add_filter( 'woocommerce_process_registration_errors', array( $this, 'on_form_submit' ), 5 );
		add_action( 'register_post', array( $this, 'on_form_submit' ), 5 );
		add_action( 'pre_comment_on_post', array( $this, 'on_form_submit' ), 5 );
	}

	/**
	 * Request for this hit.
	 *
	 * @return Request
	 */
	private function request() {
		return Request::from_globals( $this->guard->trusted_proxies() );
	}

	/**
	 * Whether the signed-in user is a store manager (never limited).
	 *
	 * @return bool
	 */
	private function is_manager() {
		return is_user_logged_in() && ( current_user_can( 'manage_options' ) || current_user_can( 'manage_woocommerce' ) );
	}

	/**
	 * Message for the shopper: the saved text (the default until the dealer edits it), which a filter can replace.
	 *
	 * @param string $reason Reason code.
	 * @return string
	 */
	private function message( $reason ) {
		$m = apply_filters( 'fflfw_defense_message', $this->config->message(), $reason );
		return is_string( $m ) ? $m : '';
	}

	/**
	 * Send the response for a decision and stop.
	 *
	 * @param array<string, mixed> $d Decision.
	 * @return void
	 */
	private function respond( $d ) {
		if ( $this->responder ) {
			call_user_func( $this->responder, $d );
			return;
		}
		status_header( (int) $d['status'] );
		nocache_headers();
		if ( $d['retry_after'] > 0 && ! headers_sent() ) {
			header( 'Retry-After: ' . (int) $d['retry_after'] );
		}
		if ( isset( $d['action'], $d['challenge'] ) && 'challenge' === $d['action'] ) {
			// FFLFW-AD-AUTOBLOCK browser check page.
			if ( ! headers_sent() ) {
				header( 'Content-Type: text/html; charset=utf-8' );
			}
			echo Auto_Block::challenge_html( (string) $d['challenge'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped inside; the token is hex only.
		}
		exit;
	}

	/**
	 * Front-end page requests.
	 *
	 * @return void
	 */
	public function on_page() {
		try {
			if ( ! $this->gate->open() || $this->is_manager() ) {
				return;
			}
			$d = $this->guard->page( $this->request() );
		} catch ( \Throwable $e ) {
			return;
		}
		if ( $d ) {
			$this->respond( $d );
		}
	}

	/**
	 * Print the hidden field in a form.
	 *
	 * @return void
	 */
	public function print_field() {
		try {
			if ( $this->gate->open() && $this->config->on( 'honeypot' ) ) {
				echo Honeypot::html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed markup, the field name is escaped inside.
			}
		} catch ( \Throwable $e ) {
			return;
		}
	}

	/**
	 * Classic checkout validation.
	 *
	 * @param mixed $data   Posted data.
	 * @param mixed $errors Error collection.
	 * @return void
	 */
	public function on_classic_checkout( $data = null, $errors = null ) {
		try {
			if ( ! $this->gate->open() || $this->is_manager() || ! is_object( $errors ) || ! method_exists( $errors, 'add' ) ) {
				return;
			}
			$d = $this->guard->checkout( $this->request() );
			if ( $d ) {
				$errors->add( 'fflfw_defense', $this->message( $d['reason'] ) );
			}
		} catch ( \Throwable $e ) {
			return;
		}
	}

	/**
	 * Block checkout (Store API) place order.
	 *
	 * @param mixed $order   Order.
	 * @param mixed $request Request.
	 * @return void
	 * @throws \Automattic\WooCommerce\StoreApi\Exceptions\RouteException When the order is refused.
	 */
	public function on_block_checkout( $order = null, $request = null ) {
		$d = null;
		try {
			if ( $this->gate->open() && ! $this->is_manager() ) {
				$d = $this->guard->checkout( $this->request() );
			}
		} catch ( \Throwable $e ) {
			return;
		}
		if ( $d && class_exists( '\Automattic\WooCommerce\StoreApi\Exceptions\RouteException' ) ) {
			throw new \Automattic\WooCommerce\StoreApi\Exceptions\RouteException( 'fflfw_defense_blocked', esc_html( $this->message( $d['reason'] ) ), (int) $d['status'] );
		}
	}

	/**
	 * Other forms (registration, comments): a filled honeypot field ends the request.
	 *
	 * @param mixed $passthrough Value a filter hook hands in.
	 * @return mixed
	 */
	public function on_form_submit( $passthrough = null ) {
		try {
			if ( ! $this->gate->open() ) {
				return $passthrough;
			}
			$d = $this->guard->form( $this->request() );
		} catch ( \Throwable $e ) {
			return $passthrough;
		}
		if ( $d ) {
			$this->respond( $d );
		}
		return $passthrough;
	}

	/**
	 * A placed order: count small ones for the card-testing check.
	 *
	 * @param mixed $order Order.
	 * @return void
	 */
	public function on_order_placed( $order = null ) {
		try {
			if ( ! $this->gate->open() || ! $this->config->on( 'velocity' ) || ! is_object( $order ) || ! method_exists( $order, 'get_total' ) ) {
				return;
			}
			$req = $this->request();
			if ( $req->ip_usable() ) {
				( new Velocity( $this->config->group( 'velocity' ) ) )->record_order( $req->ip, (float) $order->get_total() );
			}
		} catch ( \Throwable $e ) {
			return;
		}
	}

	/**
	 * A failed payment: count it for the card-testing check.
	 *
	 * @param mixed $order_id Order id.
	 * @param mixed $order    Order.
	 * @return void
	 */
	public function on_payment_failed( $order_id = 0, $order = null ) {
		try {
			if ( ! $this->gate->open() || ! $this->config->on( 'velocity' ) || ! is_object( $order ) || ! method_exists( $order, 'get_customer_ip_address' ) ) {
				return;
			}
			( new Velocity( $this->config->group( 'velocity' ) ) )->record_failure( (string) $order->get_customer_ip_address() );
		} catch ( \Throwable $e ) {
			return;
		}
	}
}
