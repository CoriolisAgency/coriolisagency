<?php
/**
 * Per-address request rate limit.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

defined( 'ABSPATH' ) || exit;

/**
 * Fixed-window limit.
 */
class Rate_Limit {

	/**
	 * Settings group.
	 *
	 * @var array<string, mixed>
	 */
	private $cfg;

	/**
	 * Constructor.
	 *
	 * @param array<string, mixed> $cfg Group settings (max, window).
	 */
	public function __construct( $cfg ) {
		$this->cfg = $cfg;
	}

	/**
	 * Count this request. Returns the seconds to wait when the visitor is over the limit, else 0.
	 *
	 * @param Request $req Request.
	 * @return int
	 */
	public function check( Request $req ) {
		if ( ! $req->ip_usable() ) {
			return 0;
		}
		$max                = max( 1, (int) $this->cfg['max'] );
		list( $n, $left )   = Counter::hit( 'rate', $req->ip, (int) $this->cfg['window'] );
		return $n > $max ? $left : 0;
	}
}
