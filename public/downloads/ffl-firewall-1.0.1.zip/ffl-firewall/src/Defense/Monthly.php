<?php
/**
 * Monthly ACTIVE DEFENSE totals for the "what we blocked this month" panel.
 *
 * Local only: nothing here is sent anywhere. One option holds up to 12 months, each with a
 * count per reason code and a separate slot for blocks that came from the shared feed (S6E).
 * The unit is REQUESTS: every request an ACTIVE DEFENSE check blocks or slows down adds one
 * (rate-limit hits included; they stay local). Months are keyed in the site timezone, so the
 * panel starts again on the 1st at midnight site time.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

defined( 'ABSPATH' ) || exit;

/**
 * Month buckets in one option: array( 'YYYY-MM' => array( 'r' => array( reason => n ), 'feed' => n ) ).
 */
class Monthly {

	const OPTION = 'fflfw_defense_monthly';
	const KEEP   = 12;

	/** Reason code the shared feed check (S6E) will use. */
	const FEED_REASON = 'shared_reputation';

	/**
	 * Countermeasure groups, in display order. Reason codes map onto these by prefix.
	 *
	 * @return array<int, string>
	 */
	public static function groups() {
		return array( 'agent', 'rate', 'honeypot', 'velocity', 'datacenter', 'auto', 'feed' );
	}

	/**
	 * Group for a reason code.
	 *
	 * @param string $reason Reason code.
	 * @return string
	 */
	public static function group_of( $reason ) {
		$reason = (string) $reason;
		if ( self::FEED_REASON === $reason ) {
			return 'feed';
		}
		if ( 0 === strpos( $reason, 'agent_' ) || 0 === strpos( $reason, 'headers_' ) ) {
			return 'agent';
		}
		if ( 0 === strpos( $reason, 'rate' ) ) {
			return 'rate';
		}
		if ( 0 === strpos( $reason, 'honeypot' ) ) {
			return 'honeypot';
		}
		if ( 0 === strpos( $reason, 'datacenter' ) ) {
			return 'datacenter';
		}
		if ( 0 === strpos( $reason, 'ad_auto_' ) ) {
			return 'auto';
		}
		return 'velocity';
	}

	/**
	 * Month key in the site timezone (wp_date uses wp_timezone()) for a Unix time.
	 *
	 * @param int $ts Unix time.
	 * @return string YYYY-MM
	 */
	public static function month_key( $ts ) {
		return (string) wp_date( 'Y-m', (int) $ts );
	}

	/**
	 * All stored months, cleaned (anything malformed is dropped).
	 *
	 * @return array<string, array{r: array<string, int>, feed: int}>
	 */
	public function all() {
		$raw = get_option( self::OPTION, array() );
		$out = array();
		if ( ! is_array( $raw ) ) {
			return $out;
		}
		foreach ( $raw as $key => $m ) {
			if ( ! is_string( $key ) || ! preg_match( '/^\d{4}-\d{2}$/', $key ) || ! is_array( $m ) ) {
				continue;
			}
			$r = array();
			foreach ( ( isset( $m['r'] ) && is_array( $m['r'] ) ) ? $m['r'] : array() as $reason => $n ) {
				if ( is_string( $reason ) && '' !== $reason && (int) $n > 0 ) {
					$r[ substr( sanitize_key( $reason ), 0, 64 ) ] = (int) $n;
				}
			}
			$out[ $key ] = array(
				'r'    => $r,
				'feed' => isset( $m['feed'] ) ? max( 0, (int) $m['feed'] ) : 0,
			);
		}
		krsort( $out );
		return array_slice( $out, 0, self::KEEP, true );
	}

	/**
	 * Count one blocked or slowed-down request.
	 *
	 * @param string $reason    Reason code.
	 * @param bool   $from_feed Whether the shared feed caused it (S6E).
	 * @param int    $ts        Unix time.
	 * @return void
	 */
	public function record( $reason, $from_feed = false, $ts = 0 ) {
		$reason = substr( sanitize_key( (string) $reason ), 0, 64 );
		if ( '' === $reason ) {
			return;
		}
		$key    = self::month_key( $ts ? $ts : Counter::now() );
		$months = $this->all();
		if ( ! isset( $months[ $key ] ) ) {
			$months[ $key ] = array(
				'r'    => array(),
				'feed' => 0,
			);
		}
		$months[ $key ]['r'][ $reason ] = ( isset( $months[ $key ]['r'][ $reason ] ) ? $months[ $key ]['r'][ $reason ] : 0 ) + 1;
		if ( $from_feed || self::FEED_REASON === $reason ) {
			++$months[ $key ]['feed'];
		}
		krsort( $months );
		update_option( self::OPTION, array_slice( $months, 0, self::KEEP, true ), false );
	}

	/**
	 * Totals for one month: per group, the shared-feed slot, and the overall total.
	 *
	 * @param string $key YYYY-MM.
	 * @return array{groups: array<string, int>, feed: int, total: int}
	 */
	public function summary( $key ) {
		$months = $this->all();
		$groups = array_fill_keys( self::groups(), 0 );
		$total  = 0;
		$m      = isset( $months[ $key ] ) ? $months[ $key ] : array(
			'r'    => array(),
			'feed' => 0,
		);
		foreach ( $m['r'] as $reason => $n ) {
			$groups[ self::group_of( $reason ) ] += $n;
			$total                               += $n;
		}
		return array(
			'groups' => $groups,
			'feed'   => (int) $m['feed'],
			'total'  => $total,
		);
	}

	/**
	 * Key of the month before one (YYYY-MM).
	 *
	 * @param string $key YYYY-MM.
	 * @return string
	 */
	public static function previous_key( $key ) {
		$y = (int) substr( (string) $key, 0, 4 );
		$m = (int) substr( (string) $key, 5, 2 ) - 1;
		if ( $m < 1 ) {
			$m = 12;
			--$y;
		}
		return sprintf( '%04d-%02d', $y, $m );
	}

	/**
	 * Clear (uninstall).
	 *
	 * @return void
	 */
	public static function clear() {
		delete_option( self::OPTION );
	}
}
