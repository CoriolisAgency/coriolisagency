<?php
/**
 * FFLFW-DC-LIST-SEED (download model, Chief 2026-11-24 1:38 PM ET): the store downloads the
 * DigitalOcean, Linode and Vultr RFC 8805 geofeeds itself, straight from the providers, once a day
 * on WP-Cron, and caches the IPv4 ranges in one option. Nothing ships in the zip and the Coriolis
 * proxy never relays the feeds. Page requests only read the cache, never fetch.
 *
 * Fail open: a failed, empty or unparseable download keeps that provider's last good list; a
 * provider list older than STALE_AFTER is not used (it blocks no one) but stays stored until a good
 * download replaces it.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

defined( 'ABSPATH' ) || exit;

/**
 * Daily download and cache of the provider geofeeds.
 */
class Datacenter_Feed {

	const CRON        = 'fflfw_dc_feed_refresh';
	const OPTION      = 'fflfw_dc_feed';
	const STALE_AFTER = 259200; // 3 days: three missed daily refreshes.
	const TIMEOUT     = 5;
	const MAX_BYTES   = 2097152;

	/**
	 * Test clock.
	 *
	 * @var int|null
	 */
	public static $now;

	/**
	 * Provider feeds (RFC 8805 geofeeds the providers publish for their own networks).
	 *
	 * @return array<string, string>
	 */
	public static function providers() {
		return array(
			'digitalocean' => 'https://digitalocean.com/geo/google.csv',
			'linode'       => 'https://geoip.linode.com/',
			'vultr'        => 'https://geofeed.constant.com/?text',
		);
	}

	/**
	 * Current time.
	 *
	 * @return int
	 */
	private static function now() {
		return null !== self::$now ? (int) self::$now : time();
	}

	/**
	 * Hooks: the daily schedule and the refresh.
	 *
	 * @return void
	 */
	public function register() {
		add_action( self::CRON, array( $this, 'refresh' ) );
		add_action( 'init', array( $this, 'schedule' ) );
	}

	/**
	 * Whether the store should download the feeds: ACTIVE DEFENSE switched on and the datacenter
	 * check on (it is on by default).
	 *
	 * @return bool
	 */
	public static function wanted() {
		$cfg = new Config();
		return true === (bool) $cfg->get( 'enabled' ) && $cfg->on( 'datacenter' );
	}

	/**
	 * Keep one daily refresh scheduled while wanted, and none otherwise.
	 *
	 * @return void
	 */
	public function schedule() {
		try {
			$next = wp_next_scheduled( self::CRON );
			if ( self::wanted() ) {
				if ( ! $next ) {
					wp_schedule_event( self::now() + 60, 'daily', self::CRON );
				}
			} elseif ( $next ) {
				wp_clear_scheduled_hook( self::CRON );
			}
		} catch ( \Throwable $e ) {
			return;
		}
	}

	/**
	 * Deactivation: leave no event behind.
	 *
	 * @return void
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( self::CRON );
	}

	/**
	 * Stored cache: provider id => array( pairs => flat start/end ints, at => last good download, count
	 * => prefixes, error => last error, tried => last attempt ).
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public static function state() {
		$s = get_option( self::OPTION, array() );
		return is_array( $s ) ? $s : array();
	}

	/**
	 * Download every provider feed (cron only). Any error keeps the provider's last good list.
	 *
	 * @return void
	 */
	public function refresh() {
		try {
			if ( ! self::wanted() ) {
				return;
			}
			$state = self::state();
			foreach ( self::providers() as $id => $url ) {
				$row          = isset( $state[ $id ] ) && is_array( $state[ $id ] ) ? $state[ $id ] : array();
				$row['tried'] = self::now();
				$cidrs        = null;
				$error        = '';
				try {
					$res = wp_remote_get(
						$url,
						array(
							'timeout'             => self::TIMEOUT,
							'redirection'         => 2,
							'limit_response_size' => self::MAX_BYTES,
							'user-agent'          => 'FFL-Firewall-Datacenter-List',
						)
					);
					if ( is_wp_error( $res ) ) {
						$error = 'request_failed';
					} elseif ( 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
						$error = 'http_' . (int) wp_remote_retrieve_response_code( $res );
					} else {
						$cidrs = self::parse( (string) wp_remote_retrieve_body( $res ) );
						if ( ! $cidrs ) {
							$error = 'empty';
						}
					}
				} catch ( \Throwable $e ) {
					$error = 'error';
				}
				if ( '' === $error && $cidrs ) {
					$row['pairs'] = Datacenter_List::from_cidrs( $cidrs );
					$row['count'] = count( $cidrs );
					$row['at']    = self::now();
				}
				$row['error'] = $error;
				$state[ $id ] = $row;
			}
			update_option( self::OPTION, $state, false );
		} catch ( \Throwable $e ) {
			return;
		}
	}

	/**
	 * IPv4 prefixes from an RFC 8805 geofeed or a plain prefix list: the first comma field of each
	 * line that is not a comment. IPv6 and anything malformed are skipped.
	 *
	 * @param string $text Feed body.
	 * @return array<int, string>
	 */
	public static function parse( $text ) {
		$out = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $line ) {
			$line = trim( $line );
			if ( '' === $line || '#' === $line[0] ) {
				continue;
			}
			$field = trim( strtok( $line, ',' ) );
			$parts = explode( '/', $field, 2 );
			if ( null === Ip::v4_int( $parts[0] ) ) {
				continue;
			}
			if ( isset( $parts[1] ) && ( ! ctype_digit( $parts[1] ) || (int) $parts[1] > 32 ) ) {
				continue;
			}
			$out[ $field ] = true;
		}
		return array_keys( $out );
	}

	/**
	 * Cached pairs from every provider whose last good download is current, merged. Stale or missing
	 * lists add nothing.
	 *
	 * @return array<int, int>
	 */
	public static function pairs() {
		$all = array();
		try {
			foreach ( self::state() as $row ) {
				if ( ! is_array( $row ) || empty( $row['pairs'] ) || ! is_array( $row['pairs'] ) || empty( $row['at'] ) ) {
					continue;
				}
				if ( self::now() - (int) $row['at'] > self::STALE_AFTER ) {
					continue;
				}
				$all = $all ? Datacenter_List::merge( $all, $row['pairs'] ) : $row['pairs'];
			}
		} catch ( \Throwable $e ) {
			return array();
		}
		return $all;
	}
}