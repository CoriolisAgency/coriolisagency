<?php
/**
 * User agent and header checks.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

defined( 'ABSPATH' ) || exit;

/**
 * Turns away requests whose user agent and headers don't look like a real browser or a known
 * crawler. Returns a short reason code, or '' to let the request through.
 */
class Agent_Check {

	/**
	 * Substrings (lowercase) of scripting and automation clients.
	 *
	 * @return array<int, string>
	 */
	public static function blocked_agents() {
		$list = array(
			'python-requests',
			'python-urllib',
			'python-httpx',
			'aiohttp',
			'scrapy',
			'curl/',
			'wget/',
			'libwww-perl',
			'go-http-client',
			'java/',
			'apache-httpclient',
			'node-fetch',
			'axios/',
			'undici',
			'headlesschrome',
			'phantomjs',
			'selenium',
			'webdriver',
			'httrack',
			'httpclient',
		);
		$out  = apply_filters( 'fflfw_defense_blocked_agents', $list );
		return is_array( $out ) ? array_map( 'strtolower', array_map( 'strval', $out ) ) : $list;
	}

	/**
	 * Substrings (lowercase) of well-known search and link-preview crawlers. FFLFW-CRAWLER-GRACE: a
	 * match only skips the header check here, and only for bots Crawler_Verify cannot verify (link
	 * previewers). A crawler Crawler_Verify knows (Google, Bing, Yandex, Baidu, Yahoo and the rest)
	 * has to verify, and then passes every check (Guard::unless_crawler).
	 *
	 * @return array<int, string>
	 */
	public static function allowed_agents() {
		$list = array(
			'googlebot',
			'adsbot-google',
			'mediapartners-google',
			'storebot-google',
			'google-inspectiontool',
			'googleother',
			'bingbot',
			'bingpreview',
			'msnbot',
			'duckduckbot',
			'applebot',
			'yandexbot',
			'baiduspider',
			'slurp',
			'facebookexternalhit',
			'meta-externalagent',
			'twitterbot',
			'linkedinbot',
			'slackbot',
			'whatsapp',
			'pinterestbot',
			'telegrambot',
			'discordbot',
		);
		$out  = apply_filters( 'fflfw_defense_allowed_agents', $list );
		return is_array( $out ) ? array_map( 'strtolower', array_map( 'strval', $out ) ) : $list;
	}

	/**
	 * Whether the user agent is on the crawler allow list.
	 *
	 * @param Request $req Request.
	 * @return bool
	 */
	public static function is_allowed_crawler( Request $req ) {
		$ua = strtolower( $req->user_agent );
		foreach ( self::allowed_agents() as $token ) {
			if ( '' !== $token && false !== strpos( $ua, $token ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Check one request.
	 *
	 * @param Request $req Request.
	 * @return string Reason code, or '' for no problem.
	 */
	public function check( Request $req ) {
		$ua = strtolower( trim( $req->user_agent ) );
		if ( '' === $ua ) {
			return 'agent_empty';
		}
		foreach ( self::blocked_agents() as $token ) {
			if ( '' !== $token && false !== strpos( $ua, $token ) ) {
				return 'agent_automation';
			}
		}
		if ( 0 === strpos( $ua, 'mozilla/' ) ) {
			if ( '' === trim( $req->header( 'accept' ) ) ) {
				return 'headers_no_accept';
			}
			if ( '' === trim( $req->header( 'accept-language' ) ) && '' === trim( $req->header( 'accept-encoding' ) ) ) {
				return 'headers_incomplete';
			}
		}
		return '';
	}
}
