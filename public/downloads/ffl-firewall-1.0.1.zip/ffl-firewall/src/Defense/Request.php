<?php
/**
 * One incoming request, reduced to what the countermeasures look at.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

defined( 'ABSPATH' ) || exit;

/**
 * Request snapshot.
 */
class Request {

	/**
	 * Visitor address ('' when unknown).
	 *
	 * @var string
	 */
	public $ip = '';

	/**
	 * True when forwarding headers are present but the sender isn't a trusted proxy,
	 * so the visitor address can't be told.
	 *
	 * @var bool
	 */
	public $ip_unclear = false;

	/**
	 * User agent.
	 *
	 * @var string
	 */
	public $user_agent = '';

	/**
	 * Lowercase header name => value.
	 *
	 * @var array<string, string>
	 */
	public $headers = array();

	/**
	 * Method.
	 *
	 * @var string
	 */
	public $method = 'GET';

	/**
	 * Path only, no query string.
	 *
	 * @var string
	 */
	public $path = '';

	/**
	 * Query string (without the ?), up to 500 characters.
	 *
	 * @var string
	 */
	public $query = '';

	/**
	 * Form fields.
	 *
	 * @var array<string, mixed>
	 */
	public $post = array();

	/**
	 * Forwarding headers that carry a visitor address, in the order they are tried.
	 */
	const FORWARD_HEADERS = array( 'cf-connecting-ip', 'true-client-ip', 'x-real-ip', 'x-forwarded-for' );

	/**
	 * Build from server variables.
	 *
	 * @param array<string, mixed> $server          $_SERVER.
	 * @param array<string, mixed> $post            $_POST.
	 * @param array<int, string>   $trusted_proxies Proxies whose forwarding headers are believed.
	 * @return self
	 */
	public static function make( $server, $post = array(), $trusted_proxies = array() ) {
		$r = new self();
		foreach ( (array) $server as $k => $v ) {
			if ( ! is_string( $k ) || ! is_scalar( $v ) ) {
				continue;
			}
			if ( 0 === strpos( $k, 'HTTP_' ) ) {
				$r->headers[ strtolower( str_replace( '_', '-', substr( $k, 5 ) ) ) ] = (string) $v;
			} elseif ( 'CONTENT_TYPE' === $k ) {
				$r->headers['content-type'] = (string) $v;
			}
		}
		$r->user_agent = isset( $r->headers['user-agent'] ) ? substr( $r->headers['user-agent'], 0, 512 ) : '';
		$r->method     = isset( $server['REQUEST_METHOD'] ) ? strtoupper( (string) $server['REQUEST_METHOD'] ) : 'GET';
		$uri           = isset( $server['REQUEST_URI'] ) ? (string) $server['REQUEST_URI'] : '';
		$q             = strpos( $uri, '?' );
		$r->path       = substr( false === $q ? $uri : substr( $uri, 0, $q ), 0, 200 );
		$r->query      = false === $q ? '' : substr( $uri, $q + 1, 500 );
		$r->post       = is_array( $post ) ? $post : array();

		$remote = Ip::normalize( isset( $server['REMOTE_ADDR'] ) ? (string) $server['REMOTE_ADDR'] : '' );
		$r->ip  = $remote;

		$forwarded = array();
		foreach ( self::FORWARD_HEADERS as $name ) {
			if ( isset( $r->headers[ $name ] ) && '' !== trim( $r->headers[ $name ] ) ) {
				$forwarded[ $name ] = $r->headers[ $name ];
			}
		}
		if ( $forwarded && '' !== $remote ) {
			if ( Ip::in_list( $remote, $trusted_proxies ) ) {
				$client = '';
				foreach ( $forwarded as $value ) {
					$parts = array_reverse( array_map( 'trim', explode( ',', $value ) ) );
					foreach ( $parts as $part ) {
						$part = Ip::normalize( $part );
						if ( '' !== $part && ! Ip::in_list( $part, $trusted_proxies ) ) {
							$client = $part;
							break 2;
						}
					}
				}
				if ( '' !== $client ) {
					$r->ip = $client;
				} else {
					$r->ip_unclear = true;
				}
			} else {
				$r->ip_unclear = true;
			}
		}
		return $r;
	}

	/**
	 * Build from the current request. WordPress adds slashes to $_SERVER and $_POST (wp_magic_quotes),
	 * so they are unslashed first: a header such as sec-ch-ua-platform: "Windows" must reach the
	 * checks and the ACTIVE DEFENSE fingerprint as sent, not as \"Windows\" (FFLFW-FP-UNSLASH).
	 *
	 * @param array<int, string> $trusted_proxies Trusted proxies.
	 * @return self
	 */
	public static function from_globals( $trusted_proxies = array() ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- read-only inspection of the incoming request; each check cleans what it reads.
		return self::make( wp_unslash( $_SERVER ), wp_unslash( $_POST ), $trusted_proxies );
	}

	/**
	 * Whether the address can key a counter: known, public and not behind an unclear proxy.
	 *
	 * @return bool
	 */
	public function ip_usable() {
		return ! $this->ip_unclear && Ip::is_public( $this->ip );
	}

	/**
	 * One header, lowercase name.
	 *
	 * @param string $name Header name.
	 * @return string
	 */
	public function header( $name ) {
		return isset( $this->headers[ $name ] ) ? $this->headers[ $name ] : '';
	}
}
