<?php
/**
 * The dealer embed script: a saved site key (WP option only) and the script tag the plugin adds
 * when ACTIVE DEFENSE is switched on and a key is saved.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Defense;

defined( 'ABSPATH' ) || exit;

/**
 * Site key storage and script injection.
 */
class Embed {

	const OPTION = 'fflfw_defense_site_key';
	const URL_OPT = 'fflfw_defense_script_url';
	const HANDLE = 'fflfw-embed';
	const FOREIGN_OPT = 'fflfw_defense_foreign';

	/**
	 * Config.
	 *
	 * @var Config
	 */
	private $config;

	/**
	 * Constructor.
	 *
	 * @param Config $config Defense config (its master switch is the toggle).
	 */
	public function __construct( Config $config ) {
		$this->config = $config;
	}

	/**
	 * Add the hooks.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ) );
		add_filter( 'script_loader_tag', array( $this, 'tag' ), 10, 3 );
	}

	/**
	 * Clean a pasted site key: letters, digits, dot, dash and underscore, 8 to 128 characters.
	 * Anything else is empty (not saved).
	 *
	 * @param mixed $raw Pasted value.
	 * @return string
	 */
	public static function clean_key( $raw ) {
		$key = preg_replace( '/[^A-Za-z0-9_.\-]/', '', trim( (string) $raw ) );
		$key = substr( (string) $key, 0, 128 );
		return strlen( $key ) >= 8 ? $key : '';
	}

	/**
	 * Saved site key ('' when none).
	 *
	 * @return string
	 */
	public function site_key() {
		$key = get_option( self::OPTION, '' );
		return is_string( $key ) ? self::clean_key( $key ) : '';
	}

	/**
	 * Save the site key as a plain WP option. Nothing links a license to it.
	 *
	 * @param string $key Cleaned key ('' clears it).
	 * @return void
	 */
	public function save_key( $key ) {
		update_option( self::OPTION, self::clean_key( $key ), false );
	}

	/**
	 * Whether the script is added: switch on and a key saved.
	 *
	 * @return bool
	 */
	public function active() {
		return true === $this->config->get( 'enabled' ) && '' !== $this->site_key();
	}

	/**
	 * Script address. The plugin carries no address of its own: the proxy sends it with the last-seen
	 * answer and it is stored here (https only). Empty until the proxy has sent one.
	 *
	 * @return string
	 */
	public function script_url() {
		$url = get_option( self::URL_OPT, '' );
		$url = is_string( $url ) ? $url : '';
		$url = (string) apply_filters( 'fflfw_embed_script_url', $url );
		return self::valid_script_url( $url ) ? $url : '';
	}

	/**
	 * A clean script address: secure scheme, a plain host, a path ending in .js, no query or fragment.
	 *
	 * @param string $url Address.
	 * @return bool
	 */
	private static function valid_script_url( $url ) {
		if ( ! is_string( $url ) || strlen( $url ) > 200 || 0 !== strpos( $url, 'https' . ':' . '//' ) ) {
			return false;
		}
		$p = wp_parse_url( $url );
		return is_array( $p )
			&& isset( $p['host'], $p['path'] )
			&& ! isset( $p['query'] ) && ! isset( $p['fragment'] ) && ! isset( $p['user'] ) && ! isset( $p['pass'] )
			&& 1 === preg_match( '/^[A-Za-z0-9.\-]+$/', $p['host'] )
			&& 1 === preg_match( '/^[A-Za-z0-9_.\/\-]*\.js$/', $p['path'] );
	}

	/**
	 * Store the script address the proxy sent (ignored unless it is a clean https .js address).
	 *
	 * @param mixed $url Address.
	 * @return void
	 */
	public function save_script_url( $url ) {
		$url = is_string( $url ) ? trim( $url ) : '';
		if ( self::valid_script_url( $url ) ) {
			update_option( self::URL_OPT, $url, false );
		}
	}

	/**
	 * Find a dealer embed tag that is not ours in page HTML: a script whose address ends in
	 * /embed.js, carries a site key, and lacks our data-fflfw="1" marker.
	 *
	 * @param string $html Page HTML.
	 * @return array{key: string}|null Key of the first foreign tag, or null when there is none.
	 */
	public static function find_foreign( $html ) {
		if ( ! is_string( $html ) || ! preg_match_all( '/<script\b[^>]*>/i', $html, $m ) ) {
			return null;
		}
		foreach ( $m[0] as $tag ) {
			if ( preg_match( '/\bdata-fflfw\s*=\s*["\']1["\']/i', $tag ) ) {
				continue;
			}
			if ( ! preg_match( '/\bsrc\s*=\s*(["\'])(.*?)\1/is', $tag, $s ) ) {
				continue;
			}
			$path = (string) preg_replace( '/[?#].*$/', '', $s[2] );
			if ( 1 !== preg_match( '#/embed\.js$#i', $path ) ) {
				continue;
			}
			if ( preg_match( '/\bdata-site-key\s*=\s*(["\'])(.*?)\1/is', $tag, $k ) || preg_match( '/\bdata-key\s*=\s*(["\'])(.*?)\1/is', $tag, $k ) ) {
				return array( 'key' => self::clean_key( html_entity_decode( $k[2] ) ) );
			}
		}
		return null;
	}

	/**
	 * Fetch the store home page once and remember whether a foreign dealer embed is on it. A failed
	 * fetch leaves the last answer alone. Runs on save, on "Check for script" and on the hourly refresh.
	 *
	 * @return void
	 */
	public function detect_foreign() {
		try {
			$html = apply_filters( 'fflfw_embed_home_html', null );
			if ( null === $html ) {
				$res = wp_remote_get( home_url( '/' ), array( 'timeout' => 5, 'redirection' => 3, 'user-agent' => 'FFL-Firewall-Script-Check' ) );
				if ( is_wp_error( $res ) || 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
					return;
				}
				$html = wp_remote_retrieve_body( $res );
			}
			$found = self::find_foreign( $html );
			update_option(
				self::FOREIGN_OPT,
				array( 'found' => null !== $found, 'key' => null !== $found ? $found['key'] : '', 'checked' => time() ),
				false
			);
		} catch ( \Throwable $e ) {
			return;
		}
	}

	/**
	 * Forget the stored foreign-embed answer.
	 *
	 * @return void
	 */
	public function clear_foreign() {
		delete_option( self::FOREIGN_OPT );
	}

	/**
	 * Whether a dealer embed that is not ours was found on the home page at the last check.
	 *
	 * @return bool
	 */
	public function foreign_present() {
		$f = get_option( self::FOREIGN_OPT, array() );
		return is_array( $f ) && ! empty( $f['found'] );
	}

	/**
	 * Whether a foreign embed is present and its site key differs from the saved one.
	 *
	 * @return bool
	 */
	public function key_mismatch() {
		if ( ! $this->foreign_present() ) {
			return false;
		}
		$f = get_option( self::FOREIGN_OPT, array() );
		return ( isset( $f['key'] ) ? (string) $f['key'] : '' ) !== $this->site_key();
	}
	/**
	 * Enqueue the script on store pages.
	 *
	 * @return void
	 */
	public function enqueue() {
		try {
			$url = $this->script_url();
			if ( ! $this->active() || '' === $url || $this->foreign_present() ) {
				return;
			}
			wp_enqueue_script( self::HANDLE, $url, array(), null, array( 'strategy' => 'defer', 'in_footer' => true ) ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion -- Remote script, version is not ours.
		} catch ( \Throwable $e ) {
			return;
		}
	}

	/**
	 * Add data-fflfw (so we can tell our tag from a dealer-pasted one) and data-site-key to our script tag.
	 *
	 * @param string $tag    Script tag HTML.
	 * @param string $handle Script handle.
	 * @param string $src    Script URL.
	 * @return string
	 */
	public function tag( $tag, $handle = '', $src = '' ) {
		if ( self::HANDLE !== $handle || ! $this->active() ) {
			return $tag;
		}
		$attr = ' data-fflfw="1" data-site-key="' . esc_attr( $this->site_key() ) . '"';
		return preg_replace( '/^<script\b/', '<script' . $attr, (string) $tag, 1 );
	}
}