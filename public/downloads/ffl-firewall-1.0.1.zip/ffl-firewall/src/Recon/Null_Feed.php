<?php
/**
 * The default feed: nothing.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Recon;

defined( 'ABSPATH' ) || exit;

/**
 * Returns no findings. RECON v1 reads WordPress.org version data and the site's configuration only.
 */
class Null_Feed implements Feed {

	/**
	 * No findings.
	 *
	 * @param array<string, mixed> $facts Site facts.
	 * @return array<int, array<string, string>>
	 */
	public function findings( array $facts ) {
		return array();
	}
}