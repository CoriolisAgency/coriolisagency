<?php
/**
 * Facts from a live WordPress site: WordPress.org version data held in the update transients, plus
 * a few configuration reads. Read-only: nothing here changes the site.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Recon;

defined( 'ABSPATH' ) || exit;

/**
 * Reads WordPress.
 */
class Wp_Facts implements Facts {

	/**
	 * Refresh WordPress's own update data. These are WordPress's standard version checks against
	 * WordPress.org, which respect WordPress's own cache window.
	 *
	 * @return void
	 */
	public function refresh() {
		try {
			if ( defined( 'ABSPATH' ) && ! function_exists( 'wp_update_plugins' ) && is_readable( ABSPATH . 'wp-admin/includes/update.php' ) ) {
				require_once ABSPATH . 'wp-admin/includes/update.php';
			}
			if ( function_exists( 'wp_version_check' ) ) {
				wp_version_check();
			}
			if ( function_exists( 'wp_update_plugins' ) ) {
				wp_update_plugins();
			}
			if ( function_exists( 'wp_update_themes' ) ) {
				wp_update_themes();
			}
		} catch ( \Throwable $e ) {
			return;
		}
	}

	/**
	 * Collect the facts.
	 *
	 * @return array<string, mixed>
	 */
	public function collect() {
		return array(
			'core'    => $this->core(),
			'php'     => $this->php(),
			'plugins' => $this->plugins(),
			'themes'  => $this->themes(),
			'config'  => $this->config(),
		);
	}

	/**
	 * WordPress core version data.
	 *
	 * @return array<string, mixed>
	 */
	private function core() {
		global $wp_version;
		$current = isset( $wp_version ) ? (string) $wp_version : '';
		$update  = false;
		$latest  = $current;
		$data    = function_exists( 'get_site_transient' ) ? get_site_transient( 'update_core' ) : false;
		if ( is_object( $data ) && ! empty( $data->updates ) && is_array( $data->updates ) ) {
			$first = $data->updates[0];
			if ( is_object( $first ) && isset( $first->response ) && 'upgrade' === $first->response ) {
				$update = true;
				$latest = isset( $first->current ) ? (string) $first->current : $latest;
			}
		}
		return array(
			'update'  => $update,
			'current' => $current,
			'latest'  => $latest,
		);
	}

	/**
	 * PHP version, as judged by WordPress.org's PHP version data when it is available.
	 *
	 * @return array<string, mixed>
	 */
	private function php() {
		$secure     = null;
		$acceptable = null;
		try {
			if ( ! function_exists( 'wp_check_php_version' ) && defined( 'ABSPATH' ) && is_readable( ABSPATH . 'wp-admin/includes/misc.php' ) ) {
				require_once ABSPATH . 'wp-admin/includes/misc.php';
			}
			if ( function_exists( 'wp_check_php_version' ) ) {
				$check = wp_check_php_version();
				if ( is_array( $check ) ) {
					$secure     = isset( $check['is_secure'] ) ? (bool) $check['is_secure'] : null;
					$acceptable = isset( $check['is_acceptable'] ) ? (bool) $check['is_acceptable'] : null;
				}
			}
		} catch ( \Throwable $e ) {
			$secure = null;
		}
		return array(
			'version'    => PHP_VERSION,
			'secure'     => $secure,
			'acceptable' => $acceptable,
		);
	}

	/**
	 * Installed plugins with any available update.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function plugins() {
		if ( ! function_exists( 'get_plugins' ) && defined( 'ABSPATH' ) && is_readable( ABSPATH . 'wp-admin/includes/plugin.php' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		if ( ! function_exists( 'get_plugins' ) ) {
			return array();
		}
		$updates = function_exists( 'get_site_transient' ) ? get_site_transient( 'update_plugins' ) : false;
		$pending = is_object( $updates ) && ! empty( $updates->response ) && is_array( $updates->response ) ? $updates->response : array();
		$out     = array();
		foreach ( (array) get_plugins() as $file => $data ) {
			$new   = isset( $pending[ $file ] ) && is_object( $pending[ $file ] ) && isset( $pending[ $file ]->new_version ) ? (string) $pending[ $file ]->new_version : '';
			$out[] = array(
				'file'    => (string) $file,
				'name'    => isset( $data['Name'] ) ? (string) $data['Name'] : (string) $file,
				'version' => isset( $data['Version'] ) ? (string) $data['Version'] : '',
				'active'  => function_exists( 'is_plugin_active' ) ? (bool) is_plugin_active( $file ) : false,
				'update'  => $new,
			);
		}
		return $out;
	}

	/**
	 * Installed themes with any available update.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function themes() {
		if ( ! function_exists( 'wp_get_themes' ) ) {
			return array();
		}
		$updates = function_exists( 'get_site_transient' ) ? get_site_transient( 'update_themes' ) : false;
		$pending = is_object( $updates ) && ! empty( $updates->response ) && is_array( $updates->response ) ? $updates->response : array();
		$active  = function_exists( 'get_stylesheet' ) ? (string) get_stylesheet() : '';
		$parent  = function_exists( 'get_template' ) ? (string) get_template() : '';
		$out     = array();
		foreach ( (array) wp_get_themes() as $slug => $theme ) {
			$new   = isset( $pending[ $slug ] ) && is_array( $pending[ $slug ] ) && isset( $pending[ $slug ]['new_version'] ) ? (string) $pending[ $slug ]['new_version'] : '';
			$out[] = array(
				'slug'    => (string) $slug,
				'name'    => is_object( $theme ) && method_exists( $theme, 'get' ) ? (string) $theme->get( 'Name' ) : (string) $slug,
				'version' => is_object( $theme ) && method_exists( $theme, 'get' ) ? (string) $theme->get( 'Version' ) : '',
				'active'  => (string) $slug === $active || (string) $slug === $parent,
				'update'  => $new,
			);
		}
		return $out;
	}

	/**
	 * Site configuration reads.
	 *
	 * @return array<string, mixed>
	 */
	private function config() {
		$home  = function_exists( 'home_url' ) ? (string) home_url() : '';
		$debug = defined( 'WP_DEBUG' ) && WP_DEBUG && ( ! defined( 'WP_DEBUG_DISPLAY' ) || WP_DEBUG_DISPLAY );
		return array(
			'https'              => 0 === strpos( $home, 'https://' ),
			'file_edit_disabled' => defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT,
			'debug_display'      => (bool) $debug,
			'open_registration'  => (bool) get_option( 'users_can_register', 0 ),
			'default_role'       => (string) get_option( 'default_role', 'subscriber' ),
			'has_admin_user'     => function_exists( 'get_user_by' ) && false !== get_user_by( 'login', 'admin' ),
		);
	}
}