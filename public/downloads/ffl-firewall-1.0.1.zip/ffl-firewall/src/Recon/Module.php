<?php
/**
 * RECON: report-only store hardening scan. Weekly and Run scan need an active
 * license. One first scan after install needs no license (FFLFW-101-03).
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Recon;

use FFL_Firewall\Admin\Ad_Interstitial;
use FFL_Firewall\Settings\Repository;

defined( 'ABSPATH' ) || exit;

/**
 * Scheduling, license gate, first-scan allowance and report storage.
 */
class Module {

	const OPTION       = 'fflfw_recon';
	const HOOK         = 'fflfw_recon_weekly';
	const FIRST_OPTION = 'fflfw_recon_first';
	const FIRST_HOOK   = 'fflfw_recon_first';
	const TOKEN_OPTION = 'fflfw_recon_first_token';

	/**
	 * Settings.
	 *
	 * @var Repository
	 */
	private $settings;

	/**
	 * Facts source override (tests).
	 *
	 * @var Facts|null
	 */
	private $facts;

	/**
	 * Feed override (tests).
	 *
	 * @var Feed|null
	 */
	private $feed;

	/**
	 * Constructor.
	 *
	 * @param Repository $settings Settings.
	 * @param Facts|null $facts    Facts source.
	 * @param Feed|null  $feed     Feed.
	 */
	public function __construct( Repository $settings, $facts = null, $feed = null ) {
		$this->settings = $settings;
		$this->facts    = $facts instanceof Facts ? $facts : null;
		$this->feed     = $feed instanceof Feed ? $feed : null;
	}

	/**
	 * Queue the local first scan 60 seconds after activation.
	 *
	 * @return void
	 */
	public static function activate() {
		$module = new self( new Repository() );
		$module->ensure_token();
		$module->schedule_first();
	}

	/**
	 * Drop the first-scan hook. Does not clear the proxy allowance.
	 *
	 * @return void
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( self::FIRST_HOOK );
	}

	/**
	 * Hook weekly and first-scan runs, and the 1.0.0 update path.
	 *
	 * @return void
	 */
	public function register() {
		add_action( self::HOOK, array( $this, 'run_weekly' ) );
		add_action( self::FIRST_HOOK, array( $this, 'run_first' ) );
		add_action( 'init', array( $this, 'ensure_schedule' ) );
		add_action( 'admin_init', array( $this, 'maybe_bootstrap_first' ) );
	}

	/**
	 * Keep one weekly event scheduled.
	 *
	 * @return void
	 */
	public function ensure_schedule() {
		if ( false === wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + DAY_IN_SECONDS, 'weekly', self::HOOK );
		}
	}

	/**
	 * On a 1.0.0 update, queue the first scan the same way activation does.
	 * When the first-open screen is not required, run the lookup with no extra click.
	 *
	 * @return void
	 */
	public function maybe_bootstrap_first() {
		if ( $this->licensed() ) {
			return;
		}
		$this->ensure_token();
		if ( $this->first_available() ) {
			$this->schedule_first();
		}
		if ( ! Ad_Interstitial::needed() ) {
			$this->maybe_run_first();
		}
	}

	/**
	 * After the first-open screen is answered, run the first scan or the pending lookup.
	 *
	 * @return void
	 */
	public function after_ack() {
		$this->maybe_run_first();
	}

	/**
	 * Whether a license is active (the condition for weekly and Run scan).
	 *
	 * @return bool
	 */
	public function licensed() {
		return 'active' === $this->settings->license_status();
	}

	/**
	 * Whether this site may still run the one unlicensed first scan.
	 *
	 * @return bool
	 */
	public function first_available() {
		if ( $this->licensed() ) {
			return false;
		}
		if ( null !== $this->last_report() ) {
			return false;
		}
		$row = get_option( self::FIRST_OPTION, null );
		return ! is_array( $row ) || empty( $row['at'] );
	}

	/**
	 * Whether a first report is waiting for the one unlicensed known-issue lookup.
	 *
	 * @return bool
	 */
	public function first_lookup_pending() {
		if ( $this->licensed() || null === $this->last_report() ) {
			return false;
		}
		$row = get_option( self::FIRST_OPTION, null );
		if ( ! is_array( $row ) ) {
			return true;
		}
		$lookup = isset( $row['lookup'] ) ? (string) $row['lookup'] : '';
		return 'pending' === $lookup || '' === $lookup;
	}

	/**
	 * The one-time first-scan token (64 lowercase hex characters).
	 *
	 * @return string
	 */
	public function ensure_token() {
		$token = get_option( self::TOKEN_OPTION, '' );
		if ( is_string( $token ) && 1 === preg_match( '/^[a-f0-9]{64}$/', $token ) ) {
			return $token;
		}
		$token = bin2hex( random_bytes( 32 ) );
		update_option( self::TOKEN_OPTION, $token, false );
		return $token;
	}

	/**
	 * Queue the local first scan at time()+60 if nothing is scheduled.
	 *
	 * @return void
	 */
	public function schedule_first() {
		if ( false === wp_next_scheduled( self::FIRST_HOOK ) ) {
			wp_schedule_single_event( time() + 60, self::FIRST_HOOK );
		}
	}

	/**
	 * The feed in use. The default returns nothing; the fflfw_recon_feed filter is the seam.
	 *
	 * @return Feed
	 */
	private function feed() {
		if ( $this->feed instanceof Feed ) {
			return $this->feed;
		}
		$feed = apply_filters( 'fflfw_recon_feed', new Null_Feed() );
		return $feed instanceof Feed ? $feed : new Null_Feed();
	}

	/**
	 * Scan and store the report.
	 *
	 * Weekly and manual runs need an active license. A first run needs first_available().
	 *
	 * @param string $trigger 'manual', 'weekly' or 'first'.
	 * @return array<string, mixed>|null The stored report.
	 */
	public function scan( $trigger = 'manual' ) {
		$first = 'first' === $trigger;
		if ( $first ) {
			if ( ! $this->first_available() ) {
				return null;
			}
		} elseif ( ! $this->licensed() ) {
			return null;
		}
		try {
			$facts    = $this->facts instanceof Facts ? $this->facts : new Wp_Facts();
			$feed     = $this->feed();
			$scanner  = new Scanner( $facts, $feed );
			$findings = $scanner->run( true );
		} catch ( \Throwable $e ) {
			return null;
		}
		if ( $first ) {
			$kind = 'first';
		} elseif ( 'weekly' === $trigger ) {
			$kind = 'weekly';
		} else {
			$kind = 'manual';
		}
		$report = array(
			'ran_at'   => time(),
			'trigger'  => $kind,
			'findings' => $findings,
		);
		// RECON known issues: a feed with a known() section (Proxy_Feed) adds it to every report, manual or weekly.
		if ( method_exists( $feed, 'known' ) ) {
			try {
				if ( $first ) {
					$report['known'] = $feed->known( $facts->collect(), $report['ran_at'], 'first' );
					$this->mark_first( $report['known'] );
				} else {
					$report['known'] = $feed->known( $facts->collect(), $report['ran_at'] );
				}
			} catch ( \Throwable $e ) {
				unset( $e ); // The built-in findings are kept either way.
				if ( $first ) {
					$this->mark_first( array( 'status' => 'unavailable' ) );
				}
			}
		} elseif ( $first ) {
			$this->mark_first( array( 'status' => 'unavailable' ) );
		}
		update_option( self::OPTION, $report, false );
		return $report;
	}

	/**
	 * WP-Cron: local first scan, plus the lookup once the first-open screen is not required.
	 *
	 * @return void
	 */
	public function run_first() {
		if ( $this->first_available() ) {
			$this->scan_local_first();
		}
		if ( ! Ad_Interstitial::needed() ) {
			$this->maybe_run_first();
		}
	}

	/**
	 * Weekly cron callback.
	 *
	 * @return void
	 */
	public function run_weekly() {
		$this->scan( 'weekly' );
	}

	/**
	 * Store a local first report with the lookup left pending (R11).
	 *
	 * @return array<string, mixed>|null
	 */
	public function scan_local_first() {
		if ( ! $this->first_available() ) {
			return $this->last_report();
		}
		try {
			$facts    = $this->facts instanceof Facts ? $this->facts : new Wp_Facts();
			$feed     = $this->feed();
			$scanner  = new Scanner( $facts, $feed );
			$findings = $scanner->run( true );
		} catch ( \Throwable $e ) {
			return null;
		}
		$report = array(
			'ran_at'   => time(),
			'trigger'  => 'first',
			'findings' => $findings,
		);
		update_option( self::OPTION, $report, false );
		update_option(
			self::FIRST_OPTION,
			array(
				'at'     => $report['ran_at'],
				'lookup' => 'pending',
			),
			false
		);
		return $report;
	}

	/**
	 * Run the first scan, or only the pending known-issue lookup, when allowed.
	 *
	 * @return void
	 */
	public function maybe_run_first() {
		if ( $this->licensed() ) {
			return;
		}
		if ( $this->first_available() ) {
			$this->scan( 'first' );
			return;
		}
		if ( $this->first_lookup_pending() ) {
			$this->run_first_lookup();
		}
	}

	/**
	 * Merge the one unlicensed known-issue lookup into the existing first report.
	 *
	 * @return void
	 */
	public function run_first_lookup() {
		$report = $this->last_report();
		if ( null === $report || ! $this->first_lookup_pending() ) {
			return;
		}
		$feed = $this->feed();
		if ( ! method_exists( $feed, 'known' ) ) {
			$this->mark_first( array( 'status' => 'unavailable' ) );
			return;
		}
		try {
			$facts           = $this->facts instanceof Facts ? $this->facts : new Wp_Facts();
			$report['known'] = $feed->known( $facts->collect(), time(), 'first' );
		} catch ( \Throwable $e ) {
			unset( $e );
			$report['known'] = array(
				'status'          => 'unavailable',
				'checked_at'      => time(),
				'feed_updated_at' => 0,
				'plugin_count'    => 0,
				'rows'            => array(),
				'copyrights'      => array(),
			);
		}
		update_option( self::OPTION, $report, false );
		$this->mark_first( $report['known'] );
	}

	/**
	 * Record the first-scan option. A failed lookup stays pending so it can be retried
	 * without burning a successful allowance; first_used and ok are terminal.
	 *
	 * @param array<string, mixed> $known Known section.
	 * @return void
	 */
	private function mark_first( $known ) {
		$status = isset( $known['status'] ) ? (string) $known['status'] : '';
		if ( 'ok' === $status ) {
			$lookup = 'done';
		} elseif ( 'first_used' === $status ) {
			$lookup = 'first_used';
		} else {
			$lookup = 'pending';
		}
		$existing = get_option( self::FIRST_OPTION, null );
		$at       = is_array( $existing ) && ! empty( $existing['at'] ) ? (int) $existing['at'] : time();
		update_option(
			self::FIRST_OPTION,
			array(
				'at'     => $at,
				'lookup' => $lookup,
			),
			false
		);
	}

	/**
	 * The last stored report, or null.
	 *
	 * @return array<string, mixed>|null
	 */
	public function last_report() {
		$report = get_option( self::OPTION, null );
		if ( ! is_array( $report ) || empty( $report['ran_at'] ) || ! isset( $report['findings'] ) || ! is_array( $report['findings'] ) ) {
			return null;
		}
		return $report;
	}

	/**
	 * Timestamp of the next weekly run, or 0.
	 *
	 * @return int
	 */
	public function next_run() {
		$next = wp_next_scheduled( self::HOOK );
		return false === $next ? 0 : (int) $next;
	}
}
