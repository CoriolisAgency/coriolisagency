<?php
/**
 * The seam for a third-party known-issue feed (not wired in this version).
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Recon;

defined( 'ABSPATH' ) || exit;

/**
 * A source of known-issue findings for the installed software.
 *
 * RECON ships with Null_Feed, which returns nothing. A later change can supply a real feed
 * through the fflfw_recon_feed filter (or by swapping the default in Module) without touching the
 * scanner, the report storage or the admin tab. Any feed lookup must be made by a Coriolis-run
 * service, never with a feed credential held in this plugin, and must never put a feed vendor's
 * name in the dealer UI.
 */
interface Feed {

	/**
	 * Known issues for the installed software.
	 *
	 * @param array<string, mixed> $facts The same facts array the scanner reads (see Facts::collect()).
	 * @return array<int, array<string, string>> Findings, each with id, severity (a Scanner::SEV_* value), title and detail.
	 */
	public function findings( array $facts );
}