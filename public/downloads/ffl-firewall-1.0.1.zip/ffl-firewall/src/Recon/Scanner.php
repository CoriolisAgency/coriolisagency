<?php
/**
 * The RECON checks. Pure: facts in, findings out. Nothing here changes the site.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Recon;

defined( 'ABSPATH' ) || exit;

/**
 * Turns site facts into a ranked list of findings.
 */
class Scanner {

	const SEV_FIRST = 'fix_first';
	const SEV_SOON  = 'fix_soon';
	const SEV_LOOK  = 'worth_a_look';

	/**
	 * Facts source.
	 *
	 * @var Facts
	 */
	private $facts;

	/**
	 * Optional known-issue feed.
	 *
	 * @var Feed
	 */
	private $feed;

	/**
	 * Constructor.
	 *
	 * @param Facts $facts Facts source.
	 * @param Feed  $feed  Feed (Null_Feed by default).
	 */
	public function __construct( Facts $facts, Feed $feed ) {
		$this->facts = $facts;
		$this->feed  = $feed;
	}

	/**
	 * Severity order, most urgent first.
	 *
	 * @return array<int, string>
	 */
	public static function severities() {
		return array( self::SEV_FIRST, self::SEV_SOON, self::SEV_LOOK );
	}

	/**
	 * Run a scan.
	 *
	 * @param bool $refresh Ask WordPress.org for fresh version data first.
	 * @return array<int, array<string, string>> Findings, most urgent first.
	 */
	public function run( $refresh = true ) {
		if ( $refresh ) {
			$this->facts->refresh();
		}
		$facts    = $this->facts->collect();
		$findings = array_merge( $this->version_findings( $facts ), $this->config_findings( $facts ) );

		try {
			foreach ( (array) $this->feed->findings( $facts ) as $extra ) {
				$clean = self::normalize( $extra );
				if ( null !== $clean ) {
					$findings[] = $clean;
				}
			}
		} catch ( \Throwable $e ) {
			unset( $e ); // A feed that fails leaves the built-in findings as they are.
		}

		$rank = array_flip( self::severities() );
		usort(
			$findings,
			function ( $a, $b ) use ( $rank ) {
				return $rank[ $a['severity'] ] <=> $rank[ $b['severity'] ];
			}
		);
		return $findings;
	}

	/**
	 * Accept only well-formed findings from outside the built-in checks.
	 *
	 * @param mixed $row Candidate finding.
	 * @return array<string, string>|null
	 */
	public static function normalize( $row ) {
		if ( ! is_array( $row ) || empty( $row['id'] ) || empty( $row['title'] ) ) {
			return null;
		}
		$severity = isset( $row['severity'] ) ? (string) $row['severity'] : '';
		if ( ! in_array( $severity, self::severities(), true ) ) {
			$severity = self::SEV_LOOK;
		}
		return array(
			'id'       => substr( preg_replace( '/[^A-Za-z0-9_.:\-]/', '', (string) $row['id'] ), 0, 80 ),
			'severity' => $severity,
			'title'    => substr( trim( strip_tags( (string) $row['title'] ) ), 0, 200 ),
			'detail'   => isset( $row['detail'] ) ? substr( trim( strip_tags( (string) $row['detail'] ) ), 0, 400 ) : '',
		);
	}

	/**
	 * Build one finding.
	 *
	 * @param string $id       Stable id.
	 * @param string $severity Severity.
	 * @param string $title    Title.
	 * @param string $detail   Detail.
	 * @return array<string, string>
	 */
	private static function f( $id, $severity, $title, $detail = '' ) {
		return array(
			'id'       => $id,
			'severity' => $severity,
			'title'    => $title,
			'detail'   => $detail,
		);
	}

	/**
	 * Findings from WordPress.org version data.
	 *
	 * @param array<string, mixed> $facts Facts.
	 * @return array<int, array<string, string>>
	 */
	private function version_findings( array $facts ) {
		$out = array();

		$core = isset( $facts['core'] ) && is_array( $facts['core'] ) ? $facts['core'] : array();
		if ( ! empty( $core['update'] ) ) {
			/* translators: 1: installed WordPress version, 2: newest version */
			$out[] = self::f( 'core-update', self::SEV_SOON, sprintf( __( 'WordPress %1$s has an update to %2$s', 'ffl-firewall' ), (string) $core['current'], (string) $core['latest'] ), __( 'Update WordPress from Dashboard > Updates, after a backup.', 'ffl-firewall' ) );
		}

		$php = isset( $facts['php'] ) && is_array( $facts['php'] ) ? $facts['php'] : array();
		if ( isset( $php['secure'] ) && false === $php['secure'] ) {
			/* translators: %s: PHP version */
			$out[] = self::f( 'php-unsupported', self::SEV_FIRST, sprintf( __( 'PHP %s is no longer receiving security fixes', 'ffl-firewall' ), (string) $php['version'] ), __( 'Ask your host to move the store to a newer PHP version.', 'ffl-firewall' ) );
		} elseif ( isset( $php['acceptable'] ) && false === $php['acceptable'] ) {
			/* translators: %s: PHP version */
			$out[] = self::f( 'php-old', self::SEV_LOOK, sprintf( __( 'PHP %s is older than WordPress recommends', 'ffl-firewall' ), (string) $php['version'] ), __( 'Ask your host about moving the store to a newer PHP version.', 'ffl-firewall' ) );
		}

		foreach ( (array) ( isset( $facts['plugins'] ) ? $facts['plugins'] : array() ) as $plugin ) {
			$name = (string) $plugin['name'];
			if ( '' !== (string) $plugin['update'] ) {
				if ( ! empty( $plugin['active'] ) ) {
					/* translators: 1: plugin name, 2: installed version, 3: newest version */
					$out[] = self::f( 'plugin-update:' . $plugin['file'], self::SEV_SOON, sprintf( __( '%1$s %2$s has an update to %3$s', 'ffl-firewall' ), $name, (string) $plugin['version'], (string) $plugin['update'] ), __( 'Update it from the Plugins screen, after a backup.', 'ffl-firewall' ) );
				} else {
					/* translators: 1: plugin name, 2: newest version */
					$out[] = self::f( 'plugin-update-inactive:' . $plugin['file'], self::SEV_LOOK, sprintf( __( '%1$s is switched off and has an update to %2$s', 'ffl-firewall' ), $name, (string) $plugin['update'] ), __( 'Update it or delete it. Plugins you do not use are best removed.', 'ffl-firewall' ) );
				}
			} elseif ( empty( $plugin['active'] ) ) {
				/* translators: %s: plugin name */
				$out[] = self::f( 'plugin-inactive:' . $plugin['file'], self::SEV_LOOK, sprintf( __( '%s is installed but switched off', 'ffl-firewall' ), $name ), __( 'Delete plugins you do not use.', 'ffl-firewall' ) );
			}
		}

		foreach ( (array) ( isset( $facts['themes'] ) ? $facts['themes'] : array() ) as $theme ) {
			if ( '' === (string) $theme['update'] ) {
				continue;
			}
			if ( ! empty( $theme['active'] ) ) {
				/* translators: 1: theme name, 2: installed version, 3: newest version */
				$out[] = self::f( 'theme-update:' . $theme['slug'], self::SEV_SOON, sprintf( __( 'Theme %1$s %2$s has an update to %3$s', 'ffl-firewall' ), (string) $theme['name'], (string) $theme['version'], (string) $theme['update'] ), __( 'Update it from the Themes screen, after a backup.', 'ffl-firewall' ) );
			} else {
				/* translators: 1: theme name, 2: newest version */
				$out[] = self::f( 'theme-update-inactive:' . $theme['slug'], self::SEV_LOOK, sprintf( __( 'Theme %1$s is switched off and has an update to %2$s', 'ffl-firewall' ), (string) $theme['name'], (string) $theme['update'] ), __( 'Update it or delete it.', 'ffl-firewall' ) );
			}
		}

		return $out;
	}

	/**
	 * Configuration gaps.
	 *
	 * @param array<string, mixed> $facts Facts.
	 * @return array<int, array<string, string>>
	 */
	private function config_findings( array $facts ) {
		$out = array();
		$c   = isset( $facts['config'] ) && is_array( $facts['config'] ) ? $facts['config'] : array();

		if ( isset( $c['https'] ) && false === $c['https'] ) {
			$out[] = self::f( 'no-https', self::SEV_FIRST, __( "Your store address doesn't use HTTPS", 'ffl-firewall' ), __( 'Ask your host to install a certificate, then switch the WordPress and site addresses to https.', 'ffl-firewall' ) );
		}
		if ( ! empty( $c['open_registration'] ) && ! in_array( (string) $c['default_role'], array( 'subscriber', 'customer' ), true ) ) {
			/* translators: %s: role name */
			$out[] = self::f( 'registration-role', self::SEV_FIRST, sprintf( __( 'Anyone can register, and new accounts get the %s role', 'ffl-firewall' ), (string) $c['default_role'] ), __( 'In Settings > General, set New User Default Role to Subscriber or Customer.', 'ffl-firewall' ) );
		}
		if ( ! empty( $c['debug_display'] ) ) {
			$out[] = self::f( 'debug-display', self::SEV_SOON, __( 'Error messages are shown on your pages', 'ffl-firewall' ), __( 'Ask your developer to set WP_DEBUG_DISPLAY to false on the live store.', 'ffl-firewall' ) );
		}
		if ( ! empty( $c['has_admin_user'] ) ) {
			$out[] = self::f( 'admin-username', self::SEV_LOOK, __( 'A user is named "admin"', 'ffl-firewall' ), __( 'That name is the first one bots guess. Create a user with a different name and remove this one.', 'ffl-firewall' ) );
		}
		if ( isset( $c['file_edit_disabled'] ) && false === $c['file_edit_disabled'] ) {
			$out[] = self::f( 'file-edit', self::SEV_LOOK, __( 'The plugin and theme file editor is on', 'ffl-firewall' ), __( 'Ask your developer to set DISALLOW_FILE_EDIT to true in wp-config.php.', 'ffl-firewall' ) );
		}

		return $out;
	}
}