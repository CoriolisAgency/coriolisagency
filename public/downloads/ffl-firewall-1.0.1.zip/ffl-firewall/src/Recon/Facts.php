<?php
/**
 * Where the scanner gets its facts about the site.
 *
 * @package FFL_Firewall
 */

namespace FFL_Firewall\Recon;

defined( 'ABSPATH' ) || exit;

/**
 * A source of site facts (WordPress in production, a fake in tests).
 */
interface Facts {

	/**
	 * Ask WordPress.org for fresh version data where that is allowed (a scan the dealer started or
	 * the weekly run). Never throws.
	 *
	 * @return void
	 */
	public function refresh();

	/**
	 * Collect the facts:
	 * - core:    update (bool), current (string), latest (string)
	 * - php:     version (string), secure (bool|null), acceptable (bool|null)
	 * - plugins: list of file, name, version, active (bool), update (new version or '')
	 * - themes:  list of slug, name, version, active (bool), update (new version or '')
	 * - config:  https, file_edit_disabled, debug_display, open_registration, default_role, has_admin_user
	 *
	 * @return array<string, mixed>
	 */
	public function collect();
}