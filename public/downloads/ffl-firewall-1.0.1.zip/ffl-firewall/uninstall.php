<?php
/**
 * Uninstall handler for FFL Firewall.
 *
 * @package FFL_Firewall
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'fflfw_settings' );
delete_option( 'fflfw_license_status' );
delete_option( 'fflfw_log' );
delete_option( 'fflfw_defense' );
delete_option( 'fflfw_defense_log' );
delete_option( 'fflfw_defense_monthly' );
delete_option( 'fflfw_defense_site_key' );
delete_option( 'fflfw_defense_site_key_auto' );
delete_option( 'fflfw_defense_consent' );
delete_option( 'fflfw_defense_seen' );
delete_option( 'fflfw_defense_script_url' );
delete_option( 'fflfw_defense_foreign' );
delete_option( 'fflfw_recon' );
delete_option( 'fflfw_reputation' );
delete_option( 'fflfw_reputation_state' );
delete_option( 'fflfw_reputation_buffer' );
delete_option( 'fflfw_reputation_feed' );
delete_option( 'fflfw_reputation_unblocks' );
delete_option( 'fflfw_license_recheck' );
delete_option( 'fflfw_ad_signals' );
delete_option( 'fflfw_ad_state' );
delete_option( 'fflfw_ad_autoblock' );
delete_option( 'fflfw_ad_unblocked' );
delete_option( 'fflfw_ad_secret' );
delete_option( 'fflfw_ad_ack' );
delete_option( 'fflfw_recon_first' );
delete_option( 'fflfw_recon_first_token' );
wp_clear_scheduled_hook( 'fflfw_license_recheck' );
wp_clear_scheduled_hook( 'fflfw_defense_refresh_seen' );
wp_clear_scheduled_hook( 'fflfw_recon_weekly' );
wp_clear_scheduled_hook( 'fflfw_recon_first' );
wp_clear_scheduled_hook( 'fflfw_reputation_flush' );
wp_clear_scheduled_hook( 'fflfw_reputation_pull' );
